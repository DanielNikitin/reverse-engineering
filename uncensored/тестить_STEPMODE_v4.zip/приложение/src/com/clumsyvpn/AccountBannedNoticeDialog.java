package com.clumsyvpn;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Уведомление «Ваш аккаунт был заблокирован» — показывается, когда ключ,
 * которым сейчас пользуется человек, перестал работать из-за бана ДРУГОГО
 * (например, старого) логина на этом же устройстве/ключе. Сам текущий
 * аккаунт при этом не забанен напрямую — поэтому вместо полноэкранного
 * BannedActivity показывается компактное уведомление в общем стиле
 * приложения (см. KeyNoticeDialog), с данными именно ЗАБЛОКИРОВАННОГО
 * аккаунта (его логин/ID), а не текущего.
 *
 * Работает одинаково для ключей, выданных ботом, и ключей, созданных
 * администратором вручную — источник тут не важен, сервер уже определил,
 * что ключ заморожен.
 */
public class AccountBannedNoticeDialog {

    public interface Callback {
        void onOk();
    }

    private static final int ACCENT = 0xFFFF1E4E;

    public static void show(final Context ctx, final String bannedLogin, final String bannedUserId,
                             final String reason, final Callback callback) {
        final Dialog d = new Dialog(ctx);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(ctx, 22), dp(ctx, 22), dp(ctx, 22), dp(ctx, 18));
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(ctx, 16));
            bg.setColor(0xFF0C1014);
            bg.setStroke(1, ACCENT);
            root.setBackground(bg);
        }

        TextView tvIcon = new TextView(ctx);
        tvIcon.setText("\uD83D\uDEAB");
        tvIcon.setTextSize(36);
        tvIcon.setGravity(Gravity.CENTER);
        root.addView(tvIcon);
        space(root, ctx, 10);

        TextView tvTitle = new TextView(ctx);
        tvTitle.setText("\u0412\u0430\u0448 \u0430\u043A\u043A\u0430\u0443\u043D\u0442 \u0431\u044B\u043B \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D.");
        tvTitle.setTextSize(15f);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);
        space(root, ctx, 16);

        // Карточка с логином/ID заблокированного аккаунта
        LinearLayout infoCard = new LinearLayout(ctx);
        infoCard.setOrientation(LinearLayout.VERTICAL);
        infoCard.setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12));
        {
            GradientDrawable ib = new GradientDrawable();
            ib.setShape(GradientDrawable.RECTANGLE);
            ib.setCornerRadius(dp(ctx, 10));
            ib.setColor(0xFF11171D);
            ib.setStroke(1, 0xFF17202A);
            infoCard.setBackground(ib);
        }
        infoCard.addView(buildRow(ctx, "\u041B\u043E\u0433\u0438\u043D:", bannedLogin == null || bannedLogin.isEmpty() ? "\u2014" : bannedLogin));
        space(infoCard, ctx, 8);
        infoCard.addView(buildRow(ctx, "ID:", bannedUserId == null || bannedUserId.isEmpty() ? "\u2014" : bannedUserId));
        root.addView(infoCard);

        if (reason != null && !reason.trim().isEmpty()) {
            space(root, ctx, 16);

            TextView tvReasonLabel = new TextView(ctx);
            tvReasonLabel.setText("\u041F\u0440\u0438\u0447\u0438\u043D\u0430 \u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u043A\u0438:");
            tvReasonLabel.setTextSize(11);
            tvReasonLabel.setTextColor(0xFF6C7885);
            tvReasonLabel.setGravity(Gravity.CENTER);
            root.addView(tvReasonLabel);

            space(root, ctx, 4);

            TextView tvReason = new TextView(ctx);
            tvReason.setText(reason.trim());
            tvReason.setTextSize(15);
            tvReason.setTextColor(ACCENT);
            tvReason.setTypeface(null, Typeface.BOLD);
            tvReason.setGravity(Gravity.CENTER);
            root.addView(tvReason);
        }

        space(root, ctx, 16);
        TextView tvFootnote = new TextView(ctx);
        tvFootnote.setText("\u042D\u0442\u043E\u0442 \u043A\u043B\u044E\u0447 \u0431\u043E\u043B\u044C\u0448\u0435 \u043D\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442, \u0442\u0430\u043A \u043A\u0430\u043A \u0430\u043A\u043A\u0430\u0443\u043D\u0442 \u0431\u044B\u043B \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D. " +
            "\u0412\u043E\u0439\u0434\u0438\u0442\u0435 \u0432 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0430\u043A\u043A\u0430\u0443\u043D\u0442, \u0447\u0442\u043E\u0431\u044B \u043F\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u0443\u044E \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E.");
        tvFootnote.setTextSize(12);
        tvFootnote.setTextColor(0xFF8A95A1);
        tvFootnote.setGravity(Gravity.CENTER);
        root.addView(tvFootnote);

        space(root, ctx, 20);

        TextView btnOk = new TextView(ctx);
        btnOk.setText("\u0425\u043E\u0440\u043E\u0448\u043E");
        btnOk.setTextSize(13);
        btnOk.setTextColor(0xFF000000);
        btnOk.setTypeface(null, Typeface.BOLD);
        btnOk.setGravity(Gravity.CENTER);
        btnOk.setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12));
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(ctx, 10));
            bg.setColor(ACCENT);
            btnOk.setBackground(bg);
        }
        btnOk.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        btnOk.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                if (callback != null) callback.onOk();
            }
        });
        root.addView(btnOk);

        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            int screenW = ctx.getResources().getDisplayMetrics().widthPixels;
            lp.width  = (int)(screenW * 0.88f);
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
        }
        d.show();
    }

    private static LinearLayout buildRow(Context ctx, String label, String value) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvLabel = new TextView(ctx);
        tvLabel.setText(label);
        tvLabel.setTextSize(12);
        tvLabel.setTextColor(0xFF6C7885);
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(dp(ctx, 56), ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(tvLabel);

        TextView tvValue = new TextView(ctx);
        tvValue.setText(value);
        tvValue.setTextSize(13);
        tvValue.setTextColor(0xFFFFFFFF);
        tvValue.setTypeface(null, Typeface.BOLD);
        row.addView(tvValue);

        return row;
    }

    private static void space(LinearLayout parent, Context ctx, int dpVal) {
        View v = new View(ctx);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, dpVal)));
        parent.addView(v);
    }

    private static int dp(Context ctx, int val) {
        return (int)(val * ctx.getResources().getDisplayMetrics().density + 0.5f);
    }
}
