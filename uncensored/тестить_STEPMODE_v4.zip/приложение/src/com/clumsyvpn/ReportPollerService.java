package com.clumsyvpn;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.IBinder;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Фоновый сервис опроса репортов.
 * Каждые 10 секунд проверяет /admin/reports/unseen-count.
 * Если появились новые — рассылает broadcast ACTION_NEW_REPORTS.
 * Если админ не в приложении — накапливает счётчик в SharedPreferences.
 */
public class ReportPollerService extends Service {

    public static final String ACTION_NEW_REPORTS =
            "com.clumsyvpn.ACTION_NEW_REPORTS";
    public static final String EXTRA_COUNT = "report_count";

    // Ключи SharedPreferences — те же, что в AdminPanelActivity
    static final String PREFS_ADMIN         = "admin_notif_prefs";
    static final String KEY_PENDING_REPORTS = "pending_reports_count";
    static final String KEY_LAST_SEEN_COUNT = "last_seen_report_count";

    private static final long POLL_INTERVAL_MS = 10_000L;

    private Handler  handler;
    private Runnable pollRunnable;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler();
        pollRunnable = new Runnable() {
            public void run() {
                pollReports();
                handler.postDelayed(this, POLL_INTERVAL_MS);
            }
        };
        handler.postDelayed(pollRunnable, 3000);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (handler != null && pollRunnable != null) {
            handler.removeCallbacks(pollRunnable);
        }
    }

    private void pollReports() {
        SharedPreferences authPrefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        final String login    = authPrefs.getString(AuthActivity.KEY_LOGIN, "");
        final String password = authPrefs.getString(AuthActivity.KEY_PASSWORD, "");

        // Только для администратора
        if (!"admin".equals(login)) return;

        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"adminLogin\":\"" + esc(login) +
                                  "\",\"adminPassword\":\"" + esc(password) + "\"}";
                    String resp = httpPost(AuthActivity.SERVER_URL +
                                          "/admin/reports/unseen-count", body);
                    if (resp == null) return;

                    org.json.JSONObject j = new org.json.JSONObject(resp);
                    int count = j.optInt("count", 0);

                    SharedPreferences prefs =
                            getSharedPreferences(PREFS_ADMIN, MODE_PRIVATE);
                    int lastCount = prefs.getInt(KEY_LAST_SEEN_COUNT, 0);

                    if (count > lastCount) {
                        int newArrived = count - lastCount;
                        prefs.edit().putInt(KEY_LAST_SEEN_COUNT, count).apply();

                        // Накапливаем pending (будет показано при следующем входе
                        // если AdminPanelActivity не поглотит уведомление)
                        int existing = prefs.getInt(KEY_PENDING_REPORTS, 0);
                        prefs.edit().putInt(KEY_PENDING_REPORTS, existing + newArrived).apply();

                        // Рассылаем broadcast — все зарегистрированные активити покажут баннер
                        Intent broadcast = new Intent(ACTION_NEW_REPORTS);
                        broadcast.putExtra(EXTRA_COUNT, count);
                        sendBroadcast(broadcast);
                    }
                } catch (Exception ignored) {}
            }
        }).start();
    }

    private String httpPost(String urlStr, String jsonBody) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        OutputStream os = conn.getOutputStream();
        os.write(jsonBody.getBytes("UTF-8"));
        os.close();
        int code = conn.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
            code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(),
            "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        conn.disconnect();
        return sb.toString();
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
