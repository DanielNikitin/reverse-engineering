package com.clumsyvpn;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Единое кастомное окно (не на весь экран, в стиле приложения) для уведомлений
 * "ключ деактивирован" и "ключ удалён", чтобы оба выглядели одинаково.
 *
 * Структура (сверху вниз):
 *   иконка
 *   ПРИЧИНА (крупно, выделено цветом акцента)
 *   пояснительная фраза ("Ваш ключ деактивирован администратором." /
 *       "Ключ был удалён администратором.")
 *   доп. примечание (например про приватный канал) — опционально
 *   кнопка "Хорошо"
 */
public class KeyNoticeDialog {

    public interface Callback {
        void onOk();
    }

    public static void show(final Context ctx, final String icon, final String reason,
                              final String explanation, final String footnote,
                              final int accentColor, final Callback callback) {
        final Dialog d = new Dialog(ctx);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(ctx, 22), dp(ctx, 22), dp(ctx, 22), dp(ctx, 18));
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(ctx, 16));
            bg.setColor(0xFF0C1014);
            bg.setStroke(1, accentColor);
            root.setBackground(bg);
        }

        // Пояснительная фраза — сверху
        TextView tvTitle = new TextView(ctx);
        tvTitle.setText(explanation);
        tvTitle.setTextSize(14f);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        // Причина — снизу, выделена цветом акцента
        if (reason != null && !reason.trim().isEmpty()) {
            space(root, ctx, 14);

            TextView tvReasonLabel = new TextView(ctx);
            tvReasonLabel.setText("Причина:");
            tvReasonLabel.setTextSize(11);
            tvReasonLabel.setTextColor(0xFF6C7885);
            tvReasonLabel.setGravity(Gravity.CENTER);
            root.addView(tvReasonLabel);

            space(root, ctx, 4);

            TextView tvReason = new TextView(ctx);
            tvReason.setText(reason.trim());
            tvReason.setTextSize(15);
            tvReason.setTextColor(accentColor);
            tvReason.setTypeface(null, Typeface.BOLD);
            tvReason.setGravity(Gravity.CENTER);
            root.addView(tvReason);
        }

        if (footnote != null && !footnote.trim().isEmpty()) {
            space(root, ctx, 10);
            TextView tvFootnote = new TextView(ctx);
            tvFootnote.setText(footnote.trim());
            tvFootnote.setTextSize(12);
            tvFootnote.setTextColor(0xFF8A95A1);
            tvFootnote.setGravity(Gravity.CENTER);
            root.addView(tvFootnote);
        }

        space(root, ctx, 20);

        TextView btnOk = new TextView(ctx);
        btnOk.setText("Хорошо");
        btnOk.setTextSize(13);
        btnOk.setTextColor(0xFF000000);
        btnOk.setTypeface(null, Typeface.BOLD);
        btnOk.setGravity(Gravity.CENTER);
        btnOk.setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12));
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(ctx, 10));
            bg.setColor(accentColor);
            btnOk.setBackground(bg);
        }
        btnOk.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        btnOk.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                if (callback != null) callback.onOk();
            }
        });
        root.addView(btnOk);

        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            int screenW = ctx.getResources().getDisplayMetrics().widthPixels;
            lp.width  = (int)(screenW * 0.88f);
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
        }
        d.show();
    }

    private static void space(LinearLayout parent, Context ctx, int dpVal) {
        View v = new View(ctx);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, dpVal)));
        parent.addView(v);
    }

    private static int dp(Context ctx, int val) {
        return (int)(val * ctx.getResources().getDisplayMetrics().density + 0.5f);
    }
}
