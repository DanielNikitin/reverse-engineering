package com.clumsyvpn;

import android.content.Context;

/**
 * Окно уведомления "ключ был удалён администратором". Делегирует отрисовку
 * в общий KeyNoticeDialog, чтобы дизайн совпадал с уведомлением о деактивации.
 *
 * Usage:
 *   KeyDeletedDialog.show(activity, reason, new KeyDeletedDialog.Callback() {
 *       public void onOk() { ... }
 *   });
 */
public class KeyDeletedDialog {

    public interface Callback {
        void onOk();
    }

    public static void show(final Context ctx, final String reason, final Callback callback) {
        KeyNoticeDialog.show(
            ctx,
            "🔒",
            reason,
            "Ключ был удалён администратором.",
            "Причина возможно будет опубликована в приватном канале в разделе «Информация».",
            0xFFFF1E4E,
            callback == null ? null : new KeyNoticeDialog.Callback() {
                public void onOk() { callback.onOk(); }
            }
        );
    }
}
