package com.clumsyvpn;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashSet;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * ConfigsActivity — экран управления конфигурациями (NEON V9.1).
 *
 * Обновления:
 *   - Кастомный неоновый диалог создания конфига (название/описание)
 *   - Использует bg_dialog_neon, bg_input, btn_neon_green, btn_neon_outline
 */
public class ConfigsActivity extends Activity {

    // ── Шифрование AES-256-GCM ────────────────────────────────────────────
    // Пароль намеренно разбит и собирается в рантайме — не виден в dex-строках
    private static final String ENC_PASS;
    static {
        char[] p = {'C','l','u','m','s','y','V','P','N','_',
                    '0','x','F','F','_','S','3','c','r','3','t',
                    '!','#','@','%','&','K','3','y','~','2','6'};
        ENC_PASS = new String(p);
    }
    private static final int ENC_ITER     = 65536;   // PBKDF2 iterations
    private static final int ENC_KEY_LEN  = 256;     // bits
    private static final int ENC_SALT_LEN = 16;      // bytes
    private static final int ENC_IV_LEN   = 12;      // bytes, GCM standard
    private static final int ENC_TAG_BITS = 128;     // GCM auth tag length
    static class Config {
        String name;
        String description;
        int    serverDelay;
        int    serverLoss;
        int    clientDelay;
        int    clientLoss;
        int    duration;
        boolean installed;

        // afterTimerMode: 0 = Сброс, 1 = Удалить, 2 = Задержка
        int afterTimerMode;
        int afterTimerDelayMs;
        int afterTimerDurationSec;

        // VPN, привязанный к конфигу (имя из VpnPickerActivity)
        String vpn;

        // Шифровка при экспорте: если true — файл шифруется при отправке
        boolean sendEncrypted;
        // Импортирован как зашифрованный: если true — редактирование заблокировано
        boolean importedEncrypted;

        // Фильтр по размеру пакета (в байтах)
        // filterMode: 0=Все, 1=В диап., 2=Вне диап.
        int clientSizeFilterMode;  // 0/1/2
        int clientSizeMin;         // байты
        int clientSizeMax;         // байты
        int serverSizeFilterMode;
        int serverSizeMin;
        int serverSizeMax;

        // ── Пошаговый режим ──────────────────────────────────────────────
        // configMode: 0 = Обычный, 1 = Пошаговый
        int configMode;
        // stepsAfterMode: 0 = Сброс (работает только шаг 1), 1 = Следующий шаг (цикл по всем шагам)
        int stepsAfterMode;
        ArrayList<Step> steps;

        Config(String n, String d) {
            name = n; description = d;
            serverDelay = 0; serverLoss = 0;
            clientDelay = 0; clientLoss = 0;
            duration = 0;
            afterTimerMode = 0;
            afterTimerDelayMs = 0;
            afterTimerDurationSec = 3;
            installed = false;
            vpn = "";
            sendEncrypted = false;
            importedEncrypted = false;
            clientSizeFilterMode = 0;
            clientSizeMin = 0;
            clientSizeMax = 1500;
            serverSizeFilterMode = 0;
            serverSizeMin = 0;
            serverSizeMax = 1500;

            configMode = 0;
            stepsAfterMode = 0;
            steps = new ArrayList<Step>();
        }
    }

    /**
     * Один шаг «Пошагового режима».
     * Повторяет набор сетевых параметров обычного конфига + собственное время работы.
     */
    static class Step {
        // Клиентские пакеты
        int clientDelay;              // ms
        int clientLoss;                // %
        int clientBufferMode;          // 0=Обычный,1=Слив,2=Сброс,3=Удалить

        // Серверные пакеты
        int serverDelay;               // ms
        int serverLoss;                // %
        int serverBufferMode;          // 0=Обычный,1=Слив,2=Сброс,3=Удалить

        // Фильтр по размеру пакета
        int clientSizeFilterMode;      // 0=Все,1=В диап.,2=Вне диап.
        int clientSizeMin;
        int clientSizeMax;
        int serverSizeFilterMode;
        int serverSizeMin;
        int serverSizeMax;

        // Время до следующего шага (мс), формат как в обычном конфиге
        int duration;

        Step() {
            clientDelay = 0; clientLoss = 0; clientBufferMode = 0;
            serverDelay = 0; serverLoss = 0; serverBufferMode = 0;
            clientSizeFilterMode = 0; clientSizeMin = 0; clientSizeMax = 1500;
            serverSizeFilterMode = 0; serverSizeMin = 0; serverSizeMax = 1500;
            duration = 0;
        }

        Step copy() {
            Step s = new Step();
            s.clientDelay = clientDelay; s.clientLoss = clientLoss; s.clientBufferMode = clientBufferMode;
            s.serverDelay = serverDelay; s.serverLoss = serverLoss; s.serverBufferMode = serverBufferMode;
            s.clientSizeFilterMode = clientSizeFilterMode; s.clientSizeMin = clientSizeMin; s.clientSizeMax = clientSizeMax;
            s.serverSizeFilterMode = serverSizeFilterMode; s.serverSizeMin = serverSizeMin; s.serverSizeMax = serverSizeMax;
            s.duration = duration;
            return s;
        }
    }

    static ArrayList<Config> configs = new ArrayList<Config>();

    // ── Views ─────────────────────────────────────────────────────────────
    private LinearLayout listContainer;
    private TextView     tvEmpty;

    // ── Режим отправки конфигов ───────────────────────────────────────────
    private boolean sendMode = false;
    private final HashSet<Integer> selected = new HashSet<Integer>();
    private LinearLayout panelDefault;  // "ЗАГРУЗИТЬ" / "ОТПРАВИТЬ КОНФИГ" / "+ СОЗДАТЬ КОНФИГ"
    private LinearLayout panelSend;     // "Отправить" / "Отмена" во время выбора

    private AccountStatusMonitor accountStatusMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        accountStatusMonitor = new AccountStatusMonitor(this);
        loadConfigs();
        setContentView(buildLayout());
        refreshList();
    }

    private View buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF030507);
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));

        root.addView(buildHeader());
        root.addView(divider());
        root.addView(buildScrollArea());
        root.addView(buildBottomPanel());
        return root;
    }

    private View buildHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(14), 0, dp(18), 0);
        h.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(64)));

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(26);
        back.setTypeface(null, Typeface.BOLD);
        back.setTextColor(0xFF00FF9D);
        back.setGravity(Gravity.CENTER);
        back.setBackgroundResource(R.drawable.bg_header_icon);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(44), dp(44));
        back.setLayoutParams(blp);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });

        TextView title = new TextView(this);
        title.setText("КОНФИГУРАЦИИ");
        title.setTextSize(15);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.22f);
        title.setGravity(Gravity.CENTER);
        title.setShadowLayer(10, 0, 0, 0xFFFF1E4E);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        tlp.leftMargin = dp(12);
        title.setLayoutParams(tlp);

        // Невидимый spacer справа для центровки
        View rightSpacer = new View(this);
        rightSpacer.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));

        h.addView(back);
        h.addView(title);
        h.addView(rightSpacer);
        return h;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(0xFF1A2430);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(1)));
        return v;
    }

    private View buildScrollArea() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(18), dp(18), dp(12));
        content.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        tvEmpty = new TextView(this);
        tvEmpty.setText("// КОНФИГУРАЦИЙ НЕТ\nсоздай или загрузи свою первую");
        tvEmpty.setTextSize(13);
        tvEmpty.setTextColor(0xFF6C7885);
        tvEmpty.setLetterSpacing(0.1f);
        tvEmpty.setTypeface(Typeface.MONOSPACE);
        tvEmpty.setGravity(Gravity.CENTER);
        tvEmpty.setLineSpacing(dp(4), 1f);
        tvEmpty.setPadding(dp(20), dp(60), dp(20), dp(60));
        tvEmpty.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        listContainer.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        content.addView(tvEmpty);
        content.addView(listContainer);
        sv.addView(content);
        return sv;
    }

    private View buildBottomPanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(10), dp(18), dp(18));
        panel.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        // ── Дефолтная панель (ЗАГРУЗИТЬ / ОТПРАВИТЬ / СОЗДАТЬ) ──
        panelDefault = new LinearLayout(this);
        panelDefault.setOrientation(LinearLayout.VERTICAL);
        panelDefault.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        // Ряд: "ЗАГРУЗИТЬ КОНФИГ" | "ОТПРАВИТЬ КОНФИГ"
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams trp = new LinearLayout.LayoutParams(MATCH, dp(54));
        trp.bottomMargin = dp(10);
        topRow.setLayoutParams(trp);

        Button btnLoad = new Button(this);
        btnLoad.setText("ЗАГРУЗИТЬ");
        btnLoad.setTextSize(12);
        btnLoad.setLetterSpacing(0.20f);
        btnLoad.setTypeface(null, Typeface.BOLD);
        btnLoad.setTextColor(0xFFB8C4D0);
        btnLoad.setBackgroundResource(R.drawable.btn_neon_outline);
        btnLoad.setStateListAnimator(null);
        btnLoad.setPadding(dp(4), 0, dp(4), 0);
        LinearLayout.LayoutParams lLp = new LinearLayout.LayoutParams(0, MATCH, 1f);
        lLp.rightMargin = dp(8);
        btnLoad.setLayoutParams(lLp);
        btnLoad.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openConfigPicker();
            }
        });

        Button btnSendCfg = new Button(this);
        btnSendCfg.setText("ОТПРАВИТЬ");
        btnSendCfg.setTextSize(12);
        btnSendCfg.setLetterSpacing(0.20f);
        btnSendCfg.setTypeface(null, Typeface.BOLD);
        btnSendCfg.setTextColor(0xFF00FF9D);
        btnSendCfg.setBackgroundResource(R.drawable.btn_neon_outline);
        btnSendCfg.setStateListAnimator(null);
        btnSendCfg.setShadowLayer(8, 0, 0, 0xFF00FF9D);
        btnSendCfg.setPadding(dp(4), 0, dp(4), 0);
        btnSendCfg.setLayoutParams(new LinearLayout.LayoutParams(0, MATCH, 1f));
        btnSendCfg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (configs.isEmpty()) {
                    Toast.makeText(ConfigsActivity.this,
                        "Нет конфигов для отправки", Toast.LENGTH_SHORT).show();
                    return;
                }
                enterSendMode();
            }
        });

        topRow.addView(btnLoad);
        topRow.addView(btnSendCfg);

        Button btnCreate = new Button(this);
        btnCreate.setText("+ СОЗДАТЬ КОНФИГ");
        btnCreate.setTextSize(15);
        btnCreate.setLetterSpacing(0.24f);
        btnCreate.setTypeface(null, Typeface.BOLD);
        btnCreate.setTextColor(0xFF001A0E);
        btnCreate.setBackgroundResource(R.drawable.btn_neon_green);
        btnCreate.setStateListAnimator(null);
        btnCreate.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(58)));
        btnCreate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showConfigDialog(null); }
        });

        panelDefault.addView(topRow);
        panelDefault.addView(btnCreate);

        // ── Панель режима отправки (Отправить / Отмена) ──
        panelSend = new LinearLayout(this);
        panelSend.setOrientation(LinearLayout.HORIZONTAL);
        panelSend.setVisibility(View.GONE);
        panelSend.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        Button btnCancel = new Button(this);
        btnCancel.setText("ОТМЕНА");
        btnCancel.setTextSize(14);
        btnCancel.setLetterSpacing(0.22f);
        btnCancel.setTypeface(null, Typeface.BOLD);
        btnCancel.setTextColor(0xFFB8C4D0);
        btnCancel.setBackgroundResource(R.drawable.btn_neon_outline);
        btnCancel.setStateListAnimator(null);
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(0, dp(58), 1f);
        cLp.rightMargin = dp(10);
        btnCancel.setLayoutParams(cLp);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { exitSendMode(); }
        });

        Button btnSend = new Button(this);
        btnSend.setText("ОТПРАВИТЬ");
        btnSend.setTextSize(14);
        btnSend.setLetterSpacing(0.24f);
        btnSend.setTypeface(null, Typeface.BOLD);
        btnSend.setTextColor(0xFF001A0E);
        btnSend.setBackgroundResource(R.drawable.btn_neon_green);
        btnSend.setStateListAnimator(null);
        btnSend.setLayoutParams(new LinearLayout.LayoutParams(0, dp(58), 1.2f));
        btnSend.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (selected.isEmpty()) {
                    Toast.makeText(ConfigsActivity.this,
                        "Выберите хотя бы один конфиг", Toast.LENGTH_SHORT).show();
                    return;
                }
                showSendPreviewDialog();
            }
        });

        panelSend.addView(btnCancel);
        panelSend.addView(btnSend);

        panel.addView(panelDefault);
        panel.addView(panelSend);
        return panel;
    }

    /** Включает режим выбора конфигов для отправки */
    private void enterSendMode() {
        sendMode = true;
        selected.clear();
        if (panelDefault != null) panelDefault.setVisibility(View.GONE);
        if (panelSend    != null) panelSend.setVisibility(View.VISIBLE);
        refreshList();
    }

    /** Выключает режим выбора */
    private void exitSendMode() {
        sendMode = false;
        selected.clear();
        if (panelDefault != null) panelDefault.setVisibility(View.VISIBLE);
        if (panelSend    != null) panelSend.setVisibility(View.GONE);
        refreshList();
    }

    // ════════════════════════════════════════════════════════════════════
    //  КАСТОМНЫЙ НЕОНОВЫЙ ДИАЛОГ — Создание конфига (Шаг 1)
    // ════════════════════════════════════════════════════════════════════
    private void showConfigDialog(final Config existing) {
        final boolean isNew = (existing == null);

        if (!isNew) {
            int idx = configs.indexOf(existing);
            if (idx >= 0) {
                if (existing.configMode == 1) openStepMode(idx);
                else openConfigSettings(idx);
            }
            return;
        }

        final Dialog dlg = new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        // Корневой контейнер диалога (с отступом от краёв экрана)
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundResource(R.drawable.bg_dialog_neon);
        outer.setPadding(dp(22), dp(22), dp(22), dp(20));

        // Заголовок: "СОЗДАТЬ КОНФИГ" + неоновая черта снизу
        TextView title = new TextView(this);
        title.setText("СОЗДАТЬ КОНФИГ");
        title.setTextSize(17);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.26f);
        title.setShadowLayer(14, 0, 0, 0xFF00FF9D);
        outer.addView(title);

        // Подзаголовок-комментарий (стиль "//")
        TextView subTitle = new TextView(this);
        subTitle.setText("// NEW CONFIG PROFILE");
        subTitle.setTextSize(10);
        subTitle.setTextColor(0xFFFF1E4E);
        subTitle.setTypeface(Typeface.MONOSPACE);
        subTitle.setLetterSpacing(0.2f);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(MATCH, WRAP);
        stp.topMargin = dp(4);
        stp.bottomMargin = dp(18);
        subTitle.setLayoutParams(stp);
        outer.addView(subTitle);

        // Поле "Название"
        outer.addView(neonFieldLabel("НАЗВАНИЕ", 0xFF00FF9D));
        final EditText etName = neonInputField("Например: имя автора");
        outer.addView(etName);
        outer.addView(spacer(16));

        // Поле "Описание"
        outer.addView(neonFieldLabel("ОПИСАНИЕ", 0xFFFF1E4E));
        final EditText etDesc = neonInputField("Краткое описание (необязательно)");
        outer.addView(etDesc);
        outer.addView(spacer(14));

        // Строка VPN
        String curVpn = getSharedPreferences(VpnPickerActivity.PREFS_VPN, MODE_PRIVATE)
            .getString(VpnPickerActivity.KEY_VPN, VpnPickerActivity.VPN_DEFAULT);
        LinearLayout vpnRow = new LinearLayout(this);
        vpnRow.setOrientation(LinearLayout.HORIZONTAL);
        vpnRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams vpnRowLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        vpnRowLp.bottomMargin = dp(18);
        vpnRow.setLayoutParams(vpnRowLp);

        TextView tvVpnLabel = new TextView(this);
        tvVpnLabel.setText("VPN:");
        tvVpnLabel.setTextSize(12);
        tvVpnLabel.setTextColor(0xFF6C7885);
        tvVpnLabel.setTypeface(null, Typeface.BOLD);
        tvVpnLabel.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(WRAP, WRAP);
        vlp.rightMargin = dp(8);
        tvVpnLabel.setLayoutParams(vlp);

        TextView tvVpnValue = new TextView(this);
        tvVpnValue.setText(curVpn);
        tvVpnValue.setTextSize(13);
        tvVpnValue.setTextColor(0xFF00CFFF);
        tvVpnValue.setTypeface(null, Typeface.BOLD);
        tvVpnValue.setShadowLayer(6, 0, 0, 0xFF00CFFF);

        vpnRow.addView(tvVpnLabel);
        vpnRow.addView(tvVpnValue);
        outer.addView(vpnRow);

        // ── Режим работы: Обычный / Пошаговый ──────────────────────────
        outer.addView(neonFieldLabel("РЕЖИМ РАБОТЫ", 0xFF00CFFF));
        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams modeRowLp = new LinearLayout.LayoutParams(MATCH, dp(46));
        modeRowLp.topMargin = dp(6);
        modeRowLp.bottomMargin = dp(18);
        modeRow.setLayoutParams(modeRowLp);

        final Button btnModeNormal = new Button(this);
        btnModeNormal.setText("Обычный режим");
        btnModeNormal.setTextSize(12);
        btnModeNormal.setTypeface(null, Typeface.BOLD);
        btnModeNormal.setAllCaps(false);
        btnModeNormal.setStateListAnimator(null);
        LinearLayout.LayoutParams bmn = new LinearLayout.LayoutParams(0, MATCH, 1f);
        bmn.rightMargin = dp(8);
        btnModeNormal.setLayoutParams(bmn);

        final Button btnModeStep = new Button(this);
        btnModeStep.setText("Пошаговый режим");
        btnModeStep.setTextSize(12);
        btnModeStep.setTypeface(null, Typeface.BOLD);
        btnModeStep.setAllCaps(false);
        btnModeStep.setStateListAnimator(null);
        btnModeStep.setLayoutParams(new LinearLayout.LayoutParams(0, MATCH, 1f));

        final int[] chosenMode = {0}; // 0 = Обычный (по умолчанию), 1 = Пошаговый

        final Runnable updateModeButtons = new Runnable() {
            public void run() {
                boolean stepMode = chosenMode[0] == 1;
                btnModeNormal.setBackgroundResource(stepMode ? R.drawable.btn_neon_outline : R.drawable.btn_neon_cyan);
                btnModeNormal.setTextColor(stepMode ? 0xFFB8C4D0 : 0xFF001A2A);
                btnModeStep.setBackgroundResource(stepMode ? R.drawable.btn_neon_cyan : R.drawable.btn_neon_outline);
                btnModeStep.setTextColor(stepMode ? 0xFF001A2A : 0xFFB8C4D0);
            }
        };
        updateModeButtons.run();

        btnModeNormal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { chosenMode[0] = 0; updateModeButtons.run(); }
        });
        btnModeStep.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { chosenMode[0] = 1; updateModeButtons.run(); }
        });

        modeRow.addView(btnModeNormal);
        modeRow.addView(btnModeStep);
        outer.addView(modeRow);

        // Кнопки: Отмена | Создать
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        Button btnCancel = new Button(this);
        btnCancel.setText("ОТМЕНА");
        btnCancel.setTextSize(13);
        btnCancel.setLetterSpacing(0.22f);
        btnCancel.setTypeface(null, Typeface.BOLD);
        btnCancel.setTextColor(0xFFB8C4D0);
        btnCancel.setBackgroundResource(R.drawable.btn_neon_outline);
        btnCancel.setStateListAnimator(null);
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        cLp.rightMargin = dp(10);
        btnCancel.setLayoutParams(cLp);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { dlg.dismiss(); }
        });

        Button btnCreate = new Button(this);
        btnCreate.setText("СОЗДАТЬ");
        btnCreate.setTextSize(13);
        btnCreate.setLetterSpacing(0.24f);
        btnCreate.setTypeface(null, Typeface.BOLD);
        btnCreate.setTextColor(0xFF001A0E);
        btnCreate.setBackgroundResource(R.drawable.btn_neon_green);
        btnCreate.setStateListAnimator(null);
        btnCreate.setLayoutParams(new LinearLayout.LayoutParams(0, dp(50), 1.2f));
        btnCreate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String name = etName.getText().toString().trim();
                if (name.isEmpty()) {
                    Toast.makeText(ConfigsActivity.this,
                        "Введите название", Toast.LENGTH_SHORT).show();
                    return;
                }
                Config c = new Config(name, etDesc.getText().toString().trim());
                // Сохраняем АКТУАЛЬНО выбранный VPN в момент создания конфига
                android.content.SharedPreferences vpnPrefs =
                    getSharedPreferences(VpnPickerActivity.PREFS_VPN, MODE_PRIVATE);
                c.vpn = vpnPrefs.getString(VpnPickerActivity.KEY_VPN, VpnPickerActivity.VPN_DEFAULT);
                c.configMode = chosenMode[0];
                if (c.configMode == 1) {
                    // Пошаговый режим стартует с одним шагом по умолчанию
                    c.steps.add(new Step());
                }
                configs.add(c);
                saveConfigs();
                refreshList();
                dlg.dismiss();
                if (c.configMode == 1) {
                    openStepMode(configs.size() - 1);
                } else {
                    openConfigSettings(configs.size() - 1);
                }
            }
        });

        btnRow.addView(btnCancel);
        btnRow.addView(btnCreate);
        outer.addView(btnRow);

        dlg.setContentView(outer);

        Window w = dlg.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xCC000000));
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.width  = (int)(getResources().getDisplayMetrics().widthPixels * 0.90f);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
        }
        dlg.show();
    }

    /** Открывает ConfigSettingsActivity для конфига с данным индексом */
    private void openConfigSettings(int index) {
        Intent i = new Intent(this, ConfigSettingsActivity.class);
        i.putExtra(ConfigSettingsActivity.EXTRA_CONFIG_INDEX, index);
        startActivity(i);
    }

    /** Открывает StepModeActivity (экран шагов) для конфига с данным индексом */
    private void openStepMode(int index) {
        Intent i = new Intent(this, StepModeActivity.class);
        i.putExtra(StepModeActivity.EXTRA_CONFIG_INDEX, index);
        startActivity(i);
    }

    // ── Список карточек ───────────────────────────────────────────────────
    private void refreshList() {
        listContainer.removeAllViews();
        boolean empty = configs.isEmpty();
        tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        listContainer.setVisibility(empty ? View.GONE : View.VISIBLE);
        for (int i = 0; i < configs.size(); i++) {
            listContainer.addView(buildCard(i, configs.get(i)));
        }
    }

    private View buildCard(final int index, final Config cfg) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(MATCH, WRAP);
        clp.bottomMargin = dp(12);
        card.setLayoutParams(clp);

        // Верхняя строка: чекбокс (в режиме отправки) + название + статус
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        topRow.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        // Круглый чекбокс — виден только в режиме отправки
        if (sendMode) {
            final TextView circle = new TextView(this);
            final boolean isSel = selected.contains(index);
            circle.setText(isSel ? "✓" : "");
            circle.setTextSize(15);
            circle.setTypeface(null, Typeface.BOLD);
            circle.setTextColor(0xFF001A0E);
            circle.setGravity(Gravity.CENTER);
            circle.setBackgroundResource(isSel
                ? R.drawable.bg_check_circle_on
                : R.drawable.bg_check_circle_off);
            LinearLayout.LayoutParams ccp = new LinearLayout.LayoutParams(dp(26), dp(26));
            ccp.rightMargin = dp(12);
            circle.setLayoutParams(ccp);
            topRow.addView(circle);
        }

        TextView tvName = new TextView(this);
        tvName.setText(cfg.name);
        tvName.setTextSize(15);
        tvName.setTypeface(null, Typeface.BOLD);
        tvName.setTextColor(0xFFFFFFFF);
        tvName.setLetterSpacing(0.06f);
        tvName.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));

        if (cfg.installed) {
            TextView pill = new TextView(this);
            pill.setText("● АКТИВЕН");
            pill.setTextSize(9);
            pill.setTextColor(0xFF00FF9D);
            pill.setTypeface(null, Typeface.BOLD);
            pill.setLetterSpacing(0.18f);
            pill.setShadowLayer(8, 0, 0, 0xFF00FF9D);
            topRow.addView(tvName);
            topRow.addView(pill);
        } else {
            topRow.addView(tvName);
        }

        // Описание
        TextView tvDesc = new TextView(this);
        tvDesc.setText(cfg.description.isEmpty() ? "—" : cfg.description);
        tvDesc.setTextSize(12);
        tvDesc.setTextColor(0xFF6C7885);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        dlp.topMargin = dp(4);
        dlp.bottomMargin = dp(6);
        tvDesc.setLayoutParams(dlp);

        // VPN строка
        String vpnLabel = (cfg.vpn != null && !cfg.vpn.trim().isEmpty())
            ? cfg.vpn.trim()
            : VpnPickerActivity.VPN_DEFAULT;
        LinearLayout vpnInfoRow = new LinearLayout(this);
        vpnInfoRow.setOrientation(LinearLayout.HORIZONTAL);
        vpnInfoRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams vrLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        vrLp.bottomMargin = dp(12);
        vpnInfoRow.setLayoutParams(vrLp);

        TextView tvVpnKey = new TextView(this);
        tvVpnKey.setText("VPN:");
        tvVpnKey.setTextSize(11);
        tvVpnKey.setTextColor(0xFF4A5568);
        tvVpnKey.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams vkLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        vkLp.rightMargin = dp(6);
        tvVpnKey.setLayoutParams(vkLp);

        TextView tvVpnVal = new TextView(this);
        tvVpnVal.setText(vpnLabel);
        tvVpnVal.setTextSize(11);
        tvVpnVal.setTextColor(0xFF00CFFF);
        tvVpnVal.setTypeface(null, Typeface.BOLD);
        tvVpnVal.setShadowLayer(5, 0, 0, 0xFF00CFFF);

        vpnInfoRow.addView(tvVpnKey);
        vpnInfoRow.addView(tvVpnVal);

        // Строка кнопок
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        final Button btnInstall = new Button(this);
        applyInstallStyle(btnInstall, cfg.installed);
        btnInstall.setStateListAnimator(null);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        blp.rightMargin = dp(10);
        btnInstall.setLayoutParams(blp);
        btnInstall.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                for (Config c : configs) c.installed = false;
                cfg.installed = true;
                MainActivity.curServerDelay = cfg.serverDelay;
                MainActivity.curServerLoss  = cfg.serverLoss;
                MainActivity.curClientDelay = cfg.clientDelay;
                MainActivity.curClientLoss  = cfg.clientLoss;
                MainActivity.curDuration    = cfg.duration;
                MainActivity.curAfterTimerMode        = cfg.afterTimerMode;
                MainActivity.curAfterTimerDelayMs     = cfg.afterTimerDelayMs;
                MainActivity.curAfterTimerDurationSec = cfg.afterTimerDurationSec;
                MainActivity.curClientSzMode = cfg.clientSizeFilterMode;
                MainActivity.curClientSzMin  = cfg.clientSizeMin;
                MainActivity.curClientSzMax  = cfg.clientSizeMax;
                MainActivity.curServerSzMode = cfg.serverSizeFilterMode;
                MainActivity.curServerSzMin  = cfg.serverSizeMin;
                MainActivity.curServerSzMax  = cfg.serverSizeMax;
                // ── Пошаговый режим ──────────────────────────────────────
                MainActivity.curConfigMode      = cfg.configMode;
                MainActivity.curStepsAfterMode  = cfg.stepsAfterMode;
                MainActivity.curStepsSerialized = serializeSteps(cfg.steps);
                // Применяем VPN из конфига (если задан)
                applyVpnFromConfig(cfg.vpn);
                saveConfigs();
                Toast.makeText(ConfigsActivity.this,
                    "\"" + cfg.name + "\" применён", Toast.LENGTH_SHORT).show();
                refreshList();
            }
        });

        Button btnEdit = new Button(this);
        btnEdit.setText("✎");
        btnEdit.setTextSize(20);
        btnEdit.setTypeface(null, Typeface.BOLD);
        btnEdit.setTextColor(0xFF00FF9D);
        btnEdit.setShadowLayer(8, 0, 0, 0xFF00FF9D);
        btnEdit.setBackgroundResource(R.drawable.btn_neon_outline);
        btnEdit.setStateListAnimator(null);
        LinearLayout.LayoutParams editLp = new LinearLayout.LayoutParams(dp(50), dp(46));
        editLp.rightMargin = dp(8);
        btnEdit.setLayoutParams(editLp);
        btnEdit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int idx = configs.indexOf(cfg);
                if (idx >= 0) {
                    if (cfg.configMode == 1) openStepMode(idx);
                    else openConfigSettings(idx);
                }
            }
        });

        ImageButton btnDelete = new ImageButton(this);
        // Нарисованная векторная иконка корзины (res/drawable/ic_trash_neon.xml),
        // а не системный emoji — так цвет и вид гарантированно одинаковы на всех устройствах
        btnDelete.setImageResource(R.drawable.ic_trash_neon);
        btnDelete.setScaleType(android.widget.ImageView.ScaleType.CENTER);
        btnDelete.setPadding(dp(12), dp(12), dp(12), dp(12));
        btnDelete.setBackgroundResource(R.drawable.btn_neon_red_outline);
        btnDelete.setStateListAnimator(null);
        btnDelete.setLayoutParams(new LinearLayout.LayoutParams(dp(50), dp(46)));
        btnDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                boolean wasInstalled = cfg.installed;
                configs.remove(cfg);
                // Если удалён активный конфиг — сбросить настройки и остановить FloatService
                if (wasInstalled) {
                    MainActivity.curServerDelay           = 0;
                    MainActivity.curServerLoss            = 0;
                    MainActivity.curClientDelay           = 0;
                    MainActivity.curClientLoss            = 0;
                    MainActivity.curDuration              = 0;
                    MainActivity.curAfterTimerMode        = 0;
                    MainActivity.curAfterTimerDelayMs     = 0;
                    MainActivity.curAfterTimerDurationSec = 3;
                    // Останавливаем FloatService (кнопка поверх окон) и VPN
                    try {
                        Intent stopFloat = new Intent(ConfigsActivity.this, FloatService.class);
                        stopFloat.setAction(FloatService.ACTION_STOP);
                        startService(stopFloat);
                    } catch (Exception ignored) {}
                    try {
                        Intent stopVpn = new Intent(ConfigsActivity.this, MyVpnService.class);
                        stopVpn.setAction(MyVpnService.ACTION_STOP);
                        startService(stopVpn);
                    } catch (Exception ignored) {}
                }
                saveConfigs();
                refreshList();
                Toast.makeText(ConfigsActivity.this,
                    "\"" + cfg.name + "\" удалён" + (wasInstalled ? " (конфиг деактивирован)" : ""),
                    Toast.LENGTH_SHORT).show();
            }
        });

        row.addView(btnInstall);
        // Кнопка редактирования скрыта только для импортированных зашифрованных конфигов
        if (!cfg.importedEncrypted) {
            row.addView(btnEdit);
        }
        row.addView(btnDelete);

        card.addView(topRow);
        card.addView(tvDesc);
        card.addView(vpnInfoRow);
        // В режиме отправки скрываем install/edit/delete и делаем тап по карточке = выбор
        if (sendMode) {
            row.setVisibility(View.GONE);
            card.addView(row);
            card.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (selected.contains(index)) selected.remove(index);
                    else selected.add(index);
                    refreshList();
                }
            });
        } else {
            card.addView(row);
        }
        return card;
    }

    // ════════════════════════════════════════════════════════════════════
    //  СОХРАНЕНИЕ / ЗАГРУЗКА конфигов в SharedPreferences (без библиотек)
    // ════════════════════════════════════════════════════════════════════

    private static final String PREFS_CONFIGS = "cvpn_configs";
    private static final String KEY_COUNT     = "count";

    /** Сохраняет все конфиги в SharedPreferences */
    void saveConfigs() {
        saveConfigsStatic(this);
    }

    /**
     * Статический вариант сохранения списка configs — используется как из
     * ConfigsActivity, так и из StepModeActivity (после изменения шагов),
     * чтобы формат хранения не расходился между экранами.
     */
    static void saveConfigsStatic(android.content.Context ctx) {
        android.content.SharedPreferences.Editor ed =
            ctx.getSharedPreferences(PREFS_CONFIGS, MODE_PRIVATE).edit();
        ed.putInt(KEY_COUNT, configs.size());
        ed.putInt("duration_version", 2); // 2 = мс (новый формат), 1 = секунды (устарел)
        for (int i = 0; i < configs.size(); i++) {
            Config c = configs.get(i);
            String p = "cfg_" + i + "_";
            ed.putString(p + "name",        c.name);
            ed.putString(p + "desc",        c.description);
            ed.putInt   (p + "sDelay",      c.serverDelay);
            ed.putInt   (p + "sLoss",       c.serverLoss);
            ed.putInt   (p + "cDelay",      c.clientDelay);
            ed.putInt   (p + "cLoss",       c.clientLoss);
            ed.putInt   (p + "duration",    c.duration);
            ed.putInt   (p + "atMode",      c.afterTimerMode);
            ed.putInt   (p + "atDelayMs",   c.afterTimerDelayMs);
            ed.putInt   (p + "atDurSec",    c.afterTimerDurationSec);
            ed.putBoolean(p + "installed",  c.installed);
            ed.putString(p + "vpn",         c.vpn == null ? "" : c.vpn);
            ed.putBoolean(p + "sendEncrypted",     c.sendEncrypted);
            ed.putBoolean(p + "importedEncrypted", c.importedEncrypted);
            ed.putInt    (p + "cSzMode",  c.clientSizeFilterMode);
            ed.putInt    (p + "cSzMin",   c.clientSizeMin);
            ed.putInt    (p + "cSzMax",   c.clientSizeMax);
            ed.putInt    (p + "sSzMode",  c.serverSizeFilterMode);
            ed.putInt    (p + "sSzMin",   c.serverSizeMin);
            ed.putInt    (p + "sSzMax",   c.serverSizeMax);

            ed.putInt    (p + "cfgMode",    c.configMode);
            ed.putInt    (p + "stepsAfter", c.stepsAfterMode);
            ed.putString (p + "steps",      serializeStepsStatic(c.steps));
        }
        ed.apply();
    }

    /** Сериализует список шагов в одну строку (без сторонних библиотек). */
    private String serializeSteps(ArrayList<Step> steps) {
        return serializeStepsStatic(steps);
    }

    /** Статический вариант — переиспользуется из StepModeActivity. */
    static String serializeStepsStatic(ArrayList<Step> steps) {
        if (steps == null || steps.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < steps.size(); i++) {
            Step s = steps.get(i);
            if (i > 0) sb.append(';');
            sb.append(s.clientDelay).append(',')
              .append(s.clientLoss).append(',')
              .append(s.clientBufferMode).append(',')
              .append(s.serverDelay).append(',')
              .append(s.serverLoss).append(',')
              .append(s.serverBufferMode).append(',')
              .append(s.clientSizeFilterMode).append(',')
              .append(s.clientSizeMin).append(',')
              .append(s.clientSizeMax).append(',')
              .append(s.serverSizeFilterMode).append(',')
              .append(s.serverSizeMin).append(',')
              .append(s.serverSizeMax).append(',')
              .append(s.duration);
        }
        return sb.toString();
    }

    /** Восстанавливает список шагов из строки, полученной от serializeSteps(). */
    private ArrayList<Step> deserializeSteps(String data) {
        ArrayList<Step> list = new ArrayList<Step>();
        if (data == null || data.isEmpty()) return list;
        String[] items = data.split(";");
        for (String item : items) {
            if (item.isEmpty()) continue;
            String[] f = item.split(",");
            if (f.length < 13) continue;
            try {
                Step s = new Step();
                s.clientDelay          = Integer.parseInt(f[0]);
                s.clientLoss           = Integer.parseInt(f[1]);
                s.clientBufferMode     = Integer.parseInt(f[2]);
                s.serverDelay          = Integer.parseInt(f[3]);
                s.serverLoss           = Integer.parseInt(f[4]);
                s.serverBufferMode     = Integer.parseInt(f[5]);
                s.clientSizeFilterMode = Integer.parseInt(f[6]);
                s.clientSizeMin        = Integer.parseInt(f[7]);
                s.clientSizeMax        = Integer.parseInt(f[8]);
                s.serverSizeFilterMode = Integer.parseInt(f[9]);
                s.serverSizeMin        = Integer.parseInt(f[10]);
                s.serverSizeMax        = Integer.parseInt(f[11]);
                s.duration              = Integer.parseInt(f[12]);
                list.add(s);
            } catch (NumberFormatException ignored) {}
        }
        return list;
    }

    /** Загружает конфиги из SharedPreferences при старте */
    private void loadConfigs() {
        android.content.SharedPreferences prefs =
            getSharedPreferences(PREFS_CONFIGS, MODE_PRIVATE);
        int count = prefs.getInt(KEY_COUNT, 0);
        if (count == 0) return;
        configs.clear();
        for (int i = 0; i < count; i++) {
            String p = "cfg_" + i + "_";
            String name = prefs.getString(p + "name", "");
            if (name.isEmpty()) continue;
            Config c = new Config(name, prefs.getString(p + "desc", ""));
            c.serverDelay          = prefs.getInt(p + "sDelay",    0);
            c.serverLoss           = prefs.getInt(p + "sLoss",     0);
            c.clientDelay          = prefs.getInt(p + "cDelay",    0);
            c.clientLoss           = prefs.getInt(p + "cLoss",     0);
            c.duration             = prefs.getInt(p + "duration",  0);
            // Миграция: если значение ≤ 3600, это старый формат (секунды) → конвертируем в мс.
            // Новый формат хранит мс; 3600 мс = 3.6 сек (< 1 часа в секундах — маловероятно).
            int storedVersion = prefs.getInt("duration_version", 1);
            if (storedVersion < 2 && c.duration > 0 && c.duration <= 3600) {
                c.duration *= 1000;
            }
            c.afterTimerMode       = prefs.getInt(p + "atMode",    0);
            c.afterTimerDelayMs    = prefs.getInt(p + "atDelayMs", 0);
            c.afterTimerDurationSec= prefs.getInt(p + "atDurSec",  3);
            c.installed            = prefs.getBoolean(p + "installed", false);
            String savedVpn        = prefs.getString(p + "vpn", "");
            // Миграция: если vpn не сохранён (старые конфиги) — используем дефолт
            c.vpn = (savedVpn != null && !savedVpn.isEmpty()) ? savedVpn : VpnPickerActivity.VPN_DEFAULT;
            // Миграция со старого единого флага "encrypted"
            boolean legacyEncrypted = prefs.getBoolean(p + "encrypted", false);
            c.sendEncrypted     = prefs.getBoolean(p + "sendEncrypted",     legacyEncrypted);
            c.importedEncrypted = prefs.getBoolean(p + "importedEncrypted", false);
            c.clientSizeFilterMode = prefs.getInt(p + "cSzMode", 0);
            c.clientSizeMin        = prefs.getInt(p + "cSzMin",  0);
            c.clientSizeMax        = prefs.getInt(p + "cSzMax",  1500);
            c.serverSizeFilterMode = prefs.getInt(p + "sSzMode", 0);
            c.serverSizeMin        = prefs.getInt(p + "sSzMin",  0);
            c.serverSizeMax        = prefs.getInt(p + "sSzMax",  1500);

            c.configMode    = prefs.getInt(p + "cfgMode", 0);
            c.stepsAfterMode= prefs.getInt(p + "stepsAfter", 0);
            c.steps         = deserializeSteps(prefs.getString(p + "steps", ""));
            configs.add(c);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Обновить список после возврата из ConfigSettingsActivity
        refreshList();
        accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
    }

    private void applyInstallStyle(Button btn, boolean installed) {
        btn.setTextSize(12);
        btn.setLetterSpacing(0.22f);
        btn.setTypeface(null, Typeface.BOLD);
        if (installed) {
            btn.setText("✓ УСТАНОВЛЕН");
            btn.setBackgroundResource(R.drawable.btn_neon_installed);
            btn.setTextColor(0xFF00FF9D);
        } else {
            btn.setText("УСТАНОВИТЬ");
            btn.setBackgroundResource(R.drawable.btn_neon_red);
            btn.setTextColor(0xFFFFFFFF);
        }
    }

    // ── UI helpers ────────────────────────────────────────────────────────
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    /** Маленький неоновый ярлычок: цветная вертикальная черта + текст */
    private View neonFieldLabel(String text, int accent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.bottomMargin = dp(8);
        row.setLayoutParams(rlp);

        View bar = new View(this);
        bar.setBackgroundColor(accent);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(3), dp(12));
        blp.rightMargin = dp(8);
        bar.setLayoutParams(blp);

        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(11);
        tv.setTextColor(0xFFB8C4D0);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setLetterSpacing(0.22f);

        row.addView(bar);
        row.addView(tv);
        return row;
    }

    private EditText neonInputField(String hint) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setTextColor(0xFFFFFFFF);
        et.setHintTextColor(0xFF3A4654);
        et.setTextSize(15);
        et.setTypeface(null, Typeface.BOLD);
        et.setBackgroundResource(R.drawable.bg_input);
        et.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, dp(56));
        et.setLayoutParams(lp);
        return et;
    }

    private View spacer(int dpVal) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(dpVal)));
        return v;
    }

    // ════════════════════════════════════════════════════════════════════
    //  ОТПРАВКА КОНФИГОВ — диалог предпросмотра + Intent.share + FileProvider
    // ════════════════════════════════════════════════════════════════════

    private static final String CFG_EXT = ".GalaxyClumsy";

    @Override
    public void onBackPressed() {
        if (sendMode) { exitSendMode(); return; }
        super.onBackPressed();
    }

    /** Диалог предпросмотра выбранных конфигов (overlay-эффект, не на весь экран) */
    private void showSendPreviewDialog() {
        // Собираем список выбранных конфигов
        final ArrayList<Integer> indices = new ArrayList<Integer>(selected);
        java.util.Collections.sort(indices);
        if (indices.isEmpty()) return;

        final Dialog dlg = new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dlg.setCanceledOnTouchOutside(true);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundResource(R.drawable.bg_dialog_neon);
        outer.setPadding(dp(22), dp(22), dp(22), dp(20));

        // Заголовок
        TextView title = new TextView(this);
        title.setText("ПРЕДПРОСМОТР");
        title.setTextSize(17);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.26f);
        title.setShadowLayer(14, 0, 0, 0xFF00FF9D);
        outer.addView(title);

        TextView subTitle = new TextView(this);
        subTitle.setText("// FILES TO SEND  (" + indices.size() + ")");
        subTitle.setTextSize(10);
        subTitle.setTextColor(0xFFFF1E4E);
        subTitle.setTypeface(Typeface.MONOSPACE);
        subTitle.setLetterSpacing(0.2f);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(MATCH, WRAP);
        stp.topMargin = dp(4);
        stp.bottomMargin = dp(16);
        subTitle.setLayoutParams(stp);
        outer.addView(subTitle);

        // Список файлов в скролле (на случай большого количества)
        ScrollView sv = new ScrollView(this);
        LinearLayout.LayoutParams svlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        svlp.bottomMargin = dp(20);
        sv.setLayoutParams(svlp);
        // Ограничим высоту, чтобы было видно меню сзади
        sv.setMinimumHeight(dp(60));

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        for (Integer idx : indices) {
            if (idx == null || idx < 0 || idx >= configs.size()) continue;
            final Config c = configs.get(idx);
            String fname = sanitizeFilename(c.name) + CFG_EXT;

            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setBackgroundResource(R.drawable.bg_card);
            item.setPadding(dp(14), dp(10), dp(14), dp(10));
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(MATCH, WRAP);
            ilp.bottomMargin = dp(8);
            item.setLayoutParams(ilp);

            TextView tName = new TextView(this);
            tName.setText(fname);
            tName.setTextSize(13);
            tName.setTypeface(null, Typeface.BOLD);
            tName.setTextColor(0xFFFFFFFF);
            tName.setSingleLine(true);
            tName.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);

            TextView tFmt = new TextView(this);
            tFmt.setText("формат: " + CFG_EXT);
            tFmt.setTextSize(11);
            tFmt.setTextColor(0xFF6C7885);
            tFmt.setTypeface(Typeface.MONOSPACE);
            LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(MATCH, WRAP);
            flp.topMargin = dp(2);
            tFmt.setLayoutParams(flp);

            // Чекбокс шифровки
            LinearLayout encRow = new LinearLayout(this);
            encRow.setOrientation(LinearLayout.HORIZONTAL);
            encRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams erlp = new LinearLayout.LayoutParams(MATCH, WRAP);
            erlp.topMargin = dp(8);
            encRow.setLayoutParams(erlp);

            final TextView encBox = new TextView(this);
            encBox.setTextSize(14);
            encBox.setTypeface(null, Typeface.BOLD);
            encBox.setGravity(android.view.Gravity.CENTER);
            encBox.setBackgroundResource(c.sendEncrypted
                    ? R.drawable.bg_check_circle_on
                    : R.drawable.bg_check_circle_off);
            encBox.setText(c.sendEncrypted ? "✓" : "");
            encBox.setTextColor(0xFF001A0E);
            LinearLayout.LayoutParams eblp = new LinearLayout.LayoutParams(dp(26), dp(26));
            eblp.rightMargin = dp(10);
            encBox.setLayoutParams(eblp);

            TextView encLabel = new TextView(this);
            encLabel.setText("Добавить шифровку конфига");
            encLabel.setTextSize(12);
            encLabel.setTextColor(0xFFB8C4D0);
            encLabel.setTypeface(null, Typeface.BOLD);

            encRow.addView(encBox);
            encRow.addView(encLabel);

            // Клик по всей строке шифровки
            encRow.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    c.sendEncrypted = !c.sendEncrypted;
                    encBox.setBackgroundResource(c.sendEncrypted
                            ? R.drawable.bg_check_circle_on
                            : R.drawable.bg_check_circle_off);
                    encBox.setText(c.sendEncrypted ? "✓" : "");
                    saveConfigs();
                }
            });

            item.addView(tName);
            item.addView(tFmt);
            item.addView(encRow);
            list.addView(item);
        }

        sv.addView(list);
        outer.addView(sv);

        // Кнопки
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        Button btnCancel = new Button(this);
        btnCancel.setText("ОТМЕНА");
        btnCancel.setTextSize(13);
        btnCancel.setLetterSpacing(0.22f);
        btnCancel.setTypeface(null, Typeface.BOLD);
        btnCancel.setTextColor(0xFFB8C4D0);
        btnCancel.setBackgroundResource(R.drawable.btn_neon_outline);
        btnCancel.setStateListAnimator(null);
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        cLp.rightMargin = dp(10);
        btnCancel.setLayoutParams(cLp);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { dlg.dismiss(); }
        });

        Button btnSend = new Button(this);
        btnSend.setText("ОТПРАВИТЬ");
        btnSend.setTextSize(13);
        btnSend.setLetterSpacing(0.24f);
        btnSend.setTypeface(null, Typeface.BOLD);
        btnSend.setTextColor(0xFF001A0E);
        btnSend.setBackgroundResource(R.drawable.btn_neon_green);
        btnSend.setStateListAnimator(null);
        btnSend.setLayoutParams(new LinearLayout.LayoutParams(0, dp(50), 1.2f));
        btnSend.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dlg.dismiss();
                shareConfigs(indices);
            }
        });

        btnRow.addView(btnCancel);
        btnRow.addView(btnSend);
        outer.addView(btnRow);

        dlg.setContentView(outer);

        Window w = dlg.getWindow();
        if (w != null) {
            // Полупрозрачный фон вокруг диалога — видно меню сзади (overlay-эффект)
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x99000000));
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.width  = (int)(getResources().getDisplayMetrics().widthPixels * 0.86f);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            // Сдвигаем чуть выше центра, чтобы по бокам и снизу было видно фон
            lp.dimAmount = 0.45f;
            w.setAttributes(lp);
        }
        dlg.show();
    }

    /** Создаёт файлы конфигов в cacheDir/share и запускает Intent.share */
    private void shareConfigs(ArrayList<Integer> indices) {
        ArrayList<Uri> uris = new ArrayList<Uri>();
        for (Integer idx : indices) {
            if (idx == null || idx < 0 || idx >= configs.size()) continue;
            Config c = configs.get(idx);
            String fname = sanitizeFilename(c.name) + CFG_EXT;
            File f = ConfigShareProvider.fileFor(this, fname);
            try {
                FileOutputStream fos = new FileOutputStream(f);
                String json = buildJsonForConfig(c);
                if (c.sendEncrypted) {
                    // Шифруем: AES-256-GCM + PBKDF2 (настоящее шифрование)
                    try {
                        String envelope = encryptToEnvelope(json);
                        fos.write(envelope.getBytes("UTF-8"));
                    } catch (Exception encEx) {
                        Toast.makeText(this,
                            "Ошибка шифрования: " + encEx.getMessage(),
                            Toast.LENGTH_LONG).show();
                        fos.close();
                        return;
                    }
                } else {
                    fos.write(json.getBytes("UTF-8"));
                }
                fos.flush();
                fos.close();
            } catch (Exception e) {
                Toast.makeText(this,
                    "Ошибка записи файла: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
                return;
            }
            uris.add(ConfigShareProvider.uriForFile(fname));
        }

        if (uris.isEmpty()) return;

        Intent intent;
        if (uris.size() == 1) {
            intent = new Intent(Intent.ACTION_SEND);
            intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        } else {
            intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        }
        intent.setType("application/octet-stream");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        // Для совместимости со старыми Android версиями
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        try {
            Intent chooser = Intent.createChooser(intent, "Отправить конфиг");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(chooser);
            // Выходим из режима выбора
            exitSendMode();
        } catch (Exception e) {
            Toast.makeText(this,
                "Не найдено приложение для отправки",
                Toast.LENGTH_SHORT).show();
        }
    }

    /** JSON со всеми параметрами конфига */
    private String buildJsonForConfig(Config c) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"name\": ").append(jsonStr(c.name)).append(",\n");
        sb.append("  \"description\": ").append(jsonStr(c.description == null ? "" : c.description)).append(",\n");
        sb.append("  \"server_delay\": ").append(c.serverDelay).append(",\n");
        sb.append("  \"client_delay\": ").append(c.clientDelay).append(",\n");
        sb.append("  \"server_loss\": ").append(c.serverLoss).append(",\n");
        sb.append("  \"client_loss\": ").append(c.clientLoss).append(",\n");
        sb.append("  \"timer\": ").append(c.duration).append(",\n");
        sb.append("  \"after_timer_mode\": ").append(c.afterTimerMode).append(",\n");
        sb.append("  \"after_timer_delay_ms\": ").append(c.afterTimerDelayMs).append(",\n");
        sb.append("  \"after_timer_duration_sec\": ").append(c.afterTimerDurationSec).append(",\n");
        sb.append("  \"client_sz_mode\": ").append(c.clientSizeFilterMode).append(",\n");
        sb.append("  \"client_sz_min\": ").append(c.clientSizeMin).append(",\n");
        sb.append("  \"client_sz_max\": ").append(c.clientSizeMax).append(",\n");
        sb.append("  \"server_sz_mode\": ").append(c.serverSizeFilterMode).append(",\n");
        sb.append("  \"server_sz_min\": ").append(c.serverSizeMin).append(",\n");
        sb.append("  \"server_sz_max\": ").append(c.serverSizeMax).append(",\n");
        // ── Пошаговый режим ──────────────────────────────────────────
        sb.append("  \"config_mode\": ").append(c.configMode).append(",\n");
        sb.append("  \"steps_after_mode\": ").append(c.stepsAfterMode).append(",\n");
        sb.append("  \"steps\": [\n");
        if (c.steps != null) {
            for (int i = 0; i < c.steps.size(); i++) {
                Step s = c.steps.get(i);
                sb.append("    {");
                sb.append("\"client_delay\":").append(s.clientDelay).append(",");
                sb.append("\"client_loss\":").append(s.clientLoss).append(",");
                sb.append("\"client_buffer\":").append(s.clientBufferMode).append(",");
                sb.append("\"server_delay\":").append(s.serverDelay).append(",");
                sb.append("\"server_loss\":").append(s.serverLoss).append(",");
                sb.append("\"server_buffer\":").append(s.serverBufferMode).append(",");
                sb.append("\"client_sz_mode\":").append(s.clientSizeFilterMode).append(",");
                sb.append("\"client_sz_min\":").append(s.clientSizeMin).append(",");
                sb.append("\"client_sz_max\":").append(s.clientSizeMax).append(",");
                sb.append("\"server_sz_mode\":").append(s.serverSizeFilterMode).append(",");
                sb.append("\"server_sz_min\":").append(s.serverSizeMin).append(",");
                sb.append("\"server_sz_max\":").append(s.serverSizeMax).append(",");
                sb.append("\"duration\":").append(s.duration);
                sb.append("}");
                if (i < c.steps.size() - 1) sb.append(",");
                sb.append("\n");
            }
        }
        sb.append("  ],\n");
        // VPN: всегда берём из конфига. Если пусто — используем дефолт (не глобальный кэш)
        String vpnName = (c.vpn != null && !c.vpn.isEmpty()) ? c.vpn : VpnPickerActivity.VPN_DEFAULT;
        sb.append("  \"vpn\": ").append(jsonStr(vpnName)).append("\n");
        sb.append("}\n");
        return sb.toString();
    }

    // ════════════════════════════════════════════════════════════════════
    //  ИМПОРТ КОНФИГА из .GalaxyClumsy файла (ACTION_OPEN_DOCUMENT)
    // ════════════════════════════════════════════════════════════════════

    private static final int REQ_PICK_CONFIG = 4242;

    /** Открывает системный проводник для выбора .GalaxyClumsy файла */
    private void openConfigPicker() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            // Уточняем для системного пикера, что мы ждём именно текстовые/octet-stream файлы
            i.putExtra(Intent.EXTRA_MIME_TYPES,
                new String[]{ "application/octet-stream", "application/json", "text/plain", "*/*" });
            startActivityForResult(Intent.createChooser(i, "Выберите .GalaxyClumsy файл"), REQ_PICK_CONFIG);
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось открыть проводник", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_CONFIG && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            importConfigFromUri(uri);
        }
    }

    /** Импортирует конфиг из выбранного URI */
    private void importConfigFromUri(Uri uri) {
        // 1) Проверка расширения по DISPLAY_NAME
        String displayName = queryDisplayName(uri);
        if (displayName == null) displayName = "";
        if (!displayName.toLowerCase().endsWith(CFG_EXT.toLowerCase())) {
            Toast.makeText(this,
                "Можно загружать только файлы " + CFG_EXT,
                Toast.LENGTH_LONG).show();
            return;
        }

        // 2) Чтение файла
        String content;
        try {
            java.io.InputStream is = getContentResolver().openInputStream(uri);
            if (is == null) throw new java.io.IOException("openInputStream() == null");
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            int total = 0;
            while ((n = is.read(buf)) > 0) {
                total += n;
                if (total > 256 * 1024) { // защита: не более 256КБ
                    is.close();
                    Toast.makeText(this, "Файл слишком большой", Toast.LENGTH_LONG).show();
                    return;
                }
                bo.write(buf, 0, n);
            }
            is.close();
            content = bo.toString("UTF-8");
        } catch (Exception e) {
            Toast.makeText(this,
                "Не удалось прочитать файл: " + e.getMessage(),
                Toast.LENGTH_LONG).show();
            return;
        }

        // 3) Парсинг JSON и создание Config
        Config c;
        try {
            c = parseGalaxyClumsy(content);
        } catch (Exception e) {
            Toast.makeText(this,
                "Файл повреждён или имеет неправильный формат",
                Toast.LENGTH_LONG).show();
            return;
        }
        if (c == null || c.name == null || c.name.trim().isEmpty()) {
            Toast.makeText(this,
                "Конфиг не содержит обязательных полей",
                Toast.LENGTH_LONG).show();
            return;
        }

        // 4) Имя — гарантируем уникальность
        String baseName = c.name;
        int suffix = 1;
        while (nameExists(c.name)) {
            c.name = baseName + " (" + (++suffix) + ")";
        }

        // 5) Показываем диалог подтверждения с именем, описанием и VPN
        showImportConfirmDialog(c);
    }

    /** Диалог подтверждения импорта — показывает название, описание и VPN конфига */
    private void showImportConfirmDialog(final Config c) {
        final Dialog dlg = new Dialog(this);
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundResource(R.drawable.bg_dialog_neon);
        outer.setPadding(dp(22), dp(22), dp(22), dp(20));

        // Заголовок
        TextView title = new TextView(this);
        title.setText("ИМПОРТ КОНФИГА");
        title.setTextSize(17);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.26f);
        title.setShadowLayer(14, 0, 0, 0xFF00FF9D);
        outer.addView(title);

        // Подзаголовок
        TextView subTitle = new TextView(this);
        subTitle.setText("// IMPORT CONFIG PROFILE");
        subTitle.setTextSize(10);
        subTitle.setTextColor(0xFFFF1E4E);
        subTitle.setTypeface(Typeface.MONOSPACE);
        subTitle.setLetterSpacing(0.2f);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(MATCH, WRAP);
        stp.topMargin = dp(4);
        stp.bottomMargin = dp(18);
        subTitle.setLayoutParams(stp);
        outer.addView(subTitle);

        // Карточка с данными конфига
        LinearLayout infoCard = new LinearLayout(this);
        infoCard.setOrientation(LinearLayout.VERTICAL);
        android.graphics.drawable.GradientDrawable cardBg = new android.graphics.drawable.GradientDrawable();
        cardBg.setColor(0xFF0C1014);
        cardBg.setCornerRadius(dp(12));
        cardBg.setStroke(dp(1), 0xFF17202A);
        infoCard.setBackground(cardBg);
        infoCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        cardLp.bottomMargin = dp(20);
        infoCard.setLayoutParams(cardLp);

        // Название
        infoCard.addView(importInfoRow("Название:", c.name, 0xFFFFFFFF));

        // Описание (если есть)
        if (c.description != null && !c.description.trim().isEmpty()) {
            infoCard.addView(importInfoRow("Описание:", c.description, 0xFF6C7885));
        }

        // VPN
        String vpnDisplay = (c.vpn != null && !c.vpn.trim().isEmpty())
            ? c.vpn.trim()
            : VpnPickerActivity.VPN_DEFAULT;
        infoCard.addView(importInfoRow("VPN:", vpnDisplay, 0xFF00CFFF));

        outer.addView(infoCard);

        // Кнопки
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        Button btnCancel = new Button(this);
        btnCancel.setText("ОТМЕНА");
        btnCancel.setTextSize(13);
        btnCancel.setLetterSpacing(0.22f);
        btnCancel.setTypeface(null, Typeface.BOLD);
        btnCancel.setTextColor(0xFFB8C4D0);
        btnCancel.setBackgroundResource(R.drawable.btn_neon_outline);
        btnCancel.setStateListAnimator(null);
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        cLp.rightMargin = dp(10);
        btnCancel.setLayoutParams(cLp);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { dlg.dismiss(); }
        });

        Button btnImport = new Button(this);
        btnImport.setText("ДОБАВИТЬ");
        btnImport.setTextSize(13);
        btnImport.setLetterSpacing(0.24f);
        btnImport.setTypeface(null, Typeface.BOLD);
        btnImport.setTextColor(0xFF001A0E);
        btnImport.setBackgroundResource(R.drawable.btn_neon_green);
        btnImport.setStateListAnimator(null);
        btnImport.setLayoutParams(new LinearLayout.LayoutParams(0, dp(50), 1.2f));
        btnImport.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dlg.dismiss();
                configs.add(c);
                saveConfigs();
                refreshList();
                Toast.makeText(ConfigsActivity.this,
                    "Импортировано: " + c.name,
                    Toast.LENGTH_SHORT).show();
            }
        });

        btnRow.addView(btnCancel);
        btnRow.addView(btnImport);
        outer.addView(btnRow);

        dlg.setContentView(outer);
        android.view.Window w = dlg.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xCC000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            lp.width  = (int)(getResources().getDisplayMetrics().widthPixels * 0.90f);
            lp.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
        }
        dlg.show();
    }

    /** Строка «ключ: значение» для карточки импорта */
    private LinearLayout importInfoRow(String label, String value, int valueColor) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rowLp.bottomMargin = dp(8);
        row.setLayoutParams(rowLp);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(12);
        tvLabel.setTextColor(0xFF6C7885);
        tvLabel.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(WRAP, WRAP);
        llp.rightMargin = dp(8);
        tvLabel.setLayoutParams(llp);

        TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(13);
        tvValue.setTextColor(valueColor);
        tvValue.setTypeface(null, Typeface.BOLD);
        if (valueColor == 0xFF00CFFF) {
            tvValue.setShadowLayer(6, 0, 0, 0xFF00CFFF);
        }
        tvValue.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));

        row.addView(tvLabel);
        row.addView(tvValue);
        return row;
    }

    @SuppressWarnings("unused")
    private void importConfigFromUriLegacy(android.net.Uri uri) { /* kept for reference */ }

    private boolean nameExists(String n) {
        for (Config x : configs) if (x.name.equals(n)) return true;
        return false;
    }

    /** Получает DISPLAY_NAME для URI */
    private String queryDisplayName(Uri uri) {
        try {
            android.database.Cursor cur = getContentResolver().query(
                uri, new String[]{ android.provider.OpenableColumns.DISPLAY_NAME },
                null, null, null);
            if (cur != null) {
                try {
                    if (cur.moveToFirst()) {
                        int idx = cur.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                        if (idx >= 0) return cur.getString(idx);
                    }
                } finally { cur.close(); }
            }
        } catch (Exception ignored) {}
        // Fallback — последний сегмент пути
        String last = uri.getLastPathSegment();
        return last == null ? "" : last;
    }

    /** Простейший парсер JSON для .GalaxyClumsy без зависимостей. Поддерживает шифрованный формат. */
    private Config parseGalaxyClumsy(String json) throws Exception {
        org.json.JSONObject root = new org.json.JSONObject(json);

        // Проверяем: это зашифрованный конверт?
        boolean wasEncrypted = false;
        if (root.optInt("_e", 0) == 2) {
            // Новый формат: AES-256-GCM + PBKDF2
            try {
                String innerJson = decryptFromEnvelope(root);
                root = new org.json.JSONObject(innerJson);
                wasEncrypted = true;
            } catch (Exception e) {
                throw new Exception("Ошибка расшифровки (неверный ключ или файл повреждён)");
            }
        } else if (root.optInt("_e", 0) == 1) {
            // Старый формат: просто Base64 (legacy поддержка)
            String b64 = root.optString("_d", "");
            if (b64.isEmpty()) throw new Exception("encrypted data missing");
            byte[] decoded = android.util.Base64.decode(b64, android.util.Base64.NO_WRAP);
            String innerJson = new String(decoded, "UTF-8");
            root = new org.json.JSONObject(innerJson);
            wasEncrypted = true;
        }

        org.json.JSONObject o = root;
        String name = o.optString("name", "").trim();
        String desc = o.optString("description", "");
        if (name.isEmpty()) throw new Exception("missing name");

        Config c = new Config(name, desc);
        c.serverDelay           = o.optInt("server_delay", 0);
        c.clientDelay           = o.optInt("client_delay", 0);
        c.serverLoss            = o.optInt("server_loss", 0);
        c.clientLoss            = o.optInt("client_loss", 0);
        c.duration              = o.optInt("timer", 0);
        c.afterTimerMode        = o.optInt("after_timer_mode", 0);
        c.afterTimerDelayMs     = o.optInt("after_timer_delay_ms", 0);
        c.afterTimerDurationSec = o.optInt("after_timer_duration_sec", 3);
        c.clientSizeFilterMode  = o.optInt("client_sz_mode", 0);
        c.clientSizeMin         = o.optInt("client_sz_min", 0);
        c.clientSizeMax         = o.optInt("client_sz_max", 1500);
        c.serverSizeFilterMode  = o.optInt("server_sz_mode", 0);
        c.serverSizeMin         = o.optInt("server_sz_min", 0);
        c.serverSizeMax         = o.optInt("server_sz_max", 1500);
        c.vpn                   = o.optString("vpn", "");
        c.installed             = false;
        c.importedEncrypted     = wasEncrypted; // зашифрованный конфиг — редактирование закрыто
        c.sendEncrypted         = false;        // локально НЕ шифруем — только при экспорте

        // ── Пошаговый режим ──────────────────────────────────────────
        c.configMode     = o.optInt("config_mode", 0);
        c.stepsAfterMode = o.optInt("steps_after_mode", 0);
        c.steps = new ArrayList<Step>();
        org.json.JSONArray stepsArr = o.optJSONArray("steps");
        if (stepsArr != null) {
            for (int i = 0; i < stepsArr.length(); i++) {
                org.json.JSONObject so = stepsArr.optJSONObject(i);
                if (so == null) continue;
                Step s = new Step();
                s.clientDelay          = so.optInt("client_delay", 0);
                s.clientLoss           = so.optInt("client_loss", 0);
                s.clientBufferMode     = so.optInt("client_buffer", 0);
                s.serverDelay          = so.optInt("server_delay", 0);
                s.serverLoss           = so.optInt("server_loss", 0);
                s.serverBufferMode     = so.optInt("server_buffer", 0);
                s.clientSizeFilterMode = so.optInt("client_sz_mode", 0);
                s.clientSizeMin        = so.optInt("client_sz_min", 0);
                s.clientSizeMax        = so.optInt("client_sz_max", 1500);
                s.serverSizeFilterMode = so.optInt("server_sz_mode", 0);
                s.serverSizeMin        = so.optInt("server_sz_min", 0);
                s.serverSizeMax        = so.optInt("server_sz_max", 1500);
                s.duration              = so.optInt("duration", 0);
                c.steps.add(s);
            }
        }
        if (c.configMode == 1 && c.steps.isEmpty()) {
            c.steps.add(new Step());
        }

        // Лёгкая валидация диапазонов
        if (c.serverDelay < 0)           c.serverDelay = 0;
        if (c.clientDelay < 0)           c.clientDelay = 0;
        if (c.serverLoss  < 0)           c.serverLoss  = 0;
        if (c.clientLoss  < 0)           c.clientLoss  = 0;
        if (c.serverLoss  > 100)         c.serverLoss  = 100;
        if (c.clientLoss  > 100)         c.clientLoss  = 100;
        if (c.duration    < 0)           c.duration    = 0;
        if (c.afterTimerDelayMs < 0)     c.afterTimerDelayMs = 0;
        if (c.afterTimerDurationSec < 1) c.afterTimerDurationSec = 1;
        return c;
    }

    /** Сохраняет VPN из конфига в SharedPreferences VpnPickerActivity */
    private void applyVpnFromConfig(String vpnName) {
        // Если VPN не задан — применяем стандартный (не игнорируем!)
        String name = (vpnName != null && !vpnName.trim().isEmpty())
                ? vpnName.trim()
                : VpnPickerActivity.VPN_DEFAULT;
        // Принимаем только известные значения (защита от мусора)
        if (!VpnPickerActivity.VPN_DEFAULT.equals(name)
                && !VpnPickerActivity.VPN_QUANTUM.equals(name)
                && !VpnPickerActivity.VPN_SHADOWROUTE.equals(name)) {
            name = VpnPickerActivity.VPN_DEFAULT;
        }
        getSharedPreferences(VpnPickerActivity.PREFS_VPN, MODE_PRIVATE)
            .edit()
            .putString(VpnPickerActivity.KEY_VPN, name)
            .commit(); // commit() вместо apply() — гарантированная синхронная запись
    }

    /** Безопасное JSON-экранирование строки */
    private String jsonStr(String s) {
        if (s == null) return "\"\"";
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n");  break;
                case '\r': sb.append("\\r");  break;
                case '\t': sb.append("\\t");  break;
                default:
                    if (ch < 0x20) sb.append(String.format("\\u%04x", (int) ch));
                    else sb.append(ch);
            }
        }
        sb.append("\"");
        return sb.toString();
    }

    /**
     * Шифрует JSON строку с помощью AES-256-GCM + PBKDF2WithHmacSHA256.
     * Возвращает JSON-конверт вида:
     *   {"_e":2,"_s":"<base64_salt>","_iv":"<base64_iv>","_d":"<base64_ciphertext>"}
     * Каждый вызов генерирует уникальные соль и IV через SecureRandom.
     */
    private String encryptToEnvelope(String json) throws Exception {
        byte[] salt = new byte[ENC_SALT_LEN];
        byte[] iv   = new byte[ENC_IV_LEN];
        new SecureRandom().nextBytes(salt);
        new SecureRandom().nextBytes(iv);

        // Генерируем ключ через PBKDF2 — медленно, но надёжно
        SecretKeyFactory kf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        PBEKeySpec spec = new PBEKeySpec(ENC_PASS.toCharArray(), salt, ENC_ITER, ENC_KEY_LEN);
        SecretKey rawKey = kf.generateSecret(spec);
        SecretKeySpec aesKey = new SecretKeySpec(rawKey.getEncoded(), "AES");
        spec.clearPassword();

        // AES-256-GCM шифрование
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, aesKey, new GCMParameterSpec(ENC_TAG_BITS, iv));
        byte[] ct = cipher.doFinal(json.getBytes("UTF-8"));

        String s64  = android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP);
        String iv64 = android.util.Base64.encodeToString(iv,   android.util.Base64.NO_WRAP);
        String ct64 = android.util.Base64.encodeToString(ct,   android.util.Base64.NO_WRAP);

        return "{\"_e\":2,\"_s\":\"" + s64 + "\",\"_iv\":\"" + iv64 + "\",\"_d\":\"" + ct64 + "\"}\n";
    }

    /**
     * Расшифровывает JSON-конверт формата v2 (AES-256-GCM + PBKDF2).
     * Бросает исключение если ключ неверный или файл повреждён (GCM authentication fails).
     */
    private String decryptFromEnvelope(org.json.JSONObject root) throws Exception {
        byte[] salt = android.util.Base64.decode(root.getString("_s"),  android.util.Base64.NO_WRAP);
        byte[] iv   = android.util.Base64.decode(root.getString("_iv"), android.util.Base64.NO_WRAP);
        byte[] ct   = android.util.Base64.decode(root.getString("_d"),  android.util.Base64.NO_WRAP);

        SecretKeyFactory kf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        PBEKeySpec spec = new PBEKeySpec(ENC_PASS.toCharArray(), salt, ENC_ITER, ENC_KEY_LEN);
        SecretKey rawKey = kf.generateSecret(spec);
        SecretKeySpec aesKey = new SecretKeySpec(rawKey.getEncoded(), "AES");
        spec.clearPassword();

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, aesKey, new GCMParameterSpec(ENC_TAG_BITS, iv));
        byte[] plain = cipher.doFinal(ct); // бросит AEADBadTagException если tampered
        return new String(plain, "UTF-8");
    }

    /** Преобразует название конфига в безопасное имя файла */
    private String sanitizeFilename(String name) {
        if (name == null) return "config";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < name.length(); i++) {
            char ch = name.charAt(i);
            if (Character.isLetterOrDigit(ch) || ch == '_' || ch == '-' || ch == '.') {
                sb.append(ch);
            } else if (ch == ' ') {
                sb.append('_');
            }
        }
        String out = sb.toString();
        if (out.isEmpty()) out = "config";
        // Ограничим длину
        if (out.length() > 60) out = out.substring(0, 60);
        return out;
    }
}
