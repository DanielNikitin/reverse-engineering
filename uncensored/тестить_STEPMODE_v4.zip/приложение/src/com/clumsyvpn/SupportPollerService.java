package com.clumsyvpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * SupportPollerService — фоновый сервис push-уведомлений для онлайн помощи.
 *
 * Для пользователя: каждые 10 сек проверяет /support/user/check-new.
 *   Если admin ответил — push: "Администратор ответил на ваш запрос"
 *
 * Для администратора: каждые 10 сек проверяет /support/admin/check-new.
 *   Если user написал — push: "Новая заявка в онлайн помощи"
 */
public class SupportPollerService extends Service {

    public static final String ACTION_NEW_ADMIN_MSG  = "com.clumsyvpn.ACTION_NEW_ADMIN_MSG";
    public static final String ACTION_NEW_USER_MSG   = "com.clumsyvpn.ACTION_NEW_USER_MSG";
    public static final String EXTRA_CHAT_ID         = "support_chat_id";
    public static final String EXTRA_MSG_TEXT        = "support_msg_text";

    private static final String CH_ID_USER  = "cvpn_support_user";
    private static final String CH_ID_ADMIN = "cvpn_support_admin";
    private static final int    NOTIF_ID_USER  = 5001;
    private static final int    NOTIF_ID_ADMIN = 5002;
    private static final long   POLL_INTERVAL  = 10_000L;

    // SharedPreferences keys — track last seen timestamps
    static final String PREFS_SUPPORT       = "support_poller_prefs";
    static final String KEY_LAST_ADMIN_TS   = "last_admin_msg_ts";   // for user
    static final String KEY_LAST_USER_TS    = "last_user_msg_ts";    // for admin

    private Handler  handler;
    private Runnable pollRunnable;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannels();
        handler = new Handler();
        pollRunnable = new Runnable() {
            public void run() {
                poll();
                handler.postDelayed(this, POLL_INTERVAL);
            }
        };
        handler.postDelayed(pollRunnable, 5000); // first poll after 5s
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (handler != null && pollRunnable != null)
            handler.removeCallbacks(pollRunnable);
    }

    private void poll() {
        SharedPreferences authPrefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        final String login    = authPrefs.getString(AuthActivity.KEY_LOGIN, "");
        final String password = authPrefs.getString(AuthActivity.KEY_PASSWORD, "");
        if (login.isEmpty()) return;

        final boolean isAdmin = login.equals("admin");

        new Thread(new Runnable() {
            public void run() {
                try {
                    if (isAdmin) {
                        pollAsAdmin(login, password);
                    } else {
                        pollAsUser(login, password);
                    }
                } catch (Exception ignored) {}
            }
        }).start();
    }

    // Пользователь — проверяем, ответил ли администратор
    private void pollAsUser(String login, String password) throws Exception {
        SharedPreferences prefs = getSharedPreferences(PREFS_SUPPORT, MODE_PRIVATE);
        long lastTs = prefs.getLong(KEY_LAST_ADMIN_TS, 0);

        String body = "{\"login\":\"" + esc(login) + "\",\"password\":\"" + esc(password) +
                      "\",\"since\":" + lastTs + "}";
        String resp = httpPost(AuthActivity.SERVER_URL + "/support/user/check-new", body);
        if (resp == null) return;

        org.json.JSONObject j = new org.json.JSONObject(resp);
        org.json.JSONObject msg = j.optJSONObject("newAdminMsg");
        if (msg == null) return;

        long ts = msg.optLong("timestamp", 0);
        if (ts <= lastTs) return;

        prefs.edit().putLong(KEY_LAST_ADMIN_TS, ts).apply();

        String chatId = msg.optString("chatId", "");
        String text   = msg.optString("text", "Администратор ответил");

        // Broadcast для in-app баннера (если приложение открыто)
        Intent broadcast = new Intent(ACTION_NEW_ADMIN_MSG);
        broadcast.putExtra(EXTRA_CHAT_ID, chatId);
        broadcast.putExtra(EXTRA_MSG_TEXT, text);
        sendBroadcast(broadcast);

        // Push уведомление
        showPushNotification(
            CH_ID_USER, NOTIF_ID_USER,
            "Онлайн помощь",
            "Администратор ответил на ваш запрос",
            SupportListActivity.class
        );
    }

    // Администратор — проверяем, написал ли пользователь
    private void pollAsAdmin(String login, String password) throws Exception {
        SharedPreferences prefs = getSharedPreferences(PREFS_SUPPORT, MODE_PRIVATE);
        long lastTs = prefs.getLong(KEY_LAST_USER_TS, 0);

        String body = "{\"adminLogin\":\"" + esc(login) + "\",\"adminPassword\":\"" + esc(password) +
                      "\",\"since\":" + lastTs + "}";
        String resp = httpPost(AuthActivity.SERVER_URL + "/support/admin/check-new", body);
        if (resp == null) return;

        org.json.JSONObject j = new org.json.JSONObject(resp);
        org.json.JSONObject msg = j.optJSONObject("newUserMsg");
        if (msg == null) return;

        long ts = msg.optLong("timestamp", 0);
        if (ts <= lastTs) return;

        prefs.edit().putLong(KEY_LAST_USER_TS, ts).apply();

        String userLogin = msg.optString("userLogin", "Пользователь");
        String text      = msg.optString("text", "");

        // Broadcast для in-app баннера (если AdminPanel/AdminSupportChat открыты)
        Intent broadcast = new Intent(ACTION_NEW_USER_MSG);
        broadcast.putExtra(EXTRA_MSG_TEXT, text);
        sendBroadcast(broadcast);

        // Push уведомление
        showPushNotification(
            CH_ID_ADMIN, NOTIF_ID_ADMIN,
            "Онлайн помощь",
            "Новая заявка от " + userLogin,
            AdminPanelActivity.class
        );
    }

    private void showPushNotification(String channelId, int notifId,
                                      String title, String text,
                                      Class<?> targetActivity) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;

        PendingIntent pi = PendingIntent.getActivity(
            this, notifId,
            new Intent(this, targetActivity)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP),
            Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification notif;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notif = new Notification.Builder(this, channelId)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        } else {
            notif = new Notification.Builder(this)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        }

        nm.notify(notifId, notif);
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;

            NotificationChannel chUser = new NotificationChannel(
                CH_ID_USER, "Ответы поддержки", NotificationManager.IMPORTANCE_HIGH);
            chUser.setDescription("Уведомления об ответах администратора");
            nm.createNotificationChannel(chUser);

            NotificationChannel chAdmin = new NotificationChannel(
                CH_ID_ADMIN, "Заявки поддержки", NotificationManager.IMPORTANCE_HIGH);
            chAdmin.setDescription("Уведомления о новых заявках пользователей");
            nm.createNotificationChannel(chAdmin);
        }
    }

    private String httpPost(String urlStr, String jsonBody) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        OutputStream os = conn.getOutputStream();
        os.write(jsonBody.getBytes("UTF-8"));
        os.close();
        int code = conn.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
            code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        conn.disconnect();
        return sb.toString();
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
