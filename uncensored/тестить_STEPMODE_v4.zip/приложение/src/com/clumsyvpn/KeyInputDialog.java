package com.clumsyvpn;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;

public class KeyInputDialog {

    public interface Callback {
        void onKeyAccepted(String key);
        void onCancelled();
    }

    public static void show(final Context ctx, final String deviceId, final String login, final Callback callback) {
        final Dialog d = new Dialog(ctx);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(ctx, 22), dp(ctx, 22), dp(ctx, 22), dp(ctx, 18));
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(ctx, 16));
            bg.setColor(0xFF0C1014);
            bg.setStroke(1, 0xFF00E5FF);
            root.setBackground(bg);
        }

        TextView tvIcon = new TextView(ctx);
        tvIcon.setText("🔑");
        tvIcon.setTextSize(28);
        tvIcon.setGravity(Gravity.CENTER);
        root.addView(tvIcon);

        space(root, ctx, 8);

        TextView tvTitle = new TextView(ctx);
        tvTitle.setText("Введите ключ доступа");
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        space(root, ctx, 4);

        TextView tvSub = new TextView(ctx);
        tvSub.setText("Для продолжения введите ключ");
        tvSub.setTextSize(12);
        tvSub.setTextColor(0xFF6C7885);
        tvSub.setGravity(Gravity.CENTER);
        root.addView(tvSub);

        space(root, ctx, 16);

        final EditText etKey = new EditText(ctx);
        etKey.setHint("Ключ доступа");
        etKey.setHintTextColor(0xFF3A4654);
        etKey.setTextColor(0xFFFFFFFF);
        etKey.setTextSize(14);
        etKey.setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12));
        etKey.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(ctx, 10));
            bg.setColor(0xFF080B0E);
            bg.setStroke(1, 0xFF17202A);
            etKey.setBackground(bg);
        }
        root.addView(etKey);

        final TextView tvError = new TextView(ctx);
        tvError.setTextSize(12);
        tvError.setTextColor(0xFFFF1E4E);
        tvError.setGravity(Gravity.CENTER);
        tvError.setVisibility(View.GONE);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        elp.topMargin = dp(ctx, 6);
        tvError.setLayoutParams(elp);
        root.addView(tvError);

        space(root, ctx, 18);

        LinearLayout btns = new LinearLayout(ctx);
        btns.setOrientation(LinearLayout.HORIZONTAL);

        final TextView btnCancel = makeBtn(ctx, "Отмена", 0xFF17202A, 0xFFB8C4D0);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp1.rightMargin = dp(ctx, 8);
        btnCancel.setLayoutParams(lp1);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                callback.onCancelled();
            }
        });
        btns.addView(btnCancel);

        // Фиксированная высота фрейма = высота кнопки, чтобы спиннер не уезжал
        final int btnHeight = dp(ctx, 44);

        final FrameLayout checkFrame = new FrameLayout(ctx);
        checkFrame.setLayoutParams(new LinearLayout.LayoutParams(0, btnHeight, 1f));

        final TextView btnCheck = makeBtn(ctx, "Проверить", 0xFF00E5FF, 0xFF000000);
        btnCheck.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        checkFrame.addView(btnCheck);

        final ProgressBar spinner = new ProgressBar(ctx);
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(dp(ctx, 28), dp(ctx, 28));
        slp.gravity = Gravity.CENTER;
        spinner.setLayoutParams(slp);
        spinner.setVisibility(View.GONE);
        checkFrame.addView(spinner);

        btns.addView(checkFrame);
        root.addView(btns);

        btnCheck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final String key = etKey.getText().toString().trim();
                if (key.isEmpty()) {
                    tvError.setText("Введите ключ");
                    tvError.setVisibility(View.VISIBLE);
                    return;
                }
                tvError.setVisibility(View.GONE);
                btnCheck.setVisibility(View.GONE);
                spinner.setVisibility(View.VISIBLE);
                btnCancel.setEnabled(false);

                new Thread(new Runnable() {
                    public void run() {
                        try {
                            String body = "{\"key\":\"" + esc(key) + "\",\"deviceId\":\"" + esc(deviceId) + "\",\"login\":\"" + esc(login) + "\"}";
                            String resp = httpPost(AuthActivity.SERVER_URL + "/keys/validate", body);
                            final boolean ok = resp != null && resp.contains("\"status\":\"ok\"");
                            final boolean alreadyHasKey = resp != null && resp.contains("already_has_key");
                            final boolean isDeactivated = resp != null && resp.contains("\"deactivated\"");
                            final boolean isKeyDeleted = resp != null && resp.contains("\"key_deleted\"");
                            final boolean isAccountLimit = resp != null && resp.contains("\"account_limit\"");
                            final String errMsg = extractMessage(resp);
                            new Handler(ctx.getMainLooper()).post(new Runnable() {
                                public void run() {
                                    spinner.setVisibility(View.GONE);
                                    btnCancel.setEnabled(true);
                                    if (ok) {
                                        d.dismiss();
                                        callback.onKeyAccepted(key);
                                    } else if (alreadyHasKey) {
                                        tvError.setText("У вас уже есть активный ключ");
                                        tvError.setVisibility(View.VISIBLE);
                                        btnCheck.setVisibility(View.VISIBLE);
                                        btnCheck.setEnabled(false);
                                    } else if (isAccountLimit) {
                                        btnCheck.setVisibility(View.VISIBLE);
                                        String msg = (errMsg != null && !errMsg.isEmpty())
                                            ? errMsg
                                            : "Вы превышаете лимит на создание аккаунтов или вход. Максимальное количество: 3";
                                        tvError.setText(msg);
                                        tvError.setTextColor(0xFFFF1E4E);
                                        tvError.setVisibility(View.VISIBLE);
                                    } else if (isKeyDeleted) {
                                        btnCheck.setVisibility(View.VISIBLE);
                                        String msg = "Ключ был удалён администратором. Можете ввести только новый ключ.";
                                        tvError.setText(msg);
                                        tvError.setTextColor(0xFFFF1E4E);
                                        tvError.setVisibility(View.VISIBLE);
                                    } else if (isDeactivated) {
                                        btnCheck.setVisibility(View.VISIBLE);
                                        btnCheck.setEnabled(true);
                                        String msg = (errMsg != null && !errMsg.isEmpty()) ? errMsg : "Ваш ключ деактивирован администратором.";
                                        tvError.setText(msg);
                                        tvError.setTextColor(0xFFFF6B00);
                                        tvError.setVisibility(View.VISIBLE);
                                    } else {
                                        btnCheck.setVisibility(View.VISIBLE);
                                        String msg = (errMsg != null && !errMsg.isEmpty()) ? errMsg : "Ключ недействителен";
                                        tvError.setText(msg);
                                        tvError.setVisibility(View.VISIBLE);
                                    }
                                }
                            });
                        } catch (Exception e) {
                            new Handler(ctx.getMainLooper()).post(new Runnable() {
                                public void run() {
                                    spinner.setVisibility(View.GONE);
                                    btnCheck.setVisibility(View.VISIBLE);
                                    btnCancel.setEnabled(true);
                                    tvError.setText("Ошибка соединения");
                                    tvError.setVisibility(View.VISIBLE);
                                }
                            });
                        }
                    }
                }).start();
            }
        });

        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            int screenW = ctx.getResources().getDisplayMetrics().widthPixels;
            lp.width  = (int)(screenW * 0.88f);
            lp.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
        }
        d.show();
    }

    private static TextView makeBtn(Context ctx, String text, int bgColor, int textColor) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextSize(13);
        tv.setTextColor(textColor);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(ctx, 10));
        bg.setColor(bgColor);
        tv.setBackground(bg);
        return tv;
    }

    private static void space(LinearLayout parent, Context ctx, int dpVal) {
        View v = new View(ctx);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, dpVal)));
        parent.addView(v);
    }

    private static int dp(Context ctx, int val) {
        return (int)(val * ctx.getResources().getDisplayMetrics().density + 0.5f);
    }

    private static String httpPost(String urlStr, String body) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        OutputStream os = conn.getOutputStream();
        os.write(body.getBytes("UTF-8"));
        os.flush(); os.close();
        int code = conn.getResponseCode();
        java.io.InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        if (stream == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close(); conn.disconnect();
        return sb.toString();
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String extractField(String json, String field) {
        try {
            if (json == null) return null;
            String key = "\"" + field + "\"";
            int idx = json.indexOf(key);
            if (idx < 0) return null;
            int colon = json.indexOf(':', idx + key.length());
            if (colon < 0) return null;
            int start = json.indexOf('"', colon + 1);
            if (start < 0) return null;
            int end = json.indexOf('"', start + 1);
            if (end < 0) return null;
            return json.substring(start + 1, end);
        } catch (Exception e) { return null; }
    }

    private static String extractMessage(String json) {
        try {
            if (json == null) return null;
            org.json.JSONObject obj = new org.json.JSONObject(json);
            return obj.optString("message", null);
        } catch (Exception e) {
            return extractField(json, "message");
        }
    }
}
