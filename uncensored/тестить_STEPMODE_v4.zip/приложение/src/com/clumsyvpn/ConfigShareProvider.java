package com.clumsyvpn;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Минимальный ContentProvider для безопасного шаринга файлов
 * через content:// URI без зависимостей от support/androidx FileProvider.
 *
 * URI формат: content://com.clumsyvpn.fileprovider/share/<filename>
 * Файл должен находиться в getCacheDir()/share/<filename>.
 */
public class ConfigShareProvider extends ContentProvider {

    public static final String AUTHORITY = "com.clumsyvpn.fileprovider";
    public static final String DIR_NAME  = "share";

    private static final UriMatcher MATCHER = new UriMatcher(UriMatcher.NO_MATCH);
    private static final int CODE_FILE = 1;
    static {
        MATCHER.addURI(AUTHORITY, DIR_NAME + "/*", CODE_FILE);
    }

    /** Возвращает content:// URI для файла, лежащего в cacheDir/share/<name>. */
    public static Uri uriForFile(String fileName) {
        return new Uri.Builder()
                .scheme("content")
                .authority(AUTHORITY)
                .appendPath(DIR_NAME)
                .appendPath(fileName)
                .build();
    }

    /** Возвращает реальный File в cacheDir/share/<name>. Создаёт каталог при необходимости. */
    public static File fileFor(android.content.Context ctx, String fileName) {
        File dir = new File(ctx.getCacheDir(), DIR_NAME);
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, fileName);
    }

    @Override
    public boolean onCreate() { return true; }

    private File resolve(Uri uri) throws FileNotFoundException {
        if (MATCHER.match(uri) != CODE_FILE) {
            throw new FileNotFoundException("Unknown URI: " + uri);
        }
        String name = uri.getLastPathSegment();
        if (name == null || name.contains("/") || name.contains("..")) {
            throw new FileNotFoundException("Invalid name: " + name);
        }
        File f = fileFor(getContext(), name);
        if (!f.exists()) throw new FileNotFoundException("File not found: " + name);
        return f;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = resolve(uri);
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        File f;
        try { f = resolve(uri); } catch (FileNotFoundException e) { return null; }

        String[] cols = projection != null ? projection
                : new String[]{ OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE };
        Object[] vals = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            String c = cols[i];
            if (OpenableColumns.DISPLAY_NAME.equals(c)) vals[i] = f.getName();
            else if (OpenableColumns.SIZE.equals(c))    vals[i] = f.length();
            else vals[i] = null;
        }
        MatrixCursor cur = new MatrixCursor(cols, 1);
        cur.addRow(vals);
        return cur;
    }

    @Override
    public String getType(Uri uri) {
        return "application/octet-stream";
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException("Read-only provider");
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("Read-only provider");
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("Read-only provider");
    }
}
