package com.clumsyvpn;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * SupportListActivity — список чатов поддержки пользователя.
 * Открывается из FaqActivity по нажатию FAB.
 */
public class SupportListActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final String PREFS_SUPPORT    = "support_prefs";
    private static final String KEY_COOLDOWN_UNTIL = "chat_cooldown_until";

    private String serverUrl;
    private String userLogin;
    private String userPassword;

    private LinearLayout chatListContainer;
    private TextView     tvEmptyHint;

    private AccountStatusMonitor accountStatusMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        userLogin    = prefs.getString(AuthActivity.KEY_LOGIN, "");
        userPassword = prefs.getString(AuthActivity.KEY_PASSWORD, "");
        serverUrl    = AuthActivity.SERVER_URL;

        accountStatusMonitor = new AccountStatusMonitor(this);

        buildUI();
        loadChats();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadChats();
        accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
    }

    // ═══════════════════════════════════════
    //  BUILD UI
    // ═══════════════════════════════════════
    private void buildUI() {
        FrameLayout root = new FrameLayout(this);
        root.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        root.setBackgroundColor(0xFF030507);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));

        // Header
        main.addView(buildHeader());

        // Divider
        View div = new View(this);
        div.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        div.setBackgroundColor(0xFF17202A);
        main.addView(div);

        // Subtitle
        LinearLayout subtitle = new LinearLayout(this);
        subtitle.setOrientation(LinearLayout.VERTICAL);
        subtitle.setPadding(dp(20), dp(16), dp(20), dp(8));

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Мои чаты с поддержкой");
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        subtitle.addView(tvTitle);

        TextView tvSub = new TextView(this);
        tvSub.setText("История ваших обращений в поддержку");
        tvSub.setTextSize(12);
        tvSub.setTextColor(0xFF6C7885);
        tvSub.setPadding(0, dp(4), 0, 0);
        subtitle.addView(tvSub);

        main.addView(subtitle);

        // Chat list
        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));
        

        chatListContainer = new LinearLayout(this);
        chatListContainer.setOrientation(LinearLayout.VERTICAL);
        chatListContainer.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        chatListContainer.setPadding(dp(16), dp(12), dp(16), dp(100));

        tvEmptyHint = new TextView(this);
        tvEmptyHint.setText("У вас пока нет чатов.\nНажмите + чтобы создать новый.");
        tvEmptyHint.setTextSize(14);
        tvEmptyHint.setTextColor(0xFF3A4654);
        tvEmptyHint.setGravity(Gravity.CENTER);
        tvEmptyHint.setPadding(0, dp(60), 0, 0);
        tvEmptyHint.setVisibility(View.GONE);
        chatListContainer.addView(tvEmptyHint);

        scroll.addView(chatListContainer);
        main.addView(scroll);

        root.addView(main);

        // FAB — floating action button (создать чат)
        root.addView(buildFab());

        setContentView(root);
    }

    private LinearLayout buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(62)));
        header.setPadding(dp(12), 0, dp(16), 0);
        header.setBackgroundColor(0xFF07090C);

        // Back
        FrameLayout btnBackWrap = new FrameLayout(this);
        btnBackWrap.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        GradientDrawable backBg = new GradientDrawable();
        backBg.setShape(GradientDrawable.OVAL);
        backBg.setColor(0xFF0C1014);
        backBg.setStroke(1, 0xFF17202A);
        btnBackWrap.setBackground(backBg);

        TextView btnBack = new TextView(this);
        btnBack.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        btnBack.setText("‹");
        btnBack.setTextSize(24);
        btnBack.setTextColor(0xFF00FF9D);
        btnBack.setTypeface(null, Typeface.BOLD);
        btnBack.setGravity(Gravity.CENTER);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        btnBackWrap.addView(btnBack);
        header.addView(btnBackWrap);

        // Spacer
        View sp = new View(this);
        sp.setLayoutParams(new LinearLayout.LayoutParams(dp(12), 1));
        header.addView(sp);

        // Title group (centre)
        LinearLayout centerGroup = new LinearLayout(this);
        centerGroup.setOrientation(LinearLayout.HORIZONTAL);
        centerGroup.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams cgp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        cgp.gravity = Gravity.CENTER_VERTICAL;
        centerGroup.setLayoutParams(cgp);
        centerGroup.setGravity(Gravity.CENTER);

        // Support icon (custom SVG-style drawn with views)
        FrameLayout iconFrame = new FrameLayout(this);
        LinearLayout.LayoutParams iflp = new LinearLayout.LayoutParams(dp(28), dp(28));
        iflp.rightMargin = dp(8);
        iconFrame.setLayoutParams(iflp);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(0x2000FF9D);
        iconBg.setStroke(1, 0xFF00FF9D);
        iconFrame.setBackground(iconBg);
        TextView tvIconEmoji = new TextView(this);
        tvIconEmoji.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        tvIconEmoji.setText("🎧");
        tvIconEmoji.setTextSize(13);
        tvIconEmoji.setGravity(Gravity.CENTER);
        iconFrame.addView(tvIconEmoji);
        centerGroup.addView(iconFrame);

        TextView tvHeaderTitle = new TextView(this);
        tvHeaderTitle.setText("ОНЛАЙН ПОМОЩЬ");
        tvHeaderTitle.setTextSize(15);
        tvHeaderTitle.setTextColor(0xFFFFFFFF);
        tvHeaderTitle.setTypeface(null, Typeface.BOLD);
        tvHeaderTitle.setLetterSpacing(0.1f);
        centerGroup.addView(tvHeaderTitle);

        header.addView(centerGroup);

        return header;
    }

    private View buildFab() {
        // Round FAB in bottom-right
        FrameLayout.LayoutParams fabLp = new FrameLayout.LayoutParams(dp(60), dp(60));
        fabLp.gravity = Gravity.BOTTOM | Gravity.END;
        fabLp.rightMargin  = dp(20);
        fabLp.bottomMargin = dp(24);

        final LinearLayout fab = new LinearLayout(this);
        fab.setLayoutParams(fabLp);
        fab.setOrientation(LinearLayout.VERTICAL);
        fab.setGravity(Gravity.CENTER);

        GradientDrawable fabBg = new GradientDrawable();
        fabBg.setShape(GradientDrawable.OVAL);
        fabBg.setColor(0xFF00FF9D);
        // Glow effect via stroke
        fabBg.setStroke(dp(3), 0x5500FF9D);
        fab.setBackground(fabBg);

        // Support/headset icon drawn with text (emoji)
        TextView tvFabIcon = new TextView(this);
        tvFabIcon.setText("+");
        tvFabIcon.setTextSize(28);
        tvFabIcon.setTextColor(0xFF030507);
        tvFabIcon.setTypeface(null, Typeface.BOLD);
        tvFabIcon.setGravity(Gravity.CENTER);
        fab.addView(tvFabIcon);

        fab.setElevation(dp(6));

        // Pulse animation
        fab.setScaleX(1f);
        fab.setScaleY(1f);
        final android.animation.ObjectAnimator pulseX = android.animation.ObjectAnimator.ofFloat(fab, "scaleX", 1f, 1.08f, 1f);
        final android.animation.ObjectAnimator pulseY = android.animation.ObjectAnimator.ofFloat(fab, "scaleY", 1f, 1.08f, 1f);
        pulseX.setDuration(1600);
        pulseY.setDuration(1600);
        pulseX.setRepeatCount(android.animation.ObjectAnimator.INFINITE);
        pulseY.setRepeatCount(android.animation.ObjectAnimator.INFINITE);
        pulseX.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
        pulseY.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
        pulseX.start();
        pulseY.start();

        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Check cooldown
                long cooldownUntil = getSharedPreferences(PREFS_SUPPORT, MODE_PRIVATE)
                    .getLong(KEY_COOLDOWN_UNTIL, 0L);
                if (System.currentTimeMillis() < cooldownUntil) {
                    long remainMs = cooldownUntil - System.currentTimeMillis();
                    long remainH  = remainMs / 3600000;
                    long remainM  = (remainMs % 3600000) / 60000;
                    toast("Создать новый чат можно через " + remainH + "ч " + remainM + "мин");
                    return;
                }
                showCreateChatDialog();
            }
        });

        return fab;
    }

    // ═══════════════════════════════════════
    //  LOAD CHATS
    // ═══════════════════════════════════════
    private void loadChats() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"login\":\"" + esc(userLogin) + "\",\"password\":\"" + esc(userPassword) + "\"}";
                    String resp = httpPost(serverUrl + "/support/chats", body);
                    if (resp == null) return;
                    final JSONObject j = new JSONObject(resp);
                    final JSONArray chats = j.optJSONArray("chats");
                    // Check cooldown from server
                    final long cooldownUntil = j.optLong("cooldownUntil", 0L);
                    if (cooldownUntil > 0) {
                        getSharedPreferences(PREFS_SUPPORT, MODE_PRIVATE).edit()
                            .putLong(KEY_COOLDOWN_UNTIL, cooldownUntil).apply();
                    }

                    runOnUiThread(new Runnable() {
                        public void run() {
                            renderChats(chats);
                        }
                    });
                } catch (Exception e) {}
            }
        }).start();
    }

    private void renderChats(JSONArray chats) {
        chatListContainer.removeAllViews();

        if (chats == null || chats.length() == 0) {
            tvEmptyHint.setVisibility(View.VISIBLE);
            chatListContainer.addView(tvEmptyHint);
            return;
        }

        tvEmptyHint.setVisibility(View.GONE);

        for (int i = 0; i < chats.length(); i++) {
            try {
                final JSONObject chat = chats.getJSONObject(i);
                final String chatId   = chat.optString("id");
                final String chatName = chat.optString("name");
                final boolean archived = chat.optBoolean("archived", false);
                final boolean searching = chat.optBoolean("searching", false);
                final String lastMsg  = chat.optString("lastMessage", "");

                chatListContainer.addView(buildChatCard(chatId, chatName, archived, searching, lastMsg));
                chatListContainer.addView(spacerV(dp(10)));
            } catch (Exception ignored) {}
        }
    }

    private LinearLayout buildChatCard(final String chatId, final String chatName,
                                        final boolean archived, final boolean searching, final String lastMsg) {
        final LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setShape(GradientDrawable.RECTANGLE);
        cardBg.setCornerRadius(dp(14));
        cardBg.setColor(0xFF0C1014);
        if (archived) {
            cardBg.setStroke(1, 0xFF17202A);
        } else if (searching) {
            cardBg.setStroke(1, 0xFFFFD700);
        } else {
            cardBg.setStroke(1, 0xFF00FF9D);
        }
        card.setBackground(cardBg);

        // Chat icon
        FrameLayout iconWrap = new FrameLayout(this);
        LinearLayout.LayoutParams iwlp = new LinearLayout.LayoutParams(dp(44), dp(44));
        iwlp.rightMargin = dp(12);
        iconWrap.setLayoutParams(iwlp);
        GradientDrawable iwBg = new GradientDrawable();
        iwBg.setShape(GradientDrawable.OVAL);
        iwBg.setColor(archived ? 0xFF111820 : 0x2000FF9D);
        iwBg.setStroke(1, archived ? 0xFF17202A : 0xFF00FF9D);
        iconWrap.setBackground(iwBg);
        TextView tvChatIcon = new TextView(this);
        tvChatIcon.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        tvChatIcon.setText(archived ? "📁" : "💬");
        tvChatIcon.setTextSize(18);
        tvChatIcon.setGravity(Gravity.CENTER);
        iconWrap.addView(tvChatIcon);
        card.addView(iconWrap);

        // Text block
        LinearLayout textBlock = new LinearLayout(this);
        textBlock.setOrientation(LinearLayout.VERTICAL);
        textBlock.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));

        TextView tvName = new TextView(this);
        tvName.setText(chatName);
        tvName.setTextSize(14);
        tvName.setTextColor(archived ? 0xFF6C7885 : 0xFFFFFFFF);
        tvName.setTypeface(null, Typeface.BOLD);
        textBlock.addView(tvName);

        TextView tvStatus = new TextView(this);
        if (archived) {
            tvStatus.setText("Архивный чат");
            tvStatus.setTextColor(0xFF3A4654);
        } else if (searching) {
            tvStatus.setText("⏳ Поиск администратора...");
            tvStatus.setTextColor(0xFFFFD700);
        } else if (lastMsg.isEmpty()) {
            tvStatus.setText("Чат открыт");
            tvStatus.setTextColor(0xFF00FF9D);
        } else {
            tvStatus.setText(lastMsg.length() > 40 ? lastMsg.substring(0, 40) + "…" : lastMsg);
            tvStatus.setTextColor(0xFF6C7885);
        }
        tvStatus.setTextSize(12);
        textBlock.addView(tvStatus);

        card.addView(textBlock);

        // Arrow
        TextView tvArrow = new TextView(this);
        tvArrow.setText("›");
        tvArrow.setTextSize(22);
        tvArrow.setTextColor(archived ? 0xFF3A4654 : 0xFF00FF9D);
        tvArrow.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(tvArrow);

        card.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Animate press
                card.animate().scaleX(0.97f).scaleY(0.97f).setDuration(80).withEndAction(new Runnable() {
                    public void run() {
                        card.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                        Intent intent = new Intent(SupportListActivity.this, SupportChatActivity.class);
                        intent.putExtra(SupportChatActivity.EXTRA_CHAT_ID, chatId);
                        intent.putExtra(SupportChatActivity.EXTRA_CHAT_NAME, chatName);
                        startActivity(intent);
                    }
                }).start();
            }
        });

        return card;
    }

    // ═══════════════════════════════════════
    //  CREATE CHAT DIALOG
    // ═══════════════════════════════════════
    private void showCreateChatDialog() {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(20));
        bg.setColor(0xFF0C1014);
        bg.setStroke(2, 0xFF00FF9D);
        root.setBackground(bg);

        // Icon + title
        TextView tvIcon = new TextView(this);
        tvIcon.setText("🎧");
        tvIcon.setTextSize(32);
        tvIcon.setGravity(Gravity.CENTER);
        root.addView(tvIcon);

        root.addView(spacerV(dp(8)));

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Новый чат");
        tvTitle.setTextSize(18);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        root.addView(spacerV(dp(4)));

        TextView tvHint = new TextView(this);
        tvHint.setText("Придумайте название для чата");
        tvHint.setTextSize(12);
        tvHint.setTextColor(0xFF6C7885);
        tvHint.setGravity(Gravity.CENTER);
        root.addView(tvHint);

        root.addView(spacerV(dp(20)));

        final EditText etName = new EditText(this);
        etName.setHint("Название чата (макс. 20 симв.)");
        etName.setHintTextColor(0xFF3A4654);
        etName.setTextColor(0xFFFFFFFF);
        etName.setTextSize(15);
        etName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        etName.setPadding(dp(16), dp(14), dp(16), dp(14));
        etName.setSingleLine(true);
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setShape(GradientDrawable.RECTANGLE);
        inputBg.setCornerRadius(dp(12));
        inputBg.setColor(0xFF080B0E);
        inputBg.setStroke(1, 0xFF243340);
        etName.setBackground(inputBg);
        etName.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(etName);

        // Char counter
        final TextView tvCounter = new TextView(this);
        tvCounter.setText("0 / 20");
        tvCounter.setTextSize(11);
        tvCounter.setTextColor(0xFF3A4654);
        tvCounter.setGravity(Gravity.END);
        tvCounter.setPadding(0, dp(4), dp(2), 0);
        root.addView(tvCounter);

        etName.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {}
            public void afterTextChanged(android.text.Editable s) {
                tvCounter.setText(s.length() + " / 20");
                tvCounter.setTextColor(s.length() >= 18 ? 0xFFFF1E4E : 0xFF3A4654);
            }
        });

        root.addView(spacerV(dp(20)));

        // Buttons
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnCancel = buildBtn("Назад", 0xFF17202A, 0xFFB8C4D0);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        clp.rightMargin = dp(10);
        btnCancel.setLayoutParams(clp);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        btns.addView(btnCancel);

        TextView btnCreate = buildBtn("Создать", 0xFF00FF9D, 0xFF030507);
        btnCreate.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        btnCreate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String name = etName.getText().toString().trim();
                if (name.isEmpty()) { toast("Введите название"); return; }
                d.dismiss();
                createChat(name);
            }
        });
        btns.addView(btnCreate);

        root.addView(btns);

        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.88), WRAP);
        d.show();
    }

    // ═══════════════════════════════════════
    //  CREATE CHAT API
    // ═══════════════════════════════════════
    private void createChat(final String chatName) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"login\":\"" + esc(userLogin) + "\",\"password\":\"" + esc(userPassword) +
                        "\",\"chatName\":\"" + esc(chatName) + "\"}";
                    String resp = httpPost(serverUrl + "/support/chat/create", body);
                    if (resp == null) { runOnUiThread(new Runnable() { public void run() { toast("Ошибка соединения"); } }); return; }
                    final JSONObject j = new JSONObject(resp);
                    final String chatId = j.optString("chatId");
                    if (chatId == null || chatId.isEmpty()) {
                        runOnUiThread(new Runnable() { public void run() { toast("Ошибка создания чата"); } });
                        return;
                    }
                    runOnUiThread(new Runnable() {
                        public void run() {
                            loadChats();
                            // Open the new chat immediately
                            new Handler().postDelayed(new Runnable() {
                                public void run() {
                                    Intent intent = new Intent(SupportListActivity.this, SupportChatActivity.class);
                                    intent.putExtra(SupportChatActivity.EXTRA_CHAT_ID, chatId);
                                    intent.putExtra(SupportChatActivity.EXTRA_CHAT_NAME, chatName);
                                    startActivity(intent);
                                }
                            }, 300);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Ошибка"); } });
                }
            }
        }).start();
    }

    // ═══════════════════════════════════════
    //  UTILS
    // ═══════════════════════════════════════
    private TextView buildBtn(String text, int bgColor, int textColor) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(14);
        tv.setTextColor(textColor);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(12));
        bg.setColor(bgColor);
        tv.setBackground(bg);
        return tv;
    }

    private View spacerV(int height) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, height));
        return v;
    }

    private String httpPost(String urlStr, String jsonBody) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        OutputStream os = conn.getOutputStream();
        os.write(jsonBody.getBytes("UTF-8"));
        os.close();
        int code = conn.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
            code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        conn.disconnect();
        return sb.toString();
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density);
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(SupportListActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
