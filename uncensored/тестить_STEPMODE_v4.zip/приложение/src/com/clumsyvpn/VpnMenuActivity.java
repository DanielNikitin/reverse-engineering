package com.clumsyvpn;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * VpnMenuActivity V3 — VPN и прочее
 *
 * Изменения V3:
 *   • Удалён раздел «Настройки счётчика» — перенесён в CustomizeActivity.
 *   • Оставлен только чекбокс «Дополнительный счётчик авто отключения».
 *   • Галочка: зелёный текст ✓ с плавной анимацией появления (scale + alpha).
 */
public class VpnMenuActivity extends Activity {

    static final String KEY_COUNTER_ENABLED = "counter_enabled";

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    private TextView       checkExtraCounter;
    private boolean        counterEnabled = false;
    private SharedPreferences prefs;

    private AccountStatusMonitor accountStatusMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        accountStatusMonitor = new AccountStatusMonitor(this);

        prefs = getSharedPreferences(MainActivity.PREFS_FLOAT, MODE_PRIVATE);
        counterEnabled = prefs.getBoolean(KEY_COUNTER_ENABLED, false);

        setContentView(buildLayout());
    }

    @Override
    protected void onResume() {
        super.onResume();
        accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
    }

    private View buildLayout() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF030507);

        root.addView(buildHeader());
        root.addView(divider());

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(12), dp(16), dp(24));

        body.addView(buildChangeVpnRow());
        body.addView(buildCounterToggleRow());
        // Настройки счётчика перенесены в раздел Кастомизация

        root.addView(body);
        sv.addView(root);
        return sv;
    }

    private View buildHeader() {
        RelativeLayout h = new RelativeLayout(this);
        h.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(68)));
        h.setPadding(dp(12), 0, dp(16), 0);

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(26);
        back.setTypeface(null, Typeface.BOLD);
        back.setTextColor(0xFF00FF9D);
        back.setGravity(Gravity.CENTER);
        back.setBackgroundResource(R.drawable.bg_header_icon);
        RelativeLayout.LayoutParams blp = new RelativeLayout.LayoutParams(dp(44), dp(44));
        blp.addRule(RelativeLayout.CENTER_VERTICAL);
        blp.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        back.setLayoutParams(blp);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });

        TextView title = new TextView(this);
        title.setText("VPN И ПРОЧЕЕ");
        title.setTextSize(16);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFFFFFFFF);
        title.setLetterSpacing(0.25f);
        title.setGravity(Gravity.CENTER);
        RelativeLayout.LayoutParams tlp = new RelativeLayout.LayoutParams(WRAP, WRAP);
        tlp.addRule(RelativeLayout.CENTER_IN_PARENT);
        title.setLayoutParams(tlp);

        h.addView(back);
        h.addView(title);
        return h;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(0xFF1A2430);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(1)));
        return v;
    }

    private View buildChangeVpnRow() {
        RelativeLayout row = new RelativeLayout(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, dp(58));
        lp.topMargin = dp(8);
        row.setLayoutParams(lp);
        row.setBackgroundResource(R.drawable.bg_card);
        row.setPadding(dp(20), 0, dp(20), 0);
        row.setClickable(true);
        row.setFocusable(true);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.HORIZONTAL);
        left.setGravity(Gravity.CENTER_VERTICAL);
        RelativeLayout.LayoutParams llp = new RelativeLayout.LayoutParams(WRAP, WRAP);
        llp.addRule(RelativeLayout.CENTER_VERTICAL);
        left.setLayoutParams(llp);

        FrameLayout iconFrame = new FrameLayout(this);
        iconFrame.setLayoutParams(new LinearLayout.LayoutParams(dp(32), dp(32)));
        iconFrame.setBackgroundResource(R.drawable.bg_icon_circle_green);
        TextView icon = new TextView(this);
        icon.setText("🌐");
        icon.setTextSize(16);
        icon.setGravity(Gravity.CENTER);
        icon.setLayoutParams(new ViewGroup.LayoutParams(MATCH, MATCH));
        iconFrame.addView(icon);

        TextView label = new TextView(this);
        label.setText("Поменять VPN");
        label.setTextSize(15);
        label.setTypeface(null, Typeface.BOLD);
        label.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        labelLp.leftMargin = dp(12);
        label.setLayoutParams(labelLp);

        left.addView(iconFrame);
        left.addView(label);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextSize(24);
        arrow.setTypeface(null, Typeface.BOLD);
        arrow.setTextColor(0xFF00FF9D);
        RelativeLayout.LayoutParams alp = new RelativeLayout.LayoutParams(WRAP, WRAP);
        alp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        alp.addRule(RelativeLayout.CENTER_VERTICAL);
        arrow.setLayoutParams(alp);

        row.addView(left);
        row.addView(arrow);
        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(VpnMenuActivity.this, VpnPickerActivity.class));
            }
        });
        return row;
    }

    private View buildCounterToggleRow() {
        RelativeLayout row = new RelativeLayout(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, dp(56));
        lp.topMargin = dp(10);
        row.setLayoutParams(lp);
        row.setBackgroundResource(R.drawable.bg_card);
        row.setPadding(dp(20), 0, dp(20), 0);
        row.setClickable(true);
        row.setFocusable(true);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.HORIZONTAL);
        left.setGravity(Gravity.CENTER_VERTICAL);
        RelativeLayout.LayoutParams llp = new RelativeLayout.LayoutParams(WRAP, WRAP);
        llp.addRule(RelativeLayout.CENTER_VERTICAL);
        left.setLayoutParams(llp);

        // Квадратный чекбокс с анимированной зелёной галочкой
        checkExtraCounter = new TextView(this);
        checkExtraCounter.setTextSize(14);
        checkExtraCounter.setTypeface(null, Typeface.BOLD);
        checkExtraCounter.setTextColor(0xFF00FF9D);
        checkExtraCounter.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams chlp = new LinearLayout.LayoutParams(dp(22), dp(22));
        chlp.rightMargin = dp(12);
        checkExtraCounter.setLayoutParams(chlp);

        TextView label = new TextView(this);
        label.setText("Дополнительный счётчик авто отключения");
        label.setTextSize(14);
        label.setTypeface(null, Typeface.BOLD);
        label.setTextColor(0xFFFFFFFF);

        left.addView(checkExtraCounter);
        left.addView(label);
        row.addView(left);

        updateCheckVisual(false);

        row.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                counterEnabled = !counterEnabled;
                prefs.edit().putBoolean(KEY_COUNTER_ENABLED, counterEnabled).apply();
                MainActivity.curCounterEnabled = counterEnabled;
                updateCheckVisual(true);
            }
        });
        return row;
    }

    /**
     * Обновляет визуал чекбокса.
     * @param animate — true при клике (плавная анимация появления/скрытия галочки)
     */
    private void updateCheckVisual(boolean animate) {
        if (checkExtraCounter == null) return;
        if (counterEnabled) {
            checkExtraCounter.setBackgroundResource(R.drawable.bg_check_counter_on);
            if (animate) {
                // Галочка появляется с анимацией scale + alpha
                checkExtraCounter.setScaleX(0.3f);
                checkExtraCounter.setScaleY(0.3f);
                checkExtraCounter.setAlpha(0f);
                checkExtraCounter.setText("✓");
                checkExtraCounter.animate()
                    .scaleX(1f).scaleY(1f).alpha(1f)
                    .setDuration(200)
                    .start();
            } else {
                checkExtraCounter.setText("✓");
                checkExtraCounter.setAlpha(1f);
                checkExtraCounter.setScaleX(1f);
                checkExtraCounter.setScaleY(1f);
            }
        } else {
            checkExtraCounter.setBackgroundResource(R.drawable.bg_check_circle_off);
            if (animate) {
                checkExtraCounter.animate()
                    .scaleX(0.6f).scaleY(0.6f).alpha(0f)
                    .setDuration(130)
                    .withEndAction(new Runnable() {
                        public void run() {
                            checkExtraCounter.setText("");
                            checkExtraCounter.setScaleX(1f);
                            checkExtraCounter.setScaleY(1f);
                            checkExtraCounter.setAlpha(1f);
                        }
                    }).start();
            } else {
                checkExtraCounter.setText("");
                checkExtraCounter.setAlpha(1f);
                checkExtraCounter.setScaleX(1f);
                checkExtraCounter.setScaleY(1f);
            }
        }
    }

    private int dp(int px) {
        return Math.round(px * getResources().getDisplayMetrics().density);
    }
}
