package com.clumsyvpn;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Handler;
import android.os.AsyncTask;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * ChatActivity — онлайн чат с анимированным неоновым фоном.
 * Использует long-polling (каждые 2 сек) для получения новых сообщений.
 * Эндпоинты: POST /chat/send, GET /chat/messages?since=<timestamp>
 */
public class ChatActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int POLL_INTERVAL_MS = 2000;

    private String myLogin = "Гость";
    private String myCreatedAt = "";
    private String serverUrl;

    private LinearLayout messagesContainer;
    private ScrollView scrollView;
    private EditText inputField;
    private Handler pollHandler;
    private Runnable pollRunnable;
    private long lastMessageTime = 0;
    // Кэш удалённых аккаунтов (логин → true если удалён)
    private java.util.HashMap<String, Boolean> deletedUsers = new java.util.HashMap<>();

    // Режим удаления сообщений (только для администратора)
    private boolean isMyAdmin = false;
    private boolean deleteModeActive = false;
    private java.util.HashMap<String, Boolean> selectedForDelete = new java.util.HashMap<>();
    private java.util.HashMap<View, String> messageViewToId = new java.util.HashMap<>();
    private java.util.HashMap<View, android.view.ViewGroup> messageViewToCircle = new java.util.HashMap<>();
    private LinearLayout deleteModeBar;
    private TextView deleteCountLabel;
    private String myPassword = "";


    // Мут
    private boolean isMuted = false;
    private String muteUntil = "";
    private String muteReason = "";
    private FrameLayout inputBarFrame; // содержит либо inputBar, либо muteBar

    // Цвета анимации фона
    private static final int[] BG_COLORS = {
        0xFF0A0F1A, 0xFF0D1A2E, 0xFF0A1A2A, 0xFF0D1529, 0xFF0A0F1A
    };
    private LinearLayout bgView;
    private Handler bgHandler;
    private int bgStep = 0;

    private AccountStatusMonitor accountStatusMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Читаем логин и данные из SharedPreferences
        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        myLogin = prefs.getString(AuthActivity.KEY_LOGIN, "Гость");
        if (myLogin == null || myLogin.isEmpty()) myLogin = "Гость";
        myCreatedAt = prefs.getString(AuthActivity.KEY_CREATED_AT, "");
        myPassword  = prefs.getString(AuthActivity.KEY_PASSWORD, "");
        isMyAdmin   = prefs.getBoolean("is_admin", false);
        serverUrl = AuthActivity.SERVER_URL;

        accountStatusMonitor = new AccountStatusMonitor(this);

        // Поднимаем контент над клавиатурой
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        buildUI();
        startBgAnimation();
        startPolling();
        checkMuteStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
    }

    private void buildUI() {
        // Корень
        FrameLayout root = new FrameLayout(this);
        root.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));

        // Анимированный фон
        bgView = new LinearLayout(this);
        bgView.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));
        bgView.setBackgroundColor(0xFF0A0F1A);
        root.addView(bgView);

        // Основной контент
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        main.setBackgroundColor(Color.TRANSPARENT);

        // Шапка
        main.addView(buildHeader());

        // Разделитель
        View div = new View(this);
        div.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        div.setBackgroundColor(0xFF1A2430);
        main.addView(div);

        // Область сообщений
        scrollView = new ScrollView(this);
        LinearLayout.LayoutParams svlp = new LinearLayout.LayoutParams(MATCH, 0, 1f);
        scrollView.setLayoutParams(svlp);
        scrollView.setBackgroundColor(Color.TRANSPARENT);
        scrollView.setFillViewport(true);

        messagesContainer = new LinearLayout(this);
        messagesContainer.setOrientation(LinearLayout.VERTICAL);
        messagesContainer.setPadding(dp(12), dp(12), dp(12), dp(8));
        // MATCH_PARENT height + gravity BOTTOM — сообщения снизу как в Telegram
        LinearLayout.LayoutParams mcLp = new LinearLayout.LayoutParams(MATCH, MATCH);
        messagesContainer.setLayoutParams(mcLp);
        messagesContainer.setGravity(Gravity.BOTTOM);
        scrollView.addView(messagesContainer);

        main.addView(scrollView);

        // Поле ввода внизу
        inputBarFrame = new FrameLayout(this);
        inputBarFrame.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        inputBarFrame.addView(buildInputBar());
        main.addView(inputBarFrame);

        // Панель удаления (скрыта по умолчанию, отображается в режиме удаления)
        deleteModeBar = buildDeleteModeBar();
        deleteModeBar.setVisibility(View.GONE);
        main.addView(deleteModeBar);

        root.addView(main);
        setContentView(root);
    }

    private View buildHeader() {
        RelativeLayout header = new RelativeLayout(this);
        header.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(60)));
        header.setPadding(dp(12), 0, dp(16), 0);
        header.setBackgroundColor(0xCC0A0F1A);

        // Кнопка назад
        FrameLayout backBtn = new FrameLayout(this);
        backBtn.setLayoutParams(new RelativeLayout.LayoutParams(dp(44), dp(44)));
        GradientDrawable backBg = new GradientDrawable();
        backBg.setShape(GradientDrawable.RECTANGLE);
        backBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        backBg.setColor(0xFF0C1014);
        backBg.setStroke(1, 0xFF17202A);
        backBg.setStroke(1, 0xFF1A2F40);
        backBtn.setBackground(backBg);

        TextView backText = new TextView(this);
        backText.setText("‹");
        backText.setTextSize(26);
        backText.setTypeface(null, Typeface.BOLD);
        backText.setTextColor(0xFF00FF9D);
        backText.setGravity(Gravity.CENTER);
        backText.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        backBtn.addView(backText);

        RelativeLayout.LayoutParams bklp = new RelativeLayout.LayoutParams(dp(44), dp(44));
        bklp.addRule(RelativeLayout.CENTER_VERTICAL);
        bklp.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        backBtn.setLayoutParams(bklp);
        backBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        header.addView(backBtn);

        // Заголовок
        LinearLayout titleArea = new LinearLayout(this);
        titleArea.setOrientation(LinearLayout.VERTICAL);
        titleArea.setGravity(Gravity.CENTER);
        RelativeLayout.LayoutParams talp = new RelativeLayout.LayoutParams(WRAP, WRAP);
        talp.addRule(RelativeLayout.CENTER_IN_PARENT);
        titleArea.setLayoutParams(talp);

        TextView title = new TextView(this);
        title.setText("ОНЛАЙН ЧАТ");
        title.setTextSize(15);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFFFFFFFF);
        title.setLetterSpacing(0.2f);
        title.setGravity(Gravity.CENTER);
        titleArea.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("вы: " + myLogin);
        subtitle.setTextSize(10);
        subtitle.setTextColor(0xFF00FF9D);
        subtitle.setGravity(Gravity.CENTER);
        titleArea.addView(subtitle);

        header.addView(titleArea);

        // Кнопка «Удалить сообщения» — только для администратора
        if (isMyAdmin) {
            FrameLayout deleteBtn = new FrameLayout(this);
            GradientDrawable delBg = new GradientDrawable();
            delBg.setShape(GradientDrawable.OVAL);
            delBg.setColor(0xFF1A0A0A);
            delBg.setStroke(1, 0xFFFF1E4E);
            deleteBtn.setBackground(delBg);
            RelativeLayout.LayoutParams dblp = new RelativeLayout.LayoutParams(dp(44), dp(44));
            dblp.addRule(RelativeLayout.CENTER_VERTICAL);
            dblp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
            deleteBtn.setLayoutParams(dblp);
            TextView delIcon = new TextView(this);
            delIcon.setText("🗑");
            delIcon.setTextSize(16);
            delIcon.setGravity(Gravity.CENTER);
            delIcon.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
            deleteBtn.addView(delIcon);
            deleteBtn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { toggleDeleteMode(); }
            });
            header.addView(deleteBtn);
        }

        return header;
    }

    private View buildInputBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.BOTTOM);
        bar.setPadding(dp(12), dp(8), dp(12), dp(8));
        bar.setBackgroundColor(0xCC0A0F1A);
        bar.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        // Поле ввода — авторасширение, макс 2 строки
        inputField = new EditText(this);
        LinearLayout.LayoutParams etlp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        etlp.rightMargin = dp(10);
        etlp.bottomMargin = 0;
        inputField.setLayoutParams(etlp);
        inputField.setHint("Написать сообщение...");
        inputField.setHintTextColor(0xFF3A4654);
        inputField.setTextColor(0xFFFFFFFF);
        inputField.setTextSize(14);
        inputField.setSingleLine(false);
        inputField.setMaxLines(2);
        inputField.setMinLines(1);
        inputField.setImeOptions(EditorInfo.IME_FLAG_NO_ENTER_ACTION);
        inputField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setShape(GradientDrawable.RECTANGLE);
        inputBg.setCornerRadius(dp(22));
        inputBg.setColor(0xFF0C1014);
        inputBg.setStroke(1, 0xFF17202A);
        inputField.setBackground(inputBg);
        inputField.setPadding(dp(14), dp(10), dp(14), dp(10));
        bar.addView(inputField);

        // Кнопка отправки — единый стиль
        FrameLayout sendBtn = new FrameLayout(this);
        LinearLayout.LayoutParams sblp = new LinearLayout.LayoutParams(dp(46), dp(46));
        sblp.leftMargin = dp(8);
        sendBtn.setLayoutParams(sblp);
        // btn_send_round — green neon oval
        {
            android.graphics.drawable.GradientDrawable glow = new android.graphics.drawable.GradientDrawable();
            glow.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            glow.setColor(0x4000FF9D);
            android.graphics.drawable.GradientDrawable fill = new android.graphics.drawable.GradientDrawable();
            fill.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            fill.setColor(0xFF00FF9D);
            fill.setStroke(dp(1), 0xFFA8FFDB);
            android.graphics.drawable.InsetDrawable fillInset =
                new android.graphics.drawable.InsetDrawable(fill, dp(3));
            sendBtn.setBackground(new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{glow, fillInset}));
        }

        TextView sendIcon = new TextView(this);
        sendIcon.setText("➤");
        sendIcon.setTextSize(17);
        sendIcon.setTextColor(0xFF001A0E);
        sendIcon.setTypeface(null, android.graphics.Typeface.BOLD);
        sendIcon.setGravity(Gravity.CENTER);
        sendIcon.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        sendBtn.addView(sendIcon);

        sendBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { sendMessage(); }
        });
        bar.addView(sendBtn);

        return bar;
    }

    private void sendMessage() {
        String text = inputField.getText().toString().trim();
        if (TextUtils.isEmpty(text)) return;
        inputField.setText("");

        final String finalText = text;
        new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected Boolean doInBackground(Void... v) {
                try {
                    JSONObject body = new JSONObject();
                    body.put("login", myLogin);
                    body.put("text", finalText);
                    httpPost(serverUrl + "/chat/send", body.toString());
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }

            @Override
            protected void onPostExecute(Boolean ok) {
                if (!ok) {
                    // Добавляем локально если нет сервера (оффлайн режим)
                    addMessageBubble(myLogin, finalText, true, System.currentTimeMillis(), "");
                }
            }
        }.execute();
    }

    private void startPolling() {
        pollHandler = new Handler();
        pollRunnable = new Runnable() {
            @Override
            public void run() {
                fetchMessages();
                pollHandler.postDelayed(this, POLL_INTERVAL_MS);
            }
        };
        pollHandler.post(pollRunnable);
    }

    private void fetchMessages() {
        new AsyncTask<Void, Void, JSONArray>() {
            @Override
            protected JSONArray doInBackground(Void... v) {
                try {
                    String response = httpGet(serverUrl + "/chat/messages?since=" + lastMessageTime);
                    if (response == null) return null;
                    JSONObject obj = new JSONObject(response);
                    return obj.optJSONArray("messages");
                } catch (Exception e) {
                    return null;
                }
            }

            @Override
            protected void onPostExecute(JSONArray messages) {
                if (messages == null) return;
                for (int i = 0; i < messages.length(); i++) {
                    try {
                        JSONObject msg = messages.getJSONObject(i);
                        String login = msg.optString("login", "?");
                        String text  = msg.optString("text", "");
                        long ts      = msg.optLong("timestamp", System.currentTimeMillis());
                        String msgId = msg.optString("id", "");
                        boolean mine = login.equals(myLogin);
                        addMessageBubble(login, text, mine, ts, msgId);
                        if (ts > lastMessageTime) lastMessageTime = ts;
                    } catch (Exception ignored) {}
                }
            }
        }.execute();
    }

    /**
     * Добавляет пузырь сообщения.
     * Для чужих сообщений — белый круг с иконкой человека слева.
     * При нажатии на круг — диалог с информацией о пользователе.
     */
    /**
     * Добавляет блок сообщения в чат.
     *
     * МОЁ сообщение (isMine=true):
     *   [ник] — вправо
     *   [пузырь] — вправо, без аватара
     *
     * ЧУЖОЕ сообщение (isMine=false):
     *   [👤] | [ник  ]   — аватар слева, прижат к ВЕРХУ контента
     *         | [пузырь]  — независимо от длины текста
     */
    private void addMessageBubble(final String login, String text, boolean isMine, long timestamp, final String msgId) {
        final LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        wlp.bottomMargin = dp(12);
        wrapper.setLayoutParams(wlp);

        if (isMine) {
            // ── МОЁ: вертикально, выровнено вправо ─────────────────

            // Ник
            TextView nickView = new TextView(this);
            nickView.setText(login);
            nickView.setTextSize(10);
            nickView.setTypeface(null, Typeface.BOLD);
            nickView.setTextColor(0xFF00BFFF);
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(WRAP, WRAP);
            nlp.rightMargin  = dp(8);
            nlp.bottomMargin = dp(3);
            nlp.gravity = Gravity.RIGHT;
            nickView.setLayoutParams(nlp);
            wrapper.addView(nickView);

            // Пузырь
            TextView bubble = new TextView(this);
            bubble.setText(text);
            bubble.setTextSize(14);
            bubble.setTextColor(0xFFFFFFFF);
            bubble.setPadding(dp(12), dp(8), dp(12), dp(8));
            bubble.setMaxWidth((int)(getResources().getDisplayMetrics().widthPixels * 0.72f));
            GradientDrawable bubbleBg = new GradientDrawable();
            bubbleBg.setShape(GradientDrawable.RECTANGLE);
            bubbleBg.setCornerRadius(dp(14));
            bubbleBg.setColor(0xFF1565C0);
            bubbleBg.setStroke(1, 0xFF00BFFF);
            bubble.setBackground(bubbleBg);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(WRAP, WRAP);
            blp.gravity = Gravity.RIGHT;
            blp.rightMargin = dp(8);
            bubble.setLayoutParams(blp);
            wrapper.addView(bubble);

        } else {
            // ── ЧУЖОЕ: горизонтально — [👤/circle] слева сверху, контент справа ──

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

            // Аватар / круг выбора
            final int AVATAR_SIZE = dp(28);
            final FrameLayout avatarBtn = new FrameLayout(this);
            LinearLayout.LayoutParams ablp = new LinearLayout.LayoutParams(AVATAR_SIZE, AVATAR_SIZE);
            ablp.gravity  = Gravity.TOP;
            ablp.topMargin = dp(14);
            ablp.rightMargin = dp(6);
            avatarBtn.setLayoutParams(ablp);

            final GradientDrawable circleBg = new GradientDrawable();
            circleBg.setShape(GradientDrawable.OVAL);
            boolean isDeleted = Boolean.TRUE.equals(deletedUsers.get(login));
            circleBg.setColor(isDeleted ? 0xFF3A3A3A : 0xFFFFFFFF);
            circleBg.setStroke(dp(1), isDeleted ? 0xFF666666 : 0xFFCCCCCC);
            avatarBtn.setBackground(circleBg);

            final TextView personIcon = new TextView(this);
            personIcon.setText(isDeleted ? "👻" : "👤");
            personIcon.setTextSize(12);
            personIcon.setGravity(Gravity.CENTER);
            personIcon.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
            avatarBtn.addView(personIcon);

            avatarBtn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (deleteModeActive) {
                        toggleMessageSelection(wrapper, msgId, circleBg, personIcon);
                    } else {
                        showUserInfoDialog(login);
                    }
                }
            });

            // Контент: ник + пузырь (вертикально)
            LinearLayout content = new LinearLayout(this);
            content.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, WRAP, 1f);
            content.setLayoutParams(clp);

            // Ник
            TextView nickView = new TextView(this);
            nickView.setText(login);
            nickView.setTextSize(10);
            nickView.setTypeface(null, Typeface.BOLD);
            nickView.setTextColor(0xFF00FF9D);
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(WRAP, WRAP);
            nlp.bottomMargin = dp(3);
            nickView.setLayoutParams(nlp);
            content.addView(nickView);

            // Пузырь
            final TextView bubble = new TextView(this);
            bubble.setText(text);
            bubble.setTextSize(14);
            bubble.setTextColor(0xFF111111);
            bubble.setPadding(dp(12), dp(8), dp(12), dp(8));
            bubble.setMaxWidth((int)(getResources().getDisplayMetrics().widthPixels * 0.72f));
            final GradientDrawable bubbleBg = new GradientDrawable();
            bubbleBg.setShape(GradientDrawable.RECTANGLE);
            bubbleBg.setCornerRadius(dp(14));
            bubbleBg.setColor(0xFFFFFFFF);
            bubbleBg.setStroke(1, 0xFFDDDDDD);
            bubble.setBackground(bubbleBg);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(WRAP, WRAP);
            bubble.setLayoutParams(blp);
            final String finalText = text;
            final String finalLogin = login;
            bubble.setOnLongClickListener(new android.view.View.OnLongClickListener() {
                public boolean onLongClick(android.view.View v) {
                    if (deleteModeActive) {
                        toggleMessageSelection(wrapper, msgId, circleBg, personIcon);
                        return true;
                    }
                    showReportMenu(finalLogin, finalText);
                    return true;
                }
            });
            bubble.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (deleteModeActive) {
                        toggleMessageSelection(wrapper, msgId, circleBg, personIcon);
                    }
                }
            });
            content.addView(bubble);

            row.addView(avatarBtn);
            row.addView(content);
            wrapper.addView(row);

            // Регистрируем для режима удаления
            if (!msgId.isEmpty()) {
                messageViewToId.put(wrapper, msgId);
                messageViewToCircle.put(wrapper, avatarBtn);
            }
        }

        messagesContainer.addView(wrapper);

        // ── Авто-прокрутка вниз ──
        scrollView.post(new Runnable() {
            public void run() {
                scrollView.post(new Runnable() {
                    public void run() {
                        scrollView.fullScroll(ScrollView.FOCUS_DOWN);
                    }
                });
            }
        });
    }


    /**
     * Диалог с информацией о пользователе.
     * Показывает логин, ID и дату создания аккаунта.
     * Если это свой аккаунт — данные из SharedPreferences,
     * иначе — запрашивает сервер через GET /user/:login.
     */
    private void showUserInfoDialog(final String login) {
        boolean isMe = login.equals(myLogin);

        if (isMe) {
            String userId = generateUserId(login);
            String dateFormatted = (myCreatedAt != null && !myCreatedAt.isEmpty())
                ? formatDate(myCreatedAt) : "—";
            displayUserDialog(login, userId, dateFormatted, false, null);
        } else {
            new AsyncTask<Void, Void, String[]>() {
                @Override
                protected String[] doInBackground(Void... v) {
                    try {
                        String response = httpGet(serverUrl + "/user/" + login);
                        if (response != null) {
                            JSONObject obj = new JSONObject(response);
                            boolean deleted = obj.optBoolean("deleted", false);
                            if (deleted) {
                                return new String[]{ null, null, "deleted" };
                            }
                            String uid = obj.optString("user_id", generateUserId(login));
                            String ca  = obj.optString("created_at", "");
                            // ban info
                            String banUntilVal = "";
                            try {
                                org.json.JSONObject banObj = obj.optJSONObject("ban");
                                if (banObj != null) banUntilVal = banObj.optString("until", "");
                            } catch (Exception ignored) {}
                            return new String[]{ uid, ca, "ok", banUntilVal };
                        }
                    } catch (Exception ignored) {}
                    return new String[]{ generateUserId(login), "", "ok", "" };
                }
                @Override
                protected void onPostExecute(String[] data) {
                    boolean isDeleted = "deleted".equals(data[2]);
                    // Обновляем кэш удалённых
                    deletedUsers.put(login, isDeleted);
                    if (isDeleted) {
                        displayUserDialog(login, null, null, true, null);
                    } else {
                        String dateFormatted = (data[1] != null && !data[1].isEmpty())
                            ? formatDate(data[1]) : "—";
                        displayUserDialog(login, data[0], dateFormatted, false, data[3]);
                    }
                }
            }.execute();
        }
    }

    private void displayUserDialog(final String login, final String userId, final String createdAt, final boolean isDeleted, final String banUntil) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        // Прозрачный dim — чат виден по бокам
        dialog.getWindow().setLayout(
            android.view.WindowManager.LayoutParams.MATCH_PARENT,
            android.view.WindowManager.LayoutParams.MATCH_PARENT);
        android.view.WindowManager.LayoutParams wlp = dialog.getWindow().getAttributes();
        wlp.dimAmount = 0.55f;
        dialog.getWindow().setAttributes(wlp);
        dialog.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);

        // Корень диалога — прозрачный, клик вне карточки закрывает
        FrameLayout root = new FrameLayout(this);
        root.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        root.setBackgroundColor(0x00000000);
        root.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { dialog.dismiss(); }
        });

        // Карточка
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(24), dp(20), dp(24), dp(24));

        // Цвет обводки зависит от статуса пользователя (как в RankShareActivity)
        int cardAccent = isDeleted ? 0xFF666666
                       : ("admin".equals(login)) ? 0xFFFF1E4E
                       : (banUntil != null && "permanent".equals(banUntil)) ? 0xFF444444
                       : (banUntil != null && !banUntil.isEmpty() && !"permanent".equals(banUntil)) ? 0xFFFF8C00
                       : 0xFF00FF9D;
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setShape(GradientDrawable.RECTANGLE);
        cardBg.setCornerRadius(dp(18));
        cardBg.setColor(0xFF0C1014);
        cardBg.setStroke(dp(1), cardAccent);
        card.setBackground(cardBg);

        FrameLayout.LayoutParams cardlp = new FrameLayout.LayoutParams(
            (int)(getResources().getDisplayMetrics().widthPixels * 0.82f), WRAP);
        cardlp.gravity = Gravity.CENTER;
        card.setLayoutParams(cardlp);
        // Плавная анимация появления (как в RankShareActivity)
        card.setAlpha(0f);
        card.setScaleX(0.92f);
        card.setScaleY(0.92f);
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220)
            .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
        card.setOnClickListener(null); // не закрывать при клике на карточку

        // Шапка карточки: кнопка назад + заголовок
        RelativeLayout cardHeader = new RelativeLayout(this);
        cardHeader.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(44)));

        TextView backBtn = new TextView(this);
        backBtn.setText("‹ Назад");
        backBtn.setTextSize(14);
        backBtn.setTypeface(null, Typeface.BOLD);
        backBtn.setTextColor(0xFF00FF9D);
        RelativeLayout.LayoutParams bblp = new RelativeLayout.LayoutParams(WRAP, WRAP);
        bblp.addRule(RelativeLayout.CENTER_VERTICAL);
        bblp.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        backBtn.setLayoutParams(bblp);
        backBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { dialog.dismiss(); }
        });
        cardHeader.addView(backBtn);

        TextView cardTitle = new TextView(this);
        cardTitle.setText("ПРОФИЛЬ");
        cardTitle.setTextSize(13);
        cardTitle.setTypeface(null, Typeface.BOLD);
        cardTitle.setTextColor(0xFFFFFFFF);
        cardTitle.setLetterSpacing(0.2f);
        RelativeLayout.LayoutParams ctlp = new RelativeLayout.LayoutParams(WRAP, WRAP);
        ctlp.addRule(RelativeLayout.CENTER_IN_PARENT);
        cardTitle.setLayoutParams(ctlp);
        cardHeader.addView(cardTitle);

        card.addView(cardHeader);

        // Разделитель
        View hdiv = new View(this);
        LinearLayout.LayoutParams hdivlp = new LinearLayout.LayoutParams(MATCH, 1);
        hdivlp.topMargin = dp(8);
        hdivlp.bottomMargin = dp(16);
        hdiv.setLayoutParams(hdivlp);
        hdiv.setBackgroundColor(0xFF1A2430);
        card.addView(hdiv);

        // Determine special states
        final boolean isAdmin = "admin".equals(login);
        // Ban states: null or empty = not banned; "permanent" = perm ban; ISO date = temp ban
        final boolean isPermBanned = !isDeleted && banUntil != null && "permanent".equals(banUntil);
        final boolean isTempBanned = !isDeleted && banUntil != null && !banUntil.isEmpty() && !"permanent".equals(banUntil);

        // Days remaining for temp ban
        int tempBanDays = 0;
        if (isTempBanned) {
            try {
                java.text.SimpleDateFormat sdfBan = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US);
                sdfBan.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                java.util.Date banDate = sdfBan.parse(banUntil);
                long diff = banDate.getTime() - System.currentTimeMillis();
                tempBanDays = Math.max(1, (int)(diff / (1000 * 60 * 60 * 24)));
            } catch (Exception ignored) {}
        }
        final int finalTempBanDays = tempBanDays;

        // Avatar circle
        FrameLayout bigAvatar = new FrameLayout(this);
        LinearLayout.LayoutParams balp = new LinearLayout.LayoutParams(dp(76), dp(76));
        balp.gravity = Gravity.CENTER_HORIZONTAL;
        balp.bottomMargin = dp(12);
        bigAvatar.setLayoutParams(balp);
        GradientDrawable bigCircle = new GradientDrawable();
        bigCircle.setShape(GradientDrawable.OVAL);
        int circleColor, strokeColor;
        if (isDeleted)      { circleColor = 0xFF2A2A2A; strokeColor = 0xFF666666; }
        else if (isAdmin)   { circleColor = 0xFF1A0A00; strokeColor = 0xFFFF1E4E; }
        else if (isPermBanned) { circleColor = 0xFF1A0A0A; strokeColor = 0xFF444444; }
        else if (isTempBanned) { circleColor = 0xFF0A0A1A; strokeColor = 0xFFFF8C00; }
        else                { circleColor = 0xFF0A1520; strokeColor = 0xFF00FF9D; }
        bigCircle.setColor(circleColor);
        bigCircle.setStroke(dp(2), strokeColor);
        bigAvatar.setBackground(bigCircle);

        String avatarEmoji;
        if (isDeleted)         avatarEmoji = "👻";
        else if (isAdmin)      avatarEmoji = "🛡";
        else if (isPermBanned) avatarEmoji = "🐷";
        else if (isTempBanned) avatarEmoji = "🐷";
        else                   avatarEmoji = "👤";

        TextView bigPerson = new TextView(this);
        bigPerson.setText(avatarEmoji);
        bigPerson.setTextSize(34);
        bigPerson.setGravity(Gravity.CENTER);
        bigPerson.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        bigAvatar.addView(bigPerson);
        card.addView(bigAvatar);

        // Admin badge
        if (isAdmin) {
            android.widget.LinearLayout adminBadge = new android.widget.LinearLayout(this);
            adminBadge.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            adminBadge.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams ablp = new LinearLayout.LayoutParams(WRAP, WRAP);
            ablp.gravity = Gravity.CENTER_HORIZONTAL;
            ablp.bottomMargin = dp(14);
            adminBadge.setLayoutParams(ablp);
            adminBadge.setPadding(dp(12), dp(6), dp(12), dp(6));
            GradientDrawable badgeBg = new GradientDrawable();
            badgeBg.setShape(GradientDrawable.RECTANGLE);
            badgeBg.setCornerRadius(dp(20));
            badgeBg.setColor(0x33FF1E4E);
            badgeBg.setStroke(dp(1), 0xFFFF1E4E);
            adminBadge.setBackground(badgeBg);

            TextView shieldIcon = new TextView(this);
            shieldIcon.setText("🛡 ");
            shieldIcon.setTextSize(13);
            adminBadge.addView(shieldIcon);

            TextView adminText = new TextView(this);
            adminText.setText("Официальный администратор");
            adminText.setTextSize(12);
            adminText.setTextColor(0xFFFF1E4E);
            adminText.setTypeface(null, Typeface.BOLD);
            adminBadge.addView(adminText);

            card.addView(adminBadge);
        }

        if (isDeleted) {
            card.addView(buildInfoRow("Логин", login, true, dialog));
            TextView deletedLabel = new TextView(this);
            deletedLabel.setText("Аккаунт удалён");
            deletedLabel.setTextSize(15);
            deletedLabel.setTypeface(null, Typeface.BOLD);
            deletedLabel.setTextColor(0xFFFF3B3B);
            deletedLabel.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(MATCH, WRAP);
            dlp.topMargin = dp(12);
            dlp.bottomMargin = dp(4);
            deletedLabel.setLayoutParams(dlp);
            card.addView(deletedLabel);
        } else if (isPermBanned) {
            card.addView(buildInfoRow("Логин", login, true, dialog));
            card.addView(buildInfoRow("ID пользователя", userId, true, dialog));
            // Perm ban notice
            TextView permBanLabel = new TextView(this);
            permBanLabel.setText("🐷  Аккаунт заблокирован навсегда");
            permBanLabel.setTextSize(14);
            permBanLabel.setTypeface(null, Typeface.BOLD);
            permBanLabel.setTextColor(0xFF888888);
            permBanLabel.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams pblp = new LinearLayout.LayoutParams(MATCH, WRAP);
            pblp.topMargin = dp(10);
            pblp.bottomMargin = dp(4);
            permBanLabel.setLayoutParams(pblp);
            card.addView(permBanLabel);

            // Pig behind bars icon
            try {
                android.widget.ImageView pigView = new android.widget.ImageView(this);
                pigView.setImageResource(R.drawable.ic_pig_banned);
                LinearLayout.LayoutParams pigLp = new LinearLayout.LayoutParams(dp(90), dp(90));
                pigLp.gravity = Gravity.CENTER_HORIZONTAL;
                pigLp.topMargin = dp(8);
                pigLp.bottomMargin = dp(4);
                pigView.setLayoutParams(pigLp);
                card.addView(pigView);
            } catch (Exception ignored) {}

        } else if (isTempBanned) {
            card.addView(buildInfoRow("Логин", login, true, dialog));
            card.addView(buildInfoRow("ID пользователя", userId, true, dialog));
            card.addView(buildInfoRow("Дата создания", createdAt, false, dialog));
            // Temp ban notice
            TextView tempBanLabel = new TextView(this);
            tempBanLabel.setText("🐷  Аккаунт заблокирован");
            tempBanLabel.setTextSize(14);
            tempBanLabel.setTypeface(null, Typeface.BOLD);
            tempBanLabel.setTextColor(0xFFFF8C00);
            tempBanLabel.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams tblp = new LinearLayout.LayoutParams(MATCH, WRAP);
            tblp.topMargin = dp(10);
            tempBanLabel.setLayoutParams(tblp);
            card.addView(tempBanLabel);

            // Pig behind bars icon
            try {
                android.widget.ImageView pigView = new android.widget.ImageView(this);
                pigView.setImageResource(R.drawable.ic_pig_banned);
                LinearLayout.LayoutParams pigLp = new LinearLayout.LayoutParams(dp(90), dp(90));
                pigLp.gravity = Gravity.CENTER_HORIZONTAL;
                pigLp.topMargin = dp(8);
                pigLp.bottomMargin = dp(4);
                pigView.setLayoutParams(pigLp);
                card.addView(pigView);
            } catch (Exception ignored) {}

            TextView daysLabel = new TextView(this);
            daysLabel.setText("Осталось дней блокировки: " + finalTempBanDays);
            daysLabel.setTextSize(12);
            daysLabel.setTextColor(0xFFB8840A);
            daysLabel.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams dblp = new LinearLayout.LayoutParams(MATCH, WRAP);
            dblp.topMargin = dp(4);
            dblp.bottomMargin = dp(4);
            daysLabel.setLayoutParams(dblp);
            card.addView(daysLabel);
        } else {
            card.addView(buildInfoRow("Логин", login, true, dialog));
            card.addView(buildInfoRow("ID пользователя", userId, true, dialog));
            card.addView(buildInfoRow("Дата создания", createdAt, false, dialog));
        }

        root.addView(card);
        dialog.setContentView(root);
        dialog.show();
    }

    /** Строка информации с кнопкой копирования */
    private View buildInfoRow(final String label, final String value, final boolean copyable, final Dialog dialog) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.bottomMargin = dp(12);
        row.setLayoutParams(rlp);

        GradientDrawable rowBg = new GradientDrawable();
        rowBg.setShape(GradientDrawable.RECTANGLE);
        rowBg.setCornerRadius(dp(10));
        rowBg.setColor(0xFF0A1520);
        rowBg.setStroke(1, 0xFF1A2F40);
        row.setBackground(rowBg);
        row.setPadding(dp(14), dp(10), dp(14), dp(10));

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextSize(10);
        labelView.setTextColor(0xFF5A7A8A);
        labelView.setTypeface(null, Typeface.BOLD);
        labelView.setLetterSpacing(0.1f);
        row.addView(labelView);

        LinearLayout valueRow = new LinearLayout(this);
        valueRow.setOrientation(LinearLayout.HORIZONTAL);
        valueRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams vrlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        vrlp.topMargin = dp(4);
        valueRow.setLayoutParams(vrlp);

        TextView valueView = new TextView(this);
        valueView.setText(value);
        valueView.setTextSize(14);
        valueView.setTextColor(0xFFFFFFFF);
        valueView.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams vvlp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        valueView.setLayoutParams(vvlp);
        valueRow.addView(valueView);

        if (copyable) {
            TextView copyBtn = new TextView(this);
            copyBtn.setText("⎘  Копировать");
            copyBtn.setTextSize(11);
            copyBtn.setTextColor(0xFF00E5FF);
            copyBtn.setTypeface(null, Typeface.BOLD);
            copyBtn.setPadding(dp(12), dp(6), dp(12), dp(6));
            // btn_copy_pill — dark cyan pill
        {
            android.graphics.drawable.GradientDrawable copyPill = new android.graphics.drawable.GradientDrawable();
            copyPill.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
            copyPill.setCornerRadius(dp(20));
            copyPill.setColor(0xFF0F1E2E);
            copyPill.setStroke(dp(1), 0xFF00E5FF);
            copyBtn.setBackground(copyPill);
        }
            copyBtn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText(label, value);
                    cm.setPrimaryClip(clip);
                    Toast.makeText(ChatActivity.this, "Скопировано", Toast.LENGTH_SHORT).show();
                }
            });
            valueRow.addView(copyBtn);
        }

        row.addView(valueRow);
        return row;
    }

    /** Генерирует псевдо-уникальный ID на основе логина */
    private String generateUserId(String login) {
        int hash = 0;
        for (char c : login.toCharArray()) {
            hash = hash * 31 + c;
        }
        long id = (Math.abs((long) hash) * 9973L + 100000L) % 100000000L + 10000000L;
        return "#" + id;
    }

    /** Форматирует ISO дату в точный вид: "14 мая 2026" */
    private String formatDate(String iso) {
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US);
            sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            java.util.Date date;
            try {
                date = sdf.parse(iso);
            } catch (Exception e) {
                java.text.SimpleDateFormat sdf2 = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US);
                sdf2.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                date = sdf2.parse(iso);
            }
            if (date == null) return iso;
            java.util.Calendar cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));
            cal.setTime(date);
            int day   = cal.get(java.util.Calendar.DAY_OF_MONTH);
            int month = cal.get(java.util.Calendar.MONTH);
            int year  = cal.get(java.util.Calendar.YEAR);
            String[] months = {"января","февраля","марта","апреля","мая","июня",
                               "июля","августа","сентября","октября","ноября","декабря"};
            return day + " " + months[month] + " " + year;
        } catch (Exception ignored) {}
        return iso;
    }

    private void startBgAnimation() {
        bgHandler = new Handler();
        Runnable animRunnable = new Runnable() {
            @Override
            public void run() {
                int c1 = BG_COLORS[bgStep % BG_COLORS.length];
                int c2 = BG_COLORS[(bgStep + 1) % BG_COLORS.length];
                GradientDrawable gd = new GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    new int[]{c1, c2, 0xFF0A0F1A}
                );
                bgView.setBackground(gd);
                bgStep++;
                bgHandler.postDelayed(this, 3000);
            }
        };
        bgHandler.post(animRunnable);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pollHandler != null && pollRunnable != null) {
            pollHandler.removeCallbacks(pollRunnable);
        }
        if (bgHandler != null) bgHandler.removeCallbacksAndMessages(null);
    }

    // ─── HTTP helpers ───────────────────────────────────────────────

    private String httpPost(String urlStr, String jsonBody) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        OutputStream os = conn.getOutputStream();
        os.write(jsonBody.getBytes("UTF-8"));
        os.flush();
        os.close();
        int code = conn.getResponseCode();
        BufferedReader br = new BufferedReader(
            new InputStreamReader(code < 400 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }

    private String httpGet(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);
        int code = conn.getResponseCode();
        if (code == 200) {
            BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return sb.toString();
        }
        return null;
    }

    private int dp(int val) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(val * density);
    }
    // ── Mute check ──────────────────────────────────
    private void checkMuteStatus() {
        final String url = serverUrl + "/mute-status/" + myLogin;
        new Thread(new Runnable() {
            public void run() {
                try {
                    java.net.URL u = new java.net.URL(url);
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection) u.openConnection();
                    conn.setConnectTimeout(8000); conn.setReadTimeout(8000);
                    java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder(); String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close(); conn.disconnect();
                    final String resp = sb.toString();
                    runOnUiThread(new Runnable() {
                        public void run() {
                            if (resp.contains("\"muted\":true")) {
                                isMuted = true;
                                muteUntil  = extractField(resp, "until");
                                muteReason = extractField(resp, "reason");
                                if (muteUntil  == null) muteUntil  = "";
                                if (muteReason == null) muteReason = "";
                                showMuteBar();
                            } else {
                                isMuted = false;
                                if (inputBarFrame != null) {
                                    inputBarFrame.removeAllViews();
                                    inputBarFrame.addView(buildInputBar());
                                }
                            }
                        }
                    });
                } catch (Exception ignored) {}
            }
        }).start();
    }

    private void showMuteBar() {
        if (inputBarFrame == null) return;
        inputBarFrame.removeAllViews();

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setGravity(android.view.Gravity.CENTER);
        bar.setPadding(dp(16), dp(12), dp(16), dp(12));
        bar.setBackgroundColor(0xCC0A0F1A);
        bar.setLayoutParams(new FrameLayout.LayoutParams(MATCH, WRAP));

        TextView tvMuted = new TextView(this);
        tvMuted.setText("🔇 Вам выдали мут");
        tvMuted.setTextSize(14);
        tvMuted.setTextColor(0xFFFF1E4E);
        tvMuted.setTypeface(null, android.graphics.Typeface.BOLD);
        tvMuted.setGravity(android.view.Gravity.CENTER);
        bar.addView(tvMuted);

        final String muteU = muteUntil;
        final String muteR = muteReason;

        TextView tvDetails = new TextView(this);
        tvDetails.setText("Подробнее..");
        tvDetails.setTextSize(13);
        tvDetails.setTextColor(0xFF00BFFF);
        tvDetails.setGravity(android.view.Gravity.CENTER);
        tvDetails.setPadding(0, dp(4), 0, 0);
        tvDetails.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showMuteInfoDialog(muteU, muteR);
            }
        });
        bar.addView(tvDetails);

        inputBarFrame.addView(bar);
    }

    private void showMuteInfoDialog(String until, String reason) {
        final android.app.Dialog d = new android.app.Dialog(this);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(20));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(16));
        bg.setColor(0xFF0C1014);
        bg.setStroke(1, 0xFF1A6BFF);
        root.setBackground(bg);

        TextView title = new TextView(this);
        title.setText("🔇 Информация о муте");
        title.setTextSize(15);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(android.view.Gravity.CENTER);
        root.addView(title);

        View sep = new View(this);
        sep.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(1)));
        sep.setBackgroundColor(0xFF17202A);
        LinearLayout.LayoutParams sepl = new LinearLayout.LayoutParams(MATCH, dp(1));
        sepl.topMargin = dp(12); sepl.bottomMargin = dp(12);
        sep.setLayoutParams(sepl);
        root.addView(sep);

        String formattedUntil = until != null && !until.isEmpty() ? formatMuteDate(until) : "—";
        String formattedReason = reason != null && !reason.isEmpty() ? reason : "не указана";

        TextView tvUntil = new TextView(this);
        tvUntil.setText("Срок: " + formattedUntil);
        tvUntil.setTextSize(13);
        tvUntil.setTextColor(0xFFB8C4D0);
        root.addView(tvUntil);

        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rp.topMargin = dp(8);
        TextView tvReason = new TextView(this);
        tvReason.setText("Причина: " + formattedReason);
        tvReason.setTextSize(13);
        tvReason.setTextColor(0xFFB8C4D0);
        tvReason.setLayoutParams(rp);
        root.addView(tvReason);

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(MATCH, WRAP);
        bp.topMargin = dp(16);
        TextView btnClose = new TextView(this);
        btnClose.setText("Закрыть");
        btnClose.setTextSize(13);
        btnClose.setTextColor(0xFF00BFFF);
        btnClose.setGravity(android.view.Gravity.CENTER);
        btnClose.setPadding(dp(12), dp(10), dp(12), dp(10));
        btnClose.setLayoutParams(bp);
        btnClose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        root.addView(btnClose);

        d.setContentView(root);
        int w = (int)(getResources().getDisplayMetrics().widthPixels * 0.85);
        d.getWindow().setLayout(w, WRAP);
        d.show();
    }

    private String formatMuteDate(String iso) {
        try {
            return iso.substring(0, 10).replace("-", ".") + " " + iso.substring(11, 16);
        } catch (Exception e) { return iso; }
    }

    private String extractField(String json, String field) {
        try {
            String key = "\"" + field + "\"";
            int idx = json.indexOf(key);
            if (idx < 0) return null;
            int colon = json.indexOf(':', idx + key.length());
            if (colon < 0) return null;
            int start = json.indexOf('"', colon + 1);
            if (start < 0) return null;
            int end = json.indexOf('"', start + 1);
            if (end < 0) return null;
            return json.substring(start + 1, end);
        } catch (Exception e) { return null; }
    }

    // ══════════════════════════════════════════════════
    //  REPORT SYSTEM
    // ══════════════════════════════════════════════════
    private void showReportMenu(final String targetLogin, final String messageText) {
        if (targetLogin.equals(myLogin) || "admin".equals(targetLogin)) return;

        final android.app.Dialog d = new android.app.Dialog(this);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(20));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(16));
        bg.setColor(0xFF0C1014);
        bg.setStroke(1, 0xFFFF1E4E);
        root.setBackground(bg);

        TextView title = new TextView(this);
        title.setText("Сообщение от " + targetLogin);
        title.setTextSize(13);
        title.setTextColor(0xFF6C7885);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        android.view.View sepV = new android.view.View(this);
        LinearLayout.LayoutParams svlp = new LinearLayout.LayoutParams(MATCH, dp(1));
        svlp.topMargin = dp(10); svlp.bottomMargin = dp(10);
        sepV.setLayoutParams(svlp);
        sepV.setBackgroundColor(0xFF17202A);
        root.addView(sepV);

        String preview = messageText.length() > 80 ? messageText.substring(0, 80) + "…" : messageText;
        TextView tvPreview = new TextView(this);
        tvPreview.setText("\"" + preview + "\"");
        tvPreview.setTextSize(13);
        tvPreview.setTextColor(0xFFB8C4D0);
        tvPreview.setTypeface(null, Typeface.ITALIC);
        tvPreview.setGravity(Gravity.CENTER);
        root.addView(tvPreview);

        android.view.View gap = new android.view.View(this);
        gap.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(16)));
        root.addView(gap);

        TextView btnReport = new TextView(this);
        btnReport.setText("🚩  Репорт");
        btnReport.setTextSize(14);
        btnReport.setTextColor(0xFFFFFFFF);
        btnReport.setTypeface(null, Typeface.BOLD);
        btnReport.setGravity(Gravity.CENTER);
        btnReport.setPadding(dp(16), dp(14), dp(16), dp(14));
        android.graphics.drawable.GradientDrawable reportBg = new android.graphics.drawable.GradientDrawable();
        reportBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        reportBg.setCornerRadius(dp(12));
        reportBg.setColor(0xFFFF1E4E);
        btnReport.setBackground(reportBg);
        btnReport.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        btnReport.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                sendReport(targetLogin, messageText);
            }
        });
        root.addView(btnReport);

        android.view.View gap2 = new android.view.View(this);
        gap2.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(8)));
        root.addView(gap2);

        TextView btnCancel = new TextView(this);
        btnCancel.setText("Отмена");
        btnCancel.setTextSize(14);
        btnCancel.setTextColor(0xFF6C7885);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setPadding(0, dp(10), 0, dp(10));
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        root.addView(btnCancel);

        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.82), WRAP);
        d.show();
    }

    private void sendReport(final String targetLogin, final String messageText) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"reporterLogin\":\"" + esc(myLogin)
                        + "\",\"targetLogin\":\"" + esc(targetLogin)
                        + "\",\"messageText\":\"" + esc(messageText) + "\"}";
                    String resp = httpPost(serverUrl + "/report", body);

                    final String result;
                    if (resp == null) {
                        result = "Ошибка соединения";
                    } else if (resp.contains("already_reported")) {
                        result = "Вы уже репортили этого пользователя";
                    } else if (resp.contains("limit_reached")) {
                        result = "Лимит репортов исчерпан. Сбросится через 24 часа.";
                    } else if (resp.contains("\"ok\"") || resp.contains("success")) {
                        result = "Репорт отправлен";
                    } else {
                        result = "Ошибка: " + resp;
                    }

                    runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(ChatActivity.this, result, Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(ChatActivity.this, "Ошибка соединения", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }).start();
    }


    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }

    // ── Режим удаления (только для админа) ──────────────────────────────

    private LinearLayout buildDeleteModeBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), dp(10), dp(16), dp(10));
        bar.setBackgroundColor(0xCC1A0808);
        bar.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        deleteCountLabel = new TextView(this);
        deleteCountLabel.setText("Выбрано: 0");
        deleteCountLabel.setTextSize(13);
        deleteCountLabel.setTextColor(0xFFFFFFFF);
        deleteCountLabel.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        deleteCountLabel.setLayoutParams(lp);
        bar.addView(deleteCountLabel);

        // Кнопка «Отмена»
        TextView cancelBtn = new TextView(this);
        cancelBtn.setText("Отмена");
        cancelBtn.setTextSize(13);
        cancelBtn.setTextColor(0xFF00FF9D);
        cancelBtn.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable cancelBg = new GradientDrawable();
        cancelBg.setShape(GradientDrawable.RECTANGLE);
        cancelBg.setCornerRadius(dp(20));
        cancelBg.setColor(0xFF0C2010);
        cancelBg.setStroke(1, 0xFF00FF9D);
        cancelBtn.setBackground(cancelBg);
        LinearLayout.LayoutParams clp2 = new LinearLayout.LayoutParams(WRAP, WRAP);
        clp2.rightMargin = dp(10);
        cancelBtn.setLayoutParams(clp2);
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { exitDeleteMode(); }
        });
        bar.addView(cancelBtn);

        // Кнопка «Удалить»
        TextView deleteBtn = new TextView(this);
        deleteBtn.setText("Удалить");
        deleteBtn.setTextSize(13);
        deleteBtn.setTextColor(0xFFFFFFFF);
        deleteBtn.setTypeface(null, Typeface.BOLD);
        deleteBtn.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable deleteBg = new GradientDrawable();
        deleteBg.setShape(GradientDrawable.RECTANGLE);
        deleteBg.setCornerRadius(dp(20));
        deleteBg.setColor(0xFFCC1030);
        deleteBg.setStroke(1, 0xFFFF1E4E);
        deleteBtn.setBackground(deleteBg);
        deleteBtn.setLayoutParams(new LinearLayout.LayoutParams(WRAP, WRAP));
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { executeDeleteMessages(); }
        });
        bar.addView(deleteBtn);

        return bar;
    }

    private void toggleDeleteMode() {
        if (deleteModeActive) {
            exitDeleteMode();
        } else {
            deleteModeActive = true;
            selectedForDelete.clear();
            inputBarFrame.setVisibility(View.GONE);
            deleteModeBar.setVisibility(View.VISIBLE);
            updateDeleteCount();
            // Подсветить все кружки — показать что можно нажимать
            for (java.util.Map.Entry<View, android.view.ViewGroup> e : messageViewToCircle.entrySet()) {
                android.view.ViewGroup circle = e.getValue();
                circle.setAlpha(0.6f);
            }
        }
    }

    private void exitDeleteMode() {
        deleteModeActive = false;
        selectedForDelete.clear();
        // Сбросить визуальное выделение всех сообщений
        for (View wrapper : messageViewToId.keySet()) {
            wrapper.setAlpha(1f);
            wrapper.setScaleX(1f);
            wrapper.setScaleY(1f);
        }
        for (java.util.Map.Entry<View, android.view.ViewGroup> e : messageViewToCircle.entrySet()) {
            android.view.ViewGroup circle = e.getValue();
            circle.setAlpha(1f);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(0xFFFFFFFF);
            bg.setStroke(dp(1), 0xFFCCCCCC);
            circle.setBackground(bg);
            if (circle.getChildCount() > 0 && circle.getChildAt(0) instanceof TextView) {
                ((TextView) circle.getChildAt(0)).setText("👤");
            }
        }
        deleteModeBar.setVisibility(View.GONE);
        inputBarFrame.setVisibility(View.VISIBLE);
    }

    private void toggleMessageSelection(final View wrapper, final String msgId,
                                         final GradientDrawable circleBg, final TextView personIcon) {
        if (msgId == null || msgId.isEmpty()) return;
        boolean isSelected = Boolean.TRUE.equals(selectedForDelete.get(msgId));
        if (isSelected) {
            selectedForDelete.remove(msgId);
            // Снять выделение
            circleBg.setColor(0xFFFFFFFF);
            circleBg.setStroke(dp(1), 0xFFCCCCCC);
            personIcon.setText("👤");
            wrapper.setAlpha(1f);
            animateDeselect(wrapper);
        } else {
            selectedForDelete.put(msgId, true);
            // Залить кружок зелёным
            circleBg.setColor(0xFF00C853);
            circleBg.setStroke(dp(2), 0xFF00FF9D);
            personIcon.setText("✓");
            wrapper.setAlpha(0.9f);
            animateSelect(wrapper);
        }
        updateDeleteCount();
    }

    private void animateSelect(final View view) {
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(view, "scaleX", 1f, 1.03f, 1f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(view, "scaleY", 1f, 1.03f, 1f);
        AnimatorSet set = new AnimatorSet();
        set.playTogether(scaleX, scaleY);
        set.setDuration(200);
        set.setInterpolator(new android.view.animation.OvershootInterpolator(3f));
        set.start();
    }

    private void animateDeselect(final View view) {
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(view, "scaleX", 1.03f, 1f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(view, "scaleY", 1.03f, 1f);
        AnimatorSet set = new AnimatorSet();
        set.playTogether(scaleX, scaleY);
        set.setDuration(150);
        set.start();
    }

    private void updateDeleteCount() {
        if (deleteCountLabel != null) {
            int count = selectedForDelete.size();
            deleteCountLabel.setText("Выбрано: " + count);
        }
    }

    private void executeDeleteMessages() {
        if (selectedForDelete.isEmpty()) {
            Toast.makeText(this, "Выберите сообщения для удаления", Toast.LENGTH_SHORT).show();
            return;
        }
        final java.util.ArrayList<String> ids = new java.util.ArrayList<>(selectedForDelete.keySet());
        new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected Boolean doInBackground(Void... v) {
                try {
                    StringBuilder sb = new StringBuilder("{\"adminLogin\":\"");
                    sb.append(esc(myLogin)).append("\",\"adminPassword\":\"").append(esc(myPassword));
                    sb.append("\",\"messageIds\":[");
                    for (int i = 0; i < ids.size(); i++) {
                        if (i > 0) sb.append(",");
                        sb.append("\"").append(esc(ids.get(i))).append("\"");
                    }
                    sb.append("]}");
                    String resp = httpPost(serverUrl + "/admin/chat/delete-messages", sb.toString());
                    return resp != null && resp.contains("\"ok\"");
                } catch (Exception e) {
                    return false;
                }
            }
            @Override
            protected void onPostExecute(Boolean ok) {
                if (ok) {
                    // Удалить пузыри из UI
                    for (java.util.Map.Entry<View, String> entry : messageViewToId.entrySet()) {
                        if (selectedForDelete.containsKey(entry.getValue())) {
                            messagesContainer.removeView(entry.getKey());
                        }
                    }
                    // Очистить маппинги удалённых
                    java.util.ArrayList<View> toRemoveViews = new java.util.ArrayList<View>();
                    for (java.util.Map.Entry<View, String> entry : messageViewToId.entrySet()) {
                        if (selectedForDelete.containsKey(entry.getValue())) {
                            toRemoveViews.add(entry.getKey());
                        }
                    }
                    for (View rv : toRemoveViews) { messageViewToId.remove(rv); }
                    java.util.ArrayList<View> toRemoveCircles = new java.util.ArrayList<View>();
                    for (View w : messageViewToCircle.keySet()) {
                        if (!messageViewToId.containsKey(w)) toRemoveCircles.add(w);
                    }
                    for (View w : toRemoveCircles) { messageViewToCircle.remove(w); }
                    exitDeleteMode();
                    // Сброс lastMessageTime чтобы не загружать удалённые снова
                    lastMessageTime = 0;
                    Toast.makeText(ChatActivity.this, "Удалено: " + ids.size(), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ChatActivity.this, "Ошибка при удалении", Toast.LENGTH_SHORT).show();
                }
            }
        }.execute();
    }

}
