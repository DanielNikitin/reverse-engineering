package com.clumsyvpn;

import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

/**
 * AdminSupportChatActivity — чат поддержки со стороны администратора.
 * ИСПРАВЛЕНО: adminJoined только после первого сообщения, нет дубликатов,
 *             in-app уведомление при новом сообщении от пользователя.
 */
public class AdminSupportChatActivity extends Activity {

    public static final String EXTRA_CHAT_ID     = "chat_id";
    public static final String EXTRA_USER_LOGIN   = "user_login";
    public static final String EXTRA_USER_ID      = "user_id";
    public static final String EXTRA_CREATED_AT   = "created_at";

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    private String serverUrl;
    private String adminLogin;
    private String adminPassword;

    private String chatId;
    private String targetUserLogin;
    private String targetUserId;
    private String targetCreatedAt;

    private LinearLayout messagesContainer;
    private ScrollView   scrollView;
    private EditText     etInput;
    private TextView     btnSend;

    // In-app notification banner
    private FrameLayout notifBanner;
    private Handler notifHandler = new Handler();

    private Handler pollHandler = new Handler();
    private Runnable pollRunnable;

    private long lastMsgTimestamp = 0;
    // FIX DUPLICATES: track displayed message IDs
    private Set<String> displayedMsgIds = new HashSet<>();

    private boolean chatClosed = false;
    private long lastUserMsgTs = 0;

    // Reply-to state
    private String  replyToText = null;
    private String  replyToSender = null;
    private LinearLayout replyPreviewBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        adminLogin    = prefs.getString(AuthActivity.KEY_LOGIN, "");
        adminPassword = prefs.getString(AuthActivity.KEY_PASSWORD, "");
        serverUrl     = AuthActivity.SERVER_URL;

        chatId           = getIntent().getStringExtra(EXTRA_CHAT_ID);
        targetUserLogin  = getIntent().getStringExtra(EXTRA_USER_LOGIN);
        targetUserId     = getIntent().getStringExtra(EXTRA_USER_ID);
        targetCreatedAt  = getIntent().getStringExtra(EXTRA_CREATED_AT);

        buildUI();
        // FIX BAG 2: do NOT call joinChat() here. Admin is "joined" only after sending first message.
        loadMessages(true);
        startPolling();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pollHandler != null && pollRunnable != null)
            pollHandler.removeCallbacks(pollRunnable);
        if (notifHandler != null)
            notifHandler.removeCallbacksAndMessages(null);
    }

    // BUILD UI
    private void buildUI() {
        FrameLayout rootFrame = new FrameLayout(this);
        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));
        root.setBackgroundColor(0xFF030507);

        root.addView(buildHeader());

        View div = new View(this);
        div.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        div.setBackgroundColor(0xFF17202A);
        root.addView(div);

        root.addView(buildUserInfoStrip());

        View div2 = new View(this);
        div2.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        div2.setBackgroundColor(0xFF17202A);
        root.addView(div2);

        scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));

        messagesContainer = new LinearLayout(this);
        messagesContainer.setOrientation(LinearLayout.VERTICAL);
        messagesContainer.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        messagesContainer.setPadding(dp(12), dp(12), dp(12), dp(12));
        scrollView.addView(messagesContainer);
        root.addView(scrollView);

        root.addView(buildInputBar());

        rootFrame.addView(root);

        // Notification banner overlay
        notifBanner = new FrameLayout(this);
        notifBanner.setVisibility(View.GONE);
        FrameLayout.LayoutParams bannerLp = new FrameLayout.LayoutParams(MATCH, WRAP);
        bannerLp.topMargin = dp(8);
        notifBanner.setLayoutParams(bannerLp);
        rootFrame.addView(notifBanner);

        setContentView(rootFrame);
    }

    private LinearLayout buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(62)));
        header.setPadding(dp(12), 0, dp(12), 0);
        header.setBackgroundColor(0xFF07090C);

        FrameLayout btnBackWrap = new FrameLayout(this);
        btnBackWrap.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        GradientDrawable backBg = new GradientDrawable();
        backBg.setShape(GradientDrawable.OVAL);
        backBg.setColor(0xFF0C1014);
        backBg.setStroke(1, 0xFF17202A);
        btnBackWrap.setBackground(backBg);
        TextView btnBack = new TextView(this);
        btnBack.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        btnBack.setText("‹");
        btnBack.setTextSize(24);
        btnBack.setTextColor(0xFF00FF9D);
        btnBack.setTypeface(null, Typeface.BOLD);
        btnBack.setGravity(Gravity.CENTER);
        btnBack.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { finish(); } });
        btnBackWrap.addView(btnBack);
        header.addView(btnBackWrap);

        View sp = new View(this);
        sp.setLayoutParams(new LinearLayout.LayoutParams(dp(10), 1));
        header.addView(sp);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Чат с " + targetUserLogin);
        tvTitle.setTextSize(15);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        header.addView(tvTitle);

        final TextView btnFinish = new TextView(this);
        btnFinish.setText("Закончить чат");
        btnFinish.setTextSize(12);
        btnFinish.setTextColor(0xFFFFFFFF);
        btnFinish.setTypeface(null, Typeface.BOLD);
        btnFinish.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable finishBg = new GradientDrawable();
        finishBg.setShape(GradientDrawable.RECTANGLE);
        finishBg.setCornerRadius(dp(8));
        finishBg.setColor(0xFFFF1E4E);
        btnFinish.setBackground(finishBg);
        btnFinish.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showFinishConfirm(); }
        });
        header.addView(btnFinish);

        return header;
    }

    private LinearLayout buildUserInfoStrip() {
        LinearLayout strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setPadding(dp(16), dp(10), dp(16), dp(10));
        strip.setBackgroundColor(0xFF07090C);

        TextView tvUserInfo = new TextView(this);
        tvUserInfo.setText("👤 " + targetUserLogin + "  •  " + (targetUserId != null ? targetUserId : "—"));
        tvUserInfo.setTextSize(12);
        tvUserInfo.setTextColor(0xFF6C7885);
        tvUserInfo.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        strip.addView(tvUserInfo);

        return strip;
    }

    private LinearLayout buildInputBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        bar.setPadding(dp(12), dp(10), dp(12), dp(10));
        bar.setBackgroundColor(0xFF07090C);

        etInput = new EditText(this);
        etInput.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        etInput.setHint("Ответить пользователю...");
        etInput.setHintTextColor(0xFF3A4654);
        etInput.setTextColor(0xFFFFFFFF);
        etInput.setTextSize(14);
        etInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        etInput.setMaxLines(4);
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setShape(GradientDrawable.RECTANGLE);
        inputBg.setCornerRadius(dp(22));
        inputBg.setColor(0xFF0C1014);
        inputBg.setStroke(1, 0xFF17202A);
        etInput.setBackground(inputBg);
        bar.addView(etInput);

        View sp = new View(this);
        sp.setLayoutParams(new LinearLayout.LayoutParams(dp(8), 1));
        bar.addView(sp);

        btnSend = new TextView(this);
        btnSend.setLayoutParams(new LinearLayout.LayoutParams(dp(46), dp(46)));
        btnSend.setText("➤");
        btnSend.setTextSize(17);
        btnSend.setTextColor(0xFF001A0E);
        btnSend.setGravity(Gravity.CENTER);
        btnSend.setTypeface(null, Typeface.BOLD);
        // btn_send_round — green neon oval
        {
            android.graphics.drawable.GradientDrawable glow = new android.graphics.drawable.GradientDrawable();
            glow.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            glow.setColor(0x4000FF9D);
            android.graphics.drawable.GradientDrawable fill = new android.graphics.drawable.GradientDrawable();
            fill.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            fill.setColor(0xFF00FF9D);
            fill.setStroke(dp(1), 0xFFA8FFDB);
            android.graphics.drawable.InsetDrawable fillInset =
                new android.graphics.drawable.InsetDrawable(fill, dp(3));
            btnSend.setBackground(new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{glow, fillInset}));
        }
        btnSend.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { trySendAdminMessage(); }
        });
        bar.addView(btnSend);

        return bar;
    }

    // SEND ADMIN MESSAGE
    // FIX BAG 2: adminJoined is set on server only when admin sends first message (in /admin/send)
    private void trySendAdminMessage() {
        if (chatClosed) { toast("Чат закрыт"); return; }
        String text = etInput.getText().toString().trim();
        if (text.isEmpty()) return;
        if (replyToText != null) {
            text = "↩ " + (replyToSender != null ? replyToSender : "") + ": «" + replyToText + "»\n" + text;
            clearReplyTo();
        }
        etInput.setText("");
        final String textToSend = text;

        // FIX DUPLICATES: disable button while sending
        btnSend.setEnabled(false);
        btnSend.setAlpha(0.5f);

        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"adminLogin\":\"" + esc(adminLogin) + "\",\"adminPassword\":\"" + esc(adminPassword) +
                        "\",\"chatId\":\"" + esc(chatId) + "\",\"text\":\"" + esc(textToSend) + "\"}";
                    String resp = httpPost(serverUrl + "/support/admin/send", body);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            btnSend.setEnabled(true);
                            btnSend.setAlpha(1f);
                        }
                    });
                    if (resp != null) {
                        JSONObject j = new JSONObject(resp);
                        if (j.optBoolean("ok", false)) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    // FIX DUPLICATES: do NOT add bubble here.
                                    // Polling will pick it up from server with real ID.
                                }
                            });
                        }
                    }
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            btnSend.setEnabled(true);
                            btnSend.setAlpha(1f);
                            toast("Ошибка отправки");
                        }
                    });
                }
            }
        }).start();
    }

    // LOAD & POLL MESSAGES
    private void loadMessages(final boolean initial) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    long sinceTs = initial ? 0 : lastMsgTimestamp;
                    String body = "{\"adminLogin\":\"" + esc(adminLogin) + "\",\"adminPassword\":\"" + esc(adminPassword) +
                        "\",\"chatId\":\"" + esc(chatId) + "\",\"since\":" + sinceTs + "}";
                    String resp = httpPost(serverUrl + "/support/admin/messages", body);
                    if (resp == null) return;
                    final JSONObject j = new JSONObject(resp);
                    final JSONArray msgs = j.optJSONArray("messages");
                    final boolean archived = j.optBoolean("archived", false);

                    runOnUiThread(new Runnable() {
                        public void run() {
                            if (initial) {
                                messagesContainer.removeAllViews();
                                displayedMsgIds.clear();
                            }
                            chatClosed = archived;

                            if (msgs != null) {
                                boolean anyNew = false;
                                for (int i = 0; i < msgs.length(); i++) {
                                    try {
                                        JSONObject msg = msgs.getJSONObject(i);
                                        String msgId = msg.optString("id", "");
                                        String text   = msg.optString("text");
                                        String sender = msg.optString("sender");
                                        String senderLogin = msg.optString("senderLogin", "");
                                        long ts = msg.optLong("timestamp", 0);

                                        if (ts > lastMsgTimestamp) lastMsgTimestamp = ts;

                                        // FIX DUPLICATES: skip already-displayed messages
                                        if (!msgId.isEmpty() && displayedMsgIds.contains(msgId)) continue;
                                        if (!msgId.isEmpty()) displayedMsgIds.add(msgId);

                                        boolean isOwn = "admin".equals(sender);
                                        boolean isBot = "bot".equals(sender);
                                        String label = isOwn ? "Поддержка" : (isBot ? "Бот" : senderLogin);

                                        addMessageBubble(text, isOwn, label, ts);
                                        anyNew = true;

                                        // BAG 3: In-app notification when user sends (not on initial load)
                                        if (!isOwn && !isBot && !initial && ts > lastUserMsgTs) {
                                            lastUserMsgTs = ts;
                                            showUserNotification(senderLogin, text);
                                        }
                                    } catch (Exception ignored) {}
                                }
                                if (anyNew) scrollToBottom();
                            }
                        }
                    });
                } catch (Exception e) {}
            }
        }).start();
    }

    private void startPolling() {
        pollRunnable = new Runnable() {
            public void run() {
                if (!chatClosed) loadMessages(false);
                pollHandler.postDelayed(this, 2500);
            }
        };
        pollHandler.postDelayed(pollRunnable, 2500);
    }

    // IN-APP NOTIFICATION (БАГ 3) — пользователь написал сообщение
    private void showUserNotification(final String login, final String msgText) {
        if (notifBanner == null) return;
        notifHandler.removeCallbacksAndMessages(null);
        notifBanner.removeAllViews();

        LinearLayout banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.VERTICAL);
        banner.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bannerBg = new GradientDrawable();
        bannerBg.setShape(GradientDrawable.RECTANGLE);
        bannerBg.setColor(0xFF061630);
        bannerBg.setStroke(2, 0xFF00E5FF);
        bannerBg.setCornerRadius(dp(12));
        banner.setBackground(bannerBg);

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("✉️  " + login + " написал сообщение");
        tvTitle.setTextSize(13);
        tvTitle.setTextColor(0xFF00E5FF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        topRow.addView(tvTitle);

        TextView tvClose = new TextView(this);
        tvClose.setText("✕");
        tvClose.setTextSize(14);
        tvClose.setTextColor(0xFF6C7885);
        tvClose.setPadding(dp(8), 0, 0, 0);
        tvClose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { hideNotifBanner(); }
        });
        topRow.addView(tvClose);
        banner.addView(topRow);

        String preview = msgText.length() > 60 ? msgText.substring(0, 60) + "…" : msgText;
        TextView tvPreview = new TextView(this);
        tvPreview.setText(preview);
        tvPreview.setTextSize(12);
        tvPreview.setTextColor(0xFFB8C4D0);
        tvPreview.setPadding(0, dp(4), 0, 0);
        banner.addView(tvPreview);

        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(MATCH, WRAP);
        blp.setMargins(dp(12), dp(8), dp(12), 0);
        banner.setLayoutParams(blp);
        notifBanner.addView(banner);

        notifBanner.setAlpha(0f);
        notifBanner.setTranslationY(-dp(50));
        notifBanner.setVisibility(View.VISIBLE);
        notifBanner.animate().alpha(1f).translationY(0).setDuration(280).start();

        notifHandler.postDelayed(new Runnable() {
            public void run() { hideNotifBanner(); }
        }, 5000);
    }

    private void hideNotifBanner() {
        if (notifBanner == null) return;
        notifBanner.animate().alpha(0f).setDuration(200)
            .withEndAction(new Runnable() {
                public void run() { notifBanner.setVisibility(View.GONE); }
            }).start();
    }

    // FINISH CHAT
    private void showFinishConfirm() {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(16));
        bg.setColor(0xFF0C1014);
        bg.setStroke(1, 0xFFFF1E4E);
        root.setBackground(bg);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Завершить чат?");
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        root.addView(spacerV(dp(10)));

        TextView tvMsg = new TextView(this);
        tvMsg.setText("Пользователь не сможет больше писать в этот чат. Продолжить?");
        tvMsg.setTextSize(13);
        tvMsg.setTextColor(0xFFB8C4D0);
        tvMsg.setGravity(Gravity.CENTER);
        root.addView(tvMsg);

        root.addView(spacerV(dp(20)));

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnCancel = buildBtn("Отмена", 0xFF17202A, 0xFFB8C4D0);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        clp.rightMargin = dp(8);
        btnCancel.setLayoutParams(clp);
        btnCancel.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { d.dismiss(); } });
        btns.addView(btnCancel);

        TextView btnConfirm = buildBtn("Завершить", 0xFFFF1E4E, 0xFFFFFFFF);
        btnConfirm.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); finishChat(); }
        });
        btns.addView(btnConfirm);

        root.addView(btns);
        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.85), WRAP);
        d.show();
    }

    private void finishChat() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"adminLogin\":\"" + esc(adminLogin) + "\",\"adminPassword\":\"" + esc(adminPassword) +
                        "\",\"chatId\":\"" + esc(chatId) + "\"}";
                    httpPost(serverUrl + "/support/admin/finish", body);
                    runOnUiThread(new Runnable() {
                        public void run() { chatClosed = true; toast("Чат завершён"); finish(); }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Ошибка"); } });
                }
            }
        }).start();
    }

    // MESSAGE BUBBLE
    private void addMessageBubble(String text, boolean isAdmin, String senderLabel, long timestamp) {
        boolean isBot = "Бот".equals(senderLabel);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.bottomMargin = dp(8);
        row.setLayoutParams(rlp);

        TextView tvSender = new TextView(this);
        tvSender.setText(senderLabel);
        tvSender.setTextSize(10);
        tvSender.setTypeface(null, Typeface.BOLD);
        tvSender.setLetterSpacing(0.05f);
        tvSender.setTextColor(isAdmin ? 0xFF00FF9D : (isBot ? 0xFF6C7885 : 0xFF00E5FF));
        tvSender.setGravity(isAdmin ? Gravity.END : Gravity.START);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(MATCH, WRAP);
        slp.bottomMargin = dp(3);
        slp.leftMargin   = isAdmin ? dp(60) : dp(4);
        slp.rightMargin  = isAdmin ? dp(4) : dp(60);
        tvSender.setLayoutParams(slp);
        row.addView(tvSender);

        TextView bubble = new TextView(this);
        bubble.setText(text);
        bubble.setTextSize(14);
        bubble.setPadding(dp(14), dp(10), dp(14), dp(10));

        GradientDrawable bubbleBg = new GradientDrawable();
        bubbleBg.setShape(GradientDrawable.RECTANGLE);
        if (isAdmin) {
            bubbleBg.setCornerRadii(new float[]{dp(16), dp(16), dp(4), dp(4), dp(16), dp(16), dp(16), dp(16)});
            bubbleBg.setColor(0xFF0D2015); bubbleBg.setStroke(1, 0xFF00FF9D);
            bubble.setTextColor(0xFF00FF9D);
        } else if (isBot) {
            bubbleBg.setCornerRadii(new float[]{dp(4), dp(4), dp(16), dp(16), dp(16), dp(16), dp(16), dp(16)});
            bubbleBg.setColor(0xFF1A2430); bubbleBg.setStroke(1, 0xFF243340);
            bubble.setTextColor(0xFFFFFFFF);
        } else {
            bubbleBg.setCornerRadii(new float[]{dp(4), dp(4), dp(16), dp(16), dp(16), dp(16), dp(16), dp(16)});
            bubbleBg.setColor(0xFF0D1F2A); bubbleBg.setStroke(1, 0xFF00E5FF);
            bubble.setTextColor(0xFFFFFFFF);
        }
        bubble.setBackground(bubbleBg);

        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(WRAP, WRAP);
        blp.leftMargin  = isAdmin ? dp(60) : 0;
        blp.rightMargin = isAdmin ? 0 : dp(60);
        blp.gravity     = isAdmin ? Gravity.END : Gravity.START;
        bubble.setLayoutParams(blp);

        bubble.setAlpha(0f);
        bubble.setTranslationY(dp(8));

        final String bText   = text;
        final String bSender = senderLabel;
        bubble.setOnTouchListener(new View.OnTouchListener() {
            private float startX; private boolean triggered = false;
            public boolean onTouch(final View v, android.view.MotionEvent e) {
                switch (e.getAction()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        startX = e.getRawX(); triggered = false; return false;
                    case android.view.MotionEvent.ACTION_MOVE:
                        float dx = startX - e.getRawX();
                        if (!triggered && dx > dp(60)) {
                            triggered = true;
                            v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                            setReplyTo(bText, bSender);
                            v.animate().translationX(-dp(16)).setDuration(80)
                                .withEndAction(new Runnable() { public void run() {
                                    v.animate().translationX(0).setDuration(120).start();
                                }}).start();
                        }
                        return false;
                }
                return false;
            }
        });

        row.addView(bubble);
        messagesContainer.addView(row);
        bubble.animate().alpha(1f).translationY(0).setDuration(200).start();
    }

    private void setReplyTo(String msgText, String sender) {
        replyToText = msgText; replyToSender = sender;
        showReplyPreview();
    }

    private void clearReplyTo() {
        replyToText = null; replyToSender = null;
        if (replyPreviewBar != null && replyPreviewBar.getParent() != null)
            ((android.view.ViewGroup) replyPreviewBar.getParent()).removeView(replyPreviewBar);
        replyPreviewBar = null;
    }

    private void showReplyPreview() {
        if (replyPreviewBar != null && replyPreviewBar.getParent() != null)
            ((android.view.ViewGroup) replyPreviewBar.getParent()).removeView(replyPreviewBar);

        replyPreviewBar = new LinearLayout(this);
        replyPreviewBar.setOrientation(LinearLayout.HORIZONTAL);
        replyPreviewBar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        replyPreviewBar.setPadding(dp(12), dp(8), dp(8), dp(8));
        android.graphics.drawable.GradientDrawable pb = new android.graphics.drawable.GradientDrawable();
        pb.setColor(0xFF07090C); pb.setStroke(dp(1), 0xFF17202A);
        replyPreviewBar.setBackground(pb);

        View accentBar = new View(this);
        android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
        ab.setCornerRadius(dp(2)); ab.setColor(0xFF00FF9D);
        accentBar.setBackground(ab);
        LinearLayout.LayoutParams abLp = new LinearLayout.LayoutParams(dp(3), dp(36));
        abLp.rightMargin = dp(10); accentBar.setLayoutParams(abLp);
        replyPreviewBar.addView(accentBar);

        LinearLayout textBlock = new LinearLayout(this);
        textBlock.setOrientation(LinearLayout.VERTICAL);
        textBlock.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView tvS = new TextView(this);
        tvS.setText(replyToSender != null ? replyToSender : "Сообщение");
        tvS.setTextSize(11); tvS.setTextColor(0xFF00FF9D);
        tvS.setTypeface(null, android.graphics.Typeface.BOLD);
        textBlock.addView(tvS);
        TextView tvT = new TextView(this);
        String preview = replyToText != null && replyToText.length() > 50
            ? replyToText.substring(0, 50) + "…" : replyToText;
        tvT.setText(preview); tvT.setTextSize(12); tvT.setTextColor(0xFF6C7885); tvT.setMaxLines(1);
        textBlock.addView(tvT);
        replyPreviewBar.addView(textBlock);

        TextView tvX = new TextView(this);
        tvX.setText("✕"); tvX.setTextSize(16); tvX.setTextColor(0xFF6C7885);
        tvX.setPadding(dp(10), 0, dp(4), 0);
        tvX.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { clearReplyTo(); } });
        replyPreviewBar.addView(tvX);

        if (etInput != null && etInput.getParent() instanceof LinearLayout) {
            LinearLayout parent = (LinearLayout) etInput.getParent();
            if (parent.getParent() instanceof LinearLayout) {
                LinearLayout grandParent = (LinearLayout) parent.getParent();
                int idx = grandParent.indexOfChild(parent);
                grandParent.addView(replyPreviewBar, idx);
            }
        }
    }

    private void scrollToBottom() {
        scrollView.post(new Runnable() { public void run() { scrollView.fullScroll(ScrollView.FOCUS_DOWN); } });
    }

    // UTILS
    private TextView buildBtn(String text, int bgColor, int textColor) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13);
        tv.setTextColor(textColor);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(10));
        bg.setColor(bgColor);
        tv.setBackground(bg);
        return tv;
    }

    private View spacerV(int height) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, height));
        return v;
    }

    private String httpPost(String urlStr, String jsonBody) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        OutputStream os = conn.getOutputStream();
        os.write(jsonBody.getBytes("UTF-8"));
        os.close();
        int code = conn.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
            code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        conn.disconnect();
        return sb.toString();
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density);
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            public void run() { Toast.makeText(AdminSupportChatActivity.this, msg, Toast.LENGTH_SHORT).show(); }
        });
    }
}