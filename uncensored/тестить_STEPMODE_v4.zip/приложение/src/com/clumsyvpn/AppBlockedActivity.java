package com.clumsyvpn;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;

/**
 * Shown to all non-admin users when the app is disabled by an administrator.
 * User cannot go back or use the app.
 */
public class AppBlockedActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    // Как часто опрашиваем сервер, пока показан экран блокировки
    private static final long POLL_INTERVAL_MS = 5000;

    private android.os.Handler pollHandler;
    private Runnable pollRunnable;
    private boolean isChecking = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUI();
        pollHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    }

    @Override
    protected void onResume() {
        super.onResume();
        startPolling();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopPolling();
    }

    private void startPolling() {
        if (pollRunnable != null) return; // уже запущено
        pollRunnable = new Runnable() {
            @Override
            public void run() {
                checkIfUnblocked();
                pollHandler.postDelayed(this, POLL_INTERVAL_MS);
            }
        };
        // Первую проверку делаем сразу, не дожидаясь первого интервала —
        // на случай если приложение включили обратно ровно в момент,
        // когда пользователь открыл этот экран.
        pollHandler.post(pollRunnable);
    }

    private void stopPolling() {
        if (pollHandler != null && pollRunnable != null) {
            pollHandler.removeCallbacks(pollRunnable);
        }
        pollRunnable = null;
    }

    /**
     * Спрашивает сервер, снято ли отключение приложения. Если да —
     * закрывает этот экран, и пользователь автоматически возвращается
     * в MainActivity (которая всё это время оставалась под этим экраном
     * в стеке активностей) без необходимости перезапускать приложение.
     */
    private void checkIfUnblocked() {
        if (isChecking) return; // не запускаем параллельные проверки
        isChecking = true;
        final String serverUrl = AuthActivity.SERVER_URL;
        new Thread(new Runnable() {
            public void run() {
                boolean unblocked = false;
                try {
                    java.net.URL url = new java.net.URL(serverUrl + "/app-status");
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    conn.disconnect();
                    String resp = sb.toString();
                    if (resp.contains("\"appDisabled\":false")) {
                        unblocked = true;
                    }
                } catch (Exception e) {
                    // Сервер недоступен — оставляем экран блокировки,
                    // как и было раньше в MainActivity.checkAppStatus().
                    unblocked = false;
                }
                final boolean finalUnblocked = unblocked;
                runOnUiThread(new Runnable() {
                    public void run() {
                        isChecking = false;
                        if (finalUnblocked && !isFinishing()) {
                            stopPolling();
                            finish();
                        }
                    }
                });
            }
        }).start();
    }

    private boolean isCurrentUserAdmin() {
        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        return prefs.getBoolean("is_admin", false);
    }

    @Override
    public void onBackPressed() {
        // Block back navigation — user cannot exit this screen
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(32), dp(48), dp(32), dp(48));
        root.setBackgroundColor(0xFF030507);

        // Lock icon
        TextView icon = new TextView(this);
        icon.setText("🔒");
        icon.setTextSize(56);
        icon.setGravity(Gravity.CENTER);
        root.addView(icon);

        root.addView(spacerV(dp(24)));

        // Title
        TextView tvTitle = new TextView(this);
        tvTitle.setText("Приложение временно недоступно");
        tvTitle.setTextSize(20);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        root.addView(spacerV(dp(24)));

        // Reasons card
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setShape(GradientDrawable.RECTANGLE);
        cardBg.setCornerRadius(dp(16));
        cardBg.setColor(0xFF0C1014);
        cardBg.setStroke(1, 0xFF17202A);
        card.setBackground(cardBg);

        TextView reasonsTitle = new TextView(this);
        reasonsTitle.setText("Возможные причины:");
        reasonsTitle.setTextSize(13);
        reasonsTitle.setTextColor(0xFF6C7885);
        reasonsTitle.setTypeface(null, Typeface.BOLD);
        reasonsTitle.setLetterSpacing(0.05f);
        card.addView(reasonsTitle);

        card.addView(spacerV(dp(14)));

        String[] reasons = {
            "🔧  Технические неполадки",
            "⬆️  Обновление приложения",
            "🌐  Проблемы с сервером"
        };

        for (String reason : reasons) {
            card.addView(spacerV(dp(6)));
            TextView tvReason = new TextView(this);
            tvReason.setText(reason);
            tvReason.setTextSize(14);
            tvReason.setTextColor(0xFFB8C4D0);
            card.addView(tvReason);
        }

        root.addView(card);

        root.addView(spacerV(dp(28)));

        // Info note
        TextView tvNote = new TextView(this);
        tvNote.setText("Приложение станет доступным,\nкогда администратор включит его обратно");
        tvNote.setTextSize(12);
        tvNote.setTextColor(0xFF6C7885);
        tvNote.setGravity(Gravity.CENTER);
        root.addView(tvNote);

        // Subtle neon line at top
        GradientDrawable topLine = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0x00FF1E4E, 0xFFFF1E4E, 0x00FF1E4E}
        );
        TextView glow = new TextView(this);
        glow.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(2)));
        glow.setBackground(topLine);

        // Admin logout button — only visible to admin
        if (isCurrentUserAdmin()) {
            root.addView(spacerV(dp(28)));
            TextView btnAdminLogout = new TextView(this);
            btnAdminLogout.setText("Выйти");
            btnAdminLogout.setTextSize(16);
            btnAdminLogout.setTypeface(null, Typeface.BOLD);
            btnAdminLogout.setTextColor(0xFFFFFFFF);
            btnAdminLogout.setGravity(Gravity.CENTER);
            btnAdminLogout.setPadding(dp(40), dp(14), dp(40), dp(14));
            GradientDrawable exitBg = new GradientDrawable();
            exitBg.setShape(GradientDrawable.RECTANGLE);
            exitBg.setCornerRadius(dp(14));
            exitBg.setColor(0xFF1A6BFF);
            exitBg.setStroke(dp(1), 0xFF4D96FF);
            btnAdminLogout.setBackground(exitBg);
            btnAdminLogout.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
                    prefs.edit()
                        .putBoolean(AuthActivity.KEY_LOGGED_IN, false)
                        .putString(AuthActivity.KEY_LOGIN, "")
                        .putString(AuthActivity.KEY_PASSWORD, "")
                        .putBoolean("is_admin", false)
                        .apply();
                    Intent intent = new Intent(AppBlockedActivity.this, AuthActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }
            });
            LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(WRAP, WRAP);
            btnLp.gravity = Gravity.CENTER_HORIZONTAL;
            btnAdminLogout.setLayoutParams(btnLp);
            root.addView(btnAdminLogout);
        }

        // Wrap in frame so it appears at the very top
        android.widget.FrameLayout frame = new android.widget.FrameLayout(this);
        frame.setLayoutParams(new android.widget.FrameLayout.LayoutParams(MATCH, MATCH));
        frame.addView(glow);
        frame.addView(root);

        setContentView(frame);
    }

    private android.view.View spacerV(int height) {
        android.view.View v = new android.view.View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, height));
        return v;
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density);
    }
}
