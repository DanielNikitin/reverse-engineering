package com.clumsyvpn;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Shown when a banned user tries to log in.
 * Allows logout so they can use a different account.
 */
public class BannedActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    public static final String EXTRA_LOGIN    = "ban_login";
    public static final String EXTRA_USER_ID  = "ban_user_id";
    public static final String EXTRA_UNTIL    = "ban_until";
    public static final String EXTRA_REASON   = "ban_reason";
    /** Ключ, который был привязан к забаненному пользователю (пусто, если ключа не было) */
    public static final String EXTRA_KEY_VALUE = "ban_key_value";
    /** На сколько устройств был рассчитан этот ключ; -1, если ключа не было */
    public static final String EXTRA_KEY_MAX_DEVICES = "ban_key_max_devices";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String login  = getIntent().getStringExtra(EXTRA_LOGIN);
        String userId = getIntent().getStringExtra(EXTRA_USER_ID);
        String until  = getIntent().getStringExtra(EXTRA_UNTIL);
        String reason = getIntent().getStringExtra(EXTRA_REASON);
        String keyValue = getIntent().getStringExtra(EXTRA_KEY_VALUE);
        int keyMaxDevices = getIntent().getIntExtra(EXTRA_KEY_MAX_DEVICES, -1);

        if (login  == null) login  = "—";
        if (userId == null) userId = "—";
        if (until  == null) until  = "—";
        if (reason == null || reason.isEmpty()) reason = "не указана";
        if (keyValue == null) keyValue = "";

        buildUI(login, userId, until, reason, keyValue, keyMaxDevices);
    }

    @Override
    public void onBackPressed() {
        // Пользователь не вошёл в систему (или был выкинут из-за бана) —
        // явно ведём его на экран авторизации. Не используем просто finish(),
        // потому что BannedActivity может быть запущена с очисткой всего
        // стека задач (когда бан обнаружен в MainActivity) — тогда finish()
        // закрыл бы приложение целиком вместо возврата на экран входа.
        goToAuth();
    }

    private void buildUI(final String login, final String userId, final String until, final String reason,
                          final String keyValue, final int keyMaxDevices) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(60), dp(24), dp(40));
        root.setBackgroundColor(0xFF030507);

        // Icon — pig behind bars for temp ban, 🚫 for permanent
        boolean isPermanent = "permanent".equals(until);
        if (isPermanent) {
            TextView icon = new TextView(this);
            icon.setText("🚫");
            icon.setTextSize(52);
            icon.setGravity(Gravity.CENTER);
            root.addView(icon);
        } else {
            // Duck behind bars SVG
            android.widget.ImageView pigIcon = new android.widget.ImageView(this);
            try {
                pigIcon.setImageResource(R.drawable.ic_pig_banned);
            } catch (Exception e) {
                // fallback emoji if drawable not found
                TextView icon = new TextView(this);
                icon.setText("🐷🔒");
                icon.setTextSize(46);
                icon.setGravity(Gravity.CENTER);
                root.addView(icon);
                pigIcon = null;
            }
            if (pigIcon != null) {
                LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(100), dp(100));
                iconLp.gravity = Gravity.CENTER_HORIZONTAL;
                pigIcon.setLayoutParams(iconLp);
                root.addView(pigIcon);
            }
        }

        root.addView(spacerV(dp(20)));

        // Title
        TextView tvTitle = new TextView(this);
        tvTitle.setText("Ваш аккаунт заблокирован");
        tvTitle.setTextSize(20);
        tvTitle.setTextColor(0xFFFF1E4E);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);

        root.addView(spacerV(dp(24)));

        // Info card
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        card.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setShape(GradientDrawable.RECTANGLE);
        cardBg.setCornerRadius(dp(16));
        cardBg.setColor(0xFF0C1014);
        cardBg.setStroke(1, 0xFF301018);
        card.setBackground(cardBg);

        card.addView(buildInfoRow("Логин:", login));
        card.addView(spacerV(dp(10)));
        card.addView(buildInfoRow("ID:", userId));
        card.addView(spacerV(dp(10)));

        // Separator
        View sep = new View(this);
        sep.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        sep.setBackgroundColor(0xFF17202A);
        card.addView(sep);
        card.addView(spacerV(dp(10)));

        // Ban duration
        String banLabel = "permanent".equals(until) ? "Навсегда" : formatBanDate(until);
        card.addView(buildInfoRow("Срок бана:", banLabel));
        card.addView(spacerV(dp(10)));
        card.addView(buildInfoRow("Причина:", reason));

        root.addView(card);

        // ── Доп. информация про привязанный ключ ──
        // Показывается только если у забаненного пользователя был активный ключ.
        if (keyMaxDevices >= 0) {
            root.addView(spacerV(dp(20)));
            root.addView(buildKeyBanCard(keyValue, keyMaxDevices));
        }

        root.addView(spacerV(dp(32)));

        // Logout link
        TextView tvLogout = new TextView(this);
        tvLogout.setText("Выйти из аккаунта");
        tvLogout.setTextSize(15);
        tvLogout.setTextColor(0xFF00BFFF);
        tvLogout.setGravity(Gravity.CENTER);
        tvLogout.setPadding(0, dp(8), 0, dp(8));
        tvLogout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { doLogout(); }
        });
        root.addView(tvLogout);

        setContentView(root);
    }

    // ── Карточка с информацией о заблокированном ключе ──────────────
    private LinearLayout buildKeyBanCard(final String keyValue, int keyMaxDevices) {
        boolean singleDevice = (keyMaxDevices == 1);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        card.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setShape(GradientDrawable.RECTANGLE);
        cardBg.setCornerRadius(dp(16));
        cardBg.setColor(0xFF0C1014);
        cardBg.setStroke(1, 0xFF301018);
        card.setBackground(cardBg);

        TextView tvKeyTitle = new TextView(this);
        tvKeyTitle.setText("🔑  Ваш ключ");
        tvKeyTitle.setTextSize(14);
        tvKeyTitle.setTextColor(0xFFFFFFFF);
        tvKeyTitle.setTypeface(null, Typeface.BOLD);
        card.addView(tvKeyTitle);
        card.addView(spacerV(dp(10)));

        TextView tvMsg = new TextView(this);
        tvMsg.setTextSize(13);
        tvMsg.setTextColor(0xFFB8C4D0);
        tvMsg.setLineSpacing(dp(2), 1f);

        if (singleDevice) {
            tvMsg.setText("Ваш ключ был заблокирован. Если это произошло по ошибке, то после "
                    + "разблокировки аккаунта администратором ваш ключ будет восстановлен с тем же "
                    + "оставшимся сроком действия, который был на момент блокировки.");
        } else {
            tvMsg.setText("Ваш доступ к этому ключу был заблокирован. Если это произошло по ошибке, "
                    + "к сожалению, восстановить доступ к ключу будет невозможно.");
        }
        card.addView(tvMsg);

        // Для ключа на 1 устройство — показываем сам ключ с возможностью скопировать,
        // чтобы пользователь не потерял его на случай разбана.
        if (singleDevice && keyValue != null && !keyValue.isEmpty()) {
            card.addView(spacerV(dp(14)));

            View sep = new View(this);
            sep.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
            sep.setBackgroundColor(0xFF17202A);
            card.addView(sep);
            card.addView(spacerV(dp(14)));

            TextView tvKeyLabel = new TextView(this);
            tvKeyLabel.setText("Ваш ключ на момент блокировки:");
            tvKeyLabel.setTextSize(12);
            tvKeyLabel.setTextColor(0xFF6C7885);
            card.addView(tvKeyLabel);
            card.addView(spacerV(dp(6)));

            LinearLayout keyRow = new LinearLayout(this);
            keyRow.setOrientation(LinearLayout.HORIZONTAL);
            keyRow.setGravity(Gravity.CENTER_VERTICAL);

            TextView tvKeyValue = new TextView(this);
            tvKeyValue.setText(keyValue);
            tvKeyValue.setTextSize(13);
            tvKeyValue.setTextColor(0xFF00FF9D);
            tvKeyValue.setTypeface(null, Typeface.BOLD);
            tvKeyValue.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
            keyRow.addView(tvKeyValue);

            TextView btnCopy = new TextView(this);
            btnCopy.setText("⎘  Копировать");
            btnCopy.setTextSize(11);
            btnCopy.setTextColor(0xFF00E5FF);
            btnCopy.setTypeface(null, Typeface.BOLD);
            btnCopy.setPadding(dp(10), dp(6), dp(10), dp(6));
            GradientDrawable copyPill = new GradientDrawable();
            copyPill.setShape(GradientDrawable.RECTANGLE);
            copyPill.setCornerRadius(dp(20));
            copyPill.setColor(0xFF0F1E2E);
            copyPill.setStroke(dp(1), 0xFF00E5FF);
            btnCopy.setBackground(copyPill);
            btnCopy.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("key", keyValue));
                    Toast.makeText(BannedActivity.this, "Скопировано", Toast.LENGTH_SHORT).show();
                }
            });
            keyRow.addView(btnCopy);

            card.addView(keyRow);
            card.addView(spacerV(dp(10)));

            TextView tvHint = new TextView(this);
            tvHint.setText("Сохраните, чтобы не потерять в случае разбана.");
            tvHint.setTextSize(11);
            tvHint.setTextColor(0xFF6C7885);
            card.addView(tvHint);
        }

        return card;
    }

    private void doLogout() {
        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        prefs.edit()
            .putBoolean(AuthActivity.KEY_LOGGED_IN, false)
            .putString(AuthActivity.KEY_LOGIN, "")
            .putString(AuthActivity.KEY_PASSWORD, "")
            .putString(AuthActivity.KEY_CREATED_AT, "")
            .apply();
        goToAuth();
    }

    private void goToAuth() {
        Intent intent = new Intent(this, AuthActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    // ── helpers ──────────────────────────────────────
    private LinearLayout buildInfoRow(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(12);
        tvLabel.setTextColor(0xFF6C7885);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(90), WRAP);
        tvLabel.setLayoutParams(lp);
        row.addView(tvLabel);

        TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(13);
        tvValue.setTextColor(0xFFFFFFFF);
        tvValue.setTypeface(null, Typeface.BOLD);
        row.addView(tvValue);

        return row;
    }

    private View spacerV(int height) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, height));
        return v;
    }

    private String formatBanDate(String iso) {
        if (iso == null || iso.isEmpty()) return "—";
        try {
            // Format: 2026-05-14T10:30:00.000Z → "до 14.05.2026"
            String date = iso.substring(0, 10); // yyyy-MM-dd
            String[] parts = date.split("-");
            return "до " + parts[2] + "." + parts[1] + "." + parts[0];
        } catch (Exception e) { return iso; }
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density);
    }
}
