package com.clumsyvpn;

import android.content.Context;

public class KeyExpiredDialog {

    public interface Callback {
        void onOk();
    }

    public static void show(final Context ctx, final Callback callback) {
        KeyNoticeDialog.show(
            ctx,
            "⏳",
            null,
            "Срок ключа закончен. Зайдите на аккаунт с новым действительным ключём.",
            null,
            0xFFFFD600,
            callback == null ? null : new KeyNoticeDialog.Callback() {
                public void onOk() { callback.onOk(); }
            }
        );
    }
}
