package com.clumsyvpn;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class FaqActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    private boolean card1Open = false;
    private boolean card2Open = false;
    private boolean card3Open = false;

    private AccountStatusMonitor accountStatusMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        accountStatusMonitor = new AccountStatusMonitor(this);

        FrameLayout root = new FrameLayout(this);
        root.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));

        View faqView = getLayoutInflater().inflate(R.layout.activity_faq, root, false);
        root.addView(faqView);
        root.addView(buildSupportFab());

        setContentView(root);

        TextView btnBack = (TextView) faqView.findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { finish(); }
            });
        }

        setupCard(faqView, R.id.card1Header, R.id.card1Body, R.id.divider1, R.id.arrow1, 1);
        setupCard(faqView, R.id.card2Header, R.id.card2Body, R.id.divider2, R.id.arrow2, 2);
        setupCard(faqView, R.id.card3Header, R.id.card3Body, R.id.divider3, R.id.arrow3, 3);
    }

    @Override
    protected void onResume() {
        super.onResume();
        accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
    }

    private View buildSupportFab() {
        // Outer wrapper — positions the FAB bottom-right + adds label below
        LinearLayout wrapper = new LinearLayout(this);
        FrameLayout.LayoutParams wrapLp = new FrameLayout.LayoutParams(WRAP, WRAP);
        wrapLp.gravity = Gravity.BOTTOM | Gravity.END;
        wrapLp.rightMargin  = dp(16);
        wrapLp.bottomMargin = dp(20);
        wrapper.setLayoutParams(wrapLp);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setGravity(Gravity.CENTER_HORIZONTAL);

        // Main FAB button — custom drawn dispatcher icon
        final android.widget.FrameLayout fab = new android.widget.FrameLayout(this);
        LinearLayout.LayoutParams fabLp = new LinearLayout.LayoutParams(dp(64), dp(64));
        fab.setLayoutParams(fabLp);
        fab.setElevation(dp(10));

        // Background — deep dark with green glow ring
        android.graphics.drawable.GradientDrawable glowRing = new android.graphics.drawable.GradientDrawable();
        glowRing.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        glowRing.setColor(0xFF001A0E);
        glowRing.setStroke(dp(2), 0xFF00FF9D);
        fab.setBackground(glowRing);

        // Custom dispatcher drawing via Canvas View
        android.view.View dispatcherIcon = new android.view.View(this) {
            @Override
            protected void onDraw(android.graphics.Canvas canvas) {
                super.onDraw(canvas);
                int w = getWidth(), h = getHeight();
                android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

                // ── Head (circle) ──
                p.setColor(0xFF00FF9D);
                p.setStyle(android.graphics.Paint.Style.FILL);
                float cx = w * 0.5f, headR = w * 0.16f, headCY = h * 0.30f;
                canvas.drawCircle(cx, headCY, headR, p);

                // ── Body / shoulders ──
                android.graphics.Path body = new android.graphics.Path();
                float shoulderW = w * 0.32f, shoulderTop = h * 0.50f, bodyBot = h * 0.72f;
                body.moveTo(cx - shoulderW, bodyBot);
                body.quadTo(cx - shoulderW, shoulderTop, cx, shoulderTop);
                body.quadTo(cx + shoulderW, shoulderTop, cx + shoulderW, bodyBot);
                body.close();
                p.setColor(0xFF00FF9D);
                canvas.drawPath(body, p);

                // ── Headset arc (top) ──
                android.graphics.RectF arcRect = new android.graphics.RectF(
                    cx - w*0.28f, h*0.10f, cx + w*0.28f, h*0.46f);
                p.setColor(0xFF00FF9D);
                p.setStyle(android.graphics.Paint.Style.STROKE);
                p.setStrokeWidth(dp(2.5f));
                p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
                canvas.drawArc(arcRect, 180, 180, false, p);

                // ── Left ear cup ──
                p.setStyle(android.graphics.Paint.Style.FILL);
                p.setColor(0xFF00FF9D);
                canvas.drawRoundRect(new android.graphics.RectF(
                    cx - w*0.31f, h*0.25f, cx - w*0.20f, h*0.40f), dp(3), dp(3), p);

                // ── Right ear cup ──
                canvas.drawRoundRect(new android.graphics.RectF(
                    cx + w*0.20f, h*0.25f, cx + w*0.31f, h*0.40f), dp(3), dp(3), p);

                // ── Mic boom (small line + dot from right ear) ──
                p.setStyle(android.graphics.Paint.Style.STROKE);
                p.setStrokeWidth(dp(2));
                android.graphics.Path mic = new android.graphics.Path();
                mic.moveTo(cx + w*0.25f, h*0.40f);
                mic.lineTo(cx + w*0.30f, h*0.52f);
                canvas.drawPath(mic, p);
                p.setStyle(android.graphics.Paint.Style.FILL);
                canvas.drawCircle(cx + w*0.30f, h*0.53f, dp(3), p);
            }
        };
        dispatcherIcon.setLayoutParams(new android.widget.FrameLayout.LayoutParams(MATCH, MATCH));
        fab.addView(dispatcherIcon);

        // ── Pulse animation ──
        final android.animation.ObjectAnimator pulseX = android.animation.ObjectAnimator.ofFloat(fab, "scaleX", 1f, 1.08f, 1f);
        final android.animation.ObjectAnimator pulseY = android.animation.ObjectAnimator.ofFloat(fab, "scaleY", 1f, 1.08f, 1f);
        pulseX.setDuration(2400); pulseY.setDuration(2400);
        pulseX.setRepeatCount(android.animation.ObjectAnimator.INFINITE);
        pulseY.setRepeatCount(android.animation.ObjectAnimator.INFINITE);
        android.animation.AnimatorSet set = new android.animation.AnimatorSet();
        set.playTogether(pulseX, pulseY);
        set.start();

        // ── Label below button ──
        TextView tvLabel = new TextView(this);
        tvLabel.setText("Онлайн помощь");
        tvLabel.setTextSize(10);
        tvLabel.setTextColor(0xFF00FF9D);
        tvLabel.setTypeface(null, android.graphics.Typeface.BOLD);
        tvLabel.setGravity(Gravity.CENTER);
        tvLabel.setPadding(0, dp(5), 0, 0);
        LinearLayout.LayoutParams lblLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        tvLabel.setLayoutParams(lblLp);

        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(final View v) {
                v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).withEndAction(new Runnable() {
                    public void run() {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(110).start();
                        startActivity(new Intent(FaqActivity.this, SupportListActivity.class));
                    }
                }).start();
            }
        });

        wrapper.addView(fab);
        wrapper.addView(tvLabel);
        return wrapper;
    }

    private void setupCard(final View root, final int headerId, final int bodyId,
                           final int dividerId, final int arrowId, final int cardNum) {
        RelativeLayout header = (RelativeLayout) root.findViewById(headerId);
        if (header == null) return;
        header.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                toggleCard(root, bodyId, dividerId, arrowId, cardNum);
            }
        });
    }

    private void toggleCard(View root, int bodyId, int dividerId, int arrowId, int cardNum) {
        LinearLayout body   = (LinearLayout) root.findViewById(bodyId);
        View divider        = root.findViewById(dividerId);
        TextView arrow      = (TextView) root.findViewById(arrowId);
        if (body == null) return;

        boolean isOpen = isCardOpen(cardNum);

        if (isOpen) {
            collapseView(body);
            if (divider != null) divider.setVisibility(View.GONE);
            Animation animClose = AnimationUtils.loadAnimation(this, R.anim.faq_arrow_close);
            if (arrow != null) arrow.startAnimation(animClose);
            setCardOpen(cardNum, false);
        } else {
            expandView(body);
            if (divider != null) divider.setVisibility(View.VISIBLE);
            Animation animOpen = AnimationUtils.loadAnimation(this, R.anim.faq_arrow_open);
            if (arrow != null) arrow.startAnimation(animOpen);
            setCardOpen(cardNum, true);
        }
    }

    private void expandView(final View view) {
        view.measure(
            View.MeasureSpec.makeMeasureSpec(((View) view.getParent()).getWidth(), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        );
        final int targetHeight = view.getMeasuredHeight();
        view.getLayoutParams().height = 1;
        view.setVisibility(View.VISIBLE);

        android.animation.ValueAnimator animator = android.animation.ValueAnimator.ofInt(1, targetHeight);
        animator.setDuration(260);
        animator.setInterpolator(new android.view.animation.DecelerateInterpolator());
        animator.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(android.animation.ValueAnimator anim) {
                view.getLayoutParams().height = (int) anim.getAnimatedValue();
                view.requestLayout();
            }
        });
        animator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                view.getLayoutParams().height = WRAP;
                view.requestLayout();
            }
        });
        animator.start();
    }

    private void collapseView(final View view) {
        final int initialHeight = view.getMeasuredHeight();
        android.animation.ValueAnimator animator = android.animation.ValueAnimator.ofInt(initialHeight, 0);
        animator.setDuration(220);
        animator.setInterpolator(new android.view.animation.AccelerateInterpolator());
        animator.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(android.animation.ValueAnimator anim) {
                view.getLayoutParams().height = (int) anim.getAnimatedValue();
                view.requestLayout();
            }
        });
        animator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                view.setVisibility(View.GONE);
                view.getLayoutParams().height = WRAP;
            }
        });
        animator.start();
    }

    private boolean isCardOpen(int n) {
        if (n == 1) return card1Open;
        if (n == 2) return card2Open;
        if (n == 3) return card3Open;
        return false;
    }

    private void setCardOpen(int n, boolean open) {
        if (n == 1) card1Open = open;
        else if (n == 2) card2Open = open;
        else if (n == 3) card3Open = open;
    }

    private int dp(float val) {
        return (int)(val * getResources().getDisplayMetrics().density);
    }
}