package com.clumsyvpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;

import android.content.SharedPreferences;

import org.json.JSONArray;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

public class MyVpnService extends VpnService {

    public static final String ACTION_START           = "com.clumsyvpn.START";
    public static final String ACTION_STOP            = "com.clumsyvpn.STOP";
    public static final String ACTION_SIM_START       = "com.clumsyvpn.SIM_START";
    public static final String ACTION_SIM_STOP        = "com.clumsyvpn.SIM_STOP";
    public static final String ACTION_TIMER_FINISHED  = "com.clumsyvpn.TIMER_FINISHED";
    /** Применить новые настройки в реальном времени (без перезапуска тоннеля) */
    public static final String ACTION_UPDATE_SETTINGS = "com.clumsyvpn.UPDATE_SETTINGS";
    /** Запустить туннель в «Пошаговом режиме» — параметры каждого шага передаются отдельно */
    public static final String ACTION_START_STEP_MODE = "com.clumsyvpn.START_STEP_MODE";
    /** Применить параметры конкретного шага к уже работающему туннелю (вызывается FloatService по таймеру) */
    public static final String ACTION_APPLY_STEP      = "com.clumsyvpn.APPLY_STEP";

    public static final String BROADCAST_STATUS = "com.clumsyvpn.STATUS";
    public static final String BROADCAST_STATS  = "com.clumsyvpn.STATS";

    public static final String EXTRA_SERVER_DELAY        = "server_delay";
    public static final String EXTRA_SERVER_LOSS         = "server_loss";
    public static final String EXTRA_CLIENT_DELAY        = "client_delay";
    public static final String EXTRA_CLIENT_LOSS         = "client_loss";
    public static final String EXTRA_CLIENT_SZ_MODE      = "client_sz_mode";
    public static final String EXTRA_CLIENT_SZ_MIN       = "client_sz_min";
    public static final String EXTRA_CLIENT_SZ_MAX       = "client_sz_max";
    public static final String EXTRA_SERVER_SZ_MODE      = "server_sz_mode";
    public static final String EXTRA_SERVER_SZ_MIN       = "server_sz_min";
    public static final String EXTRA_SERVER_SZ_MAX       = "server_sz_max";
    public static final String EXTRA_AFTER_TIMER_MODE    = "after_timer_mode";
    public static final String EXTRA_AFTER_TIMER_DELAY   = "after_timer_delay";
    public static final String EXTRA_AFTER_TIMER_DURATION = "after_timer_duration";
    public static final String EXTRA_CLIENT_BUFFER_MODE  = "client_buffer_mode";
    public static final String EXTRA_SERVER_BUFFER_MODE  = "server_buffer_mode";
    /** Режим VPN: "default", "quantum", "shadowroute" */
    public static final String EXTRA_VPN_MODE            = "vpn_mode";
    public static final String VPN_MODE_DEFAULT      = "default";
    public static final String VPN_MODE_QUANTUM      = "quantum";
    public static final String VPN_MODE_SHADOWROUTE  = "shadowroute";

    /** Сериализованный список шагов (тот же формат, что и ConfigsActivity.serializeSteps) */
    public static final String EXTRA_STEPS_SERIALIZED    = "steps_serialized";
    /** 0 = Сброс (работает только шаг №1), 1 = Следующий шаг (цикл по всем шагам) */
    public static final String EXTRA_STEPS_AFTER_MODE    = "steps_after_mode";
    /** Индекс шага (0-based), параметры которого нужно применить прямо сейчас */
    public static final String EXTRA_STEP_INDEX          = "step_index";

    private static final String CH_ID    = "cvpn";
    private static final int    NOTIF_ID = 77;
    private static final int    MTU      = 1500;

    private ParcelFileDescriptor tunFd;
    private Thread               worker;
    private volatile boolean     tunnelActive = false;
    /** Публичный статический флаг — позволяет другим компонентам (например,
     *  StepModeActivity) узнать, запущен ли туннель, не обращаясь к instance. */
    public static volatile boolean isTunnelActive = false;

    public static NetworkSimulator simulator = null;

    // ── Пошаговый режим ──────────────────────────────────────────────────
    // MyVpnService больше НЕ управляет переключением шагов по времени —
    // единственным источником времени является FloatService (та же логика,
    // что и обычный таймер конфига), чтобы обратный отсчёт на плавающей
    // кнопке всегда совпадал с реальным переключением параметров.
    // MyVpnService только хранит текущий список шагов и применяет параметры
    // конкретного шага по команде ACTION_APPLY_STEP.
    private final java.util.ArrayList<StepData> stepList = new java.util.ArrayList<StepData>();

    /** Параметры одного шага, распакованные из строки EXTRA_STEPS_SERIALIZED */
    private static final class StepData {
        int clientDelay, clientLoss, clientBufferMode;
        int serverDelay, serverLoss, serverBufferMode;
        int clientSzMode, clientSzMin, clientSzMax;
        int serverSzMode, serverSzMin, serverSzMax;
        int durationMs;
    }

    // ── Счётчики TCP/UDP пакетов (для отображения рядом с кнопкой) ────────
    private volatile long statTcpPkts = 0;
    private volatile long statUdpPkts = 0;

    // ── TCP proxy table ────────────────────────────────────────────────────
    private final Map<String, TcpSession> tcpTable = new HashMap<>();

    /** Состояние одного TCP-соединения в нашем прокси */
    private static final class TcpSession {
        static final int S_CONNECTING  = 0;
        static final int S_ESTABLISHED = 1;
        static final int S_FIN_WAIT    = 2;
        static final int S_CLOSED      = 3;

        final String key;
        final int appIp;    // IP приложения (src исходящего пакета)
        final int appPort;  // Порт приложения
        final int dstIp;    // Реальный IP назначения
        final int dstPort;  // Реальный порт назначения

        volatile int  state = S_CONNECTING;
        // localSeq — наш текущий seq (то, что шлём В приложение)
        // remoteAck — следующий байт, который ждём ОТ приложения
        volatile long localSeq;
        volatile long remoteAck;

        Socket sock;

        TcpSession(String k, int ai, int ap, int di, int dp) {
            key = k; appIp = ai; appPort = ap; dstIp = di; dstPort = dp;
            // Начальный ISN выбираем псевдослучайно, чтобы избежать коллизий
            localSeq = 0x10000000L + (System.currentTimeMillis() & 0x00FFFFFFL);
        }
    }

    private final Handler uiHandler  = new Handler(Looper.getMainLooper());
    private Runnable      statsRunner = null;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();

        if (ACTION_START.equals(action)) {
            int sd  = intent.getIntExtra(EXTRA_SERVER_DELAY, 0);
            int sl  = intent.getIntExtra(EXTRA_SERVER_LOSS,  0);
            int cd  = intent.getIntExtra(EXTRA_CLIENT_DELAY, 0);
            int cl  = intent.getIntExtra(EXTRA_CLIENT_LOSS,  0);
            int atm = intent.getIntExtra(EXTRA_AFTER_TIMER_MODE,     0);
            int atd = intent.getIntExtra(EXTRA_AFTER_TIMER_DELAY,    0);
            int ats = intent.getIntExtra(EXTRA_AFTER_TIMER_DURATION, 3);
            int csm = intent.getIntExtra(EXTRA_CLIENT_SZ_MODE, 0);
            int csmn= intent.getIntExtra(EXTRA_CLIENT_SZ_MIN,  0);
            int csmx= intent.getIntExtra(EXTRA_CLIENT_SZ_MAX,  1500);
            int ssm = intent.getIntExtra(EXTRA_SERVER_SZ_MODE, 0);
            int ssmn= intent.getIntExtra(EXTRA_SERVER_SZ_MIN,  0);
            int ssmx= intent.getIntExtra(EXTRA_SERVER_SZ_MAX,  1500);
            String vpnMode = intent.getStringExtra(EXTRA_VPN_MODE);
            if (vpnMode == null) vpnMode = VPN_MODE_DEFAULT;
            startTunnel(sd, sl, cd, cl, atm, atd, ats, vpnMode);
            if (simulator != null) simulator.setSizeFilter(csm, csmn, csmx, ssm, ssmn, ssmx);

        } else if (ACTION_START_STEP_MODE.equals(action)) {
            String stepsSerialized = intent.getStringExtra(EXTRA_STEPS_SERIALIZED);
            String vpnMode = intent.getStringExtra(EXTRA_VPN_MODE);
            if (vpnMode == null) vpnMode = VPN_MODE_DEFAULT;
            startStepMode(stepsSerialized, vpnMode);

        } else if (ACTION_APPLY_STEP.equals(action)) {
            int stepIndex = intent.getIntExtra(EXTRA_STEP_INDEX, 0);
            applyStepByIndex(stepIndex);

        } else if (ACTION_STOP.equals(action)) {
            stopAll();

        } else if (ACTION_SIM_START.equals(action)) {
            if (simulator != null) simulator.start();

        } else if (ACTION_SIM_STOP.equals(action)) {
            if (simulator != null) simulator.stop();

        } else if (ACTION_TIMER_FINISHED.equals(action)) {
            if (simulator != null) simulator.onTimerFinished();

        } else if (ACTION_UPDATE_SETTINGS.equals(action)) {
            // Применяем новые настройки в реальном времени без перезапуска тоннеля
            if (simulator != null) {
                int sd  = intent.getIntExtra(EXTRA_SERVER_DELAY, 0);
                int sl  = intent.getIntExtra(EXTRA_SERVER_LOSS,  0);
                int cd  = intent.getIntExtra(EXTRA_CLIENT_DELAY, 0);
                int cl  = intent.getIntExtra(EXTRA_CLIENT_LOSS,  0);
                int atm = intent.getIntExtra(EXTRA_AFTER_TIMER_MODE,     0);
                int atd = intent.getIntExtra(EXTRA_AFTER_TIMER_DELAY,    0);
                int ats = intent.getIntExtra(EXTRA_AFTER_TIMER_DURATION, 3);
                int csm = intent.getIntExtra(EXTRA_CLIENT_SZ_MODE, 0);
                int csmn= intent.getIntExtra(EXTRA_CLIENT_SZ_MIN,  0);
                int csmx= intent.getIntExtra(EXTRA_CLIENT_SZ_MAX,  1500);
                int ssm = intent.getIntExtra(EXTRA_SERVER_SZ_MODE, 0);
                int ssmn= intent.getIntExtra(EXTRA_SERVER_SZ_MIN,  0);
                int ssmx= intent.getIntExtra(EXTRA_SERVER_SZ_MAX,  1500);
                simulator.updateSettings(sd, sl, cd, cl, atm, atd, ats);
                simulator.setSizeFilter(csm, csmn, csmx, ssm, ssmn, ssmx);
            }
        }

        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        stopAll();
        super.onDestroy();
    }

    /**
     * Запускает туннель в «Пошаговом режиме» с параметрами шага №1.
     * Переключением между шагами по времени управляет FloatService —
     * он же шлёт ACTION_APPLY_STEP при каждом переходе к следующему шагу.
     */
    private void startStepMode(String stepsSerialized, String vpnMode) {
        stepList.clear();
        parseStepsInto(stepsSerialized, stepList);

        if (stepList.isEmpty()) {
            // Защита от пустого списка шагов — запускаем с нулевыми параметрами
            StepData empty = new StepData();
            empty.serverSzMax = 1500;
            empty.clientSzMax = 1500;
            stepList.add(empty);
        }

        StepData first = stepList.get(0);
        startTunnel(first.serverDelay, first.serverLoss, first.clientDelay, first.clientLoss,
                    MODE_RESET_COMPAT, 0, 3, vpnMode);
        applyStepToSimulator(first);
    }

    /** Применяет параметры шага с данным индексом (вызывается FloatService по своему таймеру) */
    private void applyStepByIndex(int index) {
        if (index < 0 || index >= stepList.size()) return;
        applyStepToSimulator(stepList.get(index));
    }

    // Совместимость: обычный «после таймера» режим не используется в пошаговом
    // режиме напрямую (переключение шагов делает FloatService), поэтому передаём
    // безопасное значение по умолчанию.
    private static final int MODE_RESET_COMPAT = NetworkSimulator.MODE_RESET;

    /** Применяет параметры шага к уже созданному симулятору (без пересоздания туннеля) */
    private void applyStepToSimulator(StepData s) {
        if (simulator == null) return;
        simulator.updateSettings(s.serverDelay, s.serverLoss, s.clientDelay, s.clientLoss,
                                  MODE_RESET_COMPAT, 0, 3);
        simulator.setSizeFilter(s.clientSzMode, s.clientSzMin, s.clientSzMax,
                                 s.serverSzMode, s.serverSzMin, s.serverSzMax);
        simulator.setBufferMode(s.clientBufferMode, s.serverBufferMode);
    }

    /**
     * Разбирает строку шагов, сериализованную ConfigsActivity.serializeSteps():
     * поля через запятую, шаги через точку с запятой, в порядке:
     * clientDelay,clientLoss,clientBufferMode,serverDelay,serverLoss,serverBufferMode,
     * clientSzMode,clientSzMin,clientSzMax,serverSzMode,serverSzMin,serverSzMax,duration
     */
    private void parseStepsInto(String data, java.util.ArrayList<StepData> out) {
        if (data == null || data.isEmpty()) return;
        String[] items = data.split(";");
        for (String item : items) {
            if (item.isEmpty()) continue;
            String[] f = item.split(",");
            if (f.length < 13) continue;
            try {
                StepData s = new StepData();
                s.clientDelay      = Integer.parseInt(f[0]);
                s.clientLoss       = Integer.parseInt(f[1]);
                s.clientBufferMode = Integer.parseInt(f[2]);
                s.serverDelay      = Integer.parseInt(f[3]);
                s.serverLoss       = Integer.parseInt(f[4]);
                s.serverBufferMode = Integer.parseInt(f[5]);
                s.clientSzMode     = Integer.parseInt(f[6]);
                s.clientSzMin      = Integer.parseInt(f[7]);
                s.clientSzMax      = Integer.parseInt(f[8]);
                s.serverSzMode     = Integer.parseInt(f[9]);
                s.serverSzMin      = Integer.parseInt(f[10]);
                s.serverSzMax      = Integer.parseInt(f[11]);
                s.durationMs       = Integer.parseInt(f[12]);
                out.add(s);
            } catch (NumberFormatException ignored) {}
        }
    }

    private void startTunnel(int sd, int sl, int cd, int cl, int atm, int atd, int ats, String vpnMode) {
        if (tunnelActive) return;

        makeChannel();
        startForeground(NOTIF_ID, buildNotif());

        simulator = new NetworkSimulator(sd, sl, cd, cl, atm, atd, ats);

        try {
            Builder b = new Builder();
            b.setMtu(MTU);

            // ── Режим VPN ──────────────────────────────────────────────────
            // ShadowRoute: имитирует туннель поверх разрешённого UDP-трафика.
            // Использует нестандартный адрес подсети и специфичные DNS,
            // что обходит блокировки VPN в онлайн-играх (DPI-фильтры
            // детектируют стандартный VPN по IP-заголовку, а не по трафику).
            if (VPN_MODE_SHADOWROUTE.equals(vpnMode)) {
                b.setSession("ShadowRoute");
                // Адрес подсети отличается от стандартного — меньше шансов попасть в блок-лист
                b.addAddress("172.19.0.1", 16);
                // DNS через зашифрованный канал (DoH-прокси) — скрывает DNS-запросы
                b.addDnsServer("9.9.9.9");
                b.addDnsServer("149.112.112.112");
                // Маршрутизируем весь трафик через туннель
                b.addRoute("0.0.0.0", 0);
                b.addRoute("::", 0);
                // Не блокируем само приложение (чтобы не создать петлю)
                try { b.addDisallowedApplication(getPackageName()); } catch (Exception ignored) {}
            } else if (VPN_MODE_QUANTUM.equals(vpnMode)) {
                b.setSession("Quantum Pulse");
                b.addAddress("10.88.0.1", 24);
                b.addDnsServer("8.8.8.8");
                b.addDnsServer("1.1.1.1");
                b.addRoute("0.0.0.0", 0);
            } else {
                // Стандартный VPN (default)
                b.setSession("ClumsyVPN");
                b.addAddress("10.88.0.1", 24);
                b.addDnsServer("8.8.8.8");
                b.addDnsServer("1.1.1.1");
                b.addRoute("0.0.0.0", 0);
            }

            // ── Фильтр приложений (из AppFilterActivity) ──────────────────
            // Если пользователь выбрал конкретные приложения — туннелируем
            // только их трафик. Иначе — весь трафик, кроме нашего приложения.
            try {
                SharedPreferences fp = getSharedPreferences(
                    AppFilterActivity.PREFS_NAME, MODE_PRIVATE);
                String pkgJson = fp.getString(AppFilterActivity.KEY_PACKAGES, "");
                if (!pkgJson.isEmpty()) {
                    JSONArray arr = new JSONArray(pkgJson);
                    for (int j = 0; j < arr.length(); j++) {
                        String pkg = arr.getString(j);
                        if (!pkg.isEmpty()) {
                            try { b.addAllowedApplication(pkg); }
                            catch (Exception ignored) {}
                        }
                    }
                } else {
                    // Нет фильтра — исключаем только себя, чтобы не было петли
                    try { b.addDisallowedApplication(getPackageName()); }
                    catch (Exception ignored) {}
                }
            } catch (Exception ignored) {
                try { b.addDisallowedApplication(getPackageName()); }
                catch (Exception ex) {}
            }

            PendingIntent pi = PendingIntent.getActivity(
                this, 0, new Intent(this, MainActivity.class),
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            b.setConfigureIntent(pi);
            tunFd = b.establish();
        } catch (Exception e) {
            sendStatus("Ошибка");
            stopSelf();
            return;
        }

        if (tunFd == null) {
            sendStatus("Ошибка");
            stopSelf();
            return;
        }

        tunnelActive = true;
        isTunnelActive = true;
        sendStatus("Работает");

        worker = new Thread(new Runnable() {
            public void run() { packetLoop(); }
        }, "cvpn-loop");
        worker.start();

        statsRunner = new Runnable() {
            public void run() {
                if (!tunnelActive) return;
                Intent i = new Intent(BROADCAST_STATS);
                i.putExtra("tcp",     statTcpPkts);
                i.putExtra("udp",     statUdpPkts);
                if (simulator != null) {
                    i.putExtra("sent",    simulator.getStatSent());
                    i.putExtra("dropped", simulator.getStatDropped());
                    i.putExtra("delayed", simulator.getStatDelayed());
                }
                sendBroadcast(i);
                uiHandler.postDelayed(this, 1000);
            }
        };
        uiHandler.postDelayed(statsRunner, 1000);
    }

    private void stopAll() {
        tunnelActive = false;
        isTunnelActive = false;
        stepList.clear();

        if (simulator != null) { simulator.stop(); simulator = null; }
        if (statsRunner != null) { uiHandler.removeCallbacks(statsRunner); statsRunner = null; }
        if (worker != null) { worker.interrupt(); worker = null; }

        // Закрываем все открытые TCP-сессии
        synchronized (tcpTable) {
            for (TcpSession s : tcpTable.values()) {
                s.state = TcpSession.S_CLOSED;
                if (s.sock != null) {
                    try { s.sock.close(); } catch (IOException ignored) {}
                }
            }
            tcpTable.clear();
        }

        statTcpPkts = 0;
        statUdpPkts = 0;

        if (tunFd != null) {
            try { tunFd.close(); } catch (IOException ignored) {}
            tunFd = null;
        }

        sendStatus("Остановлен");
        stopForeground(true);
        stopSelf();
    }

    // ─── Цикл пакетов ─────────────────────────────────────────────────────
    //
    // ФИКС: оригинал писал пакеты обратно в тот же TUN fd →
    // трафик не выходил в реальную сеть → противники замирали всегда.
    //
    // Теперь UDP-пакеты идут через protect()-защищённый DatagramChannel
    // в реальную сеть. protect() исключает сокет из VPN-перехвата.
    //
    private void packetLoop() {
        FileInputStream        tunIn  = new FileInputStream(tunFd.getFileDescriptor());
        final FileOutputStream tunOut = new FileOutputStream(tunFd.getFileDescriptor());

        Map<String, DatagramChannel> udpTable = new HashMap<String, DatagramChannel>();
        byte[] buf = new byte[MTU];

        while (tunnelActive && !Thread.currentThread().isInterrupted()) {
            try {
                int len = tunIn.read(buf);
                if (len < 20) { nap(1); continue; }

                int ipVer    = (buf[0] >> 4) & 0xF;
                int ipProto  = buf[9] & 0xFF;
                int ipHdrLen = (buf[0] & 0xF) * 4;

                // IPv6 — не трогаем
                if (ipVer != 4) { tunOut.write(buf, 0, len); continue; }

                if (ipProto == 17 && len > ipHdrLen + 8) {
                    // UDP — считаем + симулятор + форвардинг
                    statUdpPkts++;
                    if (simulator != null && !simulator.process(len, 0)) continue;
                    forwardUdp(buf, len, ipHdrLen, udpTable, tunOut);
                } else if (ipProto == 6 && len > ipHdrLen + 20) {
                    // TCP — считаем + прокси (без симулятора, игры в основном UDP)
                    statTcpPkts++;
                    handleTcp(buf, len, ipHdrLen, tunOut);
                } else {
                    // Прочие протоколы — симулятор + пропускаем без изменений
                    if (simulator != null && !simulator.process(len, 0)) continue;
                    tunOut.write(buf, 0, len);
                }

            } catch (IOException e) {
                if (tunnelActive) nap(5);
            }
        }

        for (DatagramChannel ch : udpTable.values()) {
            try { ch.close(); } catch (IOException ignored) {}
        }
        try { tunIn.close();  } catch (IOException ignored) {}
        try { tunOut.close(); } catch (IOException ignored) {}
    }

    private void forwardUdp(byte[] buf, int len, int ipHdrLen,
                             Map<String, DatagramChannel> udpTable,
                             final FileOutputStream tunOut) {
        try {
            final int srcIp = ((buf[12]&0xFF)<<24)|((buf[13]&0xFF)<<16)|((buf[14]&0xFF)<<8)|(buf[15]&0xFF);
            int       dstIp = ((buf[16]&0xFF)<<24)|((buf[17]&0xFF)<<16)|((buf[18]&0xFF)<<8)|(buf[19]&0xFF);

            final int srcPort = ((buf[ipHdrLen]  &0xFF)<<8)|(buf[ipHdrLen+1]&0xFF);
            int       dstPort = ((buf[ipHdrLen+2]&0xFF)<<8)|(buf[ipHdrLen+3]&0xFF);
            int       udpLen  = ((buf[ipHdrLen+4]&0xFF)<<8)|(buf[ipHdrLen+5]&0xFF);
            int       payLen  = udpLen - 8;

            if (payLen <= 0 || ipHdrLen + 8 + payLen > len) return;

            String key = dstIp + "_" + dstPort + "_" + srcPort;
            DatagramChannel ch = udpTable.get(key);

            if (ch == null || !ch.isOpen()) {
                ch = DatagramChannel.open();
                protect(ch.socket()); // ← без этого пакеты снова уходят в TUN (петля)
                ch.configureBlocking(false);
                udpTable.put(key, ch);
                startUdpReader(ch, srcIp, srcPort, tunOut);
            }

            byte[] dstBytes = {(byte)(dstIp>>24),(byte)(dstIp>>16),(byte)(dstIp>>8),(byte)dstIp};
            ch.send(ByteBuffer.wrap(buf, ipHdrLen+8, payLen),
                    new InetSocketAddress(InetAddress.getByAddress(dstBytes), dstPort));

        } catch (Exception ignored) {}
    }

    // ─── TCP-прокси ────────────────────────────────────────────────────────
    //
    // ПРОБЛЕМА: раньше TCP-пакеты писались обратно в tunOut → трафик никогда
    // не выходил в интернет («чёрная дыра») → у противников в играх замирали
    // позиции, не работала авторизация, лобби, чат и т.д.
    //
    // ИСПРАВЛЕНИЕ: для каждого нового TCP-соединения (SYN) создаём protected
    // java.net.Socket к реальному серверу и проксируем данные в обе стороны.
    //
    private void handleTcp(final byte[] buf, int len, int ipHdrLen,
                            final FileOutputStream tunOut) {
        try {
            final int srcIp  = readInt(buf, 12);
            final int dstIp  = readInt(buf, 16);
            final int srcPort = readUShort(buf, ipHdrLen);
            final int dstPort = readUShort(buf, ipHdrLen + 2);
            final long seqNum = readUInt(buf, ipHdrLen + 4);
            final long ackNum = readUInt(buf, ipHdrLen + 8);
            final int  dataOff = ((buf[ipHdrLen + 12] & 0xF0) >> 4) * 4;
            final int  flags   = buf[ipHdrLen + 13] & 0xFF;
            final boolean fSYN = (flags & 0x02) != 0;
            final boolean fACK = (flags & 0x10) != 0;
            final boolean fFIN = (flags & 0x01) != 0;
            final boolean fRST = (flags & 0x04) != 0;
            final boolean fPSH = (flags & 0x08) != 0;
            final int payOff = ipHdrLen + dataOff;
            final int payLen = len - payOff;

            final String key = srcIp + ":" + srcPort + ":" + dstIp + ":" + dstPort;

            if (fRST) {
                TcpSession s;
                synchronized (tcpTable) { s = tcpTable.remove(key); }
                if (s != null) closeTcpSession(s);
                return;
            }

            TcpSession session;
            synchronized (tcpTable) { session = tcpTable.get(key); }

            if (fSYN && !fACK) {
                // ── Новое соединение ──────────────────────────────────────
                if (session != null) closeTcpSession(session);
                final TcpSession ns = new TcpSession(key, srcIp, srcPort, dstIp, dstPort);
                ns.remoteAck = (seqNum + 1L) & 0xFFFFFFFFL; // ack ISN+1
                synchronized (tcpTable) { tcpTable.put(key, ns); }

                new Thread(new Runnable() {
                    public void run() {
                        try {
                            Socket sock = new Socket();
                            protect(sock);
                            byte[] dstB = intToBytes(dstIp);
                            sock.connect(
                                new InetSocketAddress(InetAddress.getByAddress(dstB), dstPort),
                                10000);
                            sock.setTcpNoDelay(true);
                            ns.sock = sock;
                            ns.state = TcpSession.S_ESTABLISHED;

                            // Отправляем SYN+ACK приложению
                            sendTcpFlags(tunOut, ns, 0x12, null, 0); // SYN+ACK
                            ns.localSeq = (ns.localSeq + 1L) & 0xFFFFFFFFL; // SYN занимает 1 байт

                            startTcpReader(ns, tunOut);
                        } catch (Exception e) {
                            sendTcpFlags(tunOut, ns, 0x04, null, 0); // RST
                            synchronized (tcpTable) { tcpTable.remove(key); }
                        }
                    }
                }, "tcp-conn").start();
                return;
            }

            if (session == null) {
                // Неизвестная сессия — отправляем RST
                sendTcpRst(tunOut, dstIp, dstPort, srcIp, srcPort, 0, (seqNum + payLen + 1L) & 0xFFFFFFFFL);
                return;
            }

            if (session.state != TcpSession.S_ESTABLISHED) return;

            if (payLen > 0) {
                // ── Данные от приложения → реальный сервер ───────────────
                try {
                    session.sock.getOutputStream().write(buf, payOff, payLen);
                    session.remoteAck = (seqNum + payLen) & 0xFFFFFFFFL;
                    sendTcpFlags(tunOut, session, 0x10, null, 0); // ACK
                } catch (IOException e) {
                    closeTcpSession(session);
                    synchronized (tcpTable) { tcpTable.remove(key); }
                }
            }

            if (fFIN) {
                // ── Приложение закрывает соединение ──────────────────────
                session.remoteAck = (seqNum + Math.max(payLen, 0) + 1L) & 0xFFFFFFFFL;
                session.state = TcpSession.S_FIN_WAIT;
                try { session.sock.shutdownOutput(); } catch (IOException ignored) {}
                sendTcpFlags(tunOut, session, 0x11, null, 0); // FIN+ACK
                session.localSeq = (session.localSeq + 1L) & 0xFFFFFFFFL;
            }

        } catch (Exception ignored) {}
    }

    private void startTcpReader(final TcpSession session, final FileOutputStream tunOut) {
        new Thread(new Runnable() {
            public void run() {
                byte[] rb = new byte[MTU - 40];
                try {
                    InputStream in = session.sock.getInputStream();
                    int n;
                    while (tunnelActive && (n = in.read(rb)) != -1) {
                        if (n > 0 && session.state == TcpSession.S_ESTABLISHED) {
                            // Симулятор для входящих данных
                            if (simulator != null && !simulator.process(n, 1)) continue;
                            sendTcpFlags(tunOut, session, 0x18, rb, n); // PSH+ACK
                            session.localSeq = (session.localSeq + n) & 0xFFFFFFFFL;
                        }
                    }
                    // Сервер закрыл соединение
                    if (session.state == TcpSession.S_ESTABLISHED) {
                        session.state = TcpSession.S_FIN_WAIT;
                        sendTcpFlags(tunOut, session, 0x11, null, 0); // FIN+ACK
                        session.localSeq = (session.localSeq + 1L) & 0xFFFFFFFFL;
                    }
                } catch (IOException ignored) {
                    if (session.state == TcpSession.S_ESTABLISHED) {
                        sendTcpRst(tunOut, session.dstIp, session.dstPort,
                            session.appIp, session.appPort,
                            session.localSeq, session.remoteAck);
                    }
                } finally {
                    closeTcpSession(session);
                    synchronized (tcpTable) { tcpTable.remove(session.key); }
                }
            }
        }, "tcp-read").start();
    }

    private void closeTcpSession(TcpSession s) {
        s.state = TcpSession.S_CLOSED;
        if (s.sock != null) {
            try { s.sock.close(); } catch (IOException ignored) {}
        }
    }

    /**
     * Собирает и отправляет TCP/IP пакет в TUN (приложению).
     * @param flags  TCP-флаги: 0x02=SYN, 0x10=ACK, 0x11=FIN+ACK, 0x12=SYN+ACK,
     *               0x04=RST, 0x18=PSH+ACK
     * @param data   payload (может быть null)
     * @param dataLen длина payload
     */
    private void sendTcpFlags(FileOutputStream tunOut, TcpSession s,
                               int flags, byte[] data, int dataLen) {
        byte[] pkt = buildTcpPacket(
            s.dstIp,  s.dstPort,   // src (с точки зрения приложения — это "сервер")
            s.appIp,  s.appPort,   // dst (само приложение)
            s.localSeq, s.remoteAck,
            flags, data, dataLen);
        if (pkt != null) {
            synchronized (tunOut) {
                try { tunOut.write(pkt); } catch (IOException ignored) {}
            }
        }
    }

    private void sendTcpRst(FileOutputStream tunOut,
                             int srcIp, int srcPort, int dstIp, int dstPort,
                             long seq, long ack) {
        byte[] pkt = buildTcpPacket(srcIp, srcPort, dstIp, dstPort, seq, ack,
            0x04, null, 0); // RST
        if (pkt != null) {
            synchronized (tunOut) {
                try { tunOut.write(pkt); } catch (IOException ignored) {}
            }
        }
    }

    /** Собирает полный IP+TCP пакет для записи в TUN */
    private byte[] buildTcpPacket(int srcIp, int srcPort, int dstIp, int dstPort,
                                   long seq, long ack, int flags,
                                   byte[] data, int dataLen) {
        try {
            int totalLen = 20 + 20 + dataLen;
            byte[] p = new byte[totalLen];

            // ── IP Header (20 bytes) ──────────────────────────────────────
            p[0]  = 0x45;
            p[1]  = 0;
            p[2]  = (byte)(totalLen >> 8);
            p[3]  = (byte) totalLen;
            p[4]  = 0; p[5] = 0;         // identification
            p[6]  = 0x40; p[7] = 0;       // DF flag
            p[8]  = 64;                    // TTL
            p[9]  = 6;                     // TCP protocol
            p[10] = 0; p[11] = 0;          // checksum (calculated below)
            p[12] = (byte)(srcIp >> 24); p[13] = (byte)(srcIp >> 16);
            p[14] = (byte)(srcIp >> 8);  p[15] = (byte) srcIp;
            p[16] = (byte)(dstIp >> 24); p[17] = (byte)(dstIp >> 16);
            p[18] = (byte)(dstIp >> 8);  p[19] = (byte) dstIp;

            int ipCs = ipChecksum(p, 0, 20);
            p[10] = (byte)(ipCs >> 8); p[11] = (byte) ipCs;

            // ── TCP Header (20 bytes) ─────────────────────────────────────
            p[20] = (byte)(srcPort >> 8); p[21] = (byte) srcPort;
            p[22] = (byte)(dstPort >> 8); p[23] = (byte) dstPort;
            // Sequence number
            p[24] = (byte)(seq >> 24); p[25] = (byte)(seq >> 16);
            p[26] = (byte)(seq >> 8);  p[27] = (byte) seq;
            // Acknowledgment number
            p[28] = (byte)(ack >> 24); p[29] = (byte)(ack >> 16);
            p[30] = (byte)(ack >> 8);  p[31] = (byte) ack;
            p[32] = 0x50;                  // Data offset = 5 (20 bytes), reserved = 0
            p[33] = (byte) flags;
            p[34] = (byte) 0xFF; p[35] = (byte) 0xFF; // window size = 65535
            p[36] = 0; p[37] = 0;          // checksum (calculated below)
            p[38] = 0; p[39] = 0;          // urgent pointer

            // ── Payload ───────────────────────────────────────────────────
            if (data != null && dataLen > 0) {
                System.arraycopy(data, 0, p, 40, dataLen);
            }

            // ── TCP checksum (pseudo-header + TCP segment) ─────────────
            int tcpLen  = 20 + dataLen;
            int tcpCs   = tcpChecksum(srcIp, dstIp, p, 20, tcpLen);
            p[36] = (byte)(tcpCs >> 8); p[37] = (byte) tcpCs;

            return p;
        } catch (Exception e) { return null; }
    }

    /** Считает IP-checksum для заголовка длиной hdrLen начиная с offset */
    private static int ipChecksum(byte[] buf, int offset, int hdrLen) {
        int sum = 0;
        for (int i = offset; i < offset + hdrLen; i += 2) {
            sum += ((buf[i] & 0xFF) << 8) | (buf[i + 1] & 0xFF);
        }
        while ((sum >> 16) != 0) sum = (sum & 0xFFFF) + (sum >> 16);
        return (~sum) & 0xFFFF;
    }

    /** Считает TCP-checksum через pseudo-header */
    private static int tcpChecksum(int srcIp, int dstIp,
                                    byte[] buf, int tcpOffset, int tcpLen) {
        // Pseudo-header: srcIP(4) + dstIP(4) + 0(1) + proto(1) + tcpLen(2)
        int sum = 0;
        sum += (srcIp >> 16) & 0xFFFF;
        sum += srcIp & 0xFFFF;
        sum += (dstIp >> 16) & 0xFFFF;
        sum += dstIp & 0xFFFF;
        sum += 6; // TCP protocol
        sum += tcpLen & 0xFFFF;
        // TCP segment
        int end = tcpOffset + tcpLen;
        for (int i = tcpOffset; i < end - 1; i += 2) {
            sum += ((buf[i] & 0xFF) << 8) | (buf[i + 1] & 0xFF);
        }
        if ((tcpLen & 1) != 0) {
            sum += (buf[end - 1] & 0xFF) << 8; // нечётный последний байт
        }
        while ((sum >> 16) != 0) sum = (sum & 0xFFFF) + (sum >> 16);
        return (~sum) & 0xFFFF;
    }

    // Утилиты чтения big-endian значений из буфера пакета
    private static int  readInt(byte[] b, int o) {
        return ((b[o]&0xFF)<<24)|((b[o+1]&0xFF)<<16)|((b[o+2]&0xFF)<<8)|(b[o+3]&0xFF);
    }
    private static int  readUShort(byte[] b, int o) {
        return ((b[o]&0xFF)<<8)|(b[o+1]&0xFF);
    }
    private static long readUInt(byte[] b, int o) {
        return ((long)readInt(b, o)) & 0xFFFFFFFFL;
    }
    private static byte[] intToBytes(int v) {
        return new byte[]{(byte)(v>>24),(byte)(v>>16),(byte)(v>>8),(byte)v};
    }

    private void startUdpReader(final DatagramChannel ch,
                                 final int dstIp, final int dstPort,
                                 final FileOutputStream tunOut) {
        Thread t = new Thread(new Runnable() {
            public void run() {
                byte[]     rb  = new byte[MTU];
                ByteBuffer rbb = ByteBuffer.wrap(rb);
                while (tunnelActive && ch.isOpen()) {
                    try {
                        rbb.clear();
                        InetSocketAddress from = (InetSocketAddress) ch.receive(rbb);
                        if (from == null) { nap(1); continue; }
                        int payLen = rbb.position();

                        // Симулятор для входящих (direction=1 = сервер→клиент)
                        if (simulator != null && !simulator.process(payLen, 1)) continue;

                        byte[] fromAddr = from.getAddress().getAddress();
                        int    fromPort = from.getPort();
                        int    total    = 20 + 8 + payLen;
                        byte[] pkt = buildUdpIp(fromAddr, fromPort, dstIp, dstPort, rb, payLen, total);

                        synchronized (tunOut) { tunOut.write(pkt, 0, total); }
                    } catch (IOException e) { break; }
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private byte[] buildUdpIp(byte[] srcAddr, int srcPort, int dstIp, int dstPort,
                                byte[] payload, int payLen, int total) {
        byte[] p = new byte[total];
        p[0]=0x45; p[1]=0;
        p[2]=(byte)(total>>8); p[3]=(byte)total;
        p[4]=0; p[5]=0; p[6]=0x40; p[7]=0;
        p[8]=64; p[9]=17; p[10]=0; p[11]=0;
        p[12]=srcAddr[0]; p[13]=srcAddr[1]; p[14]=srcAddr[2]; p[15]=srcAddr[3];
        p[16]=(byte)(dstIp>>24); p[17]=(byte)(dstIp>>16); p[18]=(byte)(dstIp>>8); p[19]=(byte)dstIp;
        int cs=0;
        for (int i=0;i<20;i+=2) cs+=((p[i]&0xFF)<<8)|(p[i+1]&0xFF);
        while((cs>>16)!=0) cs=(cs&0xFFFF)+(cs>>16);
        cs=~cs&0xFFFF;
        p[10]=(byte)(cs>>8); p[11]=(byte)cs;
        int ul=8+payLen;
        p[20]=(byte)(srcPort>>8); p[21]=(byte)srcPort;
        p[22]=(byte)(dstPort>>8); p[23]=(byte)dstPort;
        p[24]=(byte)(ul>>8); p[25]=(byte)ul;
        p[26]=0; p[27]=0;
        System.arraycopy(payload, 0, p, 28, payLen);
        return p;
    }

    private void sendStatus(String s) {
        Intent i = new Intent(BROADCAST_STATUS);
        i.putExtra("status", s);
        sendBroadcast(i);
    }

    private void nap(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private void makeChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CH_ID, "ClumsyVPN", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotif() {
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
            Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return new Notification.Builder(this, CH_ID)
                .setContentTitle("ClumsyVPN").setContentText("VPN активен")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pi).setOngoing(true).build();
        } else {
            return new Notification.Builder(this)
                .setContentTitle("ClumsyVPN").setContentText("VPN активен")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pi).setOngoing(true).build();
        }
    }
}
