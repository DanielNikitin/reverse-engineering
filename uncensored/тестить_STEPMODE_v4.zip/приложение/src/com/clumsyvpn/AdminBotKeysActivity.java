package com.clumsyvpn;

import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.os.Bundle;
import android.os.Handler;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Раздел «Ключи, созданные ботом» в панели администратора (Key System).
 * В отличие от BotKeysActivity (личный экран пользователя, показывающий
 * только ЕГО СОБСТВЕННЫЙ бот-ключ через /bot/keys/list), этот экран
 * показывает АБСОЛЮТНО ВСЕ ключи, когда-либо выданные Telegram-ботом,
 * через админский эндпоинт /admin/bot/keys/list. Только для чтения.
 */
public class AdminBotKeysActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    private String serverUrl;
    private String adminLogin;
    private String adminPassword;

    private LinearLayout keysContainer;
    private TextView tvEmpty;

    // ── ЛОКАЛЬНО СКРЫТЫЕ КАРТОЧКИ ──────────────────────────────────
    // Та же логика, что и в KeySystemActivity: когда бот-ключ деактивирован
    // или заблокирован (бан), админ может убрать карточку из списка кнопкой
    // «Убрать карточку». Это чисто локальная отметка — на сервере ключ не
    // трогается. Если статус ключа перестал быть деактивированным/
    // заблокированным (например, после разбана) — карточка возвращается сама.
    private static final String HIDDEN_CARDS_PREFS = "admin_bot_keys_hidden_cards";

    private boolean isCardHidden(String keyValue) {
        if (keyValue == null || keyValue.isEmpty()) return false;
        SharedPreferences p = getSharedPreferences(HIDDEN_CARDS_PREFS, MODE_PRIVATE);
        return p.getBoolean(keyValue, false);
    }

    private void hideCard(String keyValue) {
        if (keyValue == null || keyValue.isEmpty()) return;
        getSharedPreferences(HIDDEN_CARDS_PREFS, MODE_PRIVATE).edit().putBoolean(keyValue, true).apply();
    }

    private void unhideCard(String keyValue) {
        if (keyValue == null || keyValue.isEmpty()) return;
        getSharedPreferences(HIDDEN_CARDS_PREFS, MODE_PRIVATE).edit().remove(keyValue).apply();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        adminLogin    = prefs.getString(AuthActivity.KEY_LOGIN, "");
        adminPassword = prefs.getString(AuthActivity.KEY_PASSWORD, "");
        serverUrl     = AuthActivity.SERVER_URL;

        buildUI();
        loadKeys();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadKeys();
    }

    // ══════════════════════════════════════════════════
    //  UI
    // ══════════════════════════════════════════════════
    private void buildUI() {
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF030507);
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));

        // Header
        final LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(16), dp(16), dp(16));
        header.setBackgroundColor(0xFF07090C);

        final TextView btnBack = new TextView(this);
        btnBack.setText("\u2039");
        btnBack.setTextSize(22);
        btnBack.setTextColor(0xFF2AABEE);
        btnBack.setTypeface(null, Typeface.BOLD);
        btnBack.setPadding(0, 0, dp(16), 0);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        header.addView(btnBack);

        final TextView tvTitle = new TextView(this);
        tvTitle.setText("\uD83E\uDD16  \u041A\u043B\u044E\u0447\u0438, \u0441\u043E\u0437\u0434\u0430\u043D\u043D\u044B\u0435 \u0431\u043E\u0442\u043E\u043C");
        tvTitle.setTextSize(15);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        header.addView(tvTitle);

        root.addView(header);

        final View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        divider.setBackgroundColor(0xFF17202A);
        root.addView(divider);

        // Подзаголовок
        final TextView tvSub = new TextView(this);
        tvSub.setText("\u0412\u0441\u0435 \u043A\u043B\u044E\u0447\u0438, \u0432\u044B\u0434\u0430\u043D\u043D\u044B\u0435 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u0447\u0435\u0440\u0435\u0437 Telegram-\u0431\u043E\u0442\u0430 (\u0432\u0441\u0435\u043C \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F\u043C).");
        tvSub.setTextSize(12);
        tvSub.setTextColor(0xFF6C7885);
        tvSub.setPadding(dp(16), dp(10), dp(16), dp(10));
        root.addView(tvSub);

        // Keys list
        final ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));

        keysContainer = new LinearLayout(this);
        keysContainer.setOrientation(LinearLayout.VERTICAL);
        keysContainer.setPadding(dp(12), dp(12), dp(12), dp(12));

        tvEmpty = new TextView(this);
        tvEmpty.setText("\u0421\u043F\u0438\u0441\u043E\u043A \u043F\u0443\u0441\u0442");
        tvEmpty.setTextSize(14);
        tvEmpty.setTextColor(0xFF6C7885);
        tvEmpty.setGravity(Gravity.CENTER);
        tvEmpty.setPadding(dp(16), dp(48), dp(16), dp(48));
        tvEmpty.setVisibility(View.GONE);
        keysContainer.addView(tvEmpty);

        scroll.addView(keysContainer);
        root.addView(scroll);

        setContentView(root);
    }

    // ══════════════════════════════════════════════════
    //  LOAD
    // ══════════════════════════════════════════════════
    private void loadKeys() {
        final String fAdminLogin    = adminLogin;
        final String fAdminPassword = adminPassword;
        final String fServerUrl     = serverUrl;
        final LinearLayout fContainer = keysContainer;
        final TextView fEmpty = tvEmpty;
        new Thread(new Runnable() {
            public void run() {
                try {
                    String q = "\"";
                    String body = "{" + q + "adminLogin" + q + ":" + q + esc(fAdminLogin) + q
                        + "," + q + "adminPassword" + q + ":" + q + esc(fAdminPassword) + q + "}";
                    String resp = httpPost(fServerUrl + "/admin/bot/keys/list", body);
                    final JSONArray arr = parseKeysArray(resp);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            fContainer.removeAllViews();
                            if (arr == null || arr.length() == 0) {
                                fEmpty.setVisibility(View.VISIBLE);
                                fContainer.addView(fEmpty);
                            } else {
                                fEmpty.setVisibility(View.GONE);
                                for (int i = 0; i < arr.length(); i++) {
                                    try { addKeyCard(arr.getJSONObject(i)); }
                                    catch (Exception ignored) {}
                                }
                            }
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            fEmpty.setText("\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438");
                            fEmpty.setVisibility(View.VISIBLE);
                            fContainer.addView(fEmpty);
                        }
                    });
                }
            }
        }).start();
    }

    private JSONArray parseKeysArray(String resp) {
        try {
            JSONObject obj = new JSONObject(resp);
            return obj.optJSONArray("keys");
        } catch (Exception e) { return null; }
    }

    // ══════════════════════════════════════════════════
    //  KEY CARD
    // ══════════════════════════════════════════════════
    private void addKeyCard(final JSONObject key) {
        try {
            final String keyValue = key.optString("key", "");
            final String status   = key.optString("status", "inactive");
            int usersCount = 0;
            try { usersCount = key.getJSONArray("users").length(); } catch (Exception ignored) {}

            final boolean isHideable = "deactivated".equals(status) || "blocked".equals(status);
            if (!isHideable && isCardHidden(keyValue)) {
                unhideCard(keyValue);
            }
            if (isCardHidden(keyValue)) {
                return;
            }

            final LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(MATCH, WRAP);
            clp.bottomMargin = dp(10);
            card.setLayoutParams(clp);

            final GradientDrawable cardBg = new GradientDrawable();
            cardBg.setShape(GradientDrawable.RECTANGLE);
            cardBg.setCornerRadius(dp(14));
            cardBg.setColor(0xFF0C1014);
            int borderColor;
            if ("active".equals(status))           borderColor = 0xFF2AABEE;
            else if ("expired".equals(status))     borderColor = 0xFFFF1E4E;
            else if ("blocked".equals(status))     borderColor = 0xFFFF1E4E;
            else if ("deactivated".equals(status)) borderColor = 0xFFFF6B00;
            else                                   borderColor = 0xFF17202A;
            cardBg.setStroke(1, borderColor);
            card.setBackground(cardBg);

            // Row: key + status
            final LinearLayout row1 = new LinearLayout(this);
            row1.setOrientation(LinearLayout.HORIZONTAL);
            row1.setGravity(Gravity.CENTER_VERTICAL);

            final TextView tvKey = new TextView(this);
            tvKey.setText(keyValue);
            tvKey.setTextSize(12);
            tvKey.setTextColor(0xFFB8C4D0);
            tvKey.setTypeface(null, Typeface.BOLD);
            tvKey.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
            row1.addView(tvKey);

            final TextView tvStatus = new TextView(this);
            String statusLabel;
            int statusColor, statusBgColor;
            if ("active".equals(status)) {
                statusLabel = "\u0410\u043A\u0442\u0438\u0432\u0435\u043D";
                statusColor = 0xFF2AABEE; statusBgColor = 0x1A2AABEE;
            } else if ("expired".equals(status)) {
                statusLabel = "\u0418\u0441\u0442\u0451\u043A";
                statusColor = 0xFFFF1E4E; statusBgColor = 0x1AFF1E4E;
            } else if ("blocked".equals(status)) {
                statusLabel = "\uD83D\uDEAB \u0417\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D";
                statusColor = 0xFFFF1E4E; statusBgColor = 0x1AFF1E4E;
            } else if ("deactivated".equals(status)) {
                statusLabel = "\u0414\u0435\u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D";
                statusColor = 0xFFFF6B00; statusBgColor = 0x1AFF6B00;
            } else {
                statusLabel = "\u041D\u0435 \u0430\u043A\u0442\u0438\u0432\u0435\u043D";
                statusColor = 0xFF6C7885; statusBgColor = 0x1A6C7885;
            }
            tvStatus.setText(statusLabel);
            tvStatus.setTextSize(11);
            tvStatus.setTextColor(statusColor);
            tvStatus.setTypeface(null, Typeface.BOLD);
            tvStatus.setPadding(dp(10), dp(4), dp(10), dp(4));
            {
                final GradientDrawable sBg = new GradientDrawable();
                sBg.setShape(GradientDrawable.RECTANGLE);
                sBg.setCornerRadius(dp(8));
                sBg.setColor(statusBgColor);
                sBg.setStroke(1, statusColor);
                tvStatus.setBackground(sBg);
            }
            row1.addView(tvStatus);
            card.addView(row1);

            // Telegram info
            final JSONObject tg = key.optJSONObject("telegram");
            final TextView tvTg = new TextView(this);
            String tgLabel;
            if (tg != null) {
                String uname = tg.optString("username", "");
                String fname = tg.optString("firstName", "");
                String who = !uname.isEmpty() ? ("@" + uname) : (!fname.isEmpty() ? fname : ("id" + tg.optString("id", "")));
                tgLabel = "\uD83E\uDD16 \u0412\u044B\u0434\u0430\u043D \u0431\u043E\u0442\u043E\u043C \u2022 " + who;
            } else {
                tgLabel = "\uD83E\uDD16 \u0412\u044B\u0434\u0430\u043D \u0431\u043E\u0442\u043E\u043C \u2022 telegramId: " + key.optString("telegramId", "?");
            }
            tvTg.setText(tgLabel);
            tvTg.setTextSize(10);
            tvTg.setTextColor(0xFF2AABEE);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(MATCH, WRAP);
            blp.topMargin = dp(4);
            tvTg.setLayoutParams(blp);
            card.addView(tvTg);

            // Users count
            final TextView tvUsers = new TextView(this);
            tvUsers.setText("\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u0439: " + usersCount);
            tvUsers.setTextSize(11);
            tvUsers.setTextColor(0xFF6C7885);
            LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(MATCH, WRAP);
            ulp.topMargin = dp(4);
            tvUsers.setLayoutParams(ulp);
            card.addView(tvUsers);

            // Expiry
            String expiryAt = key.optString("expiryAt", "");
            if (!expiryAt.isEmpty()) {
                final TextView tvExp = new TextView(this);
                tvExp.setText("\u0421\u0440\u043E\u043A: " + formatDate(expiryAt));
                tvExp.setTextSize(11);
                tvExp.setTextColor(0xFF6C7885);
                LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(MATCH, WRAP);
                elp.topMargin = dp(2);
                tvExp.setLayoutParams(elp);
                card.addView(tvExp);
            }

            final JSONObject keyRef = key;
            card.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { showKeyDetailDialog(keyRef); }
            });

            keysContainer.addView(card);
        } catch (Exception ignored) {}
    }

    // ══════════════════════════════════════════════════
    //  KEY DETAIL DIALOG
    // ══════════════════════════════════════════════════
    private void showKeyDetailDialog(final JSONObject key) {
        try {
            final String keyValue  = key.optString("key", "");
            final String status    = key.optString("status", "inactive");
            final int expiryDays   = key.optInt("expiryDays", 1488);
            final String createdAt = key.optString("createdAt", "");
            final String expiryAt  = key.optString("expiryAt", "");
            final JSONObject tg    = key.optJSONObject("telegram");

            final Dialog d = new Dialog(this);
            d.requestWindowFeature(Window.FEATURE_NO_TITLE);
            d.setCancelable(true);

            final LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(dp(20), dp(20), dp(20), dp(20));
            {
                final GradientDrawable bg = new GradientDrawable();
                bg.setShape(GradientDrawable.RECTANGLE);
                bg.setCornerRadius(dp(18));
                bg.setColor(0xFF0C1014);
                bg.setStroke(2, 0xFF2AABEE);
                root.setBackground(bg);
            }

            final TextView tvTitle = new TextView(this);
            tvTitle.setText("\uD83E\uDD16  \u041A\u043B\u044E\u0447 \u0431\u043E\u0442\u0430");
            tvTitle.setTextSize(16);
            tvTitle.setTextColor(0xFFFFFFFF);
            tvTitle.setTypeface(null, Typeface.BOLD);
            root.addView(tvTitle);
            addSpace(root, 12);

            // Статус — центрированный цветной индикатор, как в обычной карточке
            // ключа (KeySystemActivity), а не серая строка "Статус: active".
            {
                String statusLabel2;
                int statusColor2;
                if ("active".equals(status))           { statusLabel2 = "\u25CF \u0410\u043A\u0442\u0438\u0432\u0435\u043D";        statusColor2 = 0xFF00FF9D; }
                else if ("expired".equals(status))     { statusLabel2 = "\u25CF \u0418\u0441\u0442\u0451\u043A";           statusColor2 = 0xFFFF1E4E; }
                else if ("blocked".equals(status))     { statusLabel2 = "\u25CF \u0417\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D"; statusColor2 = 0xFFFF1E4E; }
                else if ("deactivated".equals(status)) { statusLabel2 = "\u25CF \u0414\u0435\u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D"; statusColor2 = 0xFFFF6B00; }
                else                                    { statusLabel2 = "\u25CF \u041D\u0435 \u0430\u043A\u0442\u0438\u0432\u0435\u043D";    statusColor2 = 0xFF6C7885; }

                final TextView tvSt = new TextView(this);
                tvSt.setText(statusLabel2);
                tvSt.setTextSize(12);
                tvSt.setTextColor(statusColor2);
                tvSt.setTypeface(null, Typeface.BOLD);
                tvSt.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(MATCH, WRAP);
                root.addView(tvSt);
                addSpace(root, 10);
            }

            addInfoRow(root, "\u0421\u0440\u043E\u043A \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F:", expiryDays + " \u0434\u043D.");
            if (!createdAt.isEmpty()) addInfoRow(root, "\u0421\u043E\u0437\u0434\u0430\u043D:", formatDate(createdAt));
            addSpace(root, 8);

            // Дивайдер перед блоком пользователя
            {
                View divU = new View(this);
                divU.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
                divU.setBackgroundColor(0xFF17202A);
                root.addView(divU);
                addSpace(root, 10);
            }

            final boolean isBlockedForCard      = "blocked".equals(status);
            final boolean isDeactivatedForCard  = "deactivated".equals(status);
            final String  reasonForCard         = key.optString("reason", "");

            JSONArray users = key.optJSONArray("users");
            if (isDeactivatedForCard || isBlockedForCard) {
                // Тот же красный маркер, что и в обычной карточке ключа
                // (KeySystemActivity.addBannedMarkerContent) — с причиной.
                final LinearLayout warnCard = new LinearLayout(this);
                warnCard.setOrientation(LinearLayout.VERTICAL);
                warnCard.setPadding(dp(12), dp(10), dp(12), dp(10));
                warnCard.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
                {
                    final GradientDrawable wBg = new GradientDrawable();
                    wBg.setShape(GradientDrawable.RECTANGLE);
                    wBg.setCornerRadius(dp(10));
                    wBg.setColor(0xFF1A0508);
                    wBg.setStroke(1, 0xFFFF1E4E);
                    warnCard.setBackground(wBg);
                }

                final TextView tvMarker = new TextView(this);
                tvMarker.setText(isBlockedForCard
                    ? "\uD83D\uDEAB \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D. \u0414\u043E\u0441\u0442\u0443\u043F \u043A \u043A\u043B\u044E\u0447\u0443 \u0434\u043B\u044F \u0434\u0430\u043D\u043D\u043E\u0433\u043E \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u043E\u0442\u043A\u043B\u044E\u0447\u0451\u043D."
                    : "\uD83D\uDEAB \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u0434\u0435\u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D. \u0414\u043E\u0441\u0442\u0443\u043F \u043A \u043A\u043B\u044E\u0447\u0443 \u0434\u043B\u044F \u0434\u0430\u043D\u043D\u043E\u0433\u043E \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F \u043E\u0442\u043A\u043B\u044E\u0447\u0451\u043D.");
                tvMarker.setTextSize(12);
                tvMarker.setTextColor(0xFFFF1E4E);
                tvMarker.setTypeface(null, Typeface.BOLD);
                warnCard.addView(tvMarker);

                final TextView tvReason = new TextView(this);
                String reasonText = reasonForCard.trim().isEmpty() ? "\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u0430" : reasonForCard;
                tvReason.setText(isBlockedForCard
                    ? ("\u041F\u0440\u0438\u0447\u0438\u043D\u0430: " + reasonText)
                    : ("\u042D\u0442\u043E\u0442 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C \u0434\u0435\u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D \u043F\u043E \u043F\u0440\u0438\u0447\u0438\u043D\u0435: " + reasonText));
                tvReason.setTextSize(12);
                tvReason.setTextColor(0xFFB8C4D0);
                LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
                rlp.topMargin = dp(4);
                tvReason.setLayoutParams(rlp);
                warnCard.addView(tvReason);

                addSpace(warnCard, 10);
                addSectionLabel(warnCard, "\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C:");
                if (users != null && users.length() > 0) {
                    buildBotUserBlock(warnCard, tg, key.optString("telegramId", ""), users.optJSONObject(0), true);
                } else {
                    buildBotUserBlock(warnCard, tg, key.optString("telegramId", ""), null, true);
                }

                root.addView(warnCard);
            } else if (users != null && users.length() > 0) {
                addSectionLabel(root, "\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0438:");
                for (int i = 0; i < users.length(); i++) {
                    JSONObject u = users.optJSONObject(i);
                    if (u == null) continue;
                    buildBotUserBlock(root, tg, key.optString("telegramId", ""), u, false);
                    if (i < users.length() - 1) addSpace(root, 8);
                }
            } else {
                addSectionLabel(root, "\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0438:");
                buildBotUserBlock(root, tg, key.optString("telegramId", ""), null, false);
                addSpace(root, 6);
                final TextView tvNoUser = new TextView(this);
                tvNoUser.setText("\u0415\u0449\u0451 \u043D\u0438\u043A\u0442\u043E \u043D\u0435 \u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043B \u043A\u043B\u044E\u0447 \u0432 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438.");
                tvNoUser.setTextSize(12);
                tvNoUser.setTextColor(0xFF6C7885);
                root.addView(tvNoUser);
            }
            addSpace(root, 12);

            buildCopyRow(root, "\u041A\u043B\u044E\u0447:", keyValue);
            addSpace(root, 10);

            // ── Динамическая строка под ключом — точно как в обычной карточке
            // ключа (KeySystemActivity.showKeyDetailDialog): "Осталось: X дн Y ч"
            // с live-обновлением, либо статический текст для остальных состояний.
            final int usersCountForTimer = (users != null) ? users.length() : 0;
            final boolean noOneLoggedIn = usersCountForTimer == 0;
            final boolean isForeverKey = "forever".equals(expiryAt);
            final boolean hasExpiry = !isForeverKey && !expiryAt.isEmpty();
            final boolean isDeactivated = "deactivated".equals(status);
            final boolean isBlocked = "blocked".equals(status);
            final boolean isExpiredNow = "expired".equals(status);

            final TextView tvExpiryTimer;
            if (isDeactivated) {
                tvExpiryTimer = null;
                addStatusLine(root, "\u041A\u043B\u044E\u0447 \u0434\u0435\u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D, \u0441\u0440\u043E\u043A \u043A\u043B\u044E\u0447\u0430 \u0438\u0441\u0442\u0451\u043A", 0xFFFF1E4E);
            } else if (isBlocked) {
                tvExpiryTimer = null;
                addStatusLine(root, "\u041A\u043B\u044E\u0447 \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D \u0438\u0437-\u0437\u0430 \u0431\u0430\u043D\u0430 \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F", 0xFFFF1E4E);
            } else if (isExpiredNow) {
                tvExpiryTimer = null;
                addStatusLine(root, "\u0421\u0440\u043E\u043A \u043A\u043B\u044E\u0447\u0430 \u0438\u0441\u0442\u0451\u043A", 0xFFFF1E4E);
            } else if (hasExpiry && noOneLoggedIn) {
                tvExpiryTimer = null;
                addStatusLine(root, "\u0415\u0449\u0451 \u043D\u0438\u043A\u0442\u043E \u043D\u0435 \u0432\u043E\u0448\u0451\u043B", 0xFF00E5FF);
            } else if (hasExpiry) {
                tvExpiryTimer = new TextView(this);
                tvExpiryTimer.setTextSize(12);
                tvExpiryTimer.setTextColor(0xFF00FF9D);
                tvExpiryTimer.setTypeface(null, Typeface.BOLD);
                LinearLayout.LayoutParams etlp = new LinearLayout.LayoutParams(MATCH, WRAP);
                etlp.bottomMargin = dp(4);
                tvExpiryTimer.setLayoutParams(etlp);
                root.addView(tvExpiryTimer);
            } else if (isForeverKey) {
                tvExpiryTimer = null;
                addStatusLine(root, "\u0421\u0440\u043E\u043A: \u267E \u041D\u0430\u0432\u0441\u0435\u0433\u0434\u0430", 0xFF00FF9D);
            } else {
                tvExpiryTimer = null;
            }

            // Live-обновление таймера, если он есть на экране
            if (tvExpiryTimer != null) {
                final Handler timerHandler = new Handler(android.os.Looper.getMainLooper());
                final Runnable[] timerRunnable = {null};
                final String fExpiryAt = expiryAt;
                timerRunnable[0] = new Runnable() {
                    public void run() {
                        try {
                            long nowMs = System.currentTimeMillis();
                            long expiryMs = parseIso(fExpiryAt);
                            long diffMs = expiryMs - nowMs;
                            if (diffMs > 0) {
                                long days  = diffMs / (24 * 3600 * 1000L);
                                long hours = (diffMs % (24 * 3600 * 1000L)) / (3600 * 1000L);
                                long mins  = (diffMs % (3600 * 1000L)) / (60 * 1000L);
                                if (days > 0) {
                                    tvExpiryTimer.setText("\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C: " + days + " \u0434\u043D. " + hours + " \u0447.");
                                } else {
                                    tvExpiryTimer.setText("\u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C: " + hours + " \u0447. " + mins + " \u043C\u0438\u043D.");
                                }
                                tvExpiryTimer.setTextColor(days == 0 && hours < 3 ? 0xFFFF1E4E : 0xFF00FF9D);
                            } else {
                                tvExpiryTimer.setText("\u0421\u0440\u043E\u043A \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0438\u0441\u0442\u0451\u043A");
                                tvExpiryTimer.setTextColor(0xFFFF1E4E);
                            }
                        } catch (Exception ignored) {}
                        timerHandler.postDelayed(timerRunnable[0], 1000);
                    }
                };
                timerHandler.post(timerRunnable[0]);
                d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                    public void onDismiss(android.content.DialogInterface dialog) {
                        timerHandler.removeCallbacks(timerRunnable[0]);
                    }
                });
            }

            addSpace(root, 16);

            if (isDeactivated || isBlocked) {
                // Та же пара кнопок, что и в обычной карточке ключа для
                // деактивированных/заблокированных ключей: "Назад" и
                // "Убрать карточку" (чисто локальное скрытие — на сервере
                // ключ остаётся, ждёт возможного разбана администратором).
                final LinearLayout btns = new LinearLayout(this);
                btns.setOrientation(LinearLayout.HORIZONTAL);

                final TextView btnBack = new TextView(this);
                btnBack.setText("\u041D\u0430\u0437\u0430\u0434");
                btnBack.setTextSize(14);
                btnBack.setTextColor(0xFFB8C4D0);
                btnBack.setTypeface(null, Typeface.BOLD);
                btnBack.setGravity(Gravity.CENTER);
                {
                    final GradientDrawable bg = new GradientDrawable();
                    bg.setShape(GradientDrawable.RECTANGLE);
                    bg.setCornerRadius(dp(10));
                    bg.setColor(0xFF17202A);
                    btnBack.setBackground(bg);
                }
                btnBack.setPadding(dp(20), dp(12), dp(20), dp(12));
                LinearLayout.LayoutParams bblp = new LinearLayout.LayoutParams(0, WRAP, 1f);
                bblp.rightMargin = dp(8);
                btnBack.setLayoutParams(bblp);
                btnBack.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) { d.dismiss(); }
                });
                btns.addView(btnBack);

                final TextView btnHide = new TextView(this);
                btnHide.setText("\u0423\u0431\u0440\u0430\u0442\u044C \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443");
                btnHide.setTextSize(14);
                btnHide.setTextColor(0xFFFF1E4E);
                btnHide.setTypeface(null, Typeface.BOLD);
                btnHide.setGravity(Gravity.CENTER);
                {
                    final GradientDrawable bg = new GradientDrawable();
                    bg.setShape(GradientDrawable.RECTANGLE);
                    bg.setCornerRadius(dp(10));
                    bg.setColor(0xFF1A0508);
                    bg.setStroke(1, 0xFFFF1E4E);
                    btnHide.setBackground(bg);
                }
                btnHide.setPadding(dp(20), dp(12), dp(20), dp(12));
                btnHide.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
                final String fKeyValueForHide = keyValue;
                btnHide.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        d.dismiss();
                        hideCard(fKeyValueForHide);
                        loadKeys();
                    }
                });
                btns.addView(btnHide);

                root.addView(btns);
            } else {
                final TextView btnClose = new TextView(this);
                btnClose.setText("\u0417\u0430\u043A\u0440\u044B\u0442\u044C");
                btnClose.setTextSize(14);
                btnClose.setTextColor(0xFFB8C4D0);
                btnClose.setTypeface(null, Typeface.BOLD);
                btnClose.setGravity(Gravity.CENTER);
                {
                    final GradientDrawable bg = new GradientDrawable();
                    bg.setShape(GradientDrawable.RECTANGLE);
                    bg.setCornerRadius(dp(10));
                    bg.setColor(0xFF17202A);
                    btnClose.setBackground(bg);
                }
                btnClose.setPadding(dp(20), dp(12), dp(20), dp(12));
                btnClose.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
                btnClose.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) { d.dismiss(); }
                });
                root.addView(btnClose);
            }

            final ScrollView sv = new ScrollView(this);
            sv.addView(root);
            d.setContentView(sv);
            if (d.getWindow() != null) {
                d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                android.view.WindowManager.LayoutParams lp = d.getWindow().getAttributes();
                lp.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.92f);
                d.getWindow().setAttributes(lp);
            }
            d.show();
        } catch (Exception ignored) {}
    }

    // ══════════════════════════════════════════════════
    //  БЛОК «ПОЛЬЗОВАТЕЛЬ» — тот же порядок и та же вёрстка, что и в
    //  обычной карточке ключа (см. KeySystemActivity.buildUserBlock /
    //  buildTelegramBlock): Устройство → ID привязки → Логин → Айди →
    //  Дата входа → отдельный блок Telegram (Ник / Юзернейм / ID).
    //  Истории аккаунтов здесь нет — этого поля не существует в записях
    //  бот-ключей (сохраняются только login/userId/device/bindId/loginAt).
    // ══════════════════════════════════════════════════
    private void buildBotUserBlock(LinearLayout root, JSONObject tg, String telegramIdFallback, JSONObject user, final boolean isPunished) {
        try {
            final JSONArray historyForButton = (user != null) ? user.optJSONArray("accountsHistory") : null;
            if (user != null) {
                String uDevice  = user.optString("device",  "");
                String uBindId  = user.optString("bindId",  "");
                String uLogin   = user.optString("login",   "");
                String uUserId  = user.optString("userId",  "");
                String uLoginAt = user.optString("loginAt", "");

                if (!uDevice.isEmpty())  addInfoRow(root, "\u0423\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E:", uDevice);
                if (!uBindId.isEmpty())  addInfoRow(root, "ID \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438:", uBindId);
                if (!uLogin.isEmpty())   buildCopyRow(root, "\u041B\u043E\u0433\u0438\u043D:", uLogin);
                if (!uUserId.isEmpty())  buildCopyRow(root, "\u0410\u0439\u0434\u0438:", uUserId);
                if (!uLoginAt.isEmpty()) addInfoRow(root, "\u0414\u0430\u0442\u0430 \u0432\u0445\u043E\u0434\u0430:", formatDate(uLoginAt));
            }

            if (tg != null || (telegramIdFallback != null && !telegramIdFallback.isEmpty())) {
                addSpace(root, 10);
                buildTelegramBlock(root, tg, telegramIdFallback);
            }

            // Кнопка "Все аккаунты..." — идёт ПОСЛЕ блока Telegram, так же как
            // и в обычной (не бот) карточке ключа.
            if (historyForButton != null && historyForButton.length() > 0) {
                addSpace(root, 8);
                final TextView btnHistory = new TextView(this);
                btnHistory.setText("\u0412\u0441\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u044B, \u0433\u0434\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043B\u0441\u044F \u044D\u0442\u043E\u0442 \u043A\u043B\u044E\u0447 \u0443 \u0434\u0430\u043D\u043D\u043E\u0433\u043E \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F");
                btnHistory.setTextSize(12);
                btnHistory.setTextColor(0xFF00E5FF);
                btnHistory.setTypeface(null, Typeface.BOLD);
                {
                    final GradientDrawable bg = new GradientDrawable();
                    bg.setShape(GradientDrawable.RECTANGLE);
                    bg.setCornerRadius(dp(8));
                    bg.setColor(0xFF091520);
                    bg.setStroke(1, 0xFF00E5FF);
                    btnHistory.setBackground(bg);
                }
                btnHistory.setPadding(dp(10), dp(8), dp(10), dp(8));
                btnHistory.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
                final JSONArray historyFinal = historyForButton;
                // Если ключ сейчас заблокирован/деактивирован, именно ЭТОТ user —
                // тот самый пострадавший аккаунт (снимок из bot_keys.json не
                // стирается при бане/деактивации). Передаём его userId/login,
                // чтобы в истории подсветить точно нужную запись.
                final String targetUserIdFinal = (user != null) ? user.optString("userId", "") : "";
                final String targetLoginFinal  = (user != null) ? user.optString("login", "")  : "";
                btnHistory.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        showBotAccountsHistoryDialog(historyFinal, isPunished, targetUserIdFinal, targetLoginFinal);
                    }
                });
                root.addView(btnHistory);
            }
        } catch (Exception ignored) {}
    }

    // Блок Telegram — визуально идентичен блоку в обычной карточке ключа:
    // значок ✈, заголовок с разделителем, «Ник», «Юзернейм», ID мелко серым внизу.
    // История смены ника/юзернейма здесь не показывается — сервер не хранит
    // такие изменения для бот-ключей (только текущий снимок на момент выдачи).
    private void buildTelegramBlock(LinearLayout root, JSONObject tg, String telegramIdFallback) {
        try {
            final LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(MATCH, WRAP);
            card.setLayoutParams(clp);
            {
                final GradientDrawable bg = new GradientDrawable();
                bg.setShape(GradientDrawable.RECTANGLE);
                bg.setCornerRadius(dp(10));
                bg.setColor(0xFF0A1929);
                bg.setStroke(1, 0xFF2AABEE);
                card.setBackground(bg);
            }

            final LinearLayout headerRow = new LinearLayout(this);
            headerRow.setOrientation(LinearLayout.HORIZONTAL);
            headerRow.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams hrLp = new LinearLayout.LayoutParams(MATCH, WRAP);
            hrLp.bottomMargin = dp(8);
            headerRow.setLayoutParams(hrLp);

            final TextView tvIcon = new TextView(this);
            tvIcon.setText("\u2708");
            tvIcon.setTextSize(13);
            tvIcon.setTextColor(0xFF2AABEE);
            tvIcon.setPadding(0, 0, dp(6), 0);
            headerRow.addView(tvIcon);

            final TextView tvTitle = new TextView(this);
            tvTitle.setText("Telegram");
            tvTitle.setTextSize(12);
            tvTitle.setTextColor(0xFF2AABEE);
            tvTitle.setTypeface(null, Typeface.BOLD);
            tvTitle.setLetterSpacing(0.08f);
            headerRow.addView(tvTitle);
            card.addView(headerRow);

            final View div = new View(this);
            LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(MATCH, 1);
            divLp.bottomMargin = dp(8);
            div.setLayoutParams(divLp);
            div.setBackgroundColor(0x332AABEE);
            card.addView(div);

            String firstName = tg != null ? tg.optString("firstName", "") : "";
            String username  = tg != null ? tg.optString("username", "")  : "";
            String tgId       = tg != null ? tg.optString("id", "") : telegramIdFallback;

            if (!firstName.isEmpty()) {
                addSimpleTelegramRow(card, "\u041D\u0438\u043A:", firstName);
            }
            if (!username.isEmpty()) {
                addSimpleTelegramRow(card, "\u042E\u0437\u0435\u0440\u043D\u0435\u0439\u043C:", "@" + username);
            }
            if (tgId != null && !tgId.isEmpty()) {
                final TextView tvId = new TextView(this);
                tvId.setText("ID: " + tgId);
                tvId.setTextSize(10);
                tvId.setTextColor(0xFF3A4654);
                LinearLayout.LayoutParams idLp = new LinearLayout.LayoutParams(MATCH, WRAP);
                idLp.topMargin = dp(4);
                tvId.setLayoutParams(idLp);
                card.addView(tvId);
            }

            root.addView(card);
        } catch (Exception ignored) {}
    }

    // Строка внутри Telegram-блока: "Метка: значение" (белым, жирным)
    private void addSimpleTelegramRow(LinearLayout parent, String label, String value) {
        final LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.bottomMargin = dp(4);
        row.setLayoutParams(rlp);

        final TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(11);
        tvLabel.setTextColor(0xFF6C7885);
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(dp(90), WRAP));
        row.addView(tvLabel);

        final TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(13);
        tvValue.setTextColor(0xFFFFFFFF);
        tvValue.setTypeface(null, Typeface.BOLD);
        row.addView(tvValue);

        parent.addView(row);
    }

    // Строка "метка: значение [Копировать]" — для Логина и Айди пользователя.
    private void buildCopyRow(LinearLayout parent, String label, final String value) {
        final LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.bottomMargin = dp(6);
        row.setLayoutParams(rlp);

        final TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(12);
        tvLabel.setTextColor(0xFF6C7885);
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(dp(70), WRAP));
        row.addView(tvLabel);

        final TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(12);
        tvValue.setTextColor(0xFF00FF9D);
        tvValue.setTypeface(null, Typeface.BOLD);
        tvValue.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(tvValue);

        final TextView btnCopy = new TextView(this);
        btnCopy.setText("\u2398  \u041A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C");
        btnCopy.setTextSize(11);
        btnCopy.setTextColor(0xFF00E5FF);
        btnCopy.setTypeface(null, Typeface.BOLD);
        btnCopy.setPadding(dp(10), dp(5), dp(10), dp(5));
        {
            final GradientDrawable copyPill = new GradientDrawable();
            copyPill.setShape(GradientDrawable.RECTANGLE);
            copyPill.setCornerRadius(dp(20));
            copyPill.setColor(0xFF0F1E2E);
            copyPill.setStroke(dp(1), 0xFF00E5FF);
            btnCopy.setBackground(copyPill);
        }
        btnCopy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                android.content.ClipboardManager cm = (android.content.ClipboardManager)
                    getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("copy", value));
                android.widget.Toast.makeText(AdminBotKeysActivity.this, "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E", android.widget.Toast.LENGTH_SHORT).show();
            }
        });
        row.addView(btnCopy);

        parent.addView(row);
    }

    // Статическая (не тикающая) строка статуса под ключом — "Ещё никто не
    // вошёл" / "Ключ деактивирован, срок ключа истёк" / "Ключ заблокирован..." и т.д.
    private void addStatusLine(LinearLayout parent, String text, int color) {
        final TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12);
        tv.setTextColor(color);
        tv.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.bottomMargin = dp(4);
        tv.setLayoutParams(lp);
        parent.addView(tv);
    }

    // ══════════════════════════════════════════════════
    //  HELPERS
    // ══════════════════════════════════════════════════
    private void addInfoRow(LinearLayout parent, String label, String value) {
        final LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.bottomMargin = dp(4);
        row.setLayoutParams(rlp);

        final TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(12);
        tvLabel.setTextColor(0xFF6C7885);
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(dp(110), WRAP));
        row.addView(tvLabel);

        final TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(13);
        tvValue.setTextColor(0xFFFFFFFF);
        tvValue.setTypeface(null, Typeface.BOLD);
        row.addView(tvValue);

        parent.addView(row);
    }

    private void addSectionLabel(LinearLayout parent, String text) {
        final TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(11);
        tv.setTextColor(0xFF6C7885);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setLetterSpacing(0.1f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(8);
        lp.bottomMargin = dp(4);
        tv.setLayoutParams(lp);
        parent.addView(tv);
    }

    // История аккаунтов, входивших с одного устройства через этот бот-ключ —
    // тот же формат, что и showAccountsHistoryDialog в KeySystemActivity.
    private void showBotAccountsHistoryDialog(JSONArray history, final boolean isKeyPunished, final String punishedUserId, final String punishedLogin) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(true);

        final ScrollView sv = new ScrollView(this);
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(16));
        {
            final GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(18));
            bg.setColor(0xFF0C1014);
            bg.setStroke(2, 0xFF00E5FF);
            root.setBackground(bg);
        }

        final TextView title = new TextView(this);
        title.setText("\uD83D\uDCCB \u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u043E\u0432 (" + history.length() + ")");
        title.setTextSize(16);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        addSpace(root, 6);

        final TextView subtitle = new TextView(this);
        subtitle.setText("\u0412\u0441\u0435 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u044B, \u0432\u0445\u043E\u0434\u0438\u0432\u0448\u0438\u0435 \u0447\u0435\u0440\u0435\u0437 \u044D\u0442\u043E\u0442 \u043A\u043B\u044E\u0447 \u043D\u0430 \u0434\u0430\u043D\u043D\u043E\u043C \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0435");
        subtitle.setTextSize(11);
        subtitle.setTextColor(0xFF6C7885);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);
        addSpace(root, 14);

        for (int i = 0; i < history.length(); i++) {
            try {
                JSONObject entry = history.getJSONObject(i);
                String hLogin   = entry.optString("login", "");
                String hUserId  = entry.optString("userId", "");
                String hFirstAt = entry.optString("firstAt", "");
                String hDevice  = entry.optString("device", "");
                String hBindId  = entry.optString("bindId", "");
                boolean hActive = entry.optBoolean("isActive", false);
                boolean hBanned = entry.optBoolean("isBanned", false);

                // Если ключ сейчас заблокирован/деактивирован целиком, доступ
                // отключён для всех аккаунтов в истории этого устройства.
                // Тому аккаунту, из-за которого это произошло, ставим
                // "Заблокирован"/"Деактивирован", остальным — "Нет доступа"
                // (ключ всё равно не работает, кто бы ни зашёл с этого устройства).
                boolean isPunishTarget = !hBanned && (
                    (!punishedUserId.isEmpty() && punishedUserId.equals(hUserId)) ||
                    (punishedUserId.isEmpty() && !punishedLogin.isEmpty() && punishedLogin.equals(hLogin))
                );
                if (isKeyPunished && isPunishTarget) hBanned = true;
                boolean hNoAccess = isKeyPunished && !hBanned;

                final LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12), dp(12), dp(12), dp(12));
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(MATCH, WRAP);
                clp.bottomMargin = dp(8);
                card.setLayoutParams(clp);
                {
                    final GradientDrawable cb = new GradientDrawable();
                    cb.setShape(GradientDrawable.RECTANGLE);
                    cb.setCornerRadius(dp(10));
                    cb.setColor(0xFF11171D);
                    int cardBorder = hBanned ? 0xFFFF1E4E : hNoAccess ? 0xFFFF6B00 : (hActive ? 0xFF00FF9D : 0xFF17202A);
                    cb.setStroke(1, cardBorder);
                    card.setBackground(cb);
                }

                final TextView tvStatus = new TextView(this);
                String statusText;
                int statusColor;
                if (hBanned) {
                    statusText = "\u25CF \u0417\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D";
                    statusColor = 0xFFFF1E4E;
                } else if (hNoAccess) {
                    statusText = "\u25CF \u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430";
                    statusColor = 0xFFFF6B00;
                } else if (hActive) {
                    statusText = "\u25CF \u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u0430\u043A\u043A\u0430\u0443\u043D\u0442";
                    statusColor = 0xFF00FF9D;
                } else {
                    statusText = "\u25CF \u041D\u0435\u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u0430\u043A\u043A\u0430\u0443\u043D\u0442";
                    statusColor = 0xFF6C7885;
                }
                tvStatus.setText(statusText);
                tvStatus.setTextSize(11);
                tvStatus.setTextColor(statusColor);
                tvStatus.setTypeface(null, Typeface.BOLD);
                LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(MATCH, WRAP);
                slp.bottomMargin = dp(6);
                tvStatus.setLayoutParams(slp);
                card.addView(tvStatus);

                if (!hDevice.isEmpty())  addInfoRow(card, "\u0423\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E:", hDevice);
                if (!hBindId.isEmpty())  addInfoRow(card, "\u0410\u0439\u0434\u0438 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438:", hBindId);
                if (!hLogin.isEmpty())   buildCopyRow(card, "\u041B\u043E\u0433\u0438\u043D:", hLogin);
                if (!hUserId.isEmpty())  buildCopyRow(card, "\u0410\u0439\u0434\u0438:", hUserId);
                if (!hFirstAt.isEmpty()) addInfoRow(card, "\u041F\u0435\u0440\u0432\u044B\u0439 \u0432\u0445\u043E\u0434:", formatDate(hFirstAt));

                root.addView(card);
            } catch (Exception ignored) {}
        }

        addSpace(root, 8);
        final TextView btnClose = new TextView(this);
        btnClose.setText("\u0417\u0430\u043A\u0440\u044B\u0442\u044C");
        btnClose.setTextSize(14);
        btnClose.setTextColor(0xFFB8C4D0);
        btnClose.setTypeface(null, Typeface.BOLD);
        btnClose.setGravity(Gravity.CENTER);
        {
            final GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(10));
            bg.setColor(0xFF17202A);
            btnClose.setBackground(bg);
        }
        btnClose.setPadding(dp(20), dp(12), dp(20), dp(12));
        btnClose.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        btnClose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        root.addView(btnClose);

        sv.addView(root);
        d.setContentView(sv);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            lp.width  = (int)(getResources().getDisplayMetrics().widthPixels * 0.92f);
            lp.height = (int)(getResources().getDisplayMetrics().heightPixels * 0.75f);
            w.setAttributes(lp);
        }
        d.show();
    }

    private void addSpace(LinearLayout parent, int dp) {
        final View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(dp)));
        parent.addView(v);
    }

    private long parseIso(String iso) {
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return sdf.parse(iso).getTime();
        } catch (Exception e) {
            try {
                java.text.SimpleDateFormat sdf2 = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                sdf2.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                return sdf2.parse(iso).getTime();
            } catch (Exception e2) { return 0; }
        }
    }

    private String formatDate(String iso) {
        try {
            java.text.SimpleDateFormat in  = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            java.text.SimpleDateFormat out = new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm");
            in.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            out.setTimeZone(java.util.TimeZone.getTimeZone("Europe/Kiev"));
            return out.format(in.parse(iso));
        } catch (Exception e) {
            try {
                java.text.SimpleDateFormat in2  = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                java.text.SimpleDateFormat out2 = new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm");
                in2.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                out2.setTimeZone(java.util.TimeZone.getTimeZone("Europe/Kiev"));
                return out2.format(in2.parse(iso));
            } catch (Exception e2) { return iso; }
        }
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density + 0.5f);
    }

    private String httpPost(String urlStr, String body) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        OutputStream os = conn.getOutputStream();
        os.write(bytes);
        os.flush();
        os.close();
        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }
}
