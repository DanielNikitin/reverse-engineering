package com.clumsyvpn;

import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.os.Bundle;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Раздел «Ключи, созданные ботом».
 * Отображает ключи, выданные Telegram-ботом для текущего пользователя.
 * Позволяет деактивировать ключ. Кнопки создания нет — ключи создаются только ботом.
 */
public class BotKeysActivity extends Activity {

    private static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = LinearLayout.LayoutParams.WRAP_CONTENT;

    private String myLogin;
    private String myPassword;
    private String myDeviceId;
    private String serverUrl;

    private LinearLayout keysContainer;
    private TextView     tvEmpty;

    private AccountStatusMonitor accountStatusMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        myLogin    = prefs.getString(AuthActivity.KEY_LOGIN,    "");
        myPassword = prefs.getString(AuthActivity.KEY_PASSWORD, "");
        myDeviceId = prefs.getString("device_id", "");
        serverUrl  = AuthActivity.SERVER_URL;

        accountStatusMonitor = new AccountStatusMonitor(this);

        buildUI();
        loadBotKeys();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadBotKeys();
        accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
    }

    // ══════════════════════════════════════════════════
    //  UI
    // ══════════════════════════════════════════════════
    private void buildUI() {
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF030507);
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));

        // Header
        final LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(16), dp(16), dp(16));
        header.setBackgroundColor(0xFF07090C);

        final TextView btnBack = new TextView(this);
        btnBack.setText("\u2039");
        btnBack.setTextSize(22);
        btnBack.setTextColor(0xFF2AABEE);
        btnBack.setTypeface(null, Typeface.BOLD);
        btnBack.setPadding(0, 0, dp(16), 0);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        header.addView(btnBack);

        final TextView tvTitle = new TextView(this);
        tvTitle.setText("\uD83E\uDD16  \u041A\u043B\u044E\u0447\u0438 \u0431\u043E\u0442\u0430");
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        header.addView(tvTitle);

        // Кнопка «Деактивировать» в хедере (деактивирует первый активный ключ)
        final TextView btnDeact = new TextView(this);
        btnDeact.setText("\u2715 \u0414\u0435\u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C");
        btnDeact.setTextSize(11);
        btnDeact.setTextColor(0xFFFF1E4E);
        btnDeact.setTypeface(null, Typeface.BOLD);
        btnDeact.setPadding(dp(10), dp(8), dp(10), dp(8));
        {
            final GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(12));
            bg.setColor(0xFF1A0508);
            bg.setStroke(1, 0xFFFF1E4E);
            btnDeact.setBackground(bg);
        }
        btnDeact.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showDeactivateDialog(); }
        });
        header.addView(btnDeact);

        root.addView(header);

        final View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        divider.setBackgroundColor(0xFF17202A);
        root.addView(divider);

        // Подзаголовок
        final TextView tvSub = new TextView(this);
        tvSub.setText("\u041A\u043B\u044E\u0447\u0438 \u0432\u044B\u0434\u0430\u044E\u0442\u0441\u044F \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u0447\u0435\u0440\u0435\u0437 Telegram-\u0431\u043E\u0442\u0430.\n\u041D\u0430\u0436\u043C\u0438\u0442\u0435 \uD83D\uDD11 \u041F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043A\u043B\u044E\u0447 \u0432 \u0431\u043E\u0442\u0435 Galaxy Clumsy.");
        tvSub.setTextSize(12);
        tvSub.setTextColor(0xFF6C7885);
        tvSub.setPadding(dp(16), dp(10), dp(16), dp(10));
        root.addView(tvSub);

        // Keys list
        final ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));

        keysContainer = new LinearLayout(this);
        keysContainer.setOrientation(LinearLayout.VERTICAL);
        keysContainer.setPadding(dp(12), dp(12), dp(12), dp(12));

        tvEmpty = new TextView(this);
        tvEmpty.setText("\u0423 \u0432\u0430\u0441 \u0435\u0449\u0451 \u043D\u0435\u0442 \u043A\u043B\u044E\u0447\u0435\u0439.\n\u041D\u0430\u0436\u043C\u0438\u0442\u0435 \uD83D\uDD11 \u041F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043A\u043B\u044E\u0447 \u0432 Telegram-\u0431\u043E\u0442\u0435.");
        tvEmpty.setTextSize(14);
        tvEmpty.setTextColor(0xFF6C7885);
        tvEmpty.setGravity(Gravity.CENTER);
        tvEmpty.setPadding(dp(16), dp(48), dp(16), dp(48));
        tvEmpty.setVisibility(View.GONE);
        keysContainer.addView(tvEmpty);

        scroll.addView(keysContainer);
        root.addView(scroll);

        setContentView(root);
    }

    // ══════════════════════════════════════════════════
    //  LOAD
    // ══════════════════════════════════════════════════
    private void loadBotKeys() {
        final String fLogin     = myLogin;
        final String fPassword  = myPassword;
        final String fDeviceId  = myDeviceId;
        final String fServerUrl = serverUrl;
        final LinearLayout fContainer = keysContainer;
        final TextView fEmpty = tvEmpty;
        new Thread(new Runnable() {
            public void run() {
                try {
                    String q = "\"";
                    String body = "{" + q + "login" + q + ":" + q + esc(fLogin) + q
                        + "," + q + "password" + q + ":" + q + esc(fPassword) + q
                        + "," + q + "deviceId" + q + ":" + q + esc(fDeviceId) + q + "}";
                    String resp = httpPost(fServerUrl + "/bot/keys/list", body);
                    final JSONArray arr = parseKeysArray(resp);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            fContainer.removeAllViews();
                            if (arr == null || arr.length() == 0) {
                                fEmpty.setVisibility(View.VISIBLE);
                                fContainer.addView(fEmpty);
                            } else {
                                fEmpty.setVisibility(View.GONE);
                                for (int i = 0; i < arr.length(); i++) {
                                    try { addKeyCard(arr.getJSONObject(i)); }
                                    catch (Exception ignored) {}
                                }
                            }
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            fEmpty.setText("\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438");
                            fEmpty.setVisibility(View.VISIBLE);
                            fContainer.addView(fEmpty);
                        }
                    });
                }
            }
        }).start();
    }

    private JSONArray parseKeysArray(String resp) {
        try {
            JSONObject obj = new JSONObject(resp);
            return obj.optJSONArray("keys");
        } catch (Exception e) { return null; }
    }

    // ══════════════════════════════════════════════════
    //  KEY CARD
    // ══════════════════════════════════════════════════
    private void addKeyCard(final JSONObject key) {
        try {
            final String keyValue = key.optString("key", "");
            final String status   = key.optString("status", "inactive");
            int usersCount = 0;
            try { usersCount = key.getJSONArray("users").length(); } catch (Exception ignored) {}

            final LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(MATCH, WRAP);
            clp.bottomMargin = dp(10);
            card.setLayoutParams(clp);

            final GradientDrawable cardBg = new GradientDrawable();
            cardBg.setShape(GradientDrawable.RECTANGLE);
            cardBg.setCornerRadius(dp(14));
            cardBg.setColor(0xFF0C1014);
            int borderColor;
            if ("active".equals(status))       borderColor = 0xFF2AABEE;
            else if ("expired".equals(status)) borderColor = 0xFFFF1E4E;
            else if ("blocked".equals(status)) borderColor = 0xFFFF1E4E;
            else if ("deactivated".equals(status)) borderColor = 0xFFFF6B00;
            else                               borderColor = 0xFF17202A;
            cardBg.setStroke(1, borderColor);
            card.setBackground(cardBg);

            // Row: key + status
            final LinearLayout row1 = new LinearLayout(this);
            row1.setOrientation(LinearLayout.HORIZONTAL);
            row1.setGravity(Gravity.CENTER_VERTICAL);

            final TextView tvKey = new TextView(this);
            tvKey.setText(keyValue);
            tvKey.setTextSize(12);
            tvKey.setTextColor(0xFFB8C4D0);
            tvKey.setTypeface(null, Typeface.BOLD);
            tvKey.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
            row1.addView(tvKey);

            final TextView tvStatus = new TextView(this);
            String statusLabel;
            int statusColor, statusBgColor;
            if ("active".equals(status)) {
                statusLabel = "\u0410\u043A\u0442\u0438\u0432\u0435\u043D";
                statusColor = 0xFF2AABEE; statusBgColor = 0x1A2AABEE;
            } else if ("expired".equals(status)) {
                statusLabel = "\u0418\u0441\u0442\u0451\u043A";
                statusColor = 0xFFFF1E4E; statusBgColor = 0x1AFF1E4E;
            } else if ("blocked".equals(status)) {
                statusLabel = "\uD83D\uDEAB \u0417\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D";
                statusColor = 0xFFFF1E4E; statusBgColor = 0x1AFF1E4E;
            } else if ("deactivated".equals(status)) {
                statusLabel = "\u0414\u0435\u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D";
                statusColor = 0xFFFF6B00; statusBgColor = 0x1AFF6B00;
            } else {
                statusLabel = "\u041D\u0435 \u0430\u043A\u0442\u0438\u0432\u0435\u043D";
                statusColor = 0xFF6C7885; statusBgColor = 0x1A6C7885;
            }
            tvStatus.setText(statusLabel);
            tvStatus.setTextSize(11);
            tvStatus.setTextColor(statusColor);
            tvStatus.setTypeface(null, Typeface.BOLD);
            tvStatus.setPadding(dp(10), dp(4), dp(10), dp(4));
            {
                final GradientDrawable sBg = new GradientDrawable();
                sBg.setShape(GradientDrawable.RECTANGLE);
                sBg.setCornerRadius(dp(8));
                sBg.setColor(statusBgColor);
                sBg.setStroke(1, statusColor);
                tvStatus.setBackground(sBg);
            }
            row1.addView(tvStatus);
            card.addView(row1);

            // Bot badge
            final TextView tvBot = new TextView(this);
            tvBot.setText("\uD83E\uDD16 \u0412\u044B\u0434\u0430\u043D \u0431\u043E\u0442\u043E\u043C");
            tvBot.setTextSize(10);
            tvBot.setTextColor(0xFF2AABEE);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(MATCH, WRAP);
            blp.topMargin = dp(4);
            tvBot.setLayoutParams(blp);
            card.addView(tvBot);

            // Users count
            final TextView tvUsers = new TextView(this);
            tvUsers.setText("\u0423\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432: 1  •  \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435\u0439: " + usersCount);
            tvUsers.setTextSize(11);
            tvUsers.setTextColor(0xFF6C7885);
            LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(MATCH, WRAP);
            ulp.topMargin = dp(4);
            tvUsers.setLayoutParams(ulp);
            card.addView(tvUsers);

            // Expiry
            String expiryAt = key.optString("expiryAt", "");
            if (!expiryAt.isEmpty()) {
                final TextView tvExp = new TextView(this);
                tvExp.setText("\u0421\u0440\u043E\u043A: " + formatDate(expiryAt));
                tvExp.setTextSize(11);
                tvExp.setTextColor(0xFF6C7885);
                LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(MATCH, WRAP);
                elp.topMargin = dp(2);
                tvExp.setLayoutParams(elp);
                card.addView(tvExp);
            }

            final JSONObject keyRef = key;
            card.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { showKeyDetailDialog(keyRef); }
            });

            keysContainer.addView(card);
        } catch (Exception ignored) {}
    }

    // ══════════════════════════════════════════════════
    //  KEY DETAIL DIALOG
    // ══════════════════════════════════════════════════
    private void showKeyDetailDialog(final JSONObject key) {
        try {
            final String keyValue = key.optString("key", "");
            final String status   = key.optString("status", "inactive");
            final int expiryDays  = key.optInt("expiryDays", 1488);
            final String createdAt = key.optString("createdAt", "");
            final String expiryAt  = key.optString("expiryAt", "");

            final Dialog d = new Dialog(this);
            d.requestWindowFeature(Window.FEATURE_NO_TITLE);
            d.setCancelable(true);

            final LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(dp(20), dp(20), dp(20), dp(20));
            {
                final GradientDrawable bg = new GradientDrawable();
                bg.setShape(GradientDrawable.RECTANGLE);
                bg.setCornerRadius(dp(18));
                bg.setColor(0xFF0C1014);
                bg.setStroke(2, 0xFF2AABEE);
                root.setBackground(bg);
            }

            // Title
            final TextView tvTitle = new TextView(this);
            tvTitle.setText("\uD83E\uDD16  \u041A\u043B\u044E\u0447 \u0431\u043E\u0442\u0430");
            tvTitle.setTextSize(16);
            tvTitle.setTextColor(0xFF2AABEE);
            tvTitle.setTypeface(null, Typeface.BOLD);
            tvTitle.setGravity(Gravity.CENTER);
            root.addView(tvTitle);
            addSpace(root, 12);

            // Status dot
            String statusLabel;
            int statusColor;
            if ("active".equals(status)) {
                statusLabel = "\u2022 \u0410\u043A\u0442\u0438\u0432\u0435\u043D"; statusColor = 0xFF2AABEE;
            } else if ("expired".equals(status)) {
                statusLabel = "\u2022 \u0418\u0441\u0442\u0451\u043A"; statusColor = 0xFFFF1E4E;
            } else if ("blocked".equals(status)) {
                statusLabel = "\u2022 \u0417\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D"; statusColor = 0xFFFF1E4E;
            } else if ("deactivated".equals(status)) {
                statusLabel = "\u2022 \u0414\u0435\u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D"; statusColor = 0xFFFF6B00;
            } else {
                statusLabel = "\u2022 \u041D\u0435 \u0430\u043A\u0442\u0438\u0432\u0435\u043D"; statusColor = 0xFF6C7885;
            }
            final TextView tvStatus = new TextView(this);
            tvStatus.setText(statusLabel);
            tvStatus.setTextSize(13);
            tvStatus.setTextColor(statusColor);
            tvStatus.setTypeface(null, Typeface.BOLD);
            tvStatus.setGravity(Gravity.CENTER);
            root.addView(tvStatus);
            addSpace(root, 12);

            // Info rows
            addInfoRow(root, "\u0423\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432:", "1");
            addInfoRow(root, "\u0421\u0440\u043E\u043A \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F:", expiryDays + " \u0434\u043D.");
            if (!createdAt.isEmpty()) addInfoRow(root, "\u0421\u043E\u0437\u0434\u0430\u043D:", formatDate(createdAt));
            if (!expiryAt.isEmpty())  addInfoRow(root, "\u0418\u0441\u0442\u0435\u043A\u0430\u0435\u0442:", formatDate(expiryAt));
            addSpace(root, 8);

            // User info
            JSONArray users = key.optJSONArray("users");
            if (users != null && users.length() > 0) {
                JSONObject u = users.getJSONObject(0);
                addSectionLabel(root, "\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C:");
                String uLogin  = u.optString("login",  "");
                String uDevice = u.optString("device", "");
                if (!uLogin.isEmpty())  addInfoRow(root, "\u041B\u043E\u0433\u0438\u043D:",     uLogin);
                if (!uDevice.isEmpty()) addInfoRow(root, "\u0423\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u043E:", uDevice);
            } else {
                addSectionLabel(root, "\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C:");
                final TextView tvNoUser = new TextView(this);
                tvNoUser.setText("\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043E \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0435 \u043D\u0435\u0442.");
                tvNoUser.setTextSize(12);
                tvNoUser.setTextColor(0xFF6C7885);
                root.addView(tvNoUser);
            }
            addSpace(root, 12);

            // Key value (copyable)
            addSectionLabel(root, "\u041A\u043B\u044E\u0447:");
            buildCopyRow(root, keyValue, d);
            addSpace(root, 16);

            // Close button
            final TextView btnClose = new TextView(this);
            btnClose.setText("\u0417\u0430\u043A\u0440\u044B\u0442\u044C");
            btnClose.setTextSize(14);
            btnClose.setTextColor(0xFFB8C4D0);
            btnClose.setTypeface(null, Typeface.BOLD);
            btnClose.setGravity(Gravity.CENTER);
            {
                final GradientDrawable bg = new GradientDrawable();
                bg.setShape(GradientDrawable.RECTANGLE);
                bg.setCornerRadius(dp(10));
                bg.setColor(0xFF17202A);
                btnClose.setBackground(bg);
            }
            btnClose.setPadding(dp(20), dp(12), dp(20), dp(12));
            btnClose.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
            btnClose.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { d.dismiss(); }
            });
            root.addView(btnClose);

            final ScrollView sv = new ScrollView(this);
            sv.addView(root);
            d.setContentView(sv);
            if (d.getWindow() != null) {
                d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                android.view.WindowManager.LayoutParams lp = d.getWindow().getAttributes();
                lp.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.92f);
                d.getWindow().setAttributes(lp);
            }
            d.show();
        } catch (Exception ignored) {}
    }

    // ══════════════════════════════════════════════════
    //  DEACTIVATE DIALOG
    // ══════════════════════════════════════════════════
    private String currentActiveKey = null;

    private void showDeactivateDialog() {
        // Находим активный ключ
        currentActiveKey = null;
        try {
            for (int i = 0; i < keysContainer.getChildCount(); i++) {
                // Берём первый видимый — это кнопка деактивации через список
            }
        } catch (Exception ignored) {}

        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(true);

        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        {
            final GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(18));
            bg.setColor(0xFF0C1014);
            bg.setStroke(2, 0xFFFF1E4E);
            root.setBackground(bg);
        }

        final TextView tvTitle = new TextView(this);
        tvTitle.setText("\u2715  \u0414\u0435\u0430\u043A\u0442\u0438\u0432\u0430\u0446\u0438\u044F \u043A\u043B\u044E\u0447\u0430");
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(0xFFFF1E4E);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);
        addSpace(root, 12);

        final TextView tvMsg = new TextView(this);
        tvMsg.setText("\u0412\u044B \u0443\u0432\u0435\u0440\u0435\u043D\u044B, \u0447\u0442\u043E \u0445\u043E\u0442\u0438\u0442\u0435 \u0434\u0435\u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0441\u0432\u043E\u0439 \u043A\u043B\u044E\u0447?\n\n\u041F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043D\u043E\u0432\u044B\u0439 \u043A\u043B\u044E\u0447 \u043C\u043E\u0436\u043D\u043E \u0431\u0443\u0434\u0435\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0435\u0440\u0435\u0437 10 \u0447\u0430\u0441\u043E\u0432.");
        tvMsg.setTextSize(13);
        tvMsg.setTextColor(0xFFB8C4D0);
        tvMsg.setGravity(Gravity.CENTER);
        root.addView(tvMsg);
        addSpace(root, 20);

        // Кнопки
        final LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        final TextView btnNo = new TextView(this);
        btnNo.setText("\u041D\u0435\u0442");
        btnNo.setTextSize(14);
        btnNo.setTextColor(0xFFB8C4D0);
        btnNo.setTypeface(null, Typeface.BOLD);
        btnNo.setGravity(Gravity.CENTER);
        {
            final GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(10));
            bg.setColor(0xFF17202A);
            btnNo.setBackground(bg);
        }
        btnNo.setPadding(dp(20), dp(12), dp(20), dp(12));
        LinearLayout.LayoutParams noLp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        noLp.rightMargin = dp(8);
        btnNo.setLayoutParams(noLp);
        btnNo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        btnRow.addView(btnNo);

        final TextView btnYes = new TextView(this);
        btnYes.setText("\u0414\u0430, \u0434\u0435\u0430\u043A\u0442\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C");
        btnYes.setTextSize(14);
        btnYes.setTextColor(0xFFFFFFFF);
        btnYes.setTypeface(null, Typeface.BOLD);
        btnYes.setGravity(Gravity.CENTER);
        {
            final GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(10));
            bg.setColor(0xFFFF1E4E);
            btnYes.setBackground(bg);
        }
        btnYes.setPadding(dp(10), dp(12), dp(10), dp(12));
        btnYes.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        btnYes.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                deactivateFirstKey();
            }
        });
        btnRow.addView(btnYes);

        root.addView(btnRow);

        d.setContentView(root);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            android.view.WindowManager.LayoutParams lp = d.getWindow().getAttributes();
            lp.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.90f);
            d.getWindow().setAttributes(lp);
        }
        d.show();
    }

    private void deactivateFirstKey() {
        final String fLogin2    = myLogin;
        final String fPassword2 = myPassword;
        final String fDeviceId2 = myDeviceId;
        final String fServerUrl2 = serverUrl;
        new Thread(new Runnable() {
            public void run() {
                try {
                    // Сначала загружаем список чтобы взять ключ
                    String q = "\"";
                    String listBody = "{" + q + "login" + q + ":" + q + esc(fLogin2) + q
                        + "," + q + "password" + q + ":" + q + esc(fPassword2) + q
                        + "," + q + "deviceId" + q + ":" + q + esc(fDeviceId2) + q + "}";
                    String listResp = httpPost(fServerUrl2 + "/bot/keys/list", listBody);
                    JSONArray arr = parseKeysArray(listResp);
                    if (arr == null || arr.length() == 0) return;

                    // Деактивируем первый активный или неактивный ключ
                    String keyToDeact = null;
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject k = arr.getJSONObject(i);
                        String st = k.optString("status", "");
                        if ("active".equals(st) || "inactive".equals(st)) {
                            keyToDeact = k.optString("key", "");
                            break;
                        }
                    }
                    if (keyToDeact == null || keyToDeact.isEmpty()) return;

                    String deactBody = "{" + q + "login" + q + ":" + q + esc(fLogin2) + q
                        + "," + q + "password" + q + ":" + q + esc(fPassword2) + q
                        + "," + q + "deviceId" + q + ":" + q + esc(fDeviceId2) + q
                        + "," + q + "key" + q + ":" + q + esc(keyToDeact) + q + "}";
                    httpPost(fServerUrl2 + "/bot/keys/deactivate", deactBody);

                    final BotKeysActivity self = BotKeysActivity.this;
                    runOnUiThread(new Runnable() {
                        public void run() { self.loadBotKeys(); }
                    });
                } catch (Exception ignored) {}
            }
        }).start();
    }

    // ══════════════════════════════════════════════════
    //  HELPERS
    // ══════════════════════════════════════════════════
    private void addInfoRow(LinearLayout parent, String label, String value) {
        final LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.bottomMargin = dp(4);
        row.setLayoutParams(rlp);

        final TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(12);
        tvLabel.setTextColor(0xFF6C7885);
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(dp(110), WRAP));
        row.addView(tvLabel);

        final TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(13);
        tvValue.setTextColor(0xFFFFFFFF);
        tvValue.setTypeface(null, Typeface.BOLD);
        row.addView(tvValue);

        parent.addView(row);
    }

    private void addSectionLabel(LinearLayout parent, String text) {
        final TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(11);
        tv.setTextColor(0xFF6C7885);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setLetterSpacing(0.1f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(8);
        lp.bottomMargin = dp(4);
        tv.setLayoutParams(lp);
        parent.addView(tv);
    }

    private void buildCopyRow(final LinearLayout parent, final String value, final Dialog d) {
        final LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        row.setLayoutParams(rlp);

        final TextView tvVal = new TextView(this);
        tvVal.setText(value);
        tvVal.setTextSize(13);
        tvVal.setTextColor(0xFF2AABEE);
        tvVal.setTypeface(null, Typeface.BOLD);
        tvVal.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(tvVal);

        final TextView btnCopy = new TextView(this);
        btnCopy.setText("\uD83D\uDCCB \u041A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C");
        btnCopy.setTextSize(11);
        btnCopy.setTextColor(0xFF2AABEE);
        btnCopy.setTypeface(null, Typeface.BOLD);
        btnCopy.setPadding(dp(10), dp(6), dp(10), dp(6));
        {
            final GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(8));
            bg.setColor(0xFF091520);
            bg.setStroke(1, 0xFF2AABEE);
            btnCopy.setBackground(bg);
        }
        btnCopy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                android.content.ClipboardManager cm = (android.content.ClipboardManager)
                    getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(
                    android.content.ClipData.newPlainText("key", value));
                btnCopy.setText("\u2713 \u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E");
                btnCopy.setTextColor(0xFF00FF9D);
            }
        });
        row.addView(btnCopy);

        parent.addView(row);
    }

    private void addSpace(LinearLayout parent, int dp) {
        final View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(dp)));
        parent.addView(v);
    }

    private String formatDate(String iso) {
        try {
            java.text.SimpleDateFormat in  = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            java.text.SimpleDateFormat out = new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm");
            in.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            out.setTimeZone(java.util.TimeZone.getTimeZone("Europe/Kiev"));
            return out.format(in.parse(iso));
        } catch (Exception e) {
            try {
                java.text.SimpleDateFormat in2  = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                java.text.SimpleDateFormat out2 = new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm");
                in2.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                out2.setTimeZone(java.util.TimeZone.getTimeZone("Europe/Kiev"));
                return out2.format(in2.parse(iso));
            } catch (Exception e2) { return iso; }
        }
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density + 0.5f);
    }

    private String httpPost(String urlStr, String body) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        OutputStream os = conn.getOutputStream();
        os.write(bytes);
        os.flush();
        os.close();
        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }
}
