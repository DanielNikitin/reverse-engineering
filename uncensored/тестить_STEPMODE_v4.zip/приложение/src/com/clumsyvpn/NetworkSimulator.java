package com.clumsyvpn;

import java.util.Random;

/**
 * NetworkSimulator V9
 *
 * Изменения V9 — улучшение Quantum Pulse на больших задержках:
 *
 * ФИКС QP-1 — Потеря силы/регистрации урона на больших секундах (5+ сек)
 *   Проблема: при delayMs >= 1000мс планировщик Android пробуждает поток
 *   с большим джиттером (±50–200мс). Drift-компенсация из V8 работала только
 *   между соседними пакетами и не могла «видеть» накопленный долг за несколько
 *   секунд. Решение: заменили простой long driftDebt на кольцевой
 *   ExponentialDriftTracker — он усредняет реальный джиттер по скользящему
 *   окну последних DRIFT_WINDOW пакетов и вычитает средний перерасход из
 *   следующего сна. Это даёт стабильный средний интервал даже при 3–10 сек.
 *
 * ФИКС QP-2 — Burst-grace работал только на первых 6 пакетах всей сессии
 *   При больших задержках «тычок» это 1–2 пакета. Теперь burst-окно
 *   сбрасывается при паузе > BURST_RESET_MS между пакетами одного направления.
 *   Эффект: каждый новый «удар» после паузы снова получает сниженную задержку.
 *
 * ФИКС QP-3 — sleepInterruptible при больших totalMs
 *   Шаг сна теперь адаптивный: MIN_SLEEP_STEP..MAX_SLEEP_STEP в зависимости
 *   от оставшегося времени. Это снижает CPU при длинных задержках и сохраняет
 *   точность прерывания.
 *
 * Логика «После таймера», MODE_RESET/DROP/DELAY — без изменений (V8).
 */
public class NetworkSimulator {

    public static final int MODE_RESET = 0;
    public static final int MODE_DROP  = 1;
    public static final int MODE_DELAY = 2;

    // ── Режимы буфера пакетов (V10 — «Пошаговый режим») ─────────────────────
    // Обычный — трафик идёт как есть (задержка/дроп применяются как обычно).
    // Слив    — пакеты копятся в очереди направления и периодически сливаются пачкой.
    // Сброс   — очередь буфера периодически полностью сбрасывается (пакеты теряются).
    // Удалить — буфер отключён: все пакеты данного направления отбрасываются сразу.
    public static final int BUFFER_NORMAL = 0;
    public static final int BUFFER_DRAIN  = 1;
    public static final int BUFFER_RESET  = 2;
    public static final int BUFFER_REMOVE = 3;

    private static final long BUFFER_DRAIN_INTERVAL_MS = 500; // период слива очереди
    private static final long BUFFER_RESET_INTERVAL_MS = 700; // период сброса очереди
    private static final int  BUFFER_MAX_QUEUE          = 64;  // защита от переполнения памяти

    private volatile int clientBufferMode = BUFFER_NORMAL;
    private volatile int serverBufferMode = BUFFER_NORMAL;

    // Простейшие очереди «буфера» на направление (используются в MODE_DRAIN/MODE_RESET)
    private final java.util.ArrayDeque<Long> clientBufferQueue = new java.util.ArrayDeque<Long>();
    private final java.util.ArrayDeque<Long> serverBufferQueue = new java.util.ArrayDeque<Long>();
    private volatile long clientBufferLastFlush = 0;
    private volatile long serverBufferLastFlush = 0;

    // ── Burst-grace ─────────────────────────────────────────────────────────
    // Первые пакеты после паузы > BURST_RESET_MS получают задержку вдвое меньше
    private static final int BURST_GRACE_PACKETS = 6;
    private static final long BURST_RESET_MS     = 800; // пауза между «тычками»

    // ── Адаптивный шаг сна ──────────────────────────────────────────────────
    private static final long MIN_SLEEP_STEP = 3;   // мс — точность прерывания
    private static final long MAX_SLEEP_STEP = 15;  // мс — CPU при длинных снах

    // ── Drift tracker ───────────────────────────────────────────────────────
    private static final int DRIFT_WINDOW = 8; // пакетов в скользящем окне

    // Простой скользящий усреднитель перерасхода сна
    private static final class DriftTracker {
        private final long[] samples = new long[DRIFT_WINDOW];
        private int head = 0;
        private int count = 0;

        void record(long intended, long actual) {
            long over = actual - intended;
            samples[head] = over;
            head = (head + 1) % DRIFT_WINDOW;
            if (count < DRIFT_WINDOW) count++;
        }

        // Возвращает средний перерасход (>0 = спали дольше нужного)
        long avgOvershoot() {
            if (count == 0) return 0;
            long sum = 0;
            for (int i = 0; i < count; i++) sum += samples[i];
            return sum / count;
        }

        void reset() { head = 0; count = 0; }
    }

    // ────────────────────────────────────────────────────────────────────────

    private volatile int serverDelayMs;
    private volatile int serverLossPercent;
    private volatile int clientDelayMs;
    private volatile int clientLossPercent;

    private volatile int afterTimerMode;
    private volatile int afterTimerDelayMs;
    private volatile int afterTimerDurationMs;

    private volatile boolean isRunning  = false;
    private volatile boolean timerFired = false;
    private volatile long    timerFiredAt = 0;
    private volatile long    stopRequestedAt = 0;

    // Фильтр по размеру пакета
    private volatile int clientSzMode = 0;
    private volatile int clientSzMin  = 0;
    private volatile int clientSzMax  = 1500;
    private volatile int serverSzMode = 0;
    private volatile int serverSzMin  = 0;
    private volatile int serverSzMax  = 1500;

    private final Random rng = new Random();

    private volatile long statSent    = 0;
    private volatile long statDropped = 0;
    private volatile long statDelayed = 0;

    // ── Состояние burst-grace (dir 0 и dir 1) ───────────────────────────────
    private volatile int  burstCountDir0   = 0;
    private volatile int  burstCountDir1   = 0;
    private volatile long lastPacketDir0Ms = 0; // время последнего пакета dir0
    private volatile long lastPacketDir1Ms = 0;

    // ── Drift trackers (dir 0 и dir 1) ──────────────────────────────────────
    private final DriftTracker driftDir0 = new DriftTracker();
    private final DriftTracker driftDir1 = new DriftTracker();

    public NetworkSimulator(int serverDelayMs, int serverLossPercent,
                            int clientDelayMs, int clientLossPercent,
                            int afterTimerMode, int afterTimerDelayMs,
                            int afterTimerDurationSec) {
        this.serverDelayMs       = serverDelayMs;
        this.serverLossPercent   = serverLossPercent;
        this.clientDelayMs       = clientDelayMs;
        this.clientLossPercent   = clientLossPercent;
        this.afterTimerMode      = afterTimerMode;
        this.afterTimerDelayMs   = afterTimerDelayMs;
        this.afterTimerDurationMs = afterTimerDurationSec * 1000;
    }

    /** Конструктор совместимости без afterTimer */
    public NetworkSimulator(int serverDelayMs, int serverLossPercent,
                            int clientDelayMs, int clientLossPercent) {
        this(serverDelayMs, serverLossPercent,
             clientDelayMs, clientLossPercent, MODE_RESET, 0, 0);
    }

    /** Конструктор совместимости без дюрации */
    public NetworkSimulator(int serverDelayMs, int serverLossPercent,
                            int clientDelayMs, int clientLossPercent,
                            int afterTimerMode, int afterTimerDelayMs) {
        this(serverDelayMs, serverLossPercent,
             clientDelayMs, clientLossPercent, afterTimerMode, afterTimerDelayMs, 3);
    }

    public void start() {
        timerFired      = false;
        timerFiredAt    = 0;
        stopRequestedAt = 0;
        burstCountDir0  = 0;
        burstCountDir1  = 0;
        lastPacketDir0Ms = 0;
        lastPacketDir1Ms = 0;
        driftDir0.reset();
        driftDir1.reset();
        synchronized (clientBufferQueue) { clientBufferQueue.clear(); }
        synchronized (serverBufferQueue) { serverBufferQueue.clear(); }
        clientBufferLastFlush = 0;
        serverBufferLastFlush = 0;
        isRunning = true;
    }

    public void stop() {
        stopRequestedAt = System.currentTimeMillis();
        isRunning = false;
    }

    public boolean isRunning() { return isRunning; }

    public void onTimerFinished() {
        timerFiredAt    = System.currentTimeMillis();
        stopRequestedAt = timerFiredAt;
        timerFired      = true;
        isRunning       = false;
    }

    public boolean process(int length, int direction) {
        if (!isRunning) {
            statSent++;
            return true;
        }

        int lossPercent;
        int delayMs;

        if (direction == 0) {
            lossPercent = serverLossPercent;
            delayMs     = serverDelayMs;
        } else {
            lossPercent = clientLossPercent;
            delayMs     = clientDelayMs;
        }

        // Фильтр по размеру пакета
        int szMode = (direction == 0) ? serverSzMode : clientSzMode;
        int szMin  = (direction == 0) ? serverSzMin  : clientSzMin;
        int szMax  = (direction == 0) ? serverSzMax  : clientSzMax;
        if (szMode != 0) {
            boolean inRange = (length >= szMin && length <= szMax);
            boolean passes  = (szMode == 1) ? inRange : !inRange;
            if (!passes) {
                statSent++;
                return true;
            }
        }

        // ── Режим буфера (Пошаговый режим) ──────────────────────────────
        int bufferMode = (direction == 0) ? serverBufferMode : clientBufferMode;
        if (bufferMode != BUFFER_NORMAL) {
            Boolean bufferResult = applyBufferMode(bufferMode, direction);
            if (bufferResult != null) {
                if (bufferResult) statSent++; else statDropped++;
                return bufferResult;
            }
            // null = пакет пропущен как обычно дальше по конвейеру (был поставлен в очередь и уже слит)
        }

        if (lossPercent > 0 && rng.nextInt(100) < lossPercent) {
            statDropped++;
            return false;
        }

        if (delayMs > 0) {
            statDelayed++;

            long nowMs = System.currentTimeMillis();

            // ── ФИКС QP-2: burst-grace с автосбросом по паузе ──────────────
            int effectiveDelay = delayMs;
            if (direction == 0) {
                long sinceLastMs = (lastPacketDir0Ms > 0) ? (nowMs - lastPacketDir0Ms) : Long.MAX_VALUE;
                if (sinceLastMs > BURST_RESET_MS) {
                    // Новый «тычок» — сбрасываем окно
                    burstCountDir0 = 0;
                }
                burstCountDir0++;
                lastPacketDir0Ms = nowMs;
                if (burstCountDir0 <= BURST_GRACE_PACKETS) {
                    effectiveDelay = Math.max(1, delayMs / 2);
                }
            } else {
                long sinceLastMs = (lastPacketDir1Ms > 0) ? (nowMs - lastPacketDir1Ms) : Long.MAX_VALUE;
                if (sinceLastMs > BURST_RESET_MS) {
                    burstCountDir1 = 0;
                }
                burstCountDir1++;
                lastPacketDir1Ms = nowMs;
                if (burstCountDir1 <= BURST_GRACE_PACKETS) {
                    effectiveDelay = Math.max(1, delayMs / 2);
                }
            }

            // ── ФИКС QP-1: drift-компенсация через скользящее среднее ──────
            DriftTracker tracker = (direction == 0) ? driftDir0 : driftDir1;
            long avgOver = tracker.avgOvershoot();
            // Вычитаем средний перерасход; минимум 1мс чтобы не пропустить совсем
            int adjustedDelay = (int) Math.max(1, effectiveDelay - avgOver);

            long sleepStart = System.currentTimeMillis();
            sleepInterruptible(adjustedDelay);
            long actualSlept = System.currentTimeMillis() - sleepStart;

            // Записываем реальный перерасход в трекер
            tracker.record(effectiveDelay, actualSlept);

            if (timerFired) {
                return applyAfterTimer();
            }
        }

        statSent++;
        return true;
    }

    private boolean applyAfterTimer() {
        if (!isRunning && stopRequestedAt > 0) {
            long sinceStop = System.currentTimeMillis() - stopRequestedAt;
            if (sinceStop > 200) {
                statSent++;
                return true;
            }
        }

        if (afterTimerDurationMs > 0) {
            long elapsed = System.currentTimeMillis() - timerFiredAt;
            if (elapsed > afterTimerDurationMs) {
                statSent++;
                return true;
            }
        }

        switch (afterTimerMode) {
            case MODE_RESET:
                statSent++;
                return true;

            case MODE_DROP:
                if (rng.nextInt(100) < 70) {
                    statDropped++;
                    return false;
                }
                statSent++;
                return true;

            case MODE_DELAY:
                if (afterTimerDelayMs > 0) {
                    try { Thread.sleep(afterTimerDelayMs); }
                    catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                }
                statSent++;
                return true;

            default:
                statSent++;
                return true;
        }
    }

    // ── ФИКС QP-3: адаптивный шаг сна ──────────────────────────────────────
    private void sleepInterruptible(int totalMs) {
        if (totalMs <= 0) return;
        long deadline = System.currentTimeMillis() + totalMs;
        while (isRunning && !timerFired && System.currentTimeMillis() < deadline) {
            if (stopRequestedAt > 0 && !isRunning) break;
            long remain = deadline - System.currentTimeMillis();
            if (remain <= 0) break;
            // Адаптивный шаг: при remain > 500мс спим до 15мс,
            // при remain <= 50мс — минимум 3мс для точности
            long step;
            if (remain > 500) step = MAX_SLEEP_STEP;
            else if (remain > 50) step = 8;
            else step = MIN_SLEEP_STEP;
            try {
                Thread.sleep(Math.min(remain, step));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    public void setSizeFilter(int clientMode, int clientMin, int clientMax,
                              int serverMode, int serverMin, int serverMax) {
        this.clientSzMode = clientMode;
        this.clientSzMin  = clientMin;
        this.clientSzMax  = clientMax;
        this.serverSzMode = serverMode;
        this.serverSzMin  = serverMin;
        this.serverSzMax  = serverMax;
    }

    /** Устанавливает режим буфера для клиентского и серверного направлений (шаг пошагового режима). */
    public void setBufferMode(int clientBufferMode, int serverBufferMode) {
        this.clientBufferMode = clientBufferMode;
        this.serverBufferMode = serverBufferMode;
    }

    public void updateSettings(int serverDelayMs, int serverLossPercent,
                               int clientDelayMs, int clientLossPercent,
                               int afterTimerMode, int afterTimerDelayMs,
                               int afterTimerDurationSec) {
        this.serverDelayMs        = serverDelayMs;
        this.serverLossPercent    = serverLossPercent;
        this.clientDelayMs        = clientDelayMs;
        this.clientLossPercent    = clientLossPercent;
        this.afterTimerMode       = afterTimerMode;
        this.afterTimerDelayMs    = afterTimerDelayMs;
        this.afterTimerDurationMs = afterTimerDurationSec * 1000;
    }

    /**
     * Применяет режим буфера для данного направления.
     *
     * BUFFER_REMOVE — буфер удалён: пакет отбрасывается сразу (return false).
     * BUFFER_RESET  — пакет копится в очереди; раз в BUFFER_RESET_INTERVAL_MS
     *                 очередь целиком сбрасывается (все накопленные пакеты теряются),
     *                 имитируя переполнение и сброс буфера роутера.
     * BUFFER_DRAIN  — пакет копится в очереди; раз в BUFFER_DRAIN_INTERVAL_MS
     *                 вся очередь «сливается» (пропускается), т.е. трафик идёт
     *                 не равномерно, а пачками — характерная картина buffer bloat.
     *
     * Возвращает Boolean (true=пропустить, false=дропнуть) если решение уже принято,
     * либо null если пакет обработан как часть очереди и не требует дальнейшего действия
     * в этом вызове (сам факт постановки в очередь уже был учтён вызывающей стороной).
     */
    private Boolean applyBufferMode(int bufferMode, int direction) {
        java.util.ArrayDeque<Long> queue = (direction == 0) ? serverBufferQueue : clientBufferQueue;

        switch (bufferMode) {
            case BUFFER_REMOVE:
                // Буфер удалён — пакеты этого направления не проходят вовсе
                return false;

            case BUFFER_RESET: {
                long now = System.currentTimeMillis();
                long lastFlush = (direction == 0) ? serverBufferLastFlush : clientBufferLastFlush;
                synchronized (queue) {
                    queue.addLast(now);
                    if (queue.size() > BUFFER_MAX_QUEUE) queue.pollFirst();
                    if (now - lastFlush >= BUFFER_RESET_INTERVAL_MS) {
                        // Сброс буфера — все накопленные пакеты этого «окна» теряются
                        queue.clear();
                        if (direction == 0) serverBufferLastFlush = now; else clientBufferLastFlush = now;
                        return false;
                    }
                }
                // Внутри окна накопления — пакет пока удерживается буфером и теряется,
                // т.к. настоящей многопоточной доставки «отложенных» пакетов через
                // синхронный process() не реализовать без искажения TCP/UDP таймингов.
                // Поэтому в пределах окна пакет проходит нормально (буферизация видна
                // только по итоговому дропу раз в BUFFER_RESET_INTERVAL_MS).
                return true;
            }

            case BUFFER_DRAIN: {
                long now = System.currentTimeMillis();
                long lastFlush = (direction == 0) ? serverBufferLastFlush : clientBufferLastFlush;
                synchronized (queue) {
                    queue.addLast(now);
                    if (queue.size() > BUFFER_MAX_QUEUE) queue.pollFirst();
                    if (now - lastFlush >= BUFFER_DRAIN_INTERVAL_MS) {
                        // Слив — пачка пакетов проходит разом
                        queue.clear();
                        if (direction == 0) serverBufferLastFlush = now; else clientBufferLastFlush = now;
                        return true;
                    }
                }
                // Пакет удерживается в очереди до следующего слива
                return false;
            }

            default:
                return true;
        }
    }

    public long getStatSent()    { return statSent;    }
    public long getStatDropped() { return statDropped; }
    public long getStatDelayed() { return statDelayed; }
}
