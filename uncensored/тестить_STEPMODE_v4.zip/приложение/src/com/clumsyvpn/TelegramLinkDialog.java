package com.clumsyvpn;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Обязательная привязка Telegram-аккаунта перед регистрацией/входом.
 *
 * Состояния одного и того же небольшого (не на весь экран) диалога:
 *   1) INTRO  — текст про необходимость привязки + кнопки "Назад" / "Перейти в Telegram-бота".
 *   2) TOKEN  — после перехода в бота: "Успешно! Почти всё готово." + поле
 *               ввода токена (может автоматически подставиться через поллинг,
 *               если бот узнал deviceId по deep-link) + кнопки "Выход" / "Проверить".
 *
 * Сервер при этом служит источником истины — даже если этот диалог обойти,
 * /register и /login сами отклонят запрос без подтверждённой привязки
 * устройства (см. TELEGRAM_BOT_TOKEN / verifiedDevices на сервере).
 */
public class TelegramLinkDialog {

    public interface Callback {
        void onVerified(String telegramId, String username, String firstName);
        void onCancelled();
    }

    private static final int POLL_INTERVAL_MS = 2000;

    public static void show(final Context ctx, final String deviceId, final Callback callback) {
        final Dialog d = new Dialog(ctx);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);

        final LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(ctx, 22), dp(ctx, 22), dp(ctx, 22), dp(ctx, 18));
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(ctx, 16));
            bg.setColor(0xFF0C1014);
            bg.setStroke(1, 0xFF00E5FF);
            root.setBackground(bg);
        }

        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            int screenW = ctx.getResources().getDisplayMetrics().widthPixels;
            lp.width = (int) (screenW * 0.88f);
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
        }

        final boolean[] stopped = { false };
        final Handler pollHandler = new Handler();

        // botUsername приходит с сервера (см. /telegram/config) — это позволяет
        // менять имя бота без обновления приложения.
        final String[] botUsername = { "" };

        buildIntro(ctx, root, deviceId, botUsername, stopped, pollHandler, d, callback);

        d.show();

        // Подтягиваем конфиг бота сразу при открытии — нужен для deep-link.
        new Thread(new Runnable() {
            public void run() {
                try {
                    String resp = httpGet(AuthActivity.SERVER_URL + "/telegram/config");
                    if (resp != null) {
                        String u = extractField(resp, "botUsername");
                        if (u != null) botUsername[0] = u;
                    }
                } catch (Exception ignored) {}
            }
        }).start();
    }

    // ──────────────────────────── STATE 1: INTRO ────────────────────────────

    private static void buildIntro(final Context ctx, final LinearLayout root, final String deviceId,
                                    final String[] botUsername, final boolean[] stopped,
                                    final Handler pollHandler, final Dialog d, final Callback callback) {
        root.removeAllViews();

        TextView tvIcon = new TextView(ctx);
        tvIcon.setText("🔐");
        tvIcon.setTextSize(28);
        tvIcon.setGravity(Gravity.CENTER);
        root.addView(tvIcon);
        space(root, ctx, 10);

        TextView tvTitle = new TextView(ctx);
        tvTitle.setText("Привязка Telegram");
        tvTitle.setTextSize(17);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setGravity(Gravity.CENTER);
        root.addView(tvTitle);
        space(root, ctx, 10);

        TextView tvBody = new TextView(ctx);
        tvBody.setText("Вам необходимо привязать свой аккаунт к нашему Telegram-боту. " +
            "Это сделано для защиты Galaxy Clumsy от использования людьми, которые не приобретали приложение. " +
            "Для продолжения необходимо перейти в Telegram-бота, и пройти проверку подписки на приватную группу.");
        tvBody.setTextSize(13.5f);
        tvBody.setTextColor(0xFFB8C4D0);
        tvBody.setGravity(Gravity.CENTER);
        root.addView(tvBody);
        space(root, ctx, 18);

        LinearLayout btnRow = new LinearLayout(ctx);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.CENTER_VERTICAL);
        btnRow.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button btnBack = new Button(ctx);
        btnBack.setText("Назад");
        btnBack.setAllCaps(false);
        btnBack.setTextSize(14);
        btnBack.setTextColor(0xFFB8C4D0);
        GradientDrawable backBg = new GradientDrawable();
        backBg.setCornerRadius(dp(ctx, 10));
        backBg.setColor(0xFF161B22);
        btnBack.setBackground(backBg);
        LinearLayout.LayoutParams backLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        backLp.rightMargin = dp(ctx, 8);
        btnBack.setMinHeight(dp(ctx, 48));
        btnBack.setLayoutParams(backLp);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                stopped[0] = true;
                d.dismiss();
                callback.onCancelled();
            }
        });
        btnRow.addView(btnBack);

        final Button btnGo = new Button(ctx);
        btnGo.setText("Перейти в Telegram-бота");
        btnGo.setAllCaps(false);
        btnGo.setTextSize(13.5f);
        btnGo.setTypeface(null, Typeface.BOLD);
        btnGo.setTextColor(0xFF001A0E);
        GradientDrawable goBg = new GradientDrawable();
        goBg.setCornerRadius(dp(ctx, 10));
        goBg.setColor(0xFF00E5FF);
        btnGo.setBackground(goBg);
        LinearLayout.LayoutParams goLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        btnGo.setMinHeight(dp(ctx, 48));
        btnGo.setLayoutParams(goLp);
        btnGo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String uname = botUsername[0];
                if (uname == null || uname.isEmpty()) {
                    Toast.makeText(ctx, "Бот ещё не настроен. Попробуйте чуть позже.", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    String url = "https://t.me/" + uname + "?start=" + deviceId;
                    ctx.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    Toast.makeText(ctx, "Не удалось открыть Telegram", Toast.LENGTH_SHORT).show();
                    return;
                }
                // Окно с полем ввода токена должно появиться только после того,
                // как бот реально выдал токен — поэтому сразу показываем экран
                // ожидания, а не поле ввода, и начинаем поллинг в фоне.
                buildWaitingState(ctx, root, deviceId, stopped, pollHandler, d, callback);
                startPolling(ctx, root, deviceId, stopped, pollHandler, d, callback);
            }
        });
        btnRow.addView(btnGo);

        root.addView(btnRow);
    }

    // ──────────────────────────── STATE 1.5: WAITING ─────────────────────────

    private static void buildWaitingState(final Context ctx, final LinearLayout root, final String deviceId,
                                           final boolean[] stopped, final Handler pollHandler,
                                           final Dialog d, final Callback callback) {
        root.removeAllViews();
        tokenFieldRef = null; // на этом экране поля ввода ещё нет

        TextView tvIcon = new TextView(ctx);
        tvIcon.setText("⏳");
        tvIcon.setTextSize(28);
        tvIcon.setGravity(Gravity.CENTER);
        root.addView(tvIcon);
        space(root, ctx, 10);

        TextView tvWait = new TextView(ctx);
        tvWait.setText("Ожидаем подтверждения в Telegram-боте…");
        tvWait.setTextSize(14.5f);
        tvWait.setTypeface(null, Typeface.BOLD);
        tvWait.setTextColor(0xFFFFFFFF);
        tvWait.setGravity(Gravity.CENTER);
        root.addView(tvWait);
        space(root, ctx, 8);

        TextView tvHint = new TextView(ctx);
        tvHint.setText("Перейдите в бота, нажмите «Проверить подписку на приватную группу» и дождитесь, " +
            "когда бот выдаст токен. Это окно обновится автоматически.");
        tvHint.setTextSize(12.5f);
        tvHint.setTextColor(0xFFB8C4D0);
        tvHint.setGravity(Gravity.CENTER);
        root.addView(tvHint);
        space(root, ctx, 16);

        final TextView tvCheckStatus = new TextView(ctx);
        tvCheckStatus.setTextSize(12);
        tvCheckStatus.setTextColor(0xFFFFD400);
        tvCheckStatus.setGravity(Gravity.CENTER);
        tvCheckStatus.setVisibility(View.GONE);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.bottomMargin = dp(ctx, 10);
        tvCheckStatus.setLayoutParams(statusLp);
        root.addView(tvCheckStatus);

        final Button btnCheckToken = new Button(ctx);
        btnCheckToken.setText("Проверить получение токена");
        btnCheckToken.setAllCaps(false);
        btnCheckToken.setTextSize(13.5f);
        btnCheckToken.setTypeface(null, Typeface.BOLD);
        btnCheckToken.setTextColor(0xFF001A0E);
        GradientDrawable checkTokenBg = new GradientDrawable();
        checkTokenBg.setCornerRadius(dp(ctx, 10));
        checkTokenBg.setColor(0xFF00E5FF);
        btnCheckToken.setBackground(checkTokenBg);
        LinearLayout.LayoutParams checkTokenLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 48));
        checkTokenLp.bottomMargin = dp(ctx, 10);
        btnCheckToken.setLayoutParams(checkTokenLp);
        btnCheckToken.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                btnCheckToken.setEnabled(false);
                btnCheckToken.setText("Проверка...");
                tvCheckStatus.setVisibility(View.GONE);
                checkTokenOnce(ctx, root, deviceId, stopped, pollHandler, d, callback, new Runnable() {
                    public void run() {
                        // Токена пока нет — остаёмся на этом же экране, просто
                        // сообщаем об этом и возвращаем кнопку в исходный вид.
                        if (stopped[0]) return;
                        btnCheckToken.setEnabled(true);
                        btnCheckToken.setText("Проверить получение токена");
                        tvCheckStatus.setText("Токен ещё не получен. Перейдите в бота, нажмите «Проверить подписку на приватную группу» и попробуйте снова.");
                        tvCheckStatus.setVisibility(View.VISIBLE);
                    }
                });
            }
        });
        root.addView(btnCheckToken);

        Button btnExit = new Button(ctx);
        btnExit.setText("Выход");
        btnExit.setAllCaps(false);
        btnExit.setTextSize(14);
        btnExit.setTextColor(0xFFB8C4D0);
        GradientDrawable exitBg = new GradientDrawable();
        exitBg.setCornerRadius(dp(ctx, 10));
        exitBg.setColor(0xFF161B22);
        btnExit.setBackground(exitBg);
        btnExit.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 48)));
        btnExit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                stopped[0] = true;
                d.dismiss();
                callback.onCancelled();
            }
        });
        root.addView(btnExit);
    }

    // ──────────────────────────── STATE 2: TOKEN ────────────────────────────

    private static EditText tokenFieldRef; // последняя созданная ссылка — для автозаполнения из поллинга
    private static TextView tokenErrorRef;

    private static void buildTokenState(final Context ctx, final LinearLayout root, final String deviceId,
                                         final boolean[] stopped, final Handler pollHandler,
                                         final Dialog d, final Callback callback) {
        root.removeAllViews();

        TextView tvOk = new TextView(ctx);
        tvOk.setText("✅ Успешно! Почти всё готово.");
        tvOk.setTextSize(16);
        tvOk.setTypeface(null, Typeface.BOLD);
        tvOk.setTextColor(0xFF00FF9D);
        tvOk.setGravity(Gravity.CENTER);
        root.addView(tvOk);
        space(root, ctx, 12);

        TextView tvHint = new TextView(ctx);
        tvHint.setText("Вставьте токен, который вы получили в Telegram-боте.");
        tvHint.setTextSize(13);
        tvHint.setTextColor(0xFFB8C4D0);
        tvHint.setGravity(Gravity.CENTER);
        root.addView(tvHint);
        space(root, ctx, 12);

        final EditText etToken = new EditText(ctx);
        etToken.setHint("Токен из Telegram-бота");
        etToken.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        etToken.setTextColor(0xFFFFFFFF);
        etToken.setHintTextColor(0xFF5A6672);
        etToken.setTextSize(14);
        etToken.setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12));
        GradientDrawable etBg = new GradientDrawable();
        etBg.setCornerRadius(dp(ctx, 10));
        etBg.setColor(0xFF161B22);
        etBg.setStroke(1, 0xFF2A3340);
        etToken.setBackground(etBg);
        root.addView(etToken);
        tokenFieldRef = etToken;

        final TextView tvError = new TextView(ctx);
        tvError.setTextSize(12);
        tvError.setTextColor(0xFFFF1E4E);
        tvError.setGravity(Gravity.CENTER);
        tvError.setVisibility(View.GONE);
        LinearLayout.LayoutParams errLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        errLp.topMargin = dp(ctx, 8);
        tvError.setLayoutParams(errLp);
        root.addView(tvError);
        tokenErrorRef = tvError;

        space(root, ctx, 16);

        LinearLayout btnRow = new LinearLayout(ctx);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button btnExit = new Button(ctx);
        btnExit.setText("Выход");
        btnExit.setAllCaps(false);
        btnExit.setTextSize(14);
        btnExit.setTextColor(0xFFB8C4D0);
        GradientDrawable exitBg = new GradientDrawable();
        exitBg.setCornerRadius(dp(ctx, 10));
        exitBg.setColor(0xFF161B22);
        btnExit.setBackground(exitBg);
        LinearLayout.LayoutParams exitLp = new LinearLayout.LayoutParams(0, dp(ctx, 48), 1f);
        exitLp.rightMargin = dp(ctx, 8);
        btnExit.setLayoutParams(exitLp);
        btnExit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                stopped[0] = true;
                d.dismiss();
                callback.onCancelled();
            }
        });
        btnRow.addView(btnExit);

        final Button btnCheck = new Button(ctx);
        btnCheck.setText("Проверить");
        btnCheck.setAllCaps(false);
        btnCheck.setTextSize(14);
        btnCheck.setTypeface(null, Typeface.BOLD);
        btnCheck.setTextColor(0xFF001A0E);
        GradientDrawable checkBg = new GradientDrawable();
        checkBg.setCornerRadius(dp(ctx, 10));
        checkBg.setColor(0xFF00FF9D);
        btnCheck.setBackground(checkBg);
        LinearLayout.LayoutParams checkLp = new LinearLayout.LayoutParams(0, dp(ctx, 48), 1f);
        btnCheck.setLayoutParams(checkLp);
        btnCheck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final String token = etToken.getText().toString().trim();
                if (token.isEmpty()) {
                    showTokenError(tvError, "Введите токен");
                    return;
                }
                tvError.setVisibility(View.GONE);
                btnCheck.setEnabled(false);
                btnCheck.setText("Проверка...");
                new Thread(new Runnable() {
                    public void run() {
                        String resp = null;
                        try {
                            String body = "{\"token\":\"" + esc(token) + "\",\"deviceId\":\"" + esc(deviceId) + "\"}";
                            resp = httpPost(AuthActivity.SERVER_URL + "/telegram/check-token", body);
                        } catch (Exception ignored) {}
                        final String fResp = resp;
                        new Handler(ctx.getMainLooper()).post(new Runnable() {
                            public void run() {
                                btnCheck.setEnabled(true);
                                btnCheck.setText("Проверить");
                                if (fResp == null) {
                                    showTokenError(tvError, "Ошибка соединения с сервером");
                                    return;
                                }
                                if (fResp.contains("\"status\":\"ok\"")) {
                                    stopped[0] = true;
                                    String tgId   = extractField(fResp, "id");
                                    String tgUser = extractField(fResp, "username");
                                    String tgName = extractField(fResp, "firstName");
                                    d.dismiss();
                                    callback.onVerified(tgId, tgUser, tgName);
                                } else {
                                    String msg = extractField(fResp, "message");
                                    showTokenError(tvError, msg != null ? msg : "Не удалось проверить токен");
                                }
                            }
                        });
                    }
                }).start();
            }
        });
        btnRow.addView(btnCheck);

        root.addView(btnRow);
    }

    private static void showTokenError(TextView tvError, String msg) {
        tvError.setText(msg);
        tvError.setVisibility(View.VISIBLE);
    }

    // ──────────────────────────── Автополлинг токена ────────────────────────

    private static void startPolling(final Context ctx, final LinearLayout root, final String deviceId,
                                      final boolean[] stopped, final Handler pollHandler,
                                      final Dialog d, final Callback callback) {
        // Java не позволяет ссылаться на локальную переменную внутри её же
        // инициализатора — оборачиваем Runnable в массив из одного элемента,
        // чтобы он мог поставить сам себя на повторный вызов через postDelayed.
        final Runnable[] pollRef = new Runnable[1];
        pollRef[0] = new Runnable() {
            public void run() {
                if (stopped[0]) return;
                checkTokenOnce(ctx, root, deviceId, stopped, pollHandler, d, callback, new Runnable() {
                    public void run() {
                        // Тихая фоновая проверка — токена пока нет, просто планируем следующую попытку.
                        if (!stopped[0]) pollHandler.postDelayed(pollRef[0], POLL_INTERVAL_MS);
                    }
                });
                // Сама следующая попытка после успешного нахождения токена не
                // нужна — пользователь уже увидит экран ввода. Если же токен не
                // найден, onNotFound выше сам планирует повтор.
            }
        };
        pollHandler.postDelayed(pollRef[0], POLL_INTERVAL_MS);
    }

    /**
     * Один запрос к /telegram/poll-token. Если бот уже выдал токен для этого
     * deviceId — переключает (если нужно) экран ожидания на экран ввода
     * токена и подставляет найденное значение. Если токена ещё нет —
     * вызывает onNotFound (используется и фоновым поллингом, и кнопкой
     * "Проверить получение токена", по-разному реагирующими на отсутствие
     * результата).
     */
    /**
     * Пробует найти токен сначала через /telegram/poll-token (новый токен от бота),
     * а если не нашёл — делает fallback запрос к /keys/token-by-device,
     * который возвращает уже существующий активный ключ для этого deviceId.
     *
     * Это покрывает сценарий переустановки приложения: ключ уже привязан к
     * deviceId, бот в ответ на «Получить токен снова» показывает существующий
     * токен, но poll-token его не видит, т.к. он уже был «использован» ранее.
     */
    private static void checkTokenOnce(final Context ctx, final LinearLayout root, final String deviceId,
                                        final boolean[] stopped, final Handler pollHandler,
                                        final Dialog d, final Callback callback, final Runnable onNotFound) {
        new Thread(new Runnable() {
            public void run() {
                // Шаг 1: стандартный poll-token (новый токен от бота)
                String pollResp = null;
                try {
                    String body = "{\"deviceId\":\"" + esc(deviceId) + "\"}";
                    pollResp = httpPost(AuthActivity.SERVER_URL + "/telegram/poll-token", body);
                } catch (Exception ignored) {}

                String foundToken = null;
                if (pollResp != null && pollResp.contains("\"found\":true")) {
                    foundToken = extractField(pollResp, "token");
                }

                if (foundToken != null && !foundToken.isEmpty()) {
                    // Нашли новый токен через стандартный poll
                    final String token = foundToken;
                    new Handler(ctx.getMainLooper()).post(new Runnable() {
                        public void run() {
                            if (stopped[0]) return;
                            if (tokenFieldRef == null) {
                                buildTokenState(ctx, root, deviceId, stopped, pollHandler, d, callback);
                            }
                            if (tokenFieldRef != null && tokenFieldRef.getText().toString().trim().isEmpty()) {
                                tokenFieldRef.setText(token);
                            }
                        }
                    });
                    return;
                }

                // Шаг 2: fallback — ищем уже существующий активный ключ для этого
                // устройства. Нужно для случая, когда пользователь удалил и
                // переустановил приложение: его токен уже активен на сервере,
                // бот его просто показывает повторно, но poll-token его не отдаёт.
                String fallbackResp = null;
                try {
                    String body = "{\"deviceId\":\"" + esc(deviceId) + "\"}";
                    fallbackResp = httpPost(AuthActivity.SERVER_URL + "/keys/token-by-device", body);
                } catch (Exception ignored) {}

                final String existingToken;
                if (fallbackResp != null && fallbackResp.contains("\"found\":true")) {
                    existingToken = extractField(fallbackResp, "token");
                } else {
                    existingToken = null;
                }

                new Handler(ctx.getMainLooper()).post(new Runnable() {
                    public void run() {
                        if (stopped[0]) return;
                        if (existingToken != null && !existingToken.isEmpty()) {
                            // Нашли уже существующий ключ — показываем экран с полем
                            // ввода и подставляем значение, чтобы пользователю не
                            // пришлось вручную копировать его из сообщения бота.
                            if (tokenFieldRef == null) {
                                buildTokenState(ctx, root, deviceId, stopped, pollHandler, d, callback);
                            }
                            if (tokenFieldRef != null && tokenFieldRef.getText().toString().trim().isEmpty()) {
                                tokenFieldRef.setText(existingToken);
                            }
                        } else if (onNotFound != null) {
                            onNotFound.run();
                        }
                    }
                });
            }
        }).start();
    }

    // ──────────────────────────── helpers ────────────────────────────

    private static void space(LinearLayout parent, Context ctx, int dpVal) {
        View v = new View(ctx);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, dpVal)));
        parent.addView(v);
    }

    private static int dp(Context ctx, int val) {
        return (int) (val * ctx.getResources().getDisplayMetrics().density + 0.5f);
    }

    private static String httpPost(String urlStr, String body) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        OutputStream os = conn.getOutputStream();
        os.write(body.getBytes("UTF-8"));
        os.flush(); os.close();
        int code = conn.getResponseCode();
        java.io.InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        if (stream == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close(); conn.disconnect();
        return sb.toString();
    }

    private static String httpGet(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(8000);
        int code = conn.getResponseCode();
        java.io.InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        if (stream == null) return null;
        BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close(); conn.disconnect();
        return sb.toString();
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String extractField(String json, String field) {
        try {
            if (json == null) return null;
            org.json.JSONObject obj = new org.json.JSONObject(json);
            if (!obj.has(field) || obj.isNull(field)) return null;
            Object val = obj.get(field);
            return String.valueOf(val);
        } catch (Exception e) { return null; }
    }
}
