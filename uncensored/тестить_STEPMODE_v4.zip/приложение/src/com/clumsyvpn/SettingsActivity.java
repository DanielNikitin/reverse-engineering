package com.clumsyvpn;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class SettingsActivity extends Activity {

    private ReportBannerHelper reportBannerHelper;
    private boolean isAdminUser = false;
    private AccountStatusMonitor accountStatusMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        accountStatusMonitor = new AccountStatusMonitor(this);
        setContentView(R.layout.activity_settings);

        SharedPreferences authPrefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        isAdminUser = "admin".equals(authPrefs.getString(AuthActivity.KEY_LOGIN, ""));
        if (isAdminUser) {
            reportBannerHelper = new ReportBannerHelper(this);
        }

        TextView btnBack = (TextView) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });

        RelativeLayout btnProfile = (RelativeLayout) findViewById(R.id.btnProfile);
        if (btnProfile != null) {
            btnProfile.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    startActivity(new Intent(SettingsActivity.this, ProfileActivity.class));
                }
            });
        }

        RelativeLayout btnVpnMenu = (RelativeLayout) findViewById(R.id.btnVpnMenu);
        if (btnVpnMenu != null) {
            btnVpnMenu.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    startActivity(new Intent(SettingsActivity.this, VpnMenuActivity.class));
                }
            });
        }

        RelativeLayout btnChat = (RelativeLayout) findViewById(R.id.btnChat);
        if (btnChat != null) {
            btnChat.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    startActivity(new Intent(SettingsActivity.this, ChatActivity.class));
                }
            });
        }

        RelativeLayout btnRankShare = (RelativeLayout) findViewById(R.id.btnRankShare);
        if (btnRankShare != null) {
            btnRankShare.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    startActivity(new Intent(SettingsActivity.this, RankShareActivity.class));
                }
            });
        }

        RelativeLayout btnFaq = (RelativeLayout) findViewById(R.id.btnFaq);
        if (btnFaq != null) {
            btnFaq.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    startActivity(new Intent(SettingsActivity.this, FaqActivity.class));
                }
            });
        }

        RelativeLayout btnAppFilter = (RelativeLayout) findViewById(R.id.btnAppFilter);
        if (btnAppFilter != null) {
            btnAppFilter.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    startActivity(new Intent(SettingsActivity.this, AppFilterActivity.class));
                }
            });
        }

        // Кнопка Админ панели — только для admin
        RelativeLayout btnAdmin = (RelativeLayout) findViewById(R.id.btnAdminPanel);
        if (btnAdmin != null) {
            SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
            String login = prefs.getString(AuthActivity.KEY_LOGIN, "");
            if ("admin".equals(login)) {
                btnAdmin.setVisibility(View.VISIBLE);
                btnAdmin.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        startActivity(new Intent(SettingsActivity.this, AdminPanelActivity.class));
                    }
                });
            } else {
                btnAdmin.setVisibility(View.GONE);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isAdminUser && reportBannerHelper != null) reportBannerHelper.onResume();
        accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isAdminUser && reportBannerHelper != null) reportBannerHelper.onPause();
        accountStatusMonitor.stop();
    }
}
