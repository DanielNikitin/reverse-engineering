package com.clumsyvpn;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class MainActivity extends Activity {

    private android.os.Handler heartbeatHandler = new android.os.Handler();
    private Runnable heartbeatRunnable;
    private AccountStatusMonitor accountStatusMonitor;

    private static final int REQ_VPN     = 100;
    private static final int REQ_OVERLAY = 101;

    private TextView   tvStatus;
    private View       statusDot;
    private LinearLayout statusBadge;
    private Button     btnToggle;
    private ImageView  logoIcon;

    private boolean vpnRunning          = false;
    private boolean receiversRegistered = false;

    static int curServerDelay = 0;
    static int curServerLoss  = 0;
    static int curClientDelay = 0;
    static int curClientLoss  = 0;
    static int curDuration    = 0;
    static int curAfterTimerMode       = 0;  // 0=Сброс, 1=Удалить, 2=Задержка
    static int curAfterTimerDelayMs    = 0;
    static int curAfterTimerDurationSec = 3;
    static int curBtnSize     = 160;

    // ── Пошаговый режим ──────────────────────────────────────────────────
    static int curConfigMode       = 0;  // 0=Обычный, 1=Пошаговый
    static int curStepsAfterMode   = 0;  // 0=Сброс, 1=Следующий шаг
    static String curStepsSerialized = "";

    // ARGB цвет плавающей кнопки (по умолчанию неон-зелёный V9)
    static int curBtnColor = 0xFF00FF9D;

    // Прозрачность плавающей кнопки (0..255), 255 = непрозрачно
    static int curBtnAlpha = 255;

    // Имя SharedPreferences с настройками плавающего окна
    static final String PREFS_FLOAT = "cvpn_float_settings";
    static final String KEY_F_SIZE  = "f_size";
    static final String KEY_F_COLOR = "f_color";
    static final String KEY_F_ALPHA = "f_alpha";
    static final String KEY_F_X     = "f_x";
    static final String KEY_F_Y     = "f_y";

    // Включён ли дополнительный счётчик авто отключения
    static boolean curCounterEnabled = false;

    // ── Уведомления о репортах (только для admin) ──
    private ReportBannerHelper reportBannerHelper;
    private boolean isAdminUser = false;

    private final BroadcastReceiver statusRx = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            String s = i.getStringExtra("status");
            if (s != null) applyStatus(s);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Определяем роль пользователя и инициализируем баннер репортов
        android.content.SharedPreferences authPrefs =
                getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        isAdminUser = "admin".equals(authPrefs.getString(AuthActivity.KEY_LOGIN, ""));
        if (isAdminUser) {
            reportBannerHelper = new ReportBannerHelper(this);
            // Запускаем фоновый сервис опроса репортов
            startService(new Intent(this, ReportPollerService.class));
        }
        // Запускаем сервис поддержки для всех пользователей (и для user, и для admin)
        startService(new Intent(this, SupportPollerService.class));

        accountStatusMonitor = new AccountStatusMonitor(this);

        tvStatus    = (TextView)     findViewById(R.id.tvStatus);
        statusDot   =                findViewById(R.id.statusDot);
        statusBadge = (LinearLayout) findViewById(R.id.statusBadge);
        btnToggle   = (Button)       findViewById(R.id.btnToggle);
        logoIcon    = (ImageView)    findViewById(R.id.logoIcon);
        View coreRingView =          findViewById(R.id.coreRing);

        RelativeLayout btnCustomize = (RelativeLayout) findViewById(R.id.btnCustomize);
        RelativeLayout btnSettings  = (RelativeLayout) findViewById(R.id.btnSettings);
        RelativeLayout btnTelegram  = (RelativeLayout) findViewById(R.id.btnTelegram);
        TextView btnSettingsIcon    = (TextView)       findViewById(R.id.btnSettingsIcon);

        // ═══ Запуск вращения логотипа (3D эффект через крутящийся вектор) ═══
        if (logoIcon != null) {
            RotateAnimation rotate = new RotateAnimation(
                0f, 360f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f);
            rotate.setDuration(8000);
            rotate.setRepeatCount(Animation.INFINITE);
            rotate.setInterpolator(new LinearInterpolator());
            logoIcon.startAnimation(rotate);
        }

        // ═══ Пульсация неонового ядра ═══
        if (coreRingView != null) {
            try {
                Animation pulse = AnimationUtils.loadAnimation(this, R.anim.pulse_ring);
                coreRingView.startAnimation(pulse);
            } catch (Exception ignored) {}
        }

        btnToggle.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (vpnRunning) doStop();
                else {
                    // Проверяем наличие активного конфига
                    if (!hasActiveConfig()) {
                        showNoConfigToast();
                        return;
                    }
                    checkOverlayAndStart();
                }
            }
        });

        btnCustomize.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CustomizeActivity.class));
            }
        });

        btnSettings.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ConfigsActivity.class));
            }
        });

        btnSettingsIcon.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });

        // ═══ Telegram канал автора ═══
        btnTelegram.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openTelegramChannel();
            }
        });

        applyStatus("Остановлен");
        // Загружаем настройки плавающей кнопки (размер, цвет, прозрачность)
        loadFloatSettings(this);
        // Загружаем последний активный конфиг при старте приложения
        loadInstalledConfig();
    }

    /**
     * Загружает сохранённые настройки плавающей кнопки.
     * Вызывается при старте MainActivity, чтобы кастомизация
     * сохранялась после перезапуска приложения.
     */
    static void loadFloatSettings(android.content.Context ctx) {
        android.content.SharedPreferences p =
            ctx.getSharedPreferences(PREFS_FLOAT, MODE_PRIVATE);
        curBtnSize       = p.getInt    (KEY_F_SIZE,  curBtnSize);
        curBtnColor      = p.getInt    (KEY_F_COLOR, curBtnColor);
        curBtnAlpha      = p.getInt    (KEY_F_ALPHA, curBtnAlpha);
        curCounterEnabled = p.getBoolean(VpnMenuActivity.KEY_COUNTER_ENABLED, false);
        if (curBtnAlpha < 60)  curBtnAlpha = 60;
        if (curBtnAlpha > 255) curBtnAlpha = 255;
    }

    /** Сохраняет настройки кастомизации плавающей кнопки */
    static void saveFloatSettings(android.content.Context ctx) {
        ctx.getSharedPreferences(PREFS_FLOAT, MODE_PRIVATE)
            .edit()
            .putInt(KEY_F_SIZE,  curBtnSize)
            .putInt(KEY_F_COLOR, curBtnColor)
            .putInt(KEY_F_ALPHA, curBtnAlpha)
            .apply();
    }

    /** Открывает Telegram-канал автора (через приложение или браузер). */
    private void openTelegramChannel() {
        String url = "https://t.me/SjVzcCRHyLExZDMy";
        try {
            Intent tg = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            tg.setPackage("org.telegram.messenger");
            startActivity(tg);
        } catch (Exception e1) {
            try {
                // Fallback — открыть в любом приложении / браузере
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception e2) {
                Toast.makeText(this,
                    "Не удалось открыть ссылку",
                    Toast.LENGTH_SHORT).show();
            }
        }
    }

    static int curClientSzMode = 0, curClientSzMin = 0, curClientSzMax = 1500;
    static int curServerSzMode = 0, curServerSzMin = 0, curServerSzMax = 1500;

    /**
     * Загружает настройки последнего активного (installed) конфига.
     * Вызывается при старте MainActivity, чтобы конфиг не сбрасывался после перезапуска.
     */
    private void loadInstalledConfig() {
        // Конфиги уже могут быть загружены из SharedPreferences в ConfigsActivity,
        // но если пользователь открыл MainActivity напрямую — грузим сами
        android.content.SharedPreferences prefs =
            getSharedPreferences("cvpn_configs", MODE_PRIVATE);
        int count = prefs.getInt("count", 0);
        if (count == 0) return;
        for (int i = 0; i < count; i++) {
            String p = "cfg_" + i + "_";
            if (prefs.getBoolean(p + "installed", false)) {
                curServerDelay           = prefs.getInt(p + "sDelay",    0);
                curServerLoss            = prefs.getInt(p + "sLoss",     0);
                curClientDelay           = prefs.getInt(p + "cDelay",    0);
                curClientLoss            = prefs.getInt(p + "cLoss",     0);
                curDuration              = prefs.getInt(p + "duration",  0);
                curAfterTimerMode        = prefs.getInt(p + "atMode",    0);
                curAfterTimerDelayMs     = prefs.getInt(p + "atDelayMs", 0);
                curAfterTimerDurationSec = prefs.getInt(p + "atDurSec",  3);
                curClientSzMode          = prefs.getInt(p + "cSzMode",   0);
                curClientSzMin           = prefs.getInt(p + "cSzMin",    0);
                curClientSzMax           = prefs.getInt(p + "cSzMax",    1500);
                curServerSzMode          = prefs.getInt(p + "sSzMode",   0);
                curServerSzMin           = prefs.getInt(p + "sSzMin",    0);
                curServerSzMax           = prefs.getInt(p + "sSzMax",    1500);

                // ── Пошаговый режим ──────────────────────────────────────
                curConfigMode            = prefs.getInt(p + "cfgMode",    0);
                curStepsAfterMode        = prefs.getInt(p + "stepsAfter", 0);
                curStepsSerialized       = prefs.getString(p + "steps",  "");
                break;
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!receiversRegistered) {
            registerReceiver(statusRx, new IntentFilter(MyVpnService.BROADCAST_STATUS));
            receiversRegistered = true;
        }
        if (isAdminUser && reportBannerHelper != null) reportBannerHelper.onResume();
        checkAppStatus();
        startHeartbeat();
        if (accountStatusMonitor != null) accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isAdminUser && reportBannerHelper != null) reportBannerHelper.onPause();
        if (receiversRegistered) {
            try { unregisterReceiver(statusRx); } catch (Exception ignored) {}
            receiversRegistered = false;
        }
        if (heartbeatHandler != null && heartbeatRunnable != null) {
            heartbeatHandler.removeCallbacks(heartbeatRunnable);
        }
        if (accountStatusMonitor != null) accountStatusMonitor.stop();
    }

    private void checkAppStatus() {
        final android.content.SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        final String myLogin = prefs.getString(AuthActivity.KEY_LOGIN, "");
        if ("admin".equals(myLogin)) return; // Admin is never blocked
        final String serverUrl = AuthActivity.SERVER_URL;
        new Thread(new Runnable() {
            public void run() {
                boolean shouldBlock = false;
                try {
                    java.net.URL url = new java.net.URL(serverUrl + "/app-status");
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    conn.disconnect();
                    String resp = sb.toString();
                    if (resp.contains("\"appDisabled\":true")) {
                        shouldBlock = true;
                    }
                } catch (Exception e) {
                    // Сервер недоступен (нет сети, авария, заблокирован DNS
                    // и т.п.) — по требованию считаем это тем же самым, что
                    // и намеренное отключение приложения администратором:
                    // без рабочего сервера приложение всё равно не может
                    // проверять ключи/баны, значит пользоваться им нельзя.
                    shouldBlock = true;
                }
                if (shouldBlock) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            startActivity(new android.content.Intent(MainActivity.this, AppBlockedActivity.class));
                        }
                    });
                }
            }
        }).start();
    }

    private void startHeartbeat() {
        final android.content.SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        final String myLogin = prefs.getString(AuthActivity.KEY_LOGIN, "");
        final String serverUrl = AuthActivity.SERVER_URL;

        // Проверка деактивации/удаления ключа/бана теперь выполняется
        // отдельно через AccountStatusMonitor (см. onResume) — он работает
        // одинаково на всех экранах приложения, а не только на этом.

        heartbeatRunnable = new Runnable() {
            public void run() {
                new Thread(new Runnable() {
                    public void run() {
                        boolean shouldBlock = false;
                        try {
                            java.net.URL url = new java.net.URL(serverUrl + "/heartbeat");
                            java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                            conn.setRequestMethod("POST");
                            conn.setRequestProperty("Content-Type", "application/json");
                            conn.setDoOutput(true);
                            conn.setConnectTimeout(8000);
                            conn.setReadTimeout(8000);
                            String body = "{\"login\":\"" + myLogin + "\"}";
                            conn.getOutputStream().write(body.getBytes("UTF-8"));
                            java.io.BufferedReader br = new java.io.BufferedReader(
                                new java.io.InputStreamReader(conn.getInputStream(), "UTF-8"));
                            StringBuilder sb = new StringBuilder();
                            String line;
                            while ((line = br.readLine()) != null) sb.append(line);
                            br.close();
                            conn.disconnect();
                            String resp = sb.toString();
                            if (resp.contains("\"appDisabled\":true") && !"admin".equals(myLogin)) {
                                shouldBlock = true;
                            }
                        } catch (Exception e) {
                            // Сервер недоступен во время активной работы приложения —
                            // тоже считаем это отключением (см. checkAppStatus()).
                            if (!"admin".equals(myLogin)) shouldBlock = true;
                        }
                        if (shouldBlock) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    startActivity(new android.content.Intent(MainActivity.this, AppBlockedActivity.class));
                                }
                            });
                        }
                    }
                }).start();

                heartbeatHandler.postDelayed(this, 15000);
            }
        };
        heartbeatHandler.postDelayed(heartbeatRunnable, 15000);
    }

    // Проверка деактивации/удаления ключа/бана теперь полностью
    // выполняется через AccountStatusMonitor (см. onResume/onPause выше),
    // что позволяет применять наказание на любом экране приложения, а не
    // только на этом.

    private void checkOverlayAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this,
                    "Разрешите 'Поверх других приложений' и вернитесь",
                    Toast.LENGTH_LONG).show();
                startActivityForResult(new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())), REQ_OVERLAY);
                return;
            }
        }
        checkVpnAndStart();
    }

    private void checkVpnAndStart() {
        Intent vpnIntent = VpnService.prepare(this);
        if (vpnIntent != null) startActivityForResult(vpnIntent, REQ_VPN);
        else doStart();
    }

    private void doStart() {
        // Определяем режим VPN из SharedPreferences
        android.content.SharedPreferences vpnPrefs =
            getSharedPreferences(VpnPickerActivity.PREFS_VPN, MODE_PRIVATE);
        String selectedVpn = vpnPrefs.getString(VpnPickerActivity.KEY_VPN, VpnPickerActivity.VPN_DEFAULT);
        String vpnMode = MyVpnService.VPN_MODE_DEFAULT;
        if (VpnPickerActivity.VPN_QUANTUM.equals(selectedVpn)) {
            vpnMode = MyVpnService.VPN_MODE_QUANTUM;
        } else if (VpnPickerActivity.VPN_SHADOWROUTE.equals(selectedVpn)) {
            vpnMode = MyVpnService.VPN_MODE_SHADOWROUTE;
        }

        Intent vpn = new Intent(this, MyVpnService.class);
        if (curConfigMode == 1) {
            // ── Пошаговый режим ──────────────────────────────────────────
            // MyVpnService хранит список шагов и применяет параметры конкретного
            // шага по команде ACTION_APPLY_STEP от FloatService (там же считается время).
            vpn.setAction(MyVpnService.ACTION_START_STEP_MODE);
            vpn.putExtra(MyVpnService.EXTRA_STEPS_SERIALIZED, curStepsSerialized);
            vpn.putExtra(MyVpnService.EXTRA_VPN_MODE,         vpnMode);
        } else {
            vpn.setAction(MyVpnService.ACTION_START);
            vpn.putExtra(MyVpnService.EXTRA_SERVER_DELAY,         curServerDelay);
            vpn.putExtra(MyVpnService.EXTRA_SERVER_LOSS,          curServerLoss);
            vpn.putExtra(MyVpnService.EXTRA_CLIENT_DELAY,         curClientDelay);
            vpn.putExtra(MyVpnService.EXTRA_CLIENT_LOSS,          curClientLoss);
            vpn.putExtra(MyVpnService.EXTRA_AFTER_TIMER_MODE,     curAfterTimerMode);
            vpn.putExtra(MyVpnService.EXTRA_AFTER_TIMER_DELAY,    curAfterTimerDelayMs);
            vpn.putExtra(MyVpnService.EXTRA_AFTER_TIMER_DURATION, curAfterTimerDurationSec);
            vpn.putExtra(MyVpnService.EXTRA_CLIENT_SZ_MODE,       curClientSzMode);
            vpn.putExtra(MyVpnService.EXTRA_CLIENT_SZ_MIN,        curClientSzMin);
            vpn.putExtra(MyVpnService.EXTRA_CLIENT_SZ_MAX,        curClientSzMax);
            vpn.putExtra(MyVpnService.EXTRA_SERVER_SZ_MODE,       curServerSzMode);
            vpn.putExtra(MyVpnService.EXTRA_SERVER_SZ_MIN,        curServerSzMin);
            vpn.putExtra(MyVpnService.EXTRA_SERVER_SZ_MAX,        curServerSzMax);
            vpn.putExtra(MyVpnService.EXTRA_VPN_MODE,             vpnMode);
        }
        startService(vpn);

        Intent fl = new Intent(this, FloatService.class);
        if (curConfigMode == 1) {
            // ── Пошаговый режим: обратный отсчёт идёт по шагам ────────────
            fl.setAction(FloatService.ACTION_START_STEP_MODE);
            fl.putExtra(FloatService.EXTRA_STEP_DURATIONS, extractStepDurations(curStepsSerialized));
            fl.putExtra(FloatService.EXTRA_STEPS_AFTER_MODE, curStepsAfterMode);
        } else {
            fl.setAction(FloatService.ACTION_START);
            fl.putExtra(FloatService.EXTRA_SECONDS,          curDuration);
            fl.putExtra(FloatService.EXTRA_AFTER_TIMER_MODE, curAfterTimerMode);
            fl.putExtra(FloatService.EXTRA_AFTER_TIMER_DELAY,curAfterTimerDelayMs);
        }
        fl.putExtra(FloatService.EXTRA_BTN_SIZE,         curBtnSize);
        fl.putExtra(FloatService.EXTRA_BTN_COLOR,        curBtnColor);
        fl.putExtra(FloatService.EXTRA_BTN_ALPHA,        curBtnAlpha);
        fl.putExtra(FloatService.EXTRA_COUNTER_ENABLED,  curCounterEnabled);
        startService(fl);

        applyStatus("Работает");
    }

    /**
     * Извлекает длительности шагов (последнее, 13-е поле каждого шага) из строки,
     * сериализованной ConfigsActivity.serializeStepsStatic(), в формат "3000,5000,2000".
     */
    private String extractStepDurations(String stepsSerialized) {
        if (stepsSerialized == null || stepsSerialized.isEmpty()) return "";
        StringBuilder out = new StringBuilder();
        String[] steps = stepsSerialized.split(";");
        for (int i = 0; i < steps.length; i++) {
            if (steps[i].isEmpty()) continue;
            String[] f = steps[i].split(",");
            if (f.length < 13) continue;
            if (out.length() > 0) out.append(",");
            out.append(f[12]); // duration — последнее поле
        }
        return out.toString();
    }

    private void doStop() {
        Intent vpn = new Intent(this, MyVpnService.class);
        vpn.setAction(MyVpnService.ACTION_STOP);
        startService(vpn);

        Intent fl = new Intent(this, FloatService.class);
        fl.setAction(FloatService.ACTION_STOP);
        startService(fl);

        applyStatus("Остановлен");
        // Загружаем последний активный конфиг при старте приложения
        loadInstalledConfig();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_VPN) {
            if (res == RESULT_OK) doStart();
            else Toast.makeText(this, "Разрешение VPN отклонено!", Toast.LENGTH_LONG).show();
        } else if (req == REQ_OVERLAY) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    && Settings.canDrawOverlays(this)) checkVpnAndStart();
            else Toast.makeText(this, "Нет разрешения поверх приложений",
                Toast.LENGTH_LONG).show();
        }
    }

    /** Возвращает true, если есть хотя бы один конфиг с installed=true */
    private boolean hasActiveConfig() {
        // Проверяем список в памяти
        for (int i = 0; i < ConfigsActivity.configs.size(); i++) {
            if (ConfigsActivity.configs.get(i).installed) return true;
        }
        // Проверяем SharedPreferences (если ConfigsActivity ещё не открывалась)
        android.content.SharedPreferences prefs =
            getSharedPreferences("cvpn_configs", MODE_PRIVATE);
        int count = prefs.getInt("count", 0);
        for (int i = 0; i < count; i++) {
            if (prefs.getBoolean("cfg_" + i + "_installed", false)) return true;
        }
        return false;
    }

    /** Показывает кастомный тост: чёрный фон, белый текст, снизу с отступами */
    private void showNoConfigToast() {
        TextView tv = new TextView(this);
        tv.setText("Нет активного конфига");
        tv.setTextColor(0xFFFFFFFF);
        tv.setTextSize(14);
        tv.setTypeface(null, android.graphics.Typeface.BOLD);
        tv.setBackgroundColor(0xFF000000);
        int pad = Math.round(14 * getResources().getDisplayMetrics().density);
        tv.setPadding(pad * 2, pad, pad * 2, pad);

        Toast toast = new Toast(this);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(tv);
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0,
            Math.round(60 * getResources().getDisplayMetrics().density));
        toast.show();
    }

    private void applyStatus(String s) {
        vpnRunning = "Работает".equals(s);
        if (vpnRunning) {
            tvStatus.setText("АКТИВЕН");
            tvStatus.setTextColor(Color.parseColor("#00FF9D"));
            if (statusDot != null) statusDot.setBackgroundColor(Color.parseColor("#00FF9D"));
            if (statusBadge != null) statusBadge.setBackgroundResource(R.drawable.bg_status_green);
            btnToggle.setText("■  СТОП");
            btnToggle.setBackgroundResource(R.drawable.btn_neon_red);
            btnToggle.setTextColor(Color.parseColor("#FFFFFF"));
        } else {
            tvStatus.setText("ОСТАНОВЛЕН");
            tvStatus.setTextColor(Color.parseColor("#FF1E4E"));
            if (statusDot != null) statusDot.setBackgroundColor(Color.parseColor("#FF1E4E"));
            if (statusBadge != null) statusBadge.setBackgroundResource(R.drawable.bg_status_red);
            btnToggle.setText("▶  СТАРТ");
            btnToggle.setBackgroundResource(R.drawable.btn_neon_green);
            btnToggle.setTextColor(Color.parseColor("#001A0E"));
        }
    }

}
