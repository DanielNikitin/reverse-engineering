package com.clumsyvpn;

import android.content.Context;
import android.os.Handler;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class KeyStatusChecker {

    public interface ResultCallback {
        /** status: "ok" | "account_deleted" | "no_key" | "deactivated" | "key_deleted" | "key_expired" | "banned" */
        void onResult(String status, String reason);

        /**
         * keyValue — ключ, который был привязан к забаненному пользователю
         *            (пустая строка, если ключа не было).
         * keyMaxDevices — на сколько устройств был рассчитан этот ключ;
         *            -1, если ключа не было вообще (keyValue пуст).
         * selfBanned — true, если забанен именно ТОТ логин, под которым
         *            выполняется проверка; false — если этот логин сам не
         *            забанен, но пользуется ключом, заблокированным из-за
         *            бана ДРУГОГО (например, старого) логина на этом же
         *            устройстве. В этом случае bannedLogin/bannedUserId —
         *            данные реально забаненного аккаунта.
         */
        void onBanned(String until, String reason, String userId, String keyValue, int keyMaxDevices,
                      boolean selfBanned, String bannedLogin, String bannedUserId);
    }

    /** Колбэк промежуточных стадий проверки — для отображения в StartupCheckDialog. */
    public interface StageListener {
        void onStage(String stageText);
    }

    public static final String STAGE_ACCOUNT = "Проверка есть ли аккаунт в системе...";
    public static final String STAGE_BAN     = "Проверка на блокировку аккаунта...";
    public static final String STAGE_KEY     = "Проверка ключа...";

    /** Старая проверка — используется в периодическом heartbeat внутри MainActivity. Без изменений. */
    public static void check(final Context ctx, final String login, final String deviceId, final ResultCallback callback) {
        if ("admin".equals(login) || login == null || login.isEmpty()) {
            callback.onResult("ok", "");
            return;
        }
        final String serverUrl = AuthActivity.SERVER_URL;
        final Handler mainHandler = new Handler(ctx.getMainLooper());

        new Thread(new Runnable() {
            public void run() {
                // 1) Бан аккаунта
                String banResp = post(serverUrl + "/check-banned", login, deviceId);
                if (banResp != null && banResp.contains("\"status\":\"banned\"")) {
                    final String until = extractBanField(banResp, "until");
                    final String reason = extractBanField(banResp, "reason");
                    final String userId = extractTopField(banResp, "user_id");
                    final String keyValue = extractBanKeyInfoField(banResp, "key");
                    final int keyMaxDevices = extractBanKeyInfoMaxDevices(banResp);
                    final boolean selfBanned = extractBoolField(banResp, "selfBanned", true);
                    final String bannedLogin = extractTopField(banResp, "bannedLogin");
                    final String bannedUserId = extractTopField(banResp, "bannedUserId");
                    mainHandler.post(new Runnable() {
                        public void run() {
                            callback.onResult("banned", reason);
                            callback.onBanned(until, reason, userId, keyValue, keyMaxDevices,
                                selfBanned, bannedLogin, bannedUserId);
                        }
                    });
                    return;
                }

                // 2) Деактивация конкретного пользователя
                String deactResp = post(serverUrl + "/keys/check-deactivated", login, deviceId);
                if (deactResp != null && deactResp.contains("\"status\":\"deactivated\"")) {
                    final String reason = extractReason(deactResp);
                    mainHandler.post(new Runnable() {
                        public void run() { callback.onResult("deactivated", reason); }
                    });
                    return;
                }

                // 3) Удаление целого ключа
                String delResp = post(serverUrl + "/keys/check-deleted", login, deviceId);
                if (delResp != null && delResp.contains("\"status\":\"key_deleted\"")) {
                    final String reason = extractReason(delResp);
                    mainHandler.post(new Runnable() {
                        public void run() { callback.onResult("key_deleted", reason); }
                    });
                    return;
                }

                // 4) Истечение срока ключа
                String expResp = post(serverUrl + "/keys/check-expired", login, deviceId);
                if (expResp != null && expResp.contains("\"status\":\"key_expired\"")) {
                    mainHandler.post(new Runnable() {
                        public void run() { callback.onResult("key_expired", ""); }
                    });
                    return;
                }

                mainHandler.post(new Runnable() {
                    public void run() { callback.onResult("ok", ""); }
                });
            }
        }).start();
    }

    /**
     * Полная пошаговая проверка для экрана автологина (StartupCheckDialog) —
     * используется только в AuthActivity при входе по сохранённой сессии
     * (например, после удаления и переустановки приложения / восстановления
     * из бэкапа). Дополнительно, по сравнению с check():
     *  1) проверяет, существует ли аккаунт в системе вообще ("account_deleted"),
     *  2) если ни одна из проверок ключа не сработала — проверяет, привязан ли
     *     аккаунт сейчас хоть к какому-то ключу вообще ("no_key").
     * stageListener получает текст текущего этапа для отображения в диалоге.
     */
    public static void checkStartup(final Context ctx, final String login, final String deviceId,
                                     final StageListener stageListener, final ResultCallback callback) {
        if ("admin".equals(login) || login == null || login.isEmpty()) {
            callback.onResult("ok", "");
            return;
        }
        final String serverUrl = AuthActivity.SERVER_URL;
        final Handler mainHandler = new Handler(ctx.getMainLooper());

        new Thread(new Runnable() {
            public void run() {
                // 0) Существует ли аккаунт в системе вообще
                stage(mainHandler, stageListener, STAGE_ACCOUNT);
                String existsResp = post(serverUrl + "/check-account-exists", login, deviceId);
                if (existsResp != null && existsResp.contains("\"exists\":false")) {
                    mainHandler.post(new Runnable() {
                        public void run() { callback.onResult("account_deleted", ""); }
                    });
                    return;
                }

                // 1) Бан аккаунта
                stage(mainHandler, stageListener, STAGE_BAN);
                String banResp = post(serverUrl + "/check-banned", login, deviceId);
                if (banResp != null && banResp.contains("\"status\":\"banned\"")) {
                    final String until = extractBanField(banResp, "until");
                    final String reason = extractBanField(banResp, "reason");
                    final String userId = extractTopField(banResp, "user_id");
                    final String keyValue = extractBanKeyInfoField(banResp, "key");
                    final int keyMaxDevices = extractBanKeyInfoMaxDevices(banResp);
                    final boolean selfBanned = extractBoolField(banResp, "selfBanned", true);
                    final String bannedLogin = extractTopField(banResp, "bannedLogin");
                    final String bannedUserId = extractTopField(banResp, "bannedUserId");
                    mainHandler.post(new Runnable() {
                        public void run() {
                            callback.onResult("banned", reason);
                            callback.onBanned(until, reason, userId, keyValue, keyMaxDevices,
                                selfBanned, bannedLogin, bannedUserId);
                        }
                    });
                    return;
                }

                // 2) Проверка ключа: деактивация конкретного пользователя / удаление /
                // истечение срока / отсутствие ключа вообще.
                stage(mainHandler, stageListener, STAGE_KEY);

                String deactResp = post(serverUrl + "/keys/check-deactivated", login, deviceId);
                if (deactResp != null && deactResp.contains("\"status\":\"deactivated\"")) {
                    final String reason = extractReason(deactResp);
                    mainHandler.post(new Runnable() {
                        public void run() { callback.onResult("deactivated", reason); }
                    });
                    return;
                }

                String delResp = post(serverUrl + "/keys/check-deleted", login, deviceId);
                if (delResp != null && delResp.contains("\"status\":\"key_deleted\"")) {
                    final String reason = extractReason(delResp);
                    mainHandler.post(new Runnable() {
                        public void run() { callback.onResult("key_deleted", reason); }
                    });
                    return;
                }

                String expResp = post(serverUrl + "/keys/check-expired", login, deviceId);
                if (expResp != null && expResp.contains("\"status\":\"key_expired\"")) {
                    mainHandler.post(new Runnable() {
                        public void run() { callback.onResult("key_expired", ""); }
                    });
                    return;
                }

                // Ничего из вышеперечисленного не сработало — последняя проверка:
                // привязан ли аккаунт прямо сейчас хоть к какому-то ключу. Если нет —
                // значит ключа по этому аккаунту в системе просто не существует
                // (например, рассинхрон данных после обновления сервера) — тихо
                // разлогиниваем без отдельного диалога с причиной.
                String memResp = post(serverUrl + "/keys/check-membership", login, deviceId);
                if (memResp != null && memResp.contains("\"hasKey\":false")) {
                    mainHandler.post(new Runnable() {
                        public void run() { callback.onResult("no_key", ""); }
                    });
                    return;
                }

                mainHandler.post(new Runnable() {
                    public void run() { callback.onResult("ok", ""); }
                });
            }
        }).start();
    }

    private static void stage(Handler mainHandler, final StageListener listener, final String text) {
        if (listener == null) return;
        mainHandler.post(new Runnable() {
            public void run() { listener.onStage(text); }
        });
    }

    private static String post(String urlStr, String login, String deviceId) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            String body = "{\"login\":\"" + esc(login) + "\",\"deviceId\":\"" + esc(deviceId) + "\"}";
            conn.getOutputStream().write(body.getBytes("UTF-8"));
            int code = conn.getResponseCode();
            java.io.InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            if (stream == null) return null;
            BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            conn.disconnect();
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private static String extractReason(String json) {
        try {
            org.json.JSONObject obj = new org.json.JSONObject(json);
            return obj.optString("reason", "");
        } catch (Exception e) {
            return "";
        }
    }

    private static String extractBanField(String json, String field) {
        try {
            org.json.JSONObject obj = new org.json.JSONObject(json);
            org.json.JSONObject ban = obj.optJSONObject("ban");
            if (ban == null) return "";
            return ban.optString(field, "");
        } catch (Exception e) {
            return "";
        }
    }

    /** Достаёт строковое поле из ban.keyInfo.{field}. Пустая строка, если ключа нет. */
    private static String extractBanKeyInfoField(String json, String field) {
        try {
            org.json.JSONObject obj = new org.json.JSONObject(json);
            org.json.JSONObject ban = obj.optJSONObject("ban");
            if (ban == null) return "";
            org.json.JSONObject keyInfo = ban.optJSONObject("keyInfo");
            if (keyInfo == null) return "";
            return keyInfo.optString(field, "");
        } catch (Exception e) {
            return "";
        }
    }

    /** Достаёт ban.keyInfo.maxDevices. -1, если ключа не было (keyInfo отсутствует). */
    private static int extractBanKeyInfoMaxDevices(String json) {
        try {
            org.json.JSONObject obj = new org.json.JSONObject(json);
            org.json.JSONObject ban = obj.optJSONObject("ban");
            if (ban == null) return -1;
            org.json.JSONObject keyInfo = ban.optJSONObject("keyInfo");
            if (keyInfo == null) return -1;
            return keyInfo.optInt("maxDevices", -1);
        } catch (Exception e) {
            return -1;
        }
    }

    private static String extractTopField(String json, String field) {
        try {
            org.json.JSONObject obj = new org.json.JSONObject(json);
            return obj.optString(field, "");
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean extractBoolField(String json, String field, boolean def) {
        try {
            org.json.JSONObject obj = new org.json.JSONObject(json);
            return obj.optBoolean(field, def);
        } catch (Exception e) {
            return def;
        }
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
