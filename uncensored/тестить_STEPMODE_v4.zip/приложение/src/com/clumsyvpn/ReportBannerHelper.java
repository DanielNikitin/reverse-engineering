package com.clumsyvpn;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Показывает баннер о новых репортах в любой Activity.
 *
 * Логика крестика: при закрытии баннера сохраняем KEY_DISMISSED_COUNT.
 * Новый баннер показывается только если текущий count > dismissed_count.
 * Таким образом переход в другое меню не дублирует то же уведомление.
 */
public class ReportBannerHelper {

    // Ключ: счётчик который был при последнем «закрытии» крестиком
    static final String KEY_DISMISSED_COUNT = "dismissed_report_count";

    private final Activity activity;
    private FrameLayout bannerContainer;

    private final Handler autoHideHandler = new Handler();
    private boolean receiverRegistered = false;

    private final BroadcastReceiver reportReceiver = new BroadcastReceiver() {
        public void onReceive(Context ctx, Intent intent) {
            int count = intent.getIntExtra(ReportPollerService.EXTRA_COUNT, 0);
            if (shouldShow(count)) showBanner(count);
        }
    };

    public ReportBannerHelper(Activity activity) {
        this.activity = activity;
        buildBannerContainer();
    }

    public void onResume() {
        if (!receiverRegistered) {
            activity.registerReceiver(reportReceiver,
                    new IntentFilter(ReportPollerService.ACTION_NEW_REPORTS));
            receiverRegistered = true;
        }
        checkPendingReports();
    }

    public void onPause() {
        if (receiverRegistered) {
            try { activity.unregisterReceiver(reportReceiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        autoHideHandler.removeCallbacksAndMessages(null);
    }

    // ──────────────────────────────────────────────

    /** Показывать ли баннер: только если count строго больше dismissed_count */
    private boolean shouldShow(int count) {
        SharedPreferences prefs = activity.getSharedPreferences(
                ReportPollerService.PREFS_ADMIN, Context.MODE_PRIVATE);
        int dismissed = prefs.getInt(KEY_DISMISSED_COUNT, 0);
        return count > dismissed;
    }

    private void saveDismissed(int count) {
        activity.getSharedPreferences(ReportPollerService.PREFS_ADMIN, Context.MODE_PRIVATE)
                .edit().putInt(KEY_DISMISSED_COUNT, count).apply();
    }

    private void buildBannerContainer() {
        bannerContainer = new FrameLayout(activity);
        bannerContainer.setVisibility(android.view.View.GONE);
        bannerContainer.setAlpha(0f);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = android.view.Gravity.TOP;
        activity.addContentView(bannerContainer, lp);
    }

    private void checkPendingReports() {
        SharedPreferences prefs = activity.getSharedPreferences(
                ReportPollerService.PREFS_ADMIN, Context.MODE_PRIVATE);
        int pending = prefs.getInt(ReportPollerService.KEY_PENDING_REPORTS, 0);
        if (pending > 0 && shouldShow(pending)) showBanner(pending);
    }

    public void showBanner(final int count) {
        if (bannerContainer == null) return;
        activity.runOnUiThread(new Runnable() {
            public void run() {
                bannerContainer.removeAllViews();
                bannerContainer.setVisibility(android.view.View.VISIBLE);
                bannerContainer.setAlpha(0f);
                bannerContainer.setTranslationY(-dp(70));

                LinearLayout banner = new LinearLayout(activity);
                banner.setOrientation(LinearLayout.HORIZONTAL);
                banner.setGravity(android.view.Gravity.CENTER_VERTICAL);
                banner.setPadding(dp(14), dp(12), dp(10), dp(12));

                GradientDrawable bg = new GradientDrawable();
                bg.setShape(GradientDrawable.RECTANGLE);
                bg.setColor(0xFF1A0810);
                bg.setStroke(dp(1), 0xFFFF1E4E);
                bg.setCornerRadius(dp(10));
                banner.setBackground(bg);

                TextView tvMsg = new TextView(activity);
                tvMsg.setText("\uD83D\uDD14  " + count + " " + plural(count));
                tvMsg.setTextSize(13);
                tvMsg.setTextColor(0xFFFF668A);
                tvMsg.setTypeface(null, android.graphics.Typeface.BOLD);
                tvMsg.setLayoutParams(new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                banner.addView(tvMsg);

                // Кнопка «Открыть»
                TextView tvOpen = new TextView(activity);
                tvOpen.setText("Открыть");
                tvOpen.setTextSize(12);
                tvOpen.setTextColor(0xFFFFFFFF);
                tvOpen.setTypeface(null, android.graphics.Typeface.BOLD);
                tvOpen.setPadding(dp(10), dp(6), dp(10), dp(6));
                GradientDrawable openBg = new GradientDrawable();
                openBg.setShape(GradientDrawable.RECTANGLE);
                openBg.setCornerRadius(dp(6));
                openBg.setColor(0xFFFF1E4E);
                tvOpen.setBackground(openBg);
                tvOpen.setOnClickListener(new android.view.View.OnClickListener() {
                    public void onClick(android.view.View v) {
                        saveDismissed(count);
                        hideBanner();
                        activity.startActivity(new Intent(activity, AdminPanelActivity.class));
                    }
                });
                banner.addView(tvOpen);

                // Кнопка «✕» — сохраняем dismissed_count, чтобы не показывать снова
                final int dismissCount = count;
                TextView tvClose = new TextView(activity);
                tvClose.setText(" \u2715");
                tvClose.setTextSize(14);
                tvClose.setTextColor(0xFF6C7885);
                tvClose.setPadding(dp(8), 0, dp(4), 0);
                tvClose.setOnClickListener(new android.view.View.OnClickListener() {
                    public void onClick(android.view.View v) {
                        saveDismissed(dismissCount);
                        hideBanner();
                    }
                });
                banner.addView(tvClose);

                FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                blp.setMargins(dp(12), dp(8), dp(12), 0);
                banner.setLayoutParams(blp);
                bannerContainer.addView(banner);

                bannerContainer.animate().alpha(1f).translationY(0).setDuration(300).start();

                autoHideHandler.removeCallbacksAndMessages(null);
                autoHideHandler.postDelayed(new Runnable() {
                    public void run() { hideBanner(); }
                }, 6000);
            }
        });
    }

    private void hideBanner() {
        if (bannerContainer == null) return;
        bannerContainer.animate().alpha(0f).setDuration(250)
                .withEndAction(new Runnable() {
                    public void run() {
                        if (bannerContainer != null) {
                            bannerContainer.setVisibility(android.view.View.GONE);
                            bannerContainer.removeAllViews();
                        }
                    }
                }).start();
    }

    private String plural(int n) {
        if (n % 100 >= 11 && n % 100 <= 19) return "новых репортов";
        int r = n % 10;
        if (r == 1) return "новый репорт";
        if (r >= 2 && r <= 4) return "новых репорта";
        return "новых репортов";
    }

    private int dp(int val) {
        return (int)(val * activity.getResources().getDisplayMetrics().density);
    }
}
