package com.clumsyvpn;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

/**
 * SupportChatActivity — чат пользователя с поддержкой.
 * ИСПРАВЛЕНО: дубликаты, adminJoined логика, in-app уведомление.
 */
public class SupportChatActivity extends Activity {

    public static final String EXTRA_CHAT_ID   = "chat_id";
    public static final String EXTRA_CHAT_NAME = "chat_name";

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    private String serverUrl;
    private String userLogin;
    private String userPassword;
    private String chatId;
    private String chatName;

    private LinearLayout messagesContainer;
    private ScrollView   scrollView;
    private EditText     etInput;
    private TextView     btnSend;
    private LinearLayout inputBar;
    private TextView     tvArchivedNote;
    private LinearLayout searchingBar;

    // In-app notification banner
    private FrameLayout notifBanner;
    private Handler notifHandler = new Handler();

    private Handler pollHandler = new Handler();
    private Runnable pollRunnable;

    private long lastMsgTimestamp = 0;
    // FIX DUPLICATES: track displayed message IDs
    private Set<String> displayedMsgIds = new HashSet<>();

    private boolean isFirstMessage = true;
    private boolean isSearching = false;
    private boolean isArchived = false;
    private boolean adminJoined = false;
    private boolean isMutedInChat = false;
    private String  muteUntilStr = "";
    private String  muteReasonStr = "";
    private LinearLayout muteBar;
    private long lastAdminMsgTs = 0;

    // Reply-to state (swipe like Telegram)
    private String  replyToText = null;
    private String  replyToSender = null;
    private LinearLayout replyPreviewBar;

    private AccountStatusMonitor accountStatusMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        userLogin    = prefs.getString(AuthActivity.KEY_LOGIN, "");
        userPassword = prefs.getString(AuthActivity.KEY_PASSWORD, "");
        serverUrl    = AuthActivity.SERVER_URL;

        accountStatusMonitor = new AccountStatusMonitor(this);

        chatId   = getIntent().getStringExtra(EXTRA_CHAT_ID);
        chatName = getIntent().getStringExtra(EXTRA_CHAT_NAME);

        buildUI();
        loadMessages(true);
        startPolling();
    }

    @Override
    protected void onResume() {
        super.onResume();
        accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pollHandler != null && pollRunnable != null)
            pollHandler.removeCallbacks(pollRunnable);
        if (notifHandler != null)
            notifHandler.removeCallbacksAndMessages(null);
    }

    // BUILD UI
    private void buildUI() {
        FrameLayout rootFrame = new FrameLayout(this);
        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));
        root.setBackgroundColor(0xFF030507);

        root.addView(buildHeader());

        View div = new View(this);
        div.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        div.setBackgroundColor(0xFF17202A);
        root.addView(div);

        scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));
        scrollView.setFillViewport(true);

        messagesContainer = new LinearLayout(this);
        messagesContainer.setOrientation(LinearLayout.VERTICAL);
        messagesContainer.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        messagesContainer.setPadding(dp(12), dp(12), dp(12), dp(12));
        scrollView.addView(messagesContainer);
        root.addView(scrollView);

        searchingBar = buildSearchingBar();
        root.addView(searchingBar);

        tvArchivedNote = new TextView(this);
        tvArchivedNote.setText("Начните новый чат — этот чат завершил администратор");
        tvArchivedNote.setTextSize(13);
        tvArchivedNote.setTextColor(0xFF6C7885);
        tvArchivedNote.setGravity(Gravity.CENTER);
        tvArchivedNote.setPadding(dp(20), dp(14), dp(20), dp(14));
        tvArchivedNote.setVisibility(View.GONE);
        GradientDrawable archBg = new GradientDrawable();
        archBg.setColor(0xFF07090C);
        archBg.setStroke(1, 0xFF17202A);
        tvArchivedNote.setBackground(archBg);
        root.addView(tvArchivedNote);

        inputBar = buildInputBar();
        root.addView(inputBar);

        rootFrame.addView(root);

        // Notification banner overlay
        notifBanner = new FrameLayout(this);
        notifBanner.setVisibility(View.GONE);
        FrameLayout.LayoutParams bannerLp = new FrameLayout.LayoutParams(MATCH, WRAP);
        bannerLp.topMargin = dp(8);
        notifBanner.setLayoutParams(bannerLp);
        rootFrame.addView(notifBanner);

        setContentView(rootFrame);
    }

    private LinearLayout buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(62)));
        header.setPadding(dp(12), 0, dp(16), 0);
        header.setBackgroundColor(0xFF07090C);

        FrameLayout btnBackWrap = new FrameLayout(this);
        btnBackWrap.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        GradientDrawable backBg = new GradientDrawable();
        backBg.setShape(GradientDrawable.OVAL);
        backBg.setColor(0xFF0C1014);
        backBg.setStroke(1, 0xFF17202A);
        btnBackWrap.setBackground(backBg);
        TextView btnBack = new TextView(this);
        btnBack.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        btnBack.setText("‹");
        btnBack.setTextSize(24);
        btnBack.setTextColor(0xFF00FF9D);
        btnBack.setTypeface(null, Typeface.BOLD);
        btnBack.setGravity(Gravity.CENTER);
        btnBack.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { finish(); } });
        btnBackWrap.addView(btnBack);
        header.addView(btnBackWrap);
        header.addView(spacerH(dp(12)));

        FrameLayout iconWrap = new FrameLayout(this);
        iconWrap.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(0x2000FF9D);
        iconBg.setStroke(1, 0xFF00FF9D);
        iconWrap.setBackground(iconBg);
        TextView tvIcon = new TextView(this);
        tvIcon.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        tvIcon.setText("💬");
        tvIcon.setTextSize(16);
        tvIcon.setGravity(Gravity.CENTER);
        iconWrap.addView(tvIcon);
        header.addView(iconWrap);
        header.addView(spacerH(dp(10)));

        LinearLayout titleBlock = new LinearLayout(this);
        titleBlock.setOrientation(LinearLayout.VERTICAL);
        titleBlock.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView tvName = new TextView(this);
        tvName.setText(chatName != null ? chatName : "Онлайн помощь");
        tvName.setTextSize(15);
        tvName.setTextColor(0xFFFFFFFF);
        tvName.setTypeface(null, Typeface.BOLD);
        titleBlock.addView(tvName);
        TextView tvSub = new TextView(this);
        tvSub.setText("Онлайн помощь");
        tvSub.setTextSize(11);
        tvSub.setTextColor(0xFF6C7885);
        titleBlock.addView(tvSub);
        header.addView(titleBlock);

        return header;
    }

    private LinearLayout buildInputBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        bar.setPadding(dp(12), dp(10), dp(12), dp(10));
        bar.setBackgroundColor(0xFF07090C);

        etInput = new EditText(this);
        etInput.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        etInput.setHint("Написать сообщение...");
        etInput.setHintTextColor(0xFF3A4654);
        etInput.setTextColor(0xFFFFFFFF);
        etInput.setTextSize(14);
        etInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        etInput.setMaxLines(4);
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setShape(GradientDrawable.RECTANGLE);
        inputBg.setCornerRadius(dp(22));
        inputBg.setColor(0xFF0C1014);
        inputBg.setStroke(1, 0xFF17202A);
        etInput.setBackground(inputBg);
        bar.addView(etInput);
        bar.addView(spacerH(dp(8)));

        btnSend = new TextView(this);
        btnSend.setLayoutParams(new LinearLayout.LayoutParams(dp(46), dp(46)));
        btnSend.setText("➤");
        btnSend.setTextSize(17);
        btnSend.setTextColor(0xFF001A0E);
        btnSend.setGravity(Gravity.CENTER);
        btnSend.setTypeface(null, Typeface.BOLD);
        // btn_send_round — green neon oval
        {
            android.graphics.drawable.GradientDrawable glow = new android.graphics.drawable.GradientDrawable();
            glow.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            glow.setColor(0x4000FF9D);
            android.graphics.drawable.GradientDrawable fill = new android.graphics.drawable.GradientDrawable();
            fill.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            fill.setColor(0xFF00FF9D);
            fill.setStroke(dp(1), 0xFFA8FFDB);
            android.graphics.drawable.InsetDrawable fillInset =
                new android.graphics.drawable.InsetDrawable(fill, dp(3));
            btnSend.setBackground(new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{glow, fillInset}));
        }
        btnSend.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { trySendMessage(); }
        });
        bar.addView(btnSend);

        return bar;
    }

    private LinearLayout buildSearchingBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        bar.setPadding(dp(16), dp(12), dp(16), dp(12));
        bar.setBackgroundColor(0xFF07090C);
        bar.setVisibility(View.GONE);

        View dot = new View(this);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(8), dp(8));
        dlp.rightMargin = dp(10);
        dlp.gravity = Gravity.CENTER_VERTICAL;
        dot.setLayoutParams(dlp);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(0xFFFFD700);
        dot.setBackground(dotBg);
        bar.addView(dot);

        TextView tvLine = new TextView(this);
        tvLine.setText("─────── ○ поиск свободных администраторов ○ ───────");
        tvLine.setTextSize(11);
        tvLine.setTextColor(0xFF6C7885);
        tvLine.setGravity(Gravity.CENTER);
        tvLine.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        bar.addView(tvLine);

        return bar;
    }

    // SEND MESSAGE
    private void trySendMessage() {
        if (isArchived) { toast("Этот чат завершён"); return; }
        if (isSearching) { toast("Ожидайте, идёт поиск администратора..."); return; }
        if (isMutedInChat) { showMuteBarSupport(); return; }

        String text = etInput.getText().toString().trim();
        if (text.isEmpty()) return;

        if (isFirstMessage && text.length() < 20) {
            showMinLengthHint();
            return;
        }

        // Prepend reply quote if replying
        if (replyToText != null) {
            String senderLabel = replyToSender != null ? replyToSender : "";
            String quote = "↩ " + senderLabel + ": «" + replyToText + "»\n";
            text = quote + text;
            clearReplyTo();
        }

        final String textToSend = text;
        etInput.setText("");
        // FIX DUPLICATES: disable send button while request is in-flight
        btnSend.setEnabled(false);
        btnSend.setAlpha(0.5f);
        sendMessage(textToSend);
    }

    private void showMinLengthHint() {
        int remaining = 20 - etInput.getText().toString().trim().length();
        toast("Опишите проблему подробнее (ещё минимум " + remaining + " символов)");
        GradientDrawable errorBg = new GradientDrawable();
        errorBg.setShape(GradientDrawable.RECTANGLE);
        errorBg.setCornerRadius(dp(22));
        errorBg.setColor(0xFF0C1014);
        errorBg.setStroke(1, 0xFFFF1E4E);
        etInput.setBackground(errorBg);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                GradientDrawable normalBg = new GradientDrawable();
                normalBg.setShape(GradientDrawable.RECTANGLE);
                normalBg.setCornerRadius(dp(22));
                normalBg.setColor(0xFF0C1014);
                normalBg.setStroke(1, 0xFF17202A);
                etInput.setBackground(normalBg);
            }
        }, 2000);
    }

    private void sendMessage(final String text) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"login\":\"" + esc(userLogin) + "\",\"password\":\"" + esc(userPassword) +
                        "\",\"chatId\":\"" + esc(chatId) + "\",\"text\":\"" + esc(text) + "\"}";
                    String resp = httpPost(serverUrl + "/support/chat/send", body);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            btnSend.setEnabled(true);
                            btnSend.setAlpha(1f);
                        }
                    });
                    if (resp != null) {
                        final JSONObject j = new JSONObject(resp);
                        final String status = j.optString("status", "");
                        if (j.optBoolean("ok", false)) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    if (isFirstMessage) {
                                        isFirstMessage = false;
                                        isSearching = true;
                                        searchingBar.setVisibility(View.VISIBLE);
                                        inputBar.setVisibility(View.GONE);
                                    }
                                    // FIX DUPLICATES: do NOT add bubble here.
                                    // Polling will pick it up from server with a real ID.
                                }
                            });
                        } else if ("muted".equals(status)) {
                            final JSONObject muteObj = j.optJSONObject("mute");
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    isMutedInChat = true;
                                    muteUntilStr  = muteObj != null ? muteObj.optString("until", "") : "";
                                    muteReasonStr = muteObj != null ? muteObj.optString("reason", "") : "";
                                    showMuteBarSupport();
                                }
                            });
                        }
                    }
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            btnSend.setEnabled(true);
                            btnSend.setAlpha(1f);
                            toast("Ошибка отправки");
                        }
                    });
                }
            }
        }).start();
    }

    // LOAD & POLL MESSAGES
    private void loadMessages(final boolean initial) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    long sinceTs = initial ? 0 : lastMsgTimestamp;
                    String body = "{\"login\":\"" + esc(userLogin) + "\",\"password\":\"" + esc(userPassword) +
                        "\",\"chatId\":\"" + esc(chatId) + "\",\"since\":" + sinceTs + "}";
                    String resp = httpPost(serverUrl + "/support/chat/messages", body);
                    if (resp == null) return;
                    final JSONObject j = new JSONObject(resp);
                    final JSONArray msgs = j.optJSONArray("messages");
                    final boolean archived = j.optBoolean("archived", false);
                    final boolean searching = j.optBoolean("searching", false);
                    final boolean hasAdmin = j.optBoolean("adminJoined", false);

                    runOnUiThread(new Runnable() {
                        public void run() {
                            if (initial) {
                                messagesContainer.removeAllViews();
                                displayedMsgIds.clear();
                            }

                            if (msgs != null) {
                                boolean anyNew = false;
                                for (int i = 0; i < msgs.length(); i++) {
                                    try {
                                        JSONObject msg = msgs.getJSONObject(i);
                                        String msgId = msg.optString("id", "");
                                        String text = msg.optString("text");
                                        String sender = msg.optString("sender");
                                        String senderLogin = msg.optString("senderLogin", "");
                                        long ts = msg.optLong("timestamp", 0);

                                        if (ts > lastMsgTimestamp) lastMsgTimestamp = ts;

                                        // FIX DUPLICATES: skip already-displayed messages
                                        if (!msgId.isEmpty() && displayedMsgIds.contains(msgId)) continue;
                                        if (!msgId.isEmpty()) displayedMsgIds.add(msgId);

                                        boolean isOwn = "user".equals(sender) && senderLogin.equals(userLogin);
                                        boolean isBot = "bot".equals(sender);
                                        boolean isAdminMsg = "admin".equals(sender);

                                        addMessageBubble(text, isOwn,
                                            isBot ? "Бот" : (isAdminMsg ? "Поддержка" : senderLogin), ts);
                                        anyNew = true;

                                        // BAG 3: In-app notification when admin replies (not on initial load)
                                        if (isAdminMsg && !initial && ts > lastAdminMsgTs) {
                                            lastAdminMsgTs = ts;
                                            showAdminNotification(text);
                                        }
                                    } catch (Exception ignored) {}
                                }
                                if (anyNew) scrollToBottom();
                            }

                            isSearching = searching;
                            isArchived = archived;
                            adminJoined = hasAdmin;

                            searchingBar.setVisibility(isSearching ? View.VISIBLE : View.GONE);

                            if (isArchived) {
                                inputBar.setVisibility(View.GONE);
                                tvArchivedNote.setVisibility(View.VISIBLE);
                                searchingBar.setVisibility(View.GONE);
                            } else if (isSearching) {
                                inputBar.setVisibility(View.GONE);
                            } else {
                                inputBar.setVisibility(View.VISIBLE);
                                tvArchivedNote.setVisibility(View.GONE);
                            }

                            if (adminJoined && !isSearching && !isArchived) {
                                isFirstMessage = false;
                            }
                        }
                    });
                } catch (Exception e) {}
            }
        }).start();
    }

    private void startPolling() {
        pollRunnable = new Runnable() {
            public void run() {
                if (!isArchived) loadMessages(false);
                pollHandler.postDelayed(this, 2500);
            }
        };
        pollHandler.postDelayed(pollRunnable, 2500);
    }

    // IN-APP NOTIFICATION (БАГ 3)
    private void showAdminNotification(final String msgText) {
        if (notifBanner == null) return;
        notifHandler.removeCallbacksAndMessages(null);
        notifBanner.removeAllViews();

        LinearLayout banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.VERTICAL);
        banner.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bannerBg = new GradientDrawable();
        bannerBg.setShape(GradientDrawable.RECTANGLE);
        bannerBg.setColor(0xFF061A0F);
        bannerBg.setStroke(2, 0xFF00FF9D);
        bannerBg.setCornerRadius(dp(12));
        banner.setBackground(bannerBg);

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("💬  Вам написал администратор");
        tvTitle.setTextSize(13);
        tvTitle.setTextColor(0xFF00FF9D);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        topRow.addView(tvTitle);

        TextView tvClose = new TextView(this);
        tvClose.setText("✕");
        tvClose.setTextSize(14);
        tvClose.setTextColor(0xFF6C7885);
        tvClose.setPadding(dp(8), 0, 0, 0);
        tvClose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { hideNotifBanner(); }
        });
        topRow.addView(tvClose);
        banner.addView(topRow);

        String preview = msgText.length() > 60 ? msgText.substring(0, 60) + "…" : msgText;
        TextView tvPreview = new TextView(this);
        tvPreview.setText(preview);
        tvPreview.setTextSize(12);
        tvPreview.setTextColor(0xFFB8C4D0);
        tvPreview.setPadding(0, dp(4), 0, 0);
        banner.addView(tvPreview);

        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(MATCH, WRAP);
        blp.setMargins(dp(12), dp(8), dp(12), 0);
        banner.setLayoutParams(blp);
        notifBanner.addView(banner);

        notifBanner.setAlpha(0f);
        notifBanner.setTranslationY(-dp(50));
        notifBanner.setVisibility(View.VISIBLE);
        notifBanner.animate().alpha(1f).translationY(0).setDuration(280).start();

        notifHandler.postDelayed(new Runnable() {
            public void run() { hideNotifBanner(); }
        }, 5000);
    }

    private void hideNotifBanner() {
        if (notifBanner == null) return;
        notifBanner.animate().alpha(0f).setDuration(200)
            .withEndAction(new Runnable() {
                public void run() { notifBanner.setVisibility(View.GONE); }
            }).start();
    }

    // MESSAGE BUBBLE
    private void addMessageBubble(String text, boolean isOwn, String senderLabel, long timestamp) {
        boolean isBot = "Бот".equals(senderLabel);
        boolean isAdmin = "Поддержка".equals(senderLabel);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.bottomMargin = dp(8);
        row.setLayoutParams(rlp);

        TextView tvSender = new TextView(this);
        tvSender.setText(senderLabel);
        tvSender.setTextSize(10);
        tvSender.setTypeface(null, Typeface.BOLD);
        tvSender.setLetterSpacing(0.05f);
        if (isBot) { tvSender.setTextColor(0xFF6C7885); tvSender.setGravity(Gravity.START); }
        else if (isAdmin) { tvSender.setTextColor(0xFF00FF9D); tvSender.setGravity(Gravity.START); }
        else if (isOwn) { tvSender.setTextColor(0xFF00E5FF); tvSender.setGravity(Gravity.END); }
        else { tvSender.setTextColor(0xFFB8C4D0); tvSender.setGravity(Gravity.START); }

        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(MATCH, WRAP);
        slp.bottomMargin = dp(3);
        slp.leftMargin   = isOwn ? dp(60) : dp(4);
        slp.rightMargin  = isOwn ? dp(4) : dp(60);
        tvSender.setLayoutParams(slp);
        row.addView(tvSender);

        TextView bubble = new TextView(this);
        bubble.setText(text);
        bubble.setTextSize(14);
        bubble.setPadding(dp(14), dp(10), dp(14), dp(10));

        GradientDrawable bubbleBg = new GradientDrawable();
        bubbleBg.setShape(GradientDrawable.RECTANGLE);
        if (isBot) {
            bubbleBg.setCornerRadii(new float[]{dp(4), dp(4), dp(16), dp(16), dp(16), dp(16), dp(16), dp(16)});
            bubbleBg.setColor(0xFF1A2430); bubbleBg.setStroke(1, 0xFF243340);
            bubble.setTextColor(0xFFFFFFFF);
        } else if (isAdmin) {
            bubbleBg.setCornerRadii(new float[]{dp(4), dp(4), dp(16), dp(16), dp(16), dp(16), dp(16), dp(16)});
            bubbleBg.setColor(0xFF0D2015); bubbleBg.setStroke(1, 0xFF00FF9D);
            bubble.setTextColor(0xFF00FF9D);
        } else if (isOwn) {
            bubbleBg.setCornerRadii(new float[]{dp(16), dp(16), dp(4), dp(4), dp(16), dp(16), dp(16), dp(16)});
            bubbleBg.setColor(0xFF0D1F2A); bubbleBg.setStroke(1, 0xFF00E5FF);
            bubble.setTextColor(0xFFFFFFFF);
        } else {
            bubbleBg.setCornerRadius(dp(14));
            bubbleBg.setColor(0xFF0C1014); bubbleBg.setStroke(1, 0xFF17202A);
            bubble.setTextColor(0xFFFFFFFF);
        }
        bubble.setBackground(bubbleBg);

        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(WRAP, WRAP);
        blp.leftMargin  = isOwn ? dp(60) : 0;
        blp.rightMargin = isOwn ? 0 : dp(60);
        blp.gravity     = isOwn ? Gravity.END : Gravity.START;
        bubble.setLayoutParams(blp);

        bubble.setAlpha(0f);
        bubble.setTranslationY(isOwn ? dp(10) : dp(-5));

        // ── Swipe-to-reply (Telegram style) ──
        final String bubbleText   = text;
        final String bubbleSender = senderLabel;
        bubble.setOnTouchListener(new View.OnTouchListener() {
            private float startX;
            private boolean triggered = false;
            public boolean onTouch(final View v, android.view.MotionEvent e) {
                switch (e.getAction()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        startX = e.getRawX();
                        triggered = false;
                        return false;
                    case android.view.MotionEvent.ACTION_MOVE:
                        float dx = startX - e.getRawX(); // positive = swipe left
                        if (!triggered && dx > dp(60)) {
                            triggered = true;
                            v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                            setReplyTo(bubbleText, bubbleSender);
                            v.animate().translationX(-dp(16)).setDuration(80)
                                .withEndAction(new Runnable() {
                                    public void run() {
                                        v.animate().translationX(0).setDuration(120).start();
                                    }
                                }).start();
                        }
                        return false;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        return false;
                }
                return false;
            }
        });

        row.addView(bubble);
        messagesContainer.addView(row);
        bubble.animate().alpha(1f).translationY(0).setDuration(200).start();
    }

    private void setReplyTo(final String msgText, final String sender) {
        replyToText   = msgText;
        replyToSender = sender;
        showReplyPreview();
    }

    private void clearReplyTo() {
        replyToText   = null;
        replyToSender = null;
        if (replyPreviewBar != null && replyPreviewBar.getParent() != null) {
            ((android.view.ViewGroup) replyPreviewBar.getParent()).removeView(replyPreviewBar);
        }
        replyPreviewBar = null;
    }

    private void showReplyPreview() {
        // Remove old preview if exists
        if (replyPreviewBar != null && replyPreviewBar.getParent() != null) {
            ((android.view.ViewGroup) replyPreviewBar.getParent()).removeView(replyPreviewBar);
        }

        replyPreviewBar = new LinearLayout(this);
        replyPreviewBar.setOrientation(LinearLayout.HORIZONTAL);
        replyPreviewBar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        replyPreviewBar.setPadding(dp(12), dp(8), dp(8), dp(8));

        android.graphics.drawable.GradientDrawable previewBg = new android.graphics.drawable.GradientDrawable();
        previewBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        previewBg.setColor(0xFF07090C);
        previewBg.setStroke(dp(1), 0xFF17202A);
        replyPreviewBar.setBackground(previewBg);

        // Green left bar
        View accentBar = new View(this);
        android.graphics.drawable.GradientDrawable accentBg = new android.graphics.drawable.GradientDrawable();
        accentBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        accentBg.setCornerRadius(dp(2));
        accentBg.setColor(0xFF00FF9D);
        accentBar.setBackground(accentBg);
        LinearLayout.LayoutParams abLp = new LinearLayout.LayoutParams(dp(3), dp(36));
        abLp.rightMargin = dp(10);
        accentBar.setLayoutParams(abLp);
        replyPreviewBar.addView(accentBar);

        // Text block
        LinearLayout textBlock = new LinearLayout(this);
        textBlock.setOrientation(LinearLayout.VERTICAL);
        textBlock.setLayoutParams(new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView tvSender = new TextView(this);
        tvSender.setText(replyToSender != null ? replyToSender : "Сообщение");
        tvSender.setTextSize(11);
        tvSender.setTextColor(0xFF00FF9D);
        tvSender.setTypeface(null, android.graphics.Typeface.BOLD);
        textBlock.addView(tvSender);

        TextView tvText = new TextView(this);
        String preview = replyToText != null && replyToText.length() > 50
            ? replyToText.substring(0, 50) + "…" : replyToText;
        tvText.setText(preview);
        tvText.setTextSize(12);
        tvText.setTextColor(0xFF6C7885);
        tvText.setMaxLines(1);
        textBlock.addView(tvText);

        replyPreviewBar.addView(textBlock);

        // Close button
        TextView tvClose = new TextView(this);
        tvClose.setText("✕");
        tvClose.setTextSize(16);
        tvClose.setTextColor(0xFF6C7885);
        tvClose.setPadding(dp(10), 0, dp(4), 0);
        tvClose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { clearReplyTo(); }
        });
        replyPreviewBar.addView(tvClose);

        // Insert above inputBar
        if (inputBar != null && inputBar.getParent() instanceof LinearLayout) {
            LinearLayout parent = (LinearLayout) inputBar.getParent();
            int idx = parent.indexOfChild(inputBar);
            parent.addView(replyPreviewBar, idx);
        }
    }

    private void showMuteBarSupport() {
        if (inputBar != null) inputBar.setVisibility(View.GONE);
        if (muteBar != null && muteBar.getParent() != null) return; // already shown

        muteBar = new LinearLayout(this);
        muteBar.setOrientation(LinearLayout.VERTICAL);
        muteBar.setGravity(android.view.Gravity.CENTER);
        muteBar.setPadding(dp(16), dp(14), dp(16), dp(14));

        android.graphics.drawable.GradientDrawable muteBg = new android.graphics.drawable.GradientDrawable();
        muteBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        muteBg.setColor(0xFF0A0608);
        muteBg.setStroke(dp(1), 0xFFFF1E4E);
        muteBar.setBackground(muteBg);

        TextView tvIcon = new TextView(this);
        tvIcon.setText("🔇");
        tvIcon.setTextSize(28);
        tvIcon.setGravity(android.view.Gravity.CENTER);
        muteBar.addView(tvIcon);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Вам выдали мут");
        tvTitle.setTextSize(14);
        tvTitle.setTextColor(0xFFFF1E4E);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setGravity(android.view.Gravity.CENTER);
        tvTitle.setPadding(0, dp(4), 0, 0);
        muteBar.addView(tvTitle);

        if (!muteUntilStr.isEmpty()) {
            TextView tvUntil = new TextView(this);
            String dateStr = muteUntilStr.length() >= 10 ? muteUntilStr.substring(0, 10) : muteUntilStr;
            tvUntil.setText("До: " + dateStr);
            tvUntil.setTextSize(12);
            tvUntil.setTextColor(0xFF6C7885);
            tvUntil.setGravity(android.view.Gravity.CENTER);
            tvUntil.setPadding(0, dp(2), 0, 0);
            muteBar.addView(tvUntil);
        }

        if (!muteReasonStr.isEmpty()) {
            TextView tvReason = new TextView(this);
            tvReason.setText("Причина: " + muteReasonStr);
            tvReason.setTextSize(12);
            tvReason.setTextColor(0xFFB8C4D0);
            tvReason.setGravity(android.view.Gravity.CENTER);
            tvReason.setPadding(0, dp(2), 0, 0);
            muteBar.addView(tvReason);
        }

        // Add to root — find the parent LinearLayout of inputBar
        if (inputBar != null && inputBar.getParent() instanceof LinearLayout) {
            LinearLayout parent = (LinearLayout) inputBar.getParent();
            int idx = parent.indexOfChild(inputBar);
            parent.addView(muteBar, idx);
        }
    }

    private void scrollToBottom() {
        scrollView.post(new Runnable() {
            public void run() { scrollView.fullScroll(ScrollView.FOCUS_DOWN); }
        });
    }

    // UTILS
    private String httpPost(String urlStr, String jsonBody) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        OutputStream os = conn.getOutputStream();
        os.write(jsonBody.getBytes("UTF-8"));
        os.close();
        int code = conn.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
            code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        conn.disconnect();
        return sb.toString();
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density);
    }

    private View spacerH(int width) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(width, 1));
        return v;
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            public void run() { Toast.makeText(SupportChatActivity.this, msg, Toast.LENGTH_SHORT).show(); }
        });
    }
}