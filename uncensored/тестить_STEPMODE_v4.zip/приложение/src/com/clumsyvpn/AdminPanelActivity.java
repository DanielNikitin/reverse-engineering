package com.clumsyvpn;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class AdminPanelActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    // Sections
    private static final int SECTION_MAIN      = 0;
    private static final int SECTION_PUNISH     = 1;
    private static final int SECTION_REPORTS    = 2;
    private static final int SECTION_SUPPORT    = 3;
    private static final int SECTION_KEYS       = 4;

    private int currentSection = SECTION_MAIN;

    private LinearLayout contentArea;
    private String serverUrl;
    private String adminLogin;
    private String adminPassword;

    // Stats views
    private TextView tvOnline;
    private TextView tvPeakOnline;
    private TextView tvTotalAccounts;
    private TextView tvAppStatus;

    private Handler refreshHandler = new Handler();
    private Runnable refreshRunnable;

    // Reports badge
    private View tvReportsBadge;  // Red pulsing circle
    private int unseenReportsCount = 0;
    private Handler badgeBlinkHandler = new Handler();
    private Runnable badgeBlinkRunnable;
    // Notification banner
    private android.widget.FrameLayout notifBanner;
    private Handler notifHandler = new Handler();

    // Support section polling
    private Handler supportPollHandler = new Handler();
    private Runnable supportPollRunnable;
    private LinearLayout supportQueueContainer;


    // Ключ для хранения накопленных репортов пока админ не в сети
    private static final String PREFS_ADMIN = "admin_notif_prefs";
    private static final String KEY_PENDING_REPORTS = "pending_reports_count";
    // Флаг: сейчас находимся в панели (для подавления накопления)
    private boolean isInForeground = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        adminLogin   = prefs.getString(AuthActivity.KEY_LOGIN, "");
        adminPassword = prefs.getString(AuthActivity.KEY_PASSWORD, "");
        serverUrl    = AuthActivity.SERVER_URL;

        buildUI();
        showSection(SECTION_MAIN);
        startAutoRefresh();
    }

    private android.content.BroadcastReceiver reportBroadcastRx;
    private boolean reportRxRegistered = false;

    // Support in-app notification receiver
    private android.content.BroadcastReceiver supportBroadcastRx;
    private boolean supportRxRegistered = false;

    @Override
    protected void onResume() {
        super.onResume();
        isInForeground = true;

        // Если до этого был открыт раздел Key System (он открывается как отдельная
        // Activity поверх этой), при возврате назад показываем "Главное меню",
        // а не застрявший текст "Открываем Key System...".
        if (currentSection == SECTION_KEYS) {
            showSection(SECTION_MAIN);
        }

        showPendingReportsIfAny();
        if (!reportRxRegistered) {
            reportBroadcastRx = new android.content.BroadcastReceiver() {
                public void onReceive(android.content.Context ctx, android.content.Intent intent) {
                    int count = intent.getIntExtra(ReportPollerService.EXTRA_COUNT, 0);
                    if (count > 0 && currentSection != SECTION_REPORTS)
                        showReportNotification(count);
                }
            };
            registerReceiver(reportBroadcastRx,
                new android.content.IntentFilter(ReportPollerService.ACTION_NEW_REPORTS));
            reportRxRegistered = true;
        }
        // БАГ 3: Listen for new support messages from users
        if (!supportRxRegistered) {
            supportBroadcastRx = new android.content.BroadcastReceiver() {
                public void onReceive(android.content.Context ctx, android.content.Intent intent) {
                    // Show in-app banner "Вам написали новую проблему"
                    if (currentSection != SECTION_SUPPORT) {
                        showSupportUserNotification();
                    }
                }
            };
            registerReceiver(supportBroadcastRx,
                new android.content.IntentFilter(SupportPollerService.ACTION_NEW_USER_MSG));
            supportRxRegistered = true;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        isInForeground = false;
        if (reportRxRegistered && reportBroadcastRx != null) {
            try { unregisterReceiver(reportBroadcastRx); } catch (Exception ignored) {}
            reportRxRegistered = false;
        }
        if (supportRxRegistered && supportBroadcastRx != null) {
            try { unregisterReceiver(supportBroadcastRx); } catch (Exception ignored) {}
            supportRxRegistered = false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (refreshHandler != null && refreshRunnable != null) {
            refreshHandler.removeCallbacks(refreshRunnable);
        }
        if (badgeBlinkHandler != null && badgeBlinkRunnable != null) {
            badgeBlinkHandler.removeCallbacks(badgeBlinkRunnable);
        }
        if (notifHandler != null) {
            notifHandler.removeCallbacksAndMessages(null);
        }
    }

    // ══════════════════════════════════════════════════
    //  BUILD UI
    // ══════════════════════════════════════════════════
    private void buildUI() {
        // Root horizontal layout: nav drawer + content
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));
        root.setBackgroundColor(0xFF030507);

        // Left nav panel
        LinearLayout nav = buildNavPanel();
        root.addView(nav);

        // Vertical divider
        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(1, MATCH));
        divider.setBackgroundColor(0xFF17202A);
        root.addView(divider);

        // Content area wrapped in FrameLayout for notification overlay
        android.widget.FrameLayout contentFrame = new android.widget.FrameLayout(this);
        contentFrame.setLayoutParams(new LinearLayout.LayoutParams(0, MATCH, 1f));

        contentArea = new LinearLayout(this);
        contentArea.setOrientation(LinearLayout.VERTICAL);
        contentArea.setLayoutParams(new android.widget.FrameLayout.LayoutParams(MATCH, MATCH));
        contentArea.setBackgroundColor(0xFF030507);
        contentFrame.addView(contentArea);

        // Notification banner (hidden by default)
        notifBanner = buildNotifBanner();
        android.widget.FrameLayout.LayoutParams bannerLp = new android.widget.FrameLayout.LayoutParams(MATCH, WRAP);
        bannerLp.gravity = android.view.Gravity.TOP;
        notifBanner.setLayoutParams(bannerLp);
        contentFrame.addView(notifBanner);

        root.addView(contentFrame);

        setContentView(root);
    }

    // ══════════════════════════════════════════════════
    //  NAV PANEL
    // ══════════════════════════════════════════════════
    private LinearLayout buildNavPanel() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(dp(180), MATCH);
        nav.setLayoutParams(nlp);
        nav.setBackgroundColor(0xFF07090C);
        nav.setPadding(0, dp(0), 0, 0);

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(dp(12), dp(28), dp(12), dp(20));

        TextView shield = new TextView(this);
        shield.setText("🛡");
        shield.setTextSize(28);
        shield.setGravity(Gravity.CENTER);
        header.addView(shield);

        TextView adminLabel = new TextView(this);
        adminLabel.setText("ADMIN");
        adminLabel.setTextSize(11);
        adminLabel.setTextColor(0xFFFF1E4E);
        adminLabel.setTypeface(null, Typeface.BOLD);
        adminLabel.setLetterSpacing(0.3f);
        adminLabel.setGravity(Gravity.CENTER);
        header.addView(adminLabel);

        TextView panelLabel = new TextView(this);
        panelLabel.setText("ПАНЕЛЬ");
        panelLabel.setTextSize(10);
        panelLabel.setTextColor(0xFF6C7885);
        panelLabel.setGravity(Gravity.CENTER);
        header.addView(panelLabel);

        nav.addView(header);

        // Separator
        View sep = new View(this);
        sep.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        sep.setBackgroundColor(0xFF17202A);
        nav.addView(sep);

        // Nav items
        nav.addView(buildNavItem("⊞  Главное меню", SECTION_MAIN));
        nav.addView(buildNavItem("⊘  Блокировка / мут", SECTION_PUNISH));
        // Reports nav item with badge dot
        LinearLayout reportsNavRow = new LinearLayout(this);
        reportsNavRow.setOrientation(LinearLayout.HORIZONTAL);
        reportsNavRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        reportsNavRow.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        TextView reportsNavItem = buildNavItem("📋  Репорты", SECTION_REPORTS);
        reportsNavItem.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        reportsNavRow.addView(reportsNavItem);
        tvReportsBadge = new View(this);
        int badgeSize = dp(10);
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(badgeSize, badgeSize);
        badgeLp.rightMargin = dp(12);
        badgeLp.gravity = android.view.Gravity.CENTER_VERTICAL;
        tvReportsBadge.setLayoutParams(badgeLp);
        android.graphics.drawable.GradientDrawable badgeCircle = new android.graphics.drawable.GradientDrawable();
        badgeCircle.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        badgeCircle.setColor(0xFFFF1E4E);
        tvReportsBadge.setBackground(badgeCircle);
        tvReportsBadge.setVisibility(android.view.View.GONE);
        reportsNavRow.addView(tvReportsBadge);
        nav.addView(reportsNavRow);

        // Support nav item
        nav.addView(buildNavItem("🎧  Онлайн помощь", SECTION_SUPPORT));
        nav.addView(buildNavItem("🔑  Key System", SECTION_KEYS));

        // Bottom back button
        LinearLayout spacer = new LinearLayout(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));
        nav.addView(spacer);

        View sep2 = new View(this);
        sep2.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        sep2.setBackgroundColor(0xFF17202A);
        nav.addView(sep2);

        TextView btnBack = new TextView(this);
        btnBack.setText("‹  Назад");
        btnBack.setTextSize(13);
        btnBack.setTextColor(0xFF00FF9D);
        btnBack.setTypeface(null, Typeface.BOLD);
        btnBack.setPadding(dp(16), dp(18), dp(16), dp(18));
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        nav.addView(btnBack);

        return nav;
    }

    private TextView buildNavItem(String label, final int section) {
        TextView item = new TextView(this);
        item.setText(label);
        item.setTextSize(13);
        item.setTextColor(section == currentSection ? 0xFFFF1E4E : 0xFFB8C4D0);
        item.setTypeface(null, section == currentSection ? Typeface.BOLD : Typeface.NORMAL);
        item.setPadding(dp(16), dp(15), dp(16), dp(15));
        if (section == currentSection) {
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0x20FF1E4E);
            item.setBackground(bg);
        }
        item.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showSection(section); }
        });
        return item;
    }

    // ══════════════════════════════════════════════════
    //  SECTION SWITCHER
    // ══════════════════════════════════════════════════
    private void showSection(int section) {
        // Stop support polling when leaving support section
        if (supportPollRunnable != null && section != SECTION_SUPPORT) {
            supportPollHandler.removeCallbacks(supportPollRunnable);
            supportPollRunnable = null;
            supportQueueContainer = null;
        }
        currentSection = section;
        contentArea.removeAllViews();

        // Header
        String sectionTitle;
        if (section == SECTION_MAIN) sectionTitle = "Главное меню";
        else if (section == SECTION_PUNISH) sectionTitle = "Блокировка / мут";
        else if (section == SECTION_SUPPORT) sectionTitle = "Онлайн помощь";
        else if (section == SECTION_KEYS) sectionTitle = "Key System";
        else sectionTitle = "Репорты";
        contentArea.addView(buildSectionHeader(sectionTitle));

        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        divider.setBackgroundColor(0xFF17202A);
        contentArea.addView(divider);

        // Content
        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));
        scroll.setFillViewport(true);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        inner.setPadding(dp(16), dp(16), dp(16), dp(16));

        if (section == SECTION_MAIN) {
            buildMainSection(inner);
        } else if (section == SECTION_PUNISH) {
            buildPunishSection(inner);
        } else if (section == SECTION_SUPPORT) {
            buildSupportSection(inner);
        } else if (section == SECTION_REPORTS) {
            buildReportsSection(inner);
            markReportsSeen();
        } else if (section == SECTION_KEYS) {
            startActivity(new android.content.Intent(this, KeySystemActivity.class));
            // Show placeholder text in the section
            TextView tv = new TextView(this);
            tv.setText("Открываем Key System...");
            tv.setTextSize(14);
            tv.setTextColor(0xFF6C7885);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(dp(16), dp(32), dp(16), dp(32));
            inner.addView(tv);
        }

        scroll.addView(inner);
        contentArea.addView(scroll);
    }

    private LinearLayout buildSectionHeader(String title) {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextSize(16);
        tv.setTextColor(0xFFFFFFFF);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setLetterSpacing(0.1f);
        h.addView(tv);

        return h;
    }

    // ══════════════════════════════════════════════════
    //  MAIN SECTION
    // ══════════════════════════════════════════════════
    private void buildMainSection(LinearLayout container) {
        // Stats card
        LinearLayout statsCard = buildCard();
        statsCard.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView statsTitle = new TextView(this);
        statsTitle.setText("📊  СТАТИСТИКА");
        statsTitle.setTextSize(12);
        statsTitle.setTextColor(0xFF6C7885);
        statsTitle.setTypeface(null, Typeface.BOLD);
        statsTitle.setLetterSpacing(0.2f);
        statsCard.addView(statsTitle);

        statsCard.addView(spacerV(dp(12)));

        tvOnline = buildStatRow(statsCard, "🟢  Онлайн сейчас", "—");
        statsCard.addView(spacerV(dp(8)));
        tvPeakOnline = buildStatRow(statsCard, "🏆  Пик онлайна", "—");
        statsCard.addView(spacerV(dp(8)));
        tvTotalAccounts = buildStatRow(statsCard, "👥  Всего аккаунтов", "—");

        container.addView(statsCard);
        container.addView(spacerV(dp(12)));

        // App status card
        LinearLayout statusCard = buildCard();
        statusCard.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView statusTitle = new TextView(this);
        statusTitle.setText("⚙️  СТАТУС ПРИЛОЖЕНИЯ");
        statusTitle.setTextSize(12);
        statusTitle.setTextColor(0xFF6C7885);
        statusTitle.setTypeface(null, Typeface.BOLD);
        statusTitle.setLetterSpacing(0.2f);
        statusCard.addView(statusTitle);

        statusCard.addView(spacerV(dp(10)));

        tvAppStatus = new TextView(this);
        tvAppStatus.setText("● Загрузка...");
        tvAppStatus.setTextSize(14);
        tvAppStatus.setTextColor(0xFF6C7885);
        tvAppStatus.setTypeface(null, Typeface.BOLD);
        statusCard.addView(tvAppStatus);

        container.addView(statusCard);
        container.addView(spacerV(dp(20)));

        // Disable button
        final TextView btnDisable = new TextView(this);
        btnDisable.setText("⛔  ОТКЛЮЧИТЬ ПРИЛОЖЕНИЕ");
        btnDisable.setTextSize(14);
        btnDisable.setTextColor(0xFFFFFFFF);
        btnDisable.setTypeface(null, Typeface.BOLD);
        btnDisable.setGravity(Gravity.CENTER);
        btnDisable.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setShape(GradientDrawable.RECTANGLE);
        btnBg.setCornerRadius(dp(12));
        btnBg.setColor(0xFFFF1E4E);
        btnBg.setStroke(1, 0xFFFF668A);
        btnDisable.setBackground(btnBg);
        btnDisable.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                animateButtonPress(btnDisable, new Runnable() {
                    public void run() { showDisableConfirm(); }
                });
            }
        });
        container.addView(btnDisable);

        // Enable button
        container.addView(spacerV(dp(10)));
        final TextView btnEnable = new TextView(this);
        btnEnable.setText("✓  ВКЛЮЧИТЬ ПРИЛОЖЕНИЕ");
        btnEnable.setTextSize(14);
        btnEnable.setTextColor(0xFF00FF9D);
        btnEnable.setTypeface(null, Typeface.BOLD);
        btnEnable.setGravity(Gravity.CENTER);
        btnEnable.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable btnEnBg = new GradientDrawable();
        btnEnBg.setShape(GradientDrawable.RECTANGLE);
        btnEnBg.setCornerRadius(dp(12));
        btnEnBg.setColor(0xFF0C1014);
        btnEnBg.setStroke(1, 0xFF00FF9D);
        btnEnable.setBackground(btnEnBg);
        btnEnable.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                animateButtonPress(btnEnable, new Runnable() {
                    public void run() { setAppDisabled(false); }
                });
            }
        });
        container.addView(btnEnable);

        loadStats();
    }

    private TextView buildStatRow(LinearLayout parent, String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(13);
        tvLabel.setTextColor(0xFFB8C4D0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        tvLabel.setLayoutParams(lp);
        row.addView(tvLabel);

        TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(14);
        tvValue.setTextColor(0xFF00FF9D);
        tvValue.setTypeface(null, Typeface.BOLD);
        tvValue.setGravity(Gravity.END);
        row.addView(tvValue);

        parent.addView(row);
        return tvValue;
    }

    private void loadStats() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = buildAdminBody();
                    String resp = httpPost(serverUrl + "/admin/stats", body);
                    if (resp == null) return;
                    final JSONObject j = new JSONObject(resp);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                if (tvOnline != null) tvOnline.setText(String.valueOf(j.optInt("online", 0)));
                                if (tvPeakOnline != null) tvPeakOnline.setText(String.valueOf(j.optInt("peakOnline", 0)));
                                if (tvTotalAccounts != null) tvTotalAccounts.setText(String.valueOf(j.optInt("totalAccounts", 0)));
                                boolean disabled = j.optBoolean("appDisabled", false);
                                if (tvAppStatus != null) {
                                    if (disabled) {
                                        tvAppStatus.setText("● Приложение ОТКЛЮЧЕНО");
                                        tvAppStatus.setTextColor(0xFFFF1E4E);
                                    } else {
                                        tvAppStatus.setText("● Приложение работает");
                                        tvAppStatus.setTextColor(0xFF00FF9D);
                                    }
                                }
                            } catch (Exception e) {}
                        }
                    });
                } catch (Exception e) {}
            }
        }).start();
    }

    private void startAutoRefresh() {
        refreshRunnable = new Runnable() {
            public void run() {
                if (currentSection == SECTION_MAIN) loadStats();
                checkUnseenReports();
                refreshHandler.postDelayed(this, 8000);
            }
        };
        refreshHandler.postDelayed(refreshRunnable, 3000);
        // Start badge blink animation
        startBadgeBlink();
    }

    private void startBadgeBlink() {
        if (unseenReportsCount > 0) showBadge();
    }

    private void showBadge() {
        if (tvReportsBadge == null) return;
        tvReportsBadge.setVisibility(android.view.View.VISIBLE);
        try {
            android.view.animation.Animation pulse =
                android.view.animation.AnimationUtils.loadAnimation(this, R.anim.pulse_report_badge);
            tvReportsBadge.startAnimation(pulse);
        } catch (Exception ignored) {}
    }

    private void hideBadge() {
        if (tvReportsBadge == null) return;
        tvReportsBadge.clearAnimation();
        tvReportsBadge.setVisibility(android.view.View.GONE);
    }

    private void checkUnseenReports() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = buildAdminBody();
                    String resp = httpPost(serverUrl + "/admin/reports/unseen-count", body);
                    if (resp == null) return;
                    final org.json.JSONObject j = new org.json.JSONObject(resp);
                    final int count = j.optInt("count", 0);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            int prev = unseenReportsCount;
                            unseenReportsCount = count;
                            if (count > 0) {
                                showBadge();
                                if (count > prev) {
                                    // Новые репорты пришли
                                    int newArrived = count - prev;
                                    if (isInForeground) {
                                        // Админ в приложении — показываем баннер сразу
                                        showReportNotification(count);
                                    } else {
                                        // Не в сети — копим в SharedPreferences
                                        accumulatePendingReports(newArrived);
                                    }
                                }
                            } else {
                                hideBadge();
                            }
                        }
                    });
                } catch (Exception e) {}
            }
        }).start();
    }

    /** Накапливает кол-во новых репортов пока админ не в сети */
    private void accumulatePendingReports(int newCount) {
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS_ADMIN, MODE_PRIVATE);
        int existing = prefs.getInt(KEY_PENDING_REPORTS, 0);
        prefs.edit().putInt(KEY_PENDING_REPORTS, existing + newCount).apply();
    }

    /** При входе в панель показывает накопленные уведомления и сбрасывает счётчик */
    private void showPendingReportsIfAny() {
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS_ADMIN, MODE_PRIVATE);
        int pending = prefs.getInt(KEY_PENDING_REPORTS, 0);
        if (pending > 0) {
            prefs.edit().putInt(KEY_PENDING_REPORTS, 0).apply();
            showReportNotification(pending);
        }
    }

    private void markReportsSeen() {
        unseenReportsCount = 0;
        hideBadge();
        getSharedPreferences(PREFS_ADMIN, MODE_PRIVATE).edit()
            .putInt(KEY_PENDING_REPORTS, 0)
            .putInt(ReportPollerService.KEY_LAST_SEEN_COUNT, 0)
            .putInt(ReportBannerHelper.KEY_DISMISSED_COUNT, 0)
            .apply();
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = buildAdminBody();
                    httpPost(serverUrl + "/admin/reports/mark-seen", body);
                } catch (Exception ignored) {}
            }
        }).start();
    }

    private android.widget.FrameLayout buildNotifBanner() {
        android.widget.FrameLayout frame = new android.widget.FrameLayout(this);
        frame.setVisibility(android.view.View.GONE);
        frame.setAlpha(0f);
        return frame;
    }

    private void showReportNotification(final int count) {
        if (notifBanner == null) return;
        notifBanner.removeAllViews();
        notifBanner.setVisibility(android.view.View.VISIBLE);
        notifBanner.setAlpha(0f);
        notifBanner.setTranslationY(-dp(60));

        LinearLayout banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.HORIZONTAL);
        banner.setGravity(android.view.Gravity.CENTER_VERTICAL);
        banner.setPadding(dp(14), dp(12), dp(10), dp(12));
        GradientDrawable bannerBg = new GradientDrawable();
        bannerBg.setShape(GradientDrawable.RECTANGLE);
        bannerBg.setColor(0xFF1A0810);
        bannerBg.setStroke(1, 0xFFFF1E4E);
        bannerBg.setCornerRadius(dp(10));
        banner.setBackground(bannerBg);

        TextView tvNotif = new TextView(this);
        tvNotif.setText("🔔  " + count + " " + pluralReports(count));
        tvNotif.setTextSize(13);
        tvNotif.setTextColor(0xFFFF668A);
        tvNotif.setTypeface(null, android.graphics.Typeface.BOLD);
        tvNotif.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        banner.addView(tvNotif);

        // Кнопка "Смотреть" — переход в раздел репортов
        TextView tvView = new TextView(this);
        tvView.setText("Смотреть");
        tvView.setTextSize(12);
        tvView.setTextColor(0xFFFFFFFF);
        tvView.setTypeface(null, android.graphics.Typeface.BOLD);
        tvView.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable viewBg = new GradientDrawable();
        viewBg.setShape(GradientDrawable.RECTANGLE);
        viewBg.setCornerRadius(dp(6));
        viewBg.setColor(0xFFFF1E4E);
        tvView.setBackground(viewBg);
        tvView.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) {
                hideNotifBanner();
                showSection(SECTION_REPORTS);
            }
        });
        banner.addView(tvView);

        TextView tvClose = new TextView(this);
        tvClose.setText(" ✕");
        tvClose.setTextSize(14);
        tvClose.setTextColor(0xFF6C7885);
        tvClose.setPadding(dp(8), 0, dp(4), 0);
        tvClose.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) { hideNotifBanner(); }
        });
        banner.addView(tvClose);

        android.widget.FrameLayout.LayoutParams blp = new android.widget.FrameLayout.LayoutParams(MATCH, WRAP);
        blp.setMargins(dp(12), dp(8), dp(12), 0);
        banner.setLayoutParams(blp);
        notifBanner.addView(banner);

        // Анимация появления сверху
        notifBanner.animate().alpha(1f).translationY(0).setDuration(300).start();

        // Автоскрытие через 6 сек
        notifHandler.removeCallbacksAndMessages(null);
        notifHandler.postDelayed(new Runnable() {
            public void run() { hideNotifBanner(); }
        }, 6000);
    }

    private void showSupportUserNotification() {
        if (notifBanner == null) return;
        notifBanner.removeAllViews();
        notifBanner.setVisibility(android.view.View.VISIBLE);
        notifBanner.setAlpha(0f);
        notifBanner.setTranslationY(-dp(60));

        LinearLayout banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.HORIZONTAL);
        banner.setGravity(android.view.Gravity.CENTER_VERTICAL);
        banner.setPadding(dp(14), dp(12), dp(10), dp(12));
        GradientDrawable bannerBg = new GradientDrawable();
        bannerBg.setShape(GradientDrawable.RECTANGLE);
        bannerBg.setColor(0xFF061630);
        bannerBg.setStroke(1, 0xFF00E5FF);
        bannerBg.setCornerRadius(dp(10));
        banner.setBackground(bannerBg);

        TextView tvNotif = new TextView(this);
        tvNotif.setText("💬  Вам написали новую проблему");
        tvNotif.setTextSize(13);
        tvNotif.setTextColor(0xFF00E5FF);
        tvNotif.setTypeface(null, android.graphics.Typeface.BOLD);
        tvNotif.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        banner.addView(tvNotif);

        TextView tvOpen = new TextView(this);
        tvOpen.setText("Открыть");
        tvOpen.setTextSize(12);
        tvOpen.setTextColor(0xFF030507);
        tvOpen.setTypeface(null, android.graphics.Typeface.BOLD);
        tvOpen.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable openBg = new GradientDrawable();
        openBg.setShape(GradientDrawable.RECTANGLE);
        openBg.setCornerRadius(dp(6));
        openBg.setColor(0xFF00E5FF);
        tvOpen.setBackground(openBg);
        tvOpen.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) {
                hideNotifBanner();
                showSection(SECTION_SUPPORT);
            }
        });
        banner.addView(tvOpen);

        TextView tvClose = new TextView(this);
        tvClose.setText(" ✕");
        tvClose.setTextSize(14);
        tvClose.setTextColor(0xFF6C7885);
        tvClose.setPadding(dp(8), 0, dp(4), 0);
        tvClose.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) { hideNotifBanner(); }
        });
        banner.addView(tvClose);

        android.widget.FrameLayout.LayoutParams blp = new android.widget.FrameLayout.LayoutParams(MATCH, WRAP);
        blp.setMargins(dp(12), dp(8), dp(12), 0);
        banner.setLayoutParams(blp);
        notifBanner.addView(banner);

        notifBanner.animate().alpha(1f).translationY(0).setDuration(300).start();

        notifHandler.removeCallbacksAndMessages(null);
        notifHandler.postDelayed(new Runnable() {
            public void run() { hideNotifBanner(); }
        }, 6000);
    }


    private void hideNotifBanner() {
        if (notifBanner == null) return;
        notifBanner.animate().alpha(0f).setDuration(250)
            .withEndAction(new Runnable() {
                public void run() { notifBanner.setVisibility(android.view.View.GONE); }
            }).start();
    }

    private String pluralReports(int n) {
        if (n % 10 == 1 && n % 100 != 11) return "новый репорт";
        if (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20)) return "новых репорта";
        return "новых репортов";
    }

    private void showDisableConfirm() {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(16));
        bg.setColor(0xFF0C1014);
        bg.setStroke(1, 0xFFFF1E4E);
        root.setBackground(bg);

        TextView title = new TextView(this);
        title.setText("⚠️ Подтверждение");
        title.setTextSize(16);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        root.addView(spacerV(dp(12)));

        TextView msg = new TextView(this);
        msg.setText("Все пользователи увидят экран блокировки приложения. Продолжить?");
        msg.setTextSize(13);
        msg.setTextColor(0xFFB8C4D0);
        msg.setGravity(Gravity.CENTER);
        root.addView(msg);

        root.addView(spacerV(dp(20)));

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.CENTER);

        TextView btnCancel = buildDialogBtn("Отмена", 0xFF17202A, 0xFFB8C4D0);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        blp.rightMargin = dp(8);
        btnCancel.setLayoutParams(blp);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        btns.addView(btnCancel);

        TextView btnConfirm = buildDialogBtn("Подтвердить", 0xFFFF1E4E, 0xFFFFFFFF);
        LinearLayout.LayoutParams blp2 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        btnConfirm.setLayoutParams(blp2);
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                setAppDisabled(true);
            }
        });
        btns.addView(btnConfirm);

        root.addView(btns);
        d.setContentView(root);

        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.85), WRAP);
        d.show();
    }

    private void setAppDisabled(final boolean disabled) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"adminLogin\":\"" + adminLogin + "\",\"adminPassword\":\"" + esc(adminPassword) + "\",\"disabled\":" + disabled + "}";
                    String resp = httpPost(serverUrl + "/admin/disable-app", body);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            toast(disabled ? "Приложение отключено" : "Приложение включено");
                            loadStats();
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Ошибка соединения"); } });
                }
            }
        }).start();
    }

    // ══════════════════════════════════════════════════
    //  PUNISH SECTION
    // ══════════════════════════════════════════════════
    private void buildPunishSection(LinearLayout container) {
        String[][] items = {
            {"⊘  Бан аккаунта",    "ban"},
            {"🔇  Мут пользователя", "mute"},
            {"✓  Снять мут",        "unmute"},
            {"✓  Снять бан",        "unban"},
        };

        TextView sectionNote = new TextView(this);
        sectionNote.setText("Управление пользователями");
        sectionNote.setTextSize(12);
        sectionNote.setTextColor(0xFF6C7885);
        sectionNote.setPadding(0, 0, 0, dp(16));
        container.addView(sectionNote);

        for (final String[] item : items) {
            LinearLayout card = buildCard();
            card.setPadding(dp(16), dp(16), dp(16), dp(16));
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);

            TextView tvLabel = new TextView(this);
            tvLabel.setText(item[0]);
            tvLabel.setTextSize(14);
            tvLabel.setTextColor(0xFFFFFFFF);
            tvLabel.setTypeface(null, Typeface.BOLD);
            tvLabel.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
            card.addView(tvLabel);

            TextView tvArrow = new TextView(this);
            tvArrow.setText("›");
            tvArrow.setTextSize(22);
            tvArrow.setTextColor(item[1].startsWith("un") ? 0xFF00FF9D : 0xFFFF1E4E);
            card.addView(tvArrow);

            card.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String action = item[1];
                    if (action.equals("ban"))    showBanDialog();
                    else if (action.equals("mute"))   showMuteDialog();
                    else if (action.equals("unban"))  showUnbanDialog();
                    else if (action.equals("unmute")) showUnmuteDialog();
                }
            });

            container.addView(card);
            container.addView(spacerV(dp(10)));
        }
    }

    // ══════════════════════════════════════════════════
    //  BAN DIALOG
    // ══════════════════════════════════════════════════
    private void showBanDialog() {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = buildDialogRoot(0xFFFF1E4E);

        TextView title = buildDialogTitle("⊘  Бан аккаунта");
        root.addView(title);
        root.addView(spacerV(dp(16)));

        final android.widget.EditText etLogin = buildInput("Логин пользователя");
        root.addView(etLogin);
        root.addView(spacerV(dp(10)));

        final android.widget.EditText etId = buildInput("ID пользователя (обязательно)");
        root.addView(etId);
        root.addView(spacerV(dp(20)));

        LinearLayout btns = buildDialogButtons(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        }, new View.OnClickListener() {
            public void onClick(View v) {
                String login = etLogin.getText().toString().trim();
                String id    = etId.getText().toString().trim();
                if (login.isEmpty()) { toast("Введите логин"); return; }
                if (id.isEmpty()) { toast("Введите ID пользователя"); return; }
                verifyAndProceedBan(d, login, id);
            }
        });
        root.addView(btns);

        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.88), WRAP);
        d.show();
    }

    private void verifyAndProceedBan(final android.app.Dialog parentDialog, final String login, final String enteredId) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String response = httpGet(serverUrl + "/user/" + login);
                    if (response == null) { runOnUiThread(new Runnable() { public void run() { toast("Ошибка соединения"); } }); return; }
                    final org.json.JSONObject obj = new org.json.JSONObject(response);
                    if (obj.optBoolean("deleted", false)) { runOnUiThread(new Runnable() { public void run() { toast("Аккаунт не найден"); } }); return; }
                    final String realId = obj.optString("user_id", "");
                    // Normalize: strip # prefix for comparison
                    String normalEntered = enteredId.startsWith("#") ? enteredId.substring(1) : enteredId;
                    String normalReal    = realId.startsWith("#") ? realId.substring(1) : realId;
                    if (!normalEntered.equals(normalReal)) {
                        runOnUiThread(new Runnable() { public void run() { toast("Неверный ID. Реальный ID: " + realId); } });
                        return;
                    }
                    runOnUiThread(new Runnable() { public void run() {
                        parentDialog.dismiss();
                        showBanDurationDialog(login);
                    }});
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Ошибка проверки ID"); } });
                }
            }
        }).start();
    }

    private void showBanDurationDialog(final String targetLogin) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = buildDialogRoot(0xFFFF1E4E);

        TextView title = buildDialogTitle("Срок бана: " + targetLogin);
        root.addView(title);
        root.addView(spacerV(dp(12)));

        // Duration options
        final int[] selectedDays = {1};
        final String[] selectedLabel = {"1 день"};

        ScrollView daysScroll = new ScrollView(this);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(MATCH, dp(160));
        daysScroll.setLayoutParams(slp);

        LinearLayout daysContainer = new LinearLayout(this);
        daysContainer.setOrientation(LinearLayout.VERTICAL);

        String[] labels = {"1 день","2 дня","3 дня","4 дня","5 дней","6 дней","7 дней","8 дней","9 дней","10 дней","Навсегда"};
        int[] daysVal  = {1,2,3,4,5,6,7,8,9,10,-1};

        final TextView[] optionViews = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            final int days = daysVal[i];
            final String lbl = labels[i];

            final TextView opt = new TextView(this);
            opt.setText(idx == 0 ? "● " + lbl : lbl);
            opt.setTextSize(13);
            opt.setTextColor(idx == 0 ? 0xFFFF1E4E : 0xFFB8C4D0);
            opt.setTypeface(null, idx == 0 ? Typeface.BOLD : Typeface.NORMAL);
            opt.setPadding(dp(12), dp(10), dp(12), dp(10));

            opt.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    for (TextView t : optionViews) {
                        if (t == null) continue;
                        String txt = t.getText().toString().replace("● ", "");
                        t.setText(txt);
                        t.setTextColor(0xFFB8C4D0);
                        t.setTypeface(null, Typeface.NORMAL);
                    }
                    opt.setText("● " + lbl);
                    opt.setTextColor(0xFFFF1E4E);
                    opt.setTypeface(null, Typeface.BOLD);
                    selectedDays[0] = days;
                    selectedLabel[0] = lbl;
                }
            });
            optionViews[i] = opt;
            daysContainer.addView(opt);
        }

        daysScroll.addView(daysContainer);
        root.addView(daysScroll);
        root.addView(spacerV(dp(12)));

        // Reason
        final android.widget.EditText etReason = buildInput("Причина бана (макс. 30 симв.)");
        etReason.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(30)});
        root.addView(etReason);
        root.addView(spacerV(dp(16)));

        LinearLayout btns = buildDialogButtons(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                showBanDialog();
            }
        }, new View.OnClickListener() {
            public void onClick(View v) {
                String reason = etReason.getText().toString().trim();
                int days = selectedDays[0];
                d.dismiss();
                applyBan(targetLogin, days, reason);
            }
        });
        root.addView(btns);

        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.88), WRAP);
        d.show();
    }

    private void applyBan(final String targetLogin, final int days, final String reason) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String daysStr = days == -1 ? "permanent" : String.valueOf(days);
                    String body = "{\"adminLogin\":\"" + adminLogin + "\",\"adminPassword\":\"" + esc(adminPassword) +
                        "\",\"targetLogin\":\"" + esc(targetLogin) + "\",\"days\":\"" + daysStr +
                        "\",\"reason\":\"" + esc(reason) + "\"}";
                    String resp = httpPost(serverUrl + "/admin/ban", body);
                    runOnUiThread(new Runnable() {
                        public void run() { toast("Бан применён: " + targetLogin); }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Ошибка"); } });
                }
            }
        }).start();
    }

    // ══════════════════════════════════════════════════
    //  MUTE DIALOG
    // ══════════════════════════════════════════════════
    private void showMuteDialog() {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = buildDialogRoot(0xFF1A6BFF);

        TextView title = buildDialogTitle("🔇  Мут пользователя");
        root.addView(title);
        root.addView(spacerV(dp(16)));

        final android.widget.EditText etLogin = buildInput("Логин пользователя");
        root.addView(etLogin);
        root.addView(spacerV(dp(10)));

        final android.widget.EditText etId = buildInput("ID пользователя (обязательно)");
        root.addView(etId);
        root.addView(spacerV(dp(20)));

        LinearLayout btns = buildDialogButtons(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        }, new View.OnClickListener() {
            public void onClick(View v) {
                String login = etLogin.getText().toString().trim();
                String id    = etId.getText().toString().trim();
                if (login.isEmpty()) { toast("Введите логин"); return; }
                if (id.isEmpty()) { toast("Введите ID пользователя"); return; }
                verifyAndProceedMute(d, login, id);
            }
        });
        root.addView(btns);

        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.88), WRAP);
        d.show();
    }

    private void verifyAndProceedMute(final android.app.Dialog parentDialog, final String login, final String enteredId) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String response = httpGet(serverUrl + "/user/" + login);
                    if (response == null) { runOnUiThread(new Runnable() { public void run() { toast("Ошибка соединения"); } }); return; }
                    final org.json.JSONObject obj = new org.json.JSONObject(response);
                    if (obj.optBoolean("deleted", false)) { runOnUiThread(new Runnable() { public void run() { toast("Аккаунт не найден"); } }); return; }
                    final String realId = obj.optString("user_id", "");
                    String normalEntered = enteredId.startsWith("#") ? enteredId.substring(1) : enteredId;
                    String normalReal    = realId.startsWith("#") ? realId.substring(1) : realId;
                    if (!normalEntered.equals(normalReal)) {
                        runOnUiThread(new Runnable() { public void run() { toast("Неверный ID. Реальный ID: " + realId); } });
                        return;
                    }
                    runOnUiThread(new Runnable() { public void run() {
                        parentDialog.dismiss();
                        showMuteParamsDialog(login);
                    }});
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Ошибка проверки ID"); } });
                }
            }
        }).start();
    }

    private void showMuteParamsDialog(final String targetLogin) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = buildDialogRoot(0xFF1A6BFF);

        TextView title = buildDialogTitle("Мут: " + targetLogin);
        root.addView(title);
        root.addView(spacerV(dp(16)));

        final android.widget.EditText etHours = buildInput("Время мута в часах (макс. 125)");
        etHours.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        root.addView(etHours);
        root.addView(spacerV(dp(10)));

        final android.widget.EditText etReason = buildInput("Причина мута (макс. 30 симв.)");
        etReason.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(30)});
        root.addView(etReason);
        root.addView(spacerV(dp(16)));

        LinearLayout btns = buildDialogButtons(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                showMuteDialog();
            }
        }, new View.OnClickListener() {
            public void onClick(View v) {
                String hoursStr = etHours.getText().toString().trim();
                if (hoursStr.isEmpty()) { toast("Введите время"); return; }
                int hours = Math.min(Integer.parseInt(hoursStr), 125);
                String reason = etReason.getText().toString().trim();
                d.dismiss();
                applyMute(targetLogin, hours, reason);
            }
        });
        root.addView(btns);

        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.88), WRAP);
        d.show();
    }

    private void applyMute(final String targetLogin, final int hours, final String reason) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"adminLogin\":\"" + adminLogin + "\",\"adminPassword\":\"" + esc(adminPassword) +
                        "\",\"targetLogin\":\"" + esc(targetLogin) + "\",\"hours\":" + hours +
                        ",\"reason\":\"" + esc(reason) + "\"}";
                    httpPost(serverUrl + "/admin/mute", body);
                    runOnUiThread(new Runnable() {
                        public void run() { toast("Мут применён: " + targetLogin); }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Ошибка"); } });
                }
            }
        }).start();
    }

    // ══════════════════════════════════════════════════
    //  UNBAN / UNMUTE DIALOGS
    // ══════════════════════════════════════════════════
    private void showUnbanDialog() {
        showUserListDialog("unban", "Снять бан");
    }

    private void showUnmuteDialog() {
        showUserListDialog("unmute", "Снять мут");
    }

    private void showUserListDialog(final String action, final String title) {
        // Load list first
        new Thread(new Runnable() {
            public void run() {
                try {
                    String endpoint = action.equals("unban") ? "/admin/banned-list" : "/admin/muted-list";
                    String body = buildAdminBody();
                    String resp = httpPost(serverUrl + endpoint, body);
                    if (resp == null) { runOnUiThread(new Runnable() { public void run() { toast("Ошибка загрузки"); } }); return; }
                    final JSONObject j = new JSONObject(resp);
                    final org.json.JSONArray users = j.optJSONArray("users");
                    runOnUiThread(new Runnable() {
                        public void run() {
                            if (users == null || users.length() == 0) {
                                toast("Список пуст");
                                return;
                            }
                            showUserPickDialog(action, title, users);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Ошибка"); } });
                }
            }
        }).start();
    }

    private void showUserPickDialog(final String action, final String title, final org.json.JSONArray users) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = buildDialogRoot(0xFF00FF9D);

        TextView tvTitle = buildDialogTitle(title);
        root.addView(tvTitle);
        root.addView(spacerV(dp(12)));

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(200)));

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);

        final String[] selectedLogin = {null};
        final String[] selectedId    = {null};
        final String[] selectedCreated = {null};
        final String[] selectedReason  = {null};
        final View[] selectedView = {null};

        for (int i = 0; i < users.length(); i++) {
            try {
                final JSONObject u = users.getJSONObject(i);
                final String uLogin = u.optString("login");
                final String uId    = u.optString("user_id");
                final String uCreated = u.optString("created_at");
                JSONObject punishment = action.equals("unban") ? u.optJSONObject("ban") : u.optJSONObject("mute");
                final String uReason = punishment != null ? punishment.optString("reason", "") : "";

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(12), dp(10), dp(12), dp(10));

                GradientDrawable rowBg = new GradientDrawable();
                rowBg.setShape(GradientDrawable.RECTANGLE);
                rowBg.setCornerRadius(dp(8));
                rowBg.setColor(0xFF0C1014);
                row.setBackground(rowBg);

                TextView tvLogin = new TextView(this);
                tvLogin.setText(uLogin);
                tvLogin.setTextSize(13);
                tvLogin.setTextColor(0xFFFFFFFF);
                tvLogin.setTypeface(null, Typeface.BOLD);
                row.addView(tvLogin);

                TextView tvId = new TextView(this);
                tvId.setText(uId);
                tvId.setTextSize(11);
                tvId.setTextColor(0xFF6C7885);
                row.addView(tvId);

                final LinearLayout finalRow = row;
                row.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        if (selectedView[0] != null) {
                            GradientDrawable bg2 = new GradientDrawable();
                            bg2.setShape(GradientDrawable.RECTANGLE);
                            bg2.setCornerRadius(dp(8));
                            bg2.setColor(0xFF0C1014);
                            selectedView[0].setBackground(bg2);
                        }
                        selectedLogin[0] = uLogin;
                        selectedId[0]    = uId;
                        selectedCreated[0] = uCreated;
                        selectedReason[0]  = uReason;
                        selectedView[0] = finalRow;
                        GradientDrawable sel = new GradientDrawable();
                        sel.setShape(GradientDrawable.RECTANGLE);
                        sel.setCornerRadius(dp(8));
                        sel.setColor(0x2000FF9D);
                        sel.setStroke(1, 0xFF00FF9D);
                        finalRow.setBackground(sel);
                    }
                });

                list.addView(row);
                if (i < users.length() - 1) list.addView(spacerV(dp(6)));
            } catch (Exception ignored) {}
        }

        scroll.addView(list);
        root.addView(scroll);
        root.addView(spacerV(dp(16)));

        LinearLayout btns = buildDialogButtons(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        }, new View.OnClickListener() {
            public void onClick(View v) {
                if (selectedLogin[0] == null) { toast("Выберите пользователя"); return; }
                d.dismiss();
                showUserInfoDialog(action, selectedLogin[0], selectedId[0], selectedCreated[0], selectedReason[0]);
            }
        });
        root.addView(btns);

        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.88), WRAP);
        d.show();
    }

    private void showUserInfoDialog(final String action, final String targetLogin, final String userId,
                                    final String createdAt, final String reason) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = buildDialogRoot(0xFF00FF9D);

        TextView tvTitle = buildDialogTitle(action.equals("unban") ? "Снять бан" : "Снять мут");
        root.addView(tvTitle);
        root.addView(spacerV(dp(16)));

        root.addView(buildInfoRow("Логин:", targetLogin));
        root.addView(spacerV(dp(6)));
        root.addView(buildInfoRow("ID:", userId));
        root.addView(spacerV(dp(6)));
        root.addView(buildInfoRow("Зарегистрирован:", formatDate(createdAt)));
        root.addView(spacerV(dp(6)));
        root.addView(buildInfoRow("Причина:", reason.isEmpty() ? "не указана" : reason));
        root.addView(spacerV(dp(20)));

        LinearLayout btns = buildDialogButtons(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        }, new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                if (action.equals("unban")) {
                    applyUnban(targetLogin);
                } else {
                    applyUnmute(targetLogin);
                }
            }
        });
        root.addView(btns);

        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.88), WRAP);
        d.show();
    }

    private void applyUnban(final String targetLogin) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"adminLogin\":\"" + adminLogin + "\",\"adminPassword\":\"" + esc(adminPassword) +
                        "\",\"targetLogin\":\"" + esc(targetLogin) + "\"}";
                    httpPost(serverUrl + "/admin/unban", body);
                    runOnUiThread(new Runnable() {
                        public void run() { toast("Бан снят: " + targetLogin); }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Ошибка"); } });
                }
            }
        }).start();
    }

    private void applyUnmute(final String targetLogin) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"adminLogin\":\"" + adminLogin + "\",\"adminPassword\":\"" + esc(adminPassword) +
                        "\",\"targetLogin\":\"" + esc(targetLogin) + "\"}";
                    httpPost(serverUrl + "/admin/unmute", body);
                    runOnUiThread(new Runnable() {
                        public void run() { toast("Мут снят: " + targetLogin); }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Ошибка"); } });
                }
            }
        }).start();
    }

    // ══════════════════════════════════════════════════
    //  UI HELPERS
    // ══════════════════════════════════════════════════
    private LinearLayout buildCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(12));
        bg.setColor(0xFF0C1014);
        bg.setStroke(1, 0xFF17202A);
        card.setBackground(bg);
        return card;
    }

    private LinearLayout buildDialogRoot(int accentColor) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(20));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(16));
        bg.setColor(0xFF0C1014);
        bg.setStroke(1, accentColor);
        root.setBackground(bg);
        return root;
    }

    private TextView buildDialogTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(15);
        tv.setTextColor(0xFFFFFFFF);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);
        return tv;
    }

    private android.widget.EditText buildInput(String hint) {
        android.widget.EditText et = new android.widget.EditText(this);
        et.setHint(hint);
        et.setHintTextColor(0xFF3A4654);
        et.setTextColor(0xFFFFFFFF);
        et.setTextSize(14);
        et.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(10));
        bg.setColor(0xFF080B0E);
        bg.setStroke(1, 0xFF17202A);
        et.setBackground(bg);
        et.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        return et;
    }

    private LinearLayout buildDialogButtons(View.OnClickListener cancelListener, View.OnClickListener nextListener) {
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnCancel = buildDialogBtn("Отмена", 0xFF17202A, 0xFFB8C4D0);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lp1.rightMargin = dp(8);
        btnCancel.setLayoutParams(lp1);
        btnCancel.setOnClickListener(cancelListener);
        btns.addView(btnCancel);

        TextView btnNext = buildDialogBtn("Далее", 0xFF00FF9D, 0xFF000000);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        btnNext.setLayoutParams(lp2);
        btnNext.setOnClickListener(nextListener);
        btns.addView(btnNext);

        return btns;
    }

    private TextView buildDialogBtn(String text, int bgColor, int textColor) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13);
        tv.setTextColor(textColor);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(10));
        bg.setColor(bgColor);
        tv.setBackground(bg);
        return tv;
    }

    private LinearLayout buildInfoRow(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(12);
        tvLabel.setTextColor(0xFF6C7885);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(110), WRAP);
        tvLabel.setLayoutParams(lp);
        row.addView(tvLabel);

        TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(13);
        tvValue.setTextColor(0xFFFFFFFF);
        tvValue.setTypeface(null, Typeface.BOLD);
        row.addView(tvValue);

        return row;
    }

    private View spacerV(int height) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, height));
        return v;
    }

    private String formatDate(String iso) {
        if (iso == null || iso.isEmpty()) return "—";
        try {
            return iso.substring(0, 10);
        } catch (Exception e) { return iso; }
    }

    // ══════════════════════════════════════════════════
    //  REPORTS SECTION
    // ══════════════════════════════════════════════════
    private void buildReportsSection(final LinearLayout container) {
        TextView note = new TextView(this);
        note.setText("Пользователи с репортами");
        note.setTextSize(12);
        note.setTextColor(0xFF6C7885);
        note.setPadding(0, 0, 0, dp(16));
        container.addView(note);

        final TextView loading = new TextView(this);
        loading.setText("Загрузка...");
        loading.setTextSize(13);
        loading.setTextColor(0xFF6C7885);
        loading.setGravity(android.view.Gravity.CENTER);
        container.addView(loading);

        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = buildAdminBody();
                    String resp = httpPost(serverUrl + "/admin/reports", body);
                    if (resp == null) { runOnUiThread(new Runnable() { public void run() { loading.setText("Ошибка загрузки"); } }); return; }
                    final org.json.JSONObject j = new org.json.JSONObject(resp);
                    final org.json.JSONArray users = j.optJSONArray("users");
                    runOnUiThread(new Runnable() {
                        public void run() {
                            container.removeView(loading);
                            if (users == null || users.length() == 0) {
                                TextView empty = new TextView(AdminPanelActivity.this);
                                empty.setText("Нет репортов");
                                empty.setTextSize(14);
                                empty.setTextColor(0xFF6C7885);
                                empty.setGravity(android.view.Gravity.CENTER);
                                empty.setPadding(0, dp(40), 0, 0);
                                container.addView(empty);
                                return;
                            }
                            for (int i = 0; i < users.length(); i++) {
                                try {
                                    final org.json.JSONObject u = users.getJSONObject(i);
                                    container.addView(buildReportUserCard(u));
                                    container.addView(spacerV(dp(10)));
                                } catch (Exception ignored) {}
                            }
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { loading.setText("Ошибка"); } });
                }
            }
        }).start();
    }

    private LinearLayout buildReportUserCard(final org.json.JSONObject u) {
        final String login = u.optString("targetLogin");
        final String userId = u.optString("userId", "—");
        final int count = u.optInt("count", 0);
        final String createdAt = u.optString("createdAt", "");
        final org.json.JSONArray reports = u.optJSONArray("reports");

        // Проверяем есть ли фото-репорты
        boolean hasPhotoReport = false;
        if (reports != null) {
            for (int i = 0; i < reports.length(); i++) {
                try {
                    if ("rank_photo".equals(reports.getJSONObject(i).optString("type"))) {
                        hasPhotoReport = true;
                        break;
                    }
                } catch (Exception ignored) {}
            }
        }

        LinearLayout card = buildCard();
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(android.view.Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));

        LinearLayout loginRow = new LinearLayout(this);
        loginRow.setOrientation(LinearLayout.HORIZONTAL);
        loginRow.setGravity(android.view.Gravity.CENTER_VERTICAL);

        if (hasPhotoReport) {
            TextView photoLabel = new TextView(this);
            photoLabel.setText("Фото ");
            photoLabel.setTextSize(11);
            photoLabel.setTypeface(null, android.graphics.Typeface.BOLD);
            photoLabel.setTextColor(0xFF00BFFF);
            LinearLayout.LayoutParams plLp = new LinearLayout.LayoutParams(WRAP, WRAP);
            plLp.rightMargin = dp(6);
            photoLabel.setLayoutParams(plLp);
            loginRow.addView(photoLabel);
        }

        TextView tvLogin = new TextView(this);
        tvLogin.setText(login);
        tvLogin.setTextSize(14);
        tvLogin.setTextColor(0xFFFFFFFF);
        tvLogin.setTypeface(null, android.graphics.Typeface.BOLD);
        loginRow.addView(tvLogin);

        info.addView(loginRow);

        TextView tvId = new TextView(this);
        tvId.setText(userId);
        tvId.setTextSize(11);
        tvId.setTextColor(0xFF6C7885);
        info.addView(tvId);

        card.addView(info);

        // Report count badge
        LinearLayout badge = new LinearLayout(this);
        badge.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setShape(GradientDrawable.RECTANGLE);
        badgeBg.setCornerRadius(dp(12));
        badgeBg.setColor(count >= 3 ? 0x33FF1E4E : 0x1AFF1E4E);
        badgeBg.setStroke(1, 0xFFFF1E4E);
        badge.setBackground(badgeBg);

        TextView tvCount = new TextView(this);
        tvCount.setText(String.valueOf(count));
        tvCount.setTextSize(15);
        tvCount.setTextColor(0xFFFF1E4E);
        tvCount.setTypeface(null, android.graphics.Typeface.BOLD);
        badge.addView(tvCount);
        card.addView(badge);

        card.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) {
                showReportDetailDialog(login, userId, createdAt, reports);
            }
        });

        return card;
    }

    private void showReportDetailDialog(final String login, final String userId, final String createdAt,
                                         final org.json.JSONArray reports) {
        final android.app.Dialog d = new android.app.Dialog(this);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        LinearLayout root = buildDialogRoot(0xFFFF1E4E);
        scroll.addView(root);

        // Header info
        root.addView(buildDialogTitle("📋  Репорт: " + login));
        root.addView(spacerV(dp(12)));
        root.addView(buildInfoRow("Логин:", login));
        root.addView(spacerV(dp(4)));
        root.addView(buildInfoRow("ID:", userId));
        root.addView(spacerV(dp(4)));
        root.addView(buildInfoRow("Создан:", formatDate(createdAt)));
        root.addView(spacerV(dp(16)));

        // Reported messages / photos
        TextView msgsTitle = new TextView(this);
        msgsTitle.setText("Репорты:");
        msgsTitle.setTextSize(12);
        msgsTitle.setTextColor(0xFF6C7885);
        msgsTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(msgsTitle);
        root.addView(spacerV(dp(8)));

        if (reports != null) {
            for (int i = 0; i < reports.length(); i++) {
                try {
                    org.json.JSONObject r = reports.getJSONObject(i);
                    String type = r.optString("type", "");
                    String msg = r.optString("messageText", "—");
                    String reporter = r.optString("reporterLogin", "—");
                    boolean isPhoto = "rank_photo".equals(type);

                    LinearLayout msgCard = new LinearLayout(this);
                    msgCard.setOrientation(LinearLayout.VERTICAL);
                    msgCard.setPadding(dp(12), dp(10), dp(12), dp(10));
                    GradientDrawable msgBg = new GradientDrawable();
                    msgBg.setShape(GradientDrawable.RECTANGLE);
                    msgBg.setCornerRadius(dp(8));
                    msgBg.setColor(0xFF080B0E);
                    msgBg.setStroke(1, isPhoto ? 0xFF00BFFF : 0xFF1A2230);
                    msgCard.setBackground(msgBg);

                    if (isPhoto) {
                        // Лейбл "Фото"
                        TextView photoLbl = new TextView(this);
                        photoLbl.setText("📷 Фото-пост");
                        photoLbl.setTextSize(11);
                        photoLbl.setTypeface(null, android.graphics.Typeface.BOLD);
                        photoLbl.setTextColor(0xFF00BFFF);
                        msgCard.addView(photoLbl);

                        // Описание если есть
                        String desc = r.optString("description", "");
                        // messageText содержит "[Фото] описание"
                        String displayDesc = msg.startsWith("[Фото] ") ? msg.substring(7) : msg;
                        if (!android.text.TextUtils.isEmpty(displayDesc) && !"—".equals(displayDesc)) {
                            TextView tvDesc = new TextView(this);
                            tvDesc.setText("\"" + displayDesc + "\"");
                            tvDesc.setTextSize(13);
                            tvDesc.setTextColor(0xFFE0E8F0);
                            tvDesc.setTypeface(null, android.graphics.Typeface.ITALIC);
                            LinearLayout.LayoutParams dLp = new LinearLayout.LayoutParams(MATCH, WRAP);
                            dLp.topMargin = dp(4);
                            tvDesc.setLayoutParams(dLp);
                            msgCard.addView(tvDesc);
                        }

                        // Фото если есть
                        String imgB64 = r.optString("imageBase64", "");
                        if (!android.text.TextUtils.isEmpty(imgB64)) {
                            try {
                                byte[] bytes = android.util.Base64.decode(imgB64, android.util.Base64.DEFAULT);
                                android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                                if (bmp != null) {
                                    android.widget.ImageView iv = new android.widget.ImageView(this);
                                    LinearLayout.LayoutParams ivLp = new LinearLayout.LayoutParams(MATCH, dp(160));
                                    ivLp.topMargin = dp(8);
                                    iv.setLayoutParams(ivLp);
                                    iv.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
                                    GradientDrawable ivBg = new GradientDrawable();
                                    ivBg.setShape(GradientDrawable.RECTANGLE);
                                    ivBg.setCornerRadius(dp(8));
                                    ivBg.setColor(0xFF1A2430);
                                    iv.setBackground(ivBg);
                                    iv.setClipToOutline(true);
                                    iv.setImageBitmap(bmp);
                                    msgCard.addView(iv);
                                }
                            } catch (Exception ignored) {}
                        }
                    } else {
                        TextView tvMsg = new TextView(this);
                        tvMsg.setText("\"" + msg + "\"");
                        tvMsg.setTextSize(13);
                        tvMsg.setTextColor(0xFFE0E8F0);
                        tvMsg.setTypeface(null, android.graphics.Typeface.ITALIC);
                        msgCard.addView(tvMsg);
                    }

                    TextView tvReporter = new TextView(this);
                    tvReporter.setText("от: " + reporter);
                    tvReporter.setTextSize(10);
                    tvReporter.setTextColor(0xFF3A4654);
                    LinearLayout.LayoutParams rLp = new LinearLayout.LayoutParams(MATCH, WRAP);
                    rLp.topMargin = dp(4);
                    tvReporter.setLayoutParams(rLp);
                    msgCard.addView(tvReporter);

                    root.addView(msgCard);
                    root.addView(spacerV(dp(6)));
                } catch (Exception ignored) {}
            }
        }

        root.addView(spacerV(dp(16)));

        // Action buttons
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);

        // Mute button (основной чат)
        TextView btnMute = buildDialogBtn("Мут", 0xFF1A6BFF, 0xFFFFFFFF);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        mlp.rightMargin = dp(6);
        btnMute.setLayoutParams(mlp);
        btnMute.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) {
                d.dismiss();
                showMuteParamsDialogDirect(login, true);
            }
        });
        btns.addView(btnMute);

        // Ban button
        TextView btnBan = buildDialogBtn("Бан", 0xFFFF1E4E, 0xFFFFFFFF);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        blp.rightMargin = dp(6);
        btnBan.setLayoutParams(blp);
        btnBan.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) {
                d.dismiss();
                showBanDurationDialogFromReport(login);
            }
        });
        btns.addView(btnBan);

        // Back button
        TextView btnBack = buildDialogBtn("Назад", 0xFF17202A, 0xFFB8C4D0);
        btnBack.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        btnBack.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) { d.dismiss(); }
        });
        btns.addView(btnBack);

        root.addView(btns);
        root.addView(spacerV(dp(6)));

        // Мут в разделе Звания (отдельная кнопка)
        boolean hasPhotoRpt = false;
        if (reports != null) {
            for (int ri = 0; ri < reports.length(); ri++) {
                try {
                    if ("rank_photo".equals(reports.getJSONObject(ri).optString("type"))) {
                        hasPhotoRpt = true;
                        break;
                    }
                } catch (Exception ignored) {}
            }
        }

        if (hasPhotoRpt) {
            TextView btnRankMute = buildDialogBtn("🔇  Мут в Звания", 0xFF003D6B, 0xFF00BFFF);
            LinearLayout.LayoutParams rmLp = new LinearLayout.LayoutParams(MATCH, WRAP);
            rmLp.bottomMargin = dp(6);
            btnRankMute.setLayoutParams(rmLp);
            GradientDrawable rmBg = new GradientDrawable();
            rmBg.setShape(GradientDrawable.RECTANGLE);
            rmBg.setCornerRadius(dp(8));
            rmBg.setColor(0xFF001830);
            rmBg.setStroke(1, 0xFF00BFFF);
            btnRankMute.setBackground(rmBg);
            btnRankMute.setOnClickListener(new android.view.View.OnClickListener() {
                public void onClick(android.view.View v) {
                    d.dismiss();
                    muteUserInRankSection(login, createdAt);
                }
            });
            root.addView(btnRankMute);
        }

        root.addView(spacerV(dp(2)));

        TextView btnDismiss = buildDialogBtn("❌  Отозвать репорт", 0xFF1A0810, 0xFFFF668A);
        btnDismiss.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        GradientDrawable dismissBg = new GradientDrawable();
        dismissBg.setShape(GradientDrawable.RECTANGLE);
        dismissBg.setCornerRadius(dp(8));
        dismissBg.setColor(0xFF1A0810);
        dismissBg.setStroke(1, 0xFFFF1E4E);
        btnDismiss.setBackground(dismissBg);
        btnDismiss.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) { d.dismiss(); dismissReport(login); }
        });
        root.addView(btnDismiss);

        d.setContentView(scroll);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92),
            (int)(getResources().getDisplayMetrics().heightPixels * 0.8));
        d.show();
    }

    // Direct mute dialog (skip ID verification for reports flow)
    private void showMuteParamsDialogDirect(final String targetLogin) {
        showMuteParamsDialogDirect(targetLogin, false);
    }

    private void showMuteParamsDialogDirect(final String targetLogin, final boolean fromReport) {
        final android.app.Dialog d = new android.app.Dialog(this);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = buildDialogRoot(0xFF1A6BFF);
        root.addView(buildDialogTitle("Мут: " + targetLogin));
        root.addView(spacerV(dp(16)));

        final android.widget.EditText etHours = buildInput("Время мута в часах (макс. 125)");
        etHours.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        root.addView(etHours);
        root.addView(spacerV(dp(10)));

        final android.widget.EditText etReason = buildInput("Причина мута");
        etReason.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(30)});
        root.addView(etReason);
        root.addView(spacerV(dp(16)));

        final boolean doRefreshReports = fromReport;
        LinearLayout btns = buildDialogButtons(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) { d.dismiss(); }
        }, new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) {
                String hoursStr = etHours.getText().toString().trim();
                if (hoursStr.isEmpty()) { toast("Введите время"); return; }
                int hours = Math.min(Integer.parseInt(hoursStr), 125);
                String reason = etReason.getText().toString().trim();
                d.dismiss();
                applyMute(targetLogin, hours, reason);
            }
        });
        root.addView(btns);

        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.88), WRAP);
        d.show();
    }

    private void showBanDurationDialogFromReport(final String targetLogin) {
        final android.app.Dialog d = new android.app.Dialog(this);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        LinearLayout root = buildDialogRoot(0xFFFF1E4E);
        root.addView(buildDialogTitle("Бан: " + targetLogin));
        root.addView(spacerV(dp(16)));
        String[] labels = {"на 1 день","на 3 дня","на 7 дней","на 30 дней","Перманентный"};
        final int[] days2 = {1,3,7,30,-1};
        for (int i = 0; i < labels.length; i++) {
            final int banDays = days2[i];
            TextView btn = buildDialogBtn(labels[i], banDays==-1?0xFF3D0010:0xFF17202A, banDays==-1?0xFFFF668A:0xFFB8C4D0);
            LinearLayout.LayoutParams blp2 = new LinearLayout.LayoutParams(MATCH, WRAP);
            blp2.bottomMargin = dp(6);
            btn.setLayoutParams(blp2);
            btn.setOnClickListener(new android.view.View.OnClickListener() {
                public void onClick(android.view.View v) { d.dismiss(); applyBanAndRefreshReports(targetLogin,banDays,""); }
            });
            root.addView(btn);
        }
        root.addView(spacerV(dp(8)));
        TextView btnCancel2 = buildDialogBtn("Отмена",0xFF07090C,0xFF6C7885);
        btnCancel2.setLayoutParams(new LinearLayout.LayoutParams(MATCH,WRAP));
        btnCancel2.setOnClickListener(new android.view.View.OnClickListener(){public void onClick(android.view.View v){d.dismiss();}});
        root.addView(btnCancel2);
        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.88),WRAP);
        d.show();
    }

    private void applyBanAndRefreshReports(final String targetLogin,final int days,final String reason){
        new Thread(new Runnable(){public void run(){
            try{
                String daysStr=days==-1?"permanent":String.valueOf(days);
                String body="{\"adminLogin\":\""+adminLogin+"\",\"adminPassword\":\""+esc(adminPassword)+
                    "\",\"targetLogin\":\""+esc(targetLogin)+"\",\"days\":\""+daysStr+"\",\"reason\":\""+esc(reason)+"\"}"; 
                httpPost(serverUrl+"/admin/ban",body);
                runOnUiThread(new Runnable(){public void run(){
                    toast("Бан применён: "+targetLogin);
                    if(currentSection==SECTION_REPORTS) showSection(SECTION_REPORTS);
                }});
            }catch(Exception e){runOnUiThread(new Runnable(){public void run(){toast("Ошибка");}});}
        }}).start();
    }

    private void applyMuteAndRefreshReports(final String targetLogin,final int hours,final String reason){
        new Thread(new Runnable(){public void run(){
            try{
                String body="{\"adminLogin\":\""+esc(adminLogin)+"\",\"adminPassword\":\""+esc(adminPassword)+
                    "\",\"targetLogin\":\""+esc(targetLogin)+"\",\"hours\":"+hours+",\"reason\":\""+esc(reason)+"\"}"; 
                httpPost(serverUrl+"/admin/mute",body);
                runOnUiThread(new Runnable(){public void run(){
                    toast("Мут применён: "+targetLogin);
                    if(currentSection==SECTION_REPORTS) showSection(SECTION_REPORTS);
                }});
            }catch(Exception e){runOnUiThread(new Runnable(){public void run(){toast("Ошибка");}});}
        }}).start();
    }

    private void muteUserInRankSection(final String targetLogin, final String createdAt) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"adminLogin\":\"" + esc(adminLogin) + "\","
                        + "\"adminPassword\":\"" + esc(adminPassword) + "\","
                        + "\"login\":\"" + esc(targetLogin) + "\","
                        + "\"createdAt\":\"" + esc(createdAt != null ? createdAt : "") + "\","
                        + "\"reason\":\"Нарушение правил раздела Звания\"}";
                    String resp = httpPost(serverUrl + "/admin/rank/mute-from-report", body);
                    final boolean ok = resp != null && resp.contains("\"ok\"");
                    runOnUiThread(new Runnable() {
                        public void run() {
                            toast(ok ? "Мут в разделе Звания выдан" : "Ошибка");
                            if (ok) showSection(SECTION_REPORTS);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Ошибка"); } });
                }
            }
        }).start();
    }

    private void dismissReport(final String targetLogin){
        new Thread(new Runnable(){public void run(){
            try{
                String body="{\"adminLogin\":\""+esc(adminLogin)+"\",\"adminPassword\":\""+esc(adminPassword)+
                    "\",\"targetLogin\":\""+esc(targetLogin)+"\"}"; 
                httpPost(serverUrl+"/admin/reports/dismiss",body);
                runOnUiThread(new Runnable(){public void run(){
                    toast("Репорт отозван");
                    showSection(SECTION_REPORTS);
                }});
            }catch(Exception e){runOnUiThread(new Runnable(){public void run(){toast("Ошибка");}});}
        }}).start();
    }

    private String buildAdminBody() {
        return "{\"adminLogin\":\"" + esc(adminLogin) + "\",\"adminPassword\":\"" + esc(adminPassword) + "\"}";
    }

    // ══════════════════════════════════════════════════
    //  HTTP
    // ══════════════════════════════════════════════════
    /** Ripple + scale animation for a button press */
    private void animateButtonPress(final View btn, final Runnable onComplete) {
        btn.setEnabled(false);
        // Scale down
        ObjectAnimator scaleDownX = ObjectAnimator.ofFloat(btn, "scaleX", 1f, 0.93f);
        ObjectAnimator scaleDownY = ObjectAnimator.ofFloat(btn, "scaleY", 1f, 0.93f);
        ObjectAnimator fadeDown   = ObjectAnimator.ofFloat(btn, "alpha", 1f, 0.6f);
        scaleDownX.setDuration(100);
        scaleDownY.setDuration(100);
        fadeDown.setDuration(100);
        AnimatorSet pressDown = new AnimatorSet();
        pressDown.playTogether(scaleDownX, scaleDownY, fadeDown);
        pressDown.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                // Scale back up
                ObjectAnimator upX = ObjectAnimator.ofFloat(btn, "scaleX", 0.93f, 1f);
                ObjectAnimator upY = ObjectAnimator.ofFloat(btn, "scaleY", 0.93f, 1f);
                ObjectAnimator fadeUp = ObjectAnimator.ofFloat(btn, "alpha", 0.6f, 1f);
                upX.setDuration(150);
                upY.setDuration(150);
                fadeUp.setDuration(150);
                AnimatorSet pressUp = new AnimatorSet();
                pressUp.playTogether(upX, upY, fadeUp);
                pressUp.addListener(new android.animation.AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(android.animation.Animator animation) {
                        btn.setEnabled(true);
                        if (onComplete != null) onComplete.run();
                    }
                });
                pressUp.start();
            }
        });
        pressDown.start();
    }

    private String httpGet(String urlStr) throws Exception {
        java.net.URL url = new java.net.URL(urlStr);
        java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        int code = conn.getResponseCode();
        java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(
            code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        conn.disconnect();
        return sb.toString();
    }

    private String httpPost(String urlStr, String jsonBody) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        OutputStream os = conn.getOutputStream();
        os.write(jsonBody.getBytes("UTF-8"));
        os.close();
        int code = conn.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
            code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        conn.disconnect();
        return sb.toString();
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density);
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(AdminPanelActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ══════════════════════════════════════════════════
    //  ONLINE SUPPORT SECTION
    // ══════════════════════════════════════════════════
    private void buildSupportSection(final LinearLayout container) {
        // Stop any previous polling
        if (supportPollRunnable != null) {
            supportPollHandler.removeCallbacks(supportPollRunnable);
            supportPollRunnable = null;
        }

        TextView note = new TextView(this);
        note.setText("Пользователи в очереди поддержки");
        note.setTextSize(12);
        note.setTextColor(0xFF6C7885);
        note.setPadding(0, 0, 0, dp(16));
        container.addView(note);

        // Dynamic queue container (updated in realtime)
        supportQueueContainer = new LinearLayout(this);
        supportQueueContainer.setOrientation(LinearLayout.VERTICAL);
        supportQueueContainer.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        container.addView(supportQueueContainer);

        // Initial load + start polling
        refreshSupportQueue();
        supportPollRunnable = new Runnable() {
            public void run() {
                if (currentSection == SECTION_SUPPORT) {
                    refreshSupportQueue();
                    supportPollHandler.postDelayed(this, 3000);
                }
            }
        };
        supportPollHandler.postDelayed(supportPollRunnable, 3000);
    }

    private void refreshSupportQueue() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = buildAdminBody();
                    String resp = httpPost(serverUrl + "/support/admin/queue", body);
                    if (resp == null) return;
                    final org.json.JSONObject j = new org.json.JSONObject(resp);
                    final org.json.JSONArray queue = j.optJSONArray("queue");
                    runOnUiThread(new Runnable() {
                        public void run() {
                            if (supportQueueContainer == null) return;
                            supportQueueContainer.removeAllViews();
                            if (queue == null || queue.length() == 0) {
                                TextView empty = new TextView(AdminPanelActivity.this);
                                empty.setText("Нет ожидающих пользователей");
                                empty.setTextSize(14);
                                empty.setTextColor(0xFF3A4654);
                                empty.setGravity(android.view.Gravity.CENTER);
                                empty.setPadding(0, dp(40), 0, 0);
                                supportQueueContainer.addView(empty);
                                return;
                            }
                            for (int i = 0; i < queue.length(); i++) {
                                try {
                                    final org.json.JSONObject u = queue.getJSONObject(i);
                                    supportQueueContainer.addView(buildSupportQueueCard(u));
                                    supportQueueContainer.addView(spacerV(dp(10)));
                                } catch (Exception ignored) {}
                            }
                        }
                    });
                } catch (Exception ignored) {}
            }
        }).start();
    }

    private LinearLayout buildSupportQueueCard(final org.json.JSONObject u) {
        final String login      = u.optString("login", "—");
        final String userId     = u.optString("userId", "—");
        final String createdAt  = u.optString("createdAt", "");
        final String chatId     = u.optString("chatId", "");
        final long   waitMs     = u.optLong("waitMs", 0L);
        final String problem    = u.optString("problem", "");

        LinearLayout card = buildCard();
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));

        // Left: login + id
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));

        TextView tvLogin = new TextView(this);
        tvLogin.setText(login);
        tvLogin.setTextSize(14);
        tvLogin.setTextColor(0xFFFFFFFF);
        tvLogin.setTypeface(null, Typeface.BOLD);
        info.addView(tvLogin);

        TextView tvId = new TextView(this);
        tvId.setText(userId);
        tvId.setTextSize(10);
        tvId.setTextColor(0xFF6C7885);
        info.addView(tvId);

        card.addView(info);

        // Right: wait time
        TextView tvWait = new TextView(this);
        tvWait.setText(formatWaitTime(waitMs));
        tvWait.setTextSize(11);
        tvWait.setTextColor(0xFFFFD700);
        tvWait.setTypeface(null, Typeface.BOLD);
        tvWait.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        card.addView(tvWait);

        card.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showSupportRequestDialog(login, userId, createdAt, chatId, problem);
            }
        });

        return card;
    }

    private String formatWaitTime(long ms) {
        if (ms < 60000) return "ожидание " + (ms / 1000) + " сек";
        if (ms < 3600000) return "ожидание " + (ms / 60000) + " мин";
        if (ms < 86400000) return "ожидание " + (ms / 3600000) + " ч";
        return "ожидание " + (ms / 86400000) + " д";
    }

    private void showSupportRequestDialog(final String login, final String userId,
                                          final String createdAt, final String chatId,
                                          final String problem) {
        final android.app.Dialog d = new android.app.Dialog(this);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = buildDialogRoot(0xFF00FF9D);

        // Title
        TextView title = buildDialogTitle("🎧  Заявка в поддержку");
        root.addView(title);
        root.addView(spacerV(dp(16)));

        // Copyable login
        buildCopyableRow(root, "Логин:", login);
        root.addView(spacerV(dp(6)));
        buildCopyableRow(root, "ID:", userId);
        root.addView(spacerV(dp(6)));
        root.addView(buildInfoRow("Создан:", formatDate(createdAt)));
        root.addView(spacerV(dp(16)));

        // Problem
        TextView tvProbLabel = new TextView(this);
        tvProbLabel.setText("Проблема:");
        tvProbLabel.setTextSize(11);
        tvProbLabel.setTextColor(0xFF6C7885);
        tvProbLabel.setTypeface(null, Typeface.BOLD);
        root.addView(tvProbLabel);
        root.addView(spacerV(dp(6)));

        TextView tvProblem = new TextView(this);
        tvProblem.setText(problem.isEmpty() ? "Пользователь ещё не описал проблему" : problem);
        tvProblem.setTextSize(13);
        tvProblem.setTextColor(problem.isEmpty() ? 0xFF3A4654 : 0xFFFFFFFF);
        
        tvProblem.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable probBg = new GradientDrawable();
        probBg.setShape(GradientDrawable.RECTANGLE);
        probBg.setCornerRadius(dp(10));
        probBg.setColor(0xFF080B0E);
        probBg.setStroke(1, 0xFF17202A);
        tvProblem.setBackground(probBg);
        root.addView(tvProblem);

        root.addView(spacerV(dp(20)));

        // Buttons
        // Row 1: Open chat + Mute
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnOpen = buildDialogBtn("Открыть чат", 0xFF00FF9D, 0xFF030507);
        LinearLayout.LayoutParams o1lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        o1lp.rightMargin = dp(6);
        btnOpen.setLayoutParams(o1lp);
        btnOpen.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                android.content.Intent intent = new android.content.Intent(
                    AdminPanelActivity.this, AdminSupportChatActivity.class);
                intent.putExtra(AdminSupportChatActivity.EXTRA_CHAT_ID, chatId);
                intent.putExtra(AdminSupportChatActivity.EXTRA_USER_LOGIN, login);
                intent.putExtra(AdminSupportChatActivity.EXTRA_USER_ID, userId);
                intent.putExtra(AdminSupportChatActivity.EXTRA_CREATED_AT, createdAt);
                startActivity(intent);
            }
        });
        row1.addView(btnOpen);

        TextView btnMute = buildDialogBtn("Мут", 0xFF1A6BFF, 0xFFFFFFFF);
        btnMute.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        btnMute.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                showMuteParamsDialogDirect(login, false);
            }
        });
        row1.addView(btnMute);
        root.addView(row1);

        root.addView(spacerV(dp(8)));

        // Row 2: Cancel help + Cancel
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnCancelHelp = buildDialogBtn("Отменить помощь", 0xFF1A0810, 0xFFFF668A);
        GradientDrawable chBg = new GradientDrawable();
        chBg.setShape(GradientDrawable.RECTANGLE);
        chBg.setCornerRadius(dp(10));
        chBg.setColor(0xFF1A0810);
        chBg.setStroke(1, 0xFFFF1E4E);
        btnCancelHelp.setBackground(chBg);
        LinearLayout.LayoutParams ch1lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        ch1lp.rightMargin = dp(6);
        btnCancelHelp.setLayoutParams(ch1lp);
        btnCancelHelp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                cancelSupportRequest(chatId, login);
            }
        });
        row2.addView(btnCancelHelp);

        TextView btnClose = buildDialogBtn("Отмена", 0xFF17202A, 0xFFB8C4D0);
        btnClose.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        btnClose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        row2.addView(btnClose);
        root.addView(row2);

        d.setContentView(root);
        d.getWindow().setLayout(
            (int)(getResources().getDisplayMetrics().widthPixels * 0.90),
            (int)(getResources().getDisplayMetrics().heightPixels * 0.80));
        d.show();
    }

    private void buildCopyableRow(LinearLayout parent, String label, final String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(12);
        tvLabel.setTextColor(0xFF6C7885);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(80), WRAP);
        tvLabel.setLayoutParams(lp);
        row.addView(tvLabel);

        TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(13);
        tvValue.setTextColor(0xFF00FF9D);
        tvValue.setTypeface(null, Typeface.BOLD);
        tvValue.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(tvValue);

        TextView btnCopy = new TextView(this);
        btnCopy.setText("⎘  Копировать");
        btnCopy.setTextSize(11);
        btnCopy.setTextColor(0xFF00E5FF);
        btnCopy.setTypeface(null, Typeface.BOLD);
        btnCopy.setPadding(dp(12), dp(6), dp(12), dp(6));
        // btn_copy_pill — dark cyan pill
        {
            android.graphics.drawable.GradientDrawable copyPill = new android.graphics.drawable.GradientDrawable();
            copyPill.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
            copyPill.setCornerRadius(dp(20));
            copyPill.setColor(0xFF0F1E2E);
            copyPill.setStroke(dp(1), 0xFF00E5FF);
            btnCopy.setBackground(copyPill);
        }
        btnCopy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                android.content.ClipboardManager cm =
                    (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(android.content.ClipData.newPlainText("copy", value));
                toast("Скопировано");
            }
        });
        row.addView(btnCopy);

        parent.addView(row);
    }

    private void cancelSupportRequest(final String chatId, final String userLogin) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"adminLogin\":\"" + esc(adminLogin) + "\",\"adminPassword\":\"" + esc(adminPassword) +
                        "\",\"chatId\":\"" + esc(chatId) + "\",\"userLogin\":\"" + esc(userLogin) + "\"}";
                    httpPost(serverUrl + "/support/admin/cancel", body);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            toast("Помощь отменена: " + userLogin);
                            if (currentSection == SECTION_SUPPORT) showSection(SECTION_SUPPORT);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("Ошибка"); } });
                }
            }
        }).start();
    }
}
