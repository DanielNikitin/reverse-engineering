package com.clumsyvpn;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class VpnPickerActivity extends Activity {

    public static final String PREFS_VPN        = "cvpn_vpn";
    public static final String KEY_VPN          = "selected_vpn";
    public static final String VPN_DEFAULT      = "Стандартный VPN";
    public static final String VPN_QUANTUM      = "Quantum Pulse";
    public static final String VPN_SHADOWROUTE  = "ShadowRoute";

    private String selectedVpn;

    private RelativeLayout itemVpnDefault;
    private RelativeLayout itemVpnQuantum;
    private RelativeLayout itemVpnShadow;
    private TextView       checkDefaultTv;
    private TextView       checkQuantumTv;
    private TextView       checkShadowTv;

    private AccountStatusMonitor accountStatusMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        accountStatusMonitor = new AccountStatusMonitor(this);
        setContentView(R.layout.activity_vpn_picker);

        // Прозрачный фон Activity (overlay поверх предыдущего экрана)
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        // Загружаем текущий выбор
        SharedPreferences prefs = getSharedPreferences(PREFS_VPN, MODE_PRIVATE);
        selectedVpn = prefs.getString(KEY_VPN, VPN_DEFAULT);

        // Находим вьюшки
        itemVpnDefault = (RelativeLayout) findViewById(R.id.itemVpnDefault);
        itemVpnQuantum = (RelativeLayout) findViewById(R.id.itemVpnQuantum);
        itemVpnShadow  = (RelativeLayout) findViewById(R.id.itemVpnShadow);
        checkDefaultTv = (TextView) findViewById(R.id.checkDefaultTv);
        checkQuantumTv = (TextView) findViewById(R.id.checkQuantumTv);
        checkShadowTv  = (TextView) findViewById(R.id.checkShadowTv);

        // Анимация снизу вверх при открытии
        final LinearLayout bottomSheet = (LinearLayout) findViewById(R.id.bottomSheet);
        if (bottomSheet != null) {
            bottomSheet.post(new Runnable() {
                public void run() {
                    TranslateAnimation anim = new TranslateAnimation(
                            0, 0, bottomSheet.getHeight(), 0);
                    anim.setDuration(280);
                    bottomSheet.startAnimation(anim);
                }
            });
        }

        // Обновить UI под текущий выбор
        updateSelection();

        // Клик на Стандартный VPN
        itemVpnDefault.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                selectedVpn = VPN_DEFAULT;
                updateSelection();
            }
        });

        // Клик на Quantum Pulse
        itemVpnQuantum.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                selectedVpn = VPN_QUANTUM;
                updateSelection();
            }
        });

        // Клик на ShadowRoute
        if (itemVpnShadow != null) {
            itemVpnShadow.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    selectedVpn = VPN_SHADOWROUTE;
                    updateSelection();
                }
            });
        }

        // Кнопка "Назад" — закрыть без изменений
        TextView btnCancel = (TextView) findViewById(R.id.btnCancel);
        if (btnCancel != null) {
            btnCancel.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { finish(); }
            });
        }

        // Клик на затемнённый фон — закрыть без изменений
        FrameLayout root = (FrameLayout) findViewById(android.R.id.content);
        if (root != null) {
            root.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { finish(); }
            });
        }

        // Кнопка "Применить"
        TextView btnApply = (TextView) findViewById(R.id.btnApply);
        if (btnApply != null) {
            btnApply.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    saveVpnSelection();
                    finish();
                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
    }

    /** Визуально выделяет выбранный VPN */
    private void updateSelection() {
        // Сброс всех
        setItemState(itemVpnDefault, checkDefaultTv, false);
        setItemState(itemVpnQuantum, checkQuantumTv, false);
        setItemState(itemVpnShadow,  checkShadowTv,  false);

        // Активируем выбранный
        if (VPN_DEFAULT.equals(selectedVpn)) {
            setItemState(itemVpnDefault, checkDefaultTv, true);
        } else if (VPN_QUANTUM.equals(selectedVpn)) {
            setItemState(itemVpnQuantum, checkQuantumTv, true);
        } else if (VPN_SHADOWROUTE.equals(selectedVpn)) {
            setItemState(itemVpnShadow, checkShadowTv, true);
        }
    }

    private void setItemState(RelativeLayout item, TextView check, boolean selected) {
        if (item == null || check == null) return;
        if (selected) {
            item.setBackgroundResource(R.drawable.bg_vpn_item_selected);
            check.setBackgroundResource(R.drawable.bg_check_circle_on);
            check.setText("\u2713");
        } else {
            item.setBackgroundResource(R.drawable.bg_vpn_item_normal);
            check.setBackgroundResource(R.drawable.bg_check_circle_off);
            check.setText("");
        }
    }

    /** Сохраняет выбор VPN в SharedPreferences */
    private void saveVpnSelection() {
        getSharedPreferences(PREFS_VPN, MODE_PRIVATE)
                .edit()
                .putString(KEY_VPN, selectedVpn)
                .commit();
    }
}
