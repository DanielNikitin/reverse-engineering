package com.clumsyvpn;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;

public class KeySystemActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    private String serverUrl;
    private String adminLogin;
    private String adminPassword;

    private LinearLayout keysContainer;
    private TextView tvEmpty;

    // ── ЛОКАЛЬНО СКРЫТЫЕ КАРТОЧКИ ──────────────────────────────────
    // Когда ключ на 1 устройство блокируется из-за бана пользователя, админ
    // может убрать карточку из списка кнопкой "Убрать карточку". Это чисто
    // локальная отметка (на сервере ключ остаётся, ждёт возможного разбана).
    // Как только статус ключа перестаёт быть "banned" — карточка возвращается.
    private static final String HIDDEN_CARDS_PREFS = "key_system_hidden_cards";

    private boolean isCardHidden(String keyValue) {
        if (keyValue == null || keyValue.isEmpty()) return false;
        SharedPreferences p = getSharedPreferences(HIDDEN_CARDS_PREFS, MODE_PRIVATE);
        return p.getBoolean(keyValue, false);
    }

    private void hideCard(String keyValue) {
        if (keyValue == null || keyValue.isEmpty()) return;
        getSharedPreferences(HIDDEN_CARDS_PREFS, MODE_PRIVATE).edit().putBoolean(keyValue, true).apply();
    }

    private void unhideCard(String keyValue) {
        if (keyValue == null || keyValue.isEmpty()) return;
        getSharedPreferences(HIDDEN_CARDS_PREFS, MODE_PRIVATE).edit().remove(keyValue).apply();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        adminLogin    = prefs.getString(AuthActivity.KEY_LOGIN, "");
        adminPassword = prefs.getString(AuthActivity.KEY_PASSWORD, "");
        serverUrl     = AuthActivity.SERVER_URL;

        buildUI();
        loadKeys();
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF030507);
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(16), dp(16), dp(16));
        header.setBackgroundColor(0xFF07090C);

        TextView btnBack = new TextView(this);
        btnBack.setText("‹");
        btnBack.setTextSize(22);
        btnBack.setTextColor(0xFF00FF9D);
        btnBack.setTypeface(null, Typeface.BOLD);
        btnBack.setPadding(0, 0, dp(16), 0);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });
        header.addView(btnBack);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("🔑  Key System");
        tvTitle.setTextSize(16);
        tvTitle.setTextColor(0xFFFFFFFF);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        header.addView(tvTitle);

        TextView btnDeactivate = new TextView(this);
        btnDeactivate.setText("✕ Деактивировать");
        btnDeactivate.setTextSize(11);
        btnDeactivate.setTextColor(0xFFFF1E4E);
        btnDeactivate.setTypeface(null, Typeface.BOLD);
        btnDeactivate.setPadding(dp(10), dp(8), dp(10), dp(8));
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(12));
            bg.setColor(0xFF1A0508);
            bg.setStroke(1, 0xFFFF1E4E);
            btnDeactivate.setBackground(bg);
        }
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(WRAP, WRAP);
        dlp.rightMargin = dp(8);
        btnDeactivate.setLayoutParams(dlp);
        btnDeactivate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showDeactivateUserDialog(); }
        });
        header.addView(btnDeactivate);

        TextView btnCreate = new TextView(this);
        btnCreate.setText("+ Создать ключ");
        btnCreate.setTextSize(12);
        btnCreate.setTextColor(0xFF000000);
        btnCreate.setTypeface(null, Typeface.BOLD);
        btnCreate.setPadding(dp(14), dp(8), dp(14), dp(8));
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(12));
            bg.setColor(0xFF00FF9D);
            btnCreate.setBackground(bg);
        }
        btnCreate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showCreateKeyDialog(); }
        });
        header.addView(btnCreate);
        root.addView(header);

        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        divider.setBackgroundColor(0xFF17202A);
        root.addView(divider);

        // Кнопка «Ключи, созданные ботом»
        {
            LinearLayout botRow = new LinearLayout(this);
            botRow.setOrientation(LinearLayout.HORIZONTAL);
            botRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
            botRow.setPadding(dp(14), dp(10), dp(14), dp(10));
            botRow.setBackgroundColor(0xFF07090C);

            TextView tvBotIcon = new TextView(this);
            tvBotIcon.setText("\uD83E\uDD16");
            tvBotIcon.setTextSize(16);
            tvBotIcon.setPadding(0, 0, dp(10), 0);
            botRow.addView(tvBotIcon);

            TextView tvBotLabel = new TextView(this);
            tvBotLabel.setText("\u041A\u043B\u044E\u0447\u0438, \u0441\u043E\u0437\u0434\u0430\u043D\u043D\u044B\u0435 \u0431\u043E\u0442\u043E\u043C");
            tvBotLabel.setTextSize(13);
            tvBotLabel.setTextColor(0xFF2AABEE);
            tvBotLabel.setTypeface(null, Typeface.BOLD);
            tvBotLabel.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
            botRow.addView(tvBotLabel);

            TextView tvBotArrow = new TextView(this);
            tvBotArrow.setText("\u203A");
            tvBotArrow.setTextSize(20);
            tvBotArrow.setTextColor(0xFF2AABEE);
            botRow.addView(tvBotArrow);

            botRow.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    // Важно: это админский раздел «Ключи, созданные ботом» — он должен
                    // показывать ВСЕ ключи, выданные ботом (через /admin/bot/keys/list),
                    // а не личный экран BotKeysActivity (который показывает ключ только
                    // ТЕКУЩЕГО вошедшего аккаунта через /bot/keys/list по его Telegram-привязке).
                    startActivity(new android.content.Intent(KeySystemActivity.this, AdminBotKeysActivity.class));
                }
            });
            root.addView(botRow);

            View divBot = new View(this);
            divBot.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
            divBot.setBackgroundColor(0xFF17202A);
            root.addView(divBot);
        }

        // Scroll content
        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));

        keysContainer = new LinearLayout(this);
        keysContainer.setOrientation(LinearLayout.VERTICAL);
        keysContainer.setPadding(dp(12), dp(12), dp(12), dp(12));

        tvEmpty = new TextView(this);
        tvEmpty.setText("Список пуст");
        tvEmpty.setTextSize(14);
        tvEmpty.setTextColor(0xFF6C7885);
        tvEmpty.setGravity(Gravity.CENTER);
        tvEmpty.setPadding(dp(16), dp(48), dp(16), dp(48));
        tvEmpty.setVisibility(View.GONE);
        keysContainer.addView(tvEmpty);

        scroll.addView(keysContainer);
        root.addView(scroll);

        setContentView(root);
    }

    // ── LOAD KEYS ─────────────────────────────────────────────────
    private void loadKeys() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"adminLogin\":\"" + esc(adminLogin) + "\",\"adminPassword\":\"" + esc(adminPassword) + "\"}";
                    String resp = httpPost(serverUrl + "/admin/keys/list", body);
                    final JSONArray arr = parseKeysArray(resp);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            keysContainer.removeAllViews();
                            if (arr == null || arr.length() == 0) {
                                tvEmpty.setVisibility(View.VISIBLE);
                                keysContainer.addView(tvEmpty);
                            } else {
                                tvEmpty.setVisibility(View.GONE);
                                for (int i = 0; i < arr.length(); i++) {
                                    try {
                                        addKeyCard(arr.getJSONObject(i));
                                    } catch (Exception ignored) {}
                                }
                            }
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            tvEmpty.setText("Ошибка загрузки");
                            tvEmpty.setVisibility(View.VISIBLE);
                            keysContainer.addView(tvEmpty);
                        }
                    });
                }
            }
        }).start();
    }

    private JSONArray parseKeysArray(String resp) {
        try {
            JSONObject obj = new JSONObject(resp);
            return obj.optJSONArray("keys");
        } catch (Exception e) { return null; }
    }

    // ── KEY CARD ──────────────────────────────────────────────────
    private void addKeyCard(final JSONObject key) {
        try {
            final String keyValue  = key.optString("key", "");
            final String status    = key.optString("status", "inactive"); // inactive / active / expired / deactivated / banned
            final int    usersCount = key.optInt("usersCount", 0);

            // Карточка могла быть локально убрана администратором, пока ключ был
            // заблокирован. Как только статус перестал быть "banned" (т.е.
            // пользователя разбанили и ключ восстановился/протух) — снимаем
            // отметку скрытия, карточка должна снова появиться в списке.
            if (!"banned".equals(status) && isCardHidden(keyValue)) {
                unhideCard(keyValue);
            }
            if (isCardHidden(keyValue)) {
                return;
            }

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(14), dp(14), dp(14));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(MATCH, WRAP);
            clp.bottomMargin = dp(10);
            card.setLayoutParams(clp);

            // Card background
            GradientDrawable cardBg = new GradientDrawable();
            cardBg.setShape(GradientDrawable.RECTANGLE);
            cardBg.setCornerRadius(dp(14));
            cardBg.setColor(0xFF0C1014);
            int borderColor;
            if ("active".equals(status))   borderColor = 0xFF00FF9D;
            else if ("expired".equals(status)) borderColor = 0xFFFF1E4E;
            else if ("banned".equals(status)) borderColor = 0xFFFF1E4E;
            else if ("deactivated".equals(status)) borderColor = 0xFFFF6B00;
            else borderColor = 0xFF17202A;
            cardBg.setStroke(1, borderColor);
            card.setBackground(cardBg);

            // Row: key value + status dot
            LinearLayout row1 = new LinearLayout(this);
            row1.setOrientation(LinearLayout.HORIZONTAL);
            row1.setGravity(Gravity.CENTER_VERTICAL);

            TextView tvKey = new TextView(this);
            tvKey.setText(keyValue);
            tvKey.setTextSize(12);
            tvKey.setTextColor(0xFFB8C4D0);
            tvKey.setTypeface(null, Typeface.BOLD);
            tvKey.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
            row1.addView(tvKey);

            // Status badge
            TextView tvStatus = new TextView(this);
            String statusLabel;
            int statusColor;
            int statusBg;
            if ("active".equals(status)) {
                statusLabel = "Активен";
                statusColor = 0xFF00FF9D;
                statusBg    = 0x1A00FF9D;
            } else if ("expired".equals(status)) {
                statusLabel = "Истёк";
                statusColor = 0xFFFF1E4E;
                statusBg    = 0x1AFF1E4E;
            } else if ("banned".equals(status)) {
                statusLabel = "🚫 Заблокирован";
                statusColor = 0xFFFF1E4E;
                statusBg    = 0x1AFF1E4E;
            } else if ("deactivated".equals(status)) {
                statusLabel = "Деактивирован";
                statusColor = 0xFFFF6B00;
                statusBg    = 0x1AFF6B00;
            } else {
                statusLabel = "Не активен";
                statusColor = 0xFF6C7885;
                statusBg    = 0x1A6C7885;
            }
            tvStatus.setText(statusLabel);
            tvStatus.setTextSize(11);
            tvStatus.setTextColor(statusColor);
            tvStatus.setTypeface(null, Typeface.BOLD);
            tvStatus.setPadding(dp(10), dp(4), dp(10), dp(4));
            {
                GradientDrawable sBg = new GradientDrawable();
                sBg.setShape(GradientDrawable.RECTANGLE);
                sBg.setCornerRadius(dp(8));
                sBg.setColor(statusBg);
                sBg.setStroke(1, statusColor);
                tvStatus.setBackground(sBg);
            }
            row1.addView(tvStatus);
            card.addView(row1);

            // Users count
            TextView tvUsers = new TextView(this);
            tvUsers.setText("Пользователей: " + usersCount);
            tvUsers.setTextSize(11);
            tvUsers.setTextColor(0xFF6C7885);
            LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(MATCH, WRAP);
            ulp.topMargin = dp(6);
            tvUsers.setLayoutParams(ulp);
            card.addView(tvUsers);

            final JSONObject keyRef = key;
            card.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { showKeyDetailDialog(keyRef); }
            });

            keysContainer.addView(card);
        } catch (Exception ignored) {}
    }

    // ── CREATE KEY DIALOG ─────────────────────────────────────────
    private void showCreateKeyDialog() {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(true);

        LinearLayout root = buildDialogRoot(0xFF00FF9D);
        root.setPadding(dp(20), dp(20), dp(20), dp(16));

        TextView title = buildDialogTitle("🔑  Создать ключ");
        root.addView(title);

        addSpace(root, 16);

        // --- Devices ---
        TextView lbl1 = buildLabel("Количество устройств:");
        root.addView(lbl1);
        addSpace(root, 6);

        final EditText etDevices = buildInput("Введите число (1, 2, ...)");
        etDevices.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        root.addView(etDevices);
        addSpace(root, 6);

        final TextView btnUnlimited = new TextView(this);
        btnUnlimited.setText("∞  Без ограничений");
        btnUnlimited.setTextSize(12);
        btnUnlimited.setTextColor(0xFF00E5FF);
        btnUnlimited.setTypeface(null, Typeface.BOLD);
        btnUnlimited.setPadding(dp(12), dp(8), dp(12), dp(8));
        btnUnlimited.setGravity(Gravity.CENTER);
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(10));
            bg.setColor(0xFF0F1E2E);
            bg.setStroke(1, 0xFF00E5FF);
            btnUnlimited.setBackground(bg);
        }
        final boolean[] isUnlimitedDevices = {false};
        btnUnlimited.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                isUnlimitedDevices[0] = !isUnlimitedDevices[0];
                if (isUnlimitedDevices[0]) {
                    etDevices.setText("");
                    etDevices.setEnabled(false);
                    etDevices.setAlpha(0.4f);
                    btnUnlimited.setTextColor(0xFF000000);
                    GradientDrawable bg = new GradientDrawable();
                    bg.setShape(GradientDrawable.RECTANGLE);
                    bg.setCornerRadius(dp(10));
                    bg.setColor(0xFF00E5FF);
                    btnUnlimited.setBackground(bg);
                } else {
                    etDevices.setEnabled(true);
                    etDevices.setAlpha(1f);
                    btnUnlimited.setTextColor(0xFF00E5FF);
                    GradientDrawable bg = new GradientDrawable();
                    bg.setShape(GradientDrawable.RECTANGLE);
                    bg.setCornerRadius(dp(10));
                    bg.setColor(0xFF0F1E2E);
                    bg.setStroke(1, 0xFF00E5FF);
                    btnUnlimited.setBackground(bg);
                }
            }
        });
        LinearLayout.LayoutParams ulpBtn = new LinearLayout.LayoutParams(MATCH, WRAP);
        btnUnlimited.setLayoutParams(ulpBtn);
        root.addView(btnUnlimited);

        addSpace(root, 14);

        // --- Expiry ---
        TextView lbl3 = buildLabel("Срок действия после активации:");
        root.addView(lbl3);
        addSpace(root, 6);

        // Переключатель единиц измерения: Дни / Минуты
        final boolean[] isMinutesUnit = {false};
        final LinearLayout unitRow = new LinearLayout(this);
        unitRow.setOrientation(LinearLayout.HORIZONTAL);

        final TextView btnUnitDays = new TextView(this);
        btnUnitDays.setText("Дни");
        btnUnitDays.setTextSize(12);
        btnUnitDays.setTypeface(null, Typeface.BOLD);
        btnUnitDays.setGravity(Gravity.CENTER);
        btnUnitDays.setPadding(dp(12), dp(8), dp(12), dp(8));

        final TextView btnUnitMinutes = new TextView(this);
        btnUnitMinutes.setText("Минуты");
        btnUnitMinutes.setTextSize(12);
        btnUnitMinutes.setTypeface(null, Typeface.BOLD);
        btnUnitMinutes.setGravity(Gravity.CENTER);
        btnUnitMinutes.setPadding(dp(12), dp(8), dp(12), dp(8));

        final EditText etDays = buildInput("Дней (напр. 30)");
        etDays.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        final Runnable refreshUnitButtons = new Runnable() {
            public void run() {
                if (isMinutesUnit[0]) {
                    GradientDrawable bgActive = new GradientDrawable();
                    bgActive.setShape(GradientDrawable.RECTANGLE);
                    bgActive.setCornerRadius(dp(10));
                    bgActive.setColor(0xFF00E5FF);
                    btnUnitMinutes.setBackground(bgActive);
                    btnUnitMinutes.setTextColor(0xFF000000);

                    GradientDrawable bgInactive = new GradientDrawable();
                    bgInactive.setShape(GradientDrawable.RECTANGLE);
                    bgInactive.setCornerRadius(dp(10));
                    bgInactive.setColor(0xFF0F1E2E);
                    bgInactive.setStroke(1, 0xFF00E5FF);
                    btnUnitDays.setBackground(bgInactive);
                    btnUnitDays.setTextColor(0xFF00E5FF);

                    etDays.setHint("Минут (напр. 90)");
                } else {
                    GradientDrawable bgActive = new GradientDrawable();
                    bgActive.setShape(GradientDrawable.RECTANGLE);
                    bgActive.setCornerRadius(dp(10));
                    bgActive.setColor(0xFF00E5FF);
                    btnUnitDays.setBackground(bgActive);
                    btnUnitDays.setTextColor(0xFF000000);

                    GradientDrawable bgInactive = new GradientDrawable();
                    bgInactive.setShape(GradientDrawable.RECTANGLE);
                    bgInactive.setCornerRadius(dp(10));
                    bgInactive.setColor(0xFF0F1E2E);
                    bgInactive.setStroke(1, 0xFF00E5FF);
                    btnUnitMinutes.setBackground(bgInactive);
                    btnUnitMinutes.setTextColor(0xFF00E5FF);

                    etDays.setHint("Дней (напр. 30)");
                }
            }
        };

        btnUnitDays.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                isMinutesUnit[0] = false;
                refreshUnitButtons.run();
            }
        });
        btnUnitMinutes.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                isMinutesUnit[0] = true;
                refreshUnitButtons.run();
            }
        });
        refreshUnitButtons.run();

        LinearLayout.LayoutParams unitLp1 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        unitLp1.rightMargin = dp(6);
        btnUnitDays.setLayoutParams(unitLp1);
        unitRow.addView(btnUnitDays);

        LinearLayout.LayoutParams unitLp2 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        btnUnitMinutes.setLayoutParams(unitLp2);
        unitRow.addView(btnUnitMinutes);

        root.addView(unitRow);
        addSpace(root, 8);

        root.addView(etDays);
        addSpace(root, 6);

        final TextView btnForever = new TextView(this);
        btnForever.setText("♾  Навсегда");
        btnForever.setTextSize(12);
        btnForever.setTextColor(0xFF00FF9D);
        btnForever.setTypeface(null, Typeface.BOLD);
        btnForever.setPadding(dp(12), dp(8), dp(12), dp(8));
        btnForever.setGravity(Gravity.CENTER);
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(10));
            bg.setColor(0xFF0B1A0F);
            bg.setStroke(1, 0xFF00FF9D);
            btnForever.setBackground(bg);
        }
        final boolean[] isForever = {false};
        btnForever.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                isForever[0] = !isForever[0];
                if (isForever[0]) {
                    etDays.setText("");
                    etDays.setEnabled(false);
                    etDays.setAlpha(0.4f);
                    btnUnitDays.setEnabled(false);
                    btnUnitMinutes.setEnabled(false);
                    unitRow.setAlpha(0.4f);
                    btnForever.setTextColor(0xFF000000);
                    GradientDrawable bg = new GradientDrawable();
                    bg.setShape(GradientDrawable.RECTANGLE);
                    bg.setCornerRadius(dp(10));
                    bg.setColor(0xFF00FF9D);
                    btnForever.setBackground(bg);
                } else {
                    etDays.setEnabled(true);
                    etDays.setAlpha(1f);
                    btnUnitDays.setEnabled(true);
                    btnUnitMinutes.setEnabled(true);
                    unitRow.setAlpha(1f);
                    btnForever.setTextColor(0xFF00FF9D);
                    GradientDrawable bg = new GradientDrawable();
                    bg.setShape(GradientDrawable.RECTANGLE);
                    bg.setCornerRadius(dp(10));
                    bg.setColor(0xFF0B1A0F);
                    bg.setStroke(1, 0xFF00FF9D);
                    btnForever.setBackground(bg);
                }
            }
        });
        LinearLayout.LayoutParams flpBtn = new LinearLayout.LayoutParams(MATCH, WRAP);
        btnForever.setLayoutParams(flpBtn);
        root.addView(btnForever);

        addSpace(root, 20);

        // Buttons row
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);

        final TextView btnCancel = buildDialogBtn("Отмена", 0xFF17202A, 0xFFB8C4D0);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lp1.rightMargin = dp(8);
        btnCancel.setLayoutParams(lp1);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        btns.addView(btnCancel);

        // Create button — wraps FrameLayout for loading spinner swap
        final FrameLayout btnCreateFrame = new FrameLayout(this);
        btnCreateFrame.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));

        final TextView btnCreate = buildDialogBtn("Создать ключ", 0xFF00FF9D, 0xFF000000);
        btnCreate.setLayoutParams(new FrameLayout.LayoutParams(MATCH, WRAP));
        btnCreateFrame.addView(btnCreate);

        final ProgressBar spinner = new ProgressBar(this);
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(dp(28), dp(28));
        slp.gravity = Gravity.CENTER;
        spinner.setLayoutParams(slp);
        spinner.setVisibility(View.GONE);
        btnCreateFrame.addView(spinner);

        btns.addView(btnCreateFrame);
        root.addView(btns);

        btnCreate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int maxDevices;
                if (isUnlimitedDevices[0]) {
                    maxDevices = 0; // 0 = unlimited on server
                } else {
                    String devStr = etDevices.getText().toString().trim();
                    if (devStr.isEmpty()) { toast("Введите количество устройств"); return; }
                    try { maxDevices = Integer.parseInt(devStr); }
                    catch (Exception e) { toast("Неверное число устройств"); return; }
                    if (maxDevices < 1) { toast("Минимум 1 устройство"); return; }
                }

                int expiryDays;
                int expiryMinutes;
                if (isForever[0]) {
                    expiryDays = 0; // 0 = forever on server
                    expiryMinutes = 0;
                } else {
                    String valStr = etDays.getText().toString().trim();
                    if (valStr.isEmpty()) { toast("Введите срок действия"); return; }
                    int value;
                    try { value = Integer.parseInt(valStr); }
                    catch (Exception e) {
                        toast(isMinutesUnit[0] ? "Неверное число минут" : "Неверное число дней");
                        return;
                    }
                    if (value < 1) {
                        toast(isMinutesUnit[0] ? "Минимум 1 минута" : "Минимум 1 день");
                        return;
                    }
                    if (isMinutesUnit[0]) {
                        expiryMinutes = value;
                        expiryDays = 0;
                    } else {
                        expiryDays = value;
                        expiryMinutes = 0;
                    }
                }

                // Show loading
                btnCreate.setVisibility(View.GONE);
                spinner.setVisibility(View.VISIBLE);
                btnCancel.setEnabled(false);

                final int fMaxDevices = maxDevices;
                final int fExpiryDays = expiryDays;
                final int fExpiryMinutes = expiryMinutes;

                new Thread(new Runnable() {
                    public void run() {
                        try {
                            String body = "{\"adminLogin\":\"" + esc(adminLogin) + "\","
                                + "\"adminPassword\":\"" + esc(adminPassword) + "\","
                                + "\"maxDevices\":" + fMaxDevices + ","
                                + "\"expiryDays\":" + fExpiryDays + ","
                                + "\"expiryMinutes\":" + fExpiryMinutes + "}";
                            final String resp = httpPost(serverUrl + "/admin/keys/create", body);
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    spinner.setVisibility(View.GONE);
                                    btnCreate.setVisibility(View.VISIBLE);
                                    btnCancel.setEnabled(true);
                                    try {
                                        JSONObject obj = new JSONObject(resp);
                                        if ("ok".equals(obj.optString("status"))) {
                                            d.dismiss();
                                            toast("Ключ создан");
                                            loadKeys();
                                        } else {
                                            toast("Ошибка: " + obj.optString("message", resp));
                                        }
                                    } catch (Exception e) {
                                        toast("Ошибка сервера");
                                    }
                                }
                            });
                        } catch (Exception e) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    spinner.setVisibility(View.GONE);
                                    btnCreate.setVisibility(View.VISIBLE);
                                    btnCancel.setEnabled(true);
                                    toast("Ошибка соединения");
                                }
                            });
                        }
                    }
                }).start();
            }
        });

        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            lp.width  = (int)(getResources().getDisplayMetrics().widthPixels * 0.88f);
            lp.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
        }
        d.show();
    }

    // ── KEY DETAIL DIALOG ─────────────────────────────────────────
    private void showKeyDetailDialog(final JSONObject key) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(true);

        final String keyValue = key.optString("key", "");
        final String status   = key.optString("status", "inactive");

        ScrollView sv = new ScrollView(this);
        LinearLayout root = buildDialogRoot(
            "active".equals(status) ? 0xFF00FF9D :
            ("expired".equals(status) || "banned".equals(status)) ? 0xFFFF1E4E : 0xFF17202A
        );

        // Title
        TextView title = buildDialogTitle("🔑  Информация о ключе");
        root.addView(title);
        addSpace(root, 14);

        // Status line
        try {
            String statusLabel;
            int statusColor;
            if ("active".equals(status)) { statusLabel = "● Активен"; statusColor = 0xFF00FF9D; }
            else if ("expired".equals(status)) { statusLabel = "● Истёк"; statusColor = 0xFFFF1E4E; }
            else if ("banned".equals(status)) { statusLabel = "● Заблокирован"; statusColor = 0xFFFF1E4E; }
            else if ("deactivated".equals(status)) { statusLabel = "● Деактивирован"; statusColor = 0xFFFF6B00; }
            else { statusLabel = "● Не активен"; statusColor = 0xFF6C7885; }

            TextView tvSt = new TextView(this);
            tvSt.setText(statusLabel);
            tvSt.setTextSize(12);
            tvSt.setTextColor(statusColor);
            tvSt.setTypeface(null, Typeface.BOLD);
            tvSt.setGravity(Gravity.CENTER);
            root.addView(tvSt);
            addSpace(root, 10);
        } catch (Exception ignored) {}

        // Key params
        try {
            int maxDevices = key.optInt("maxDevices", 0);
            int expiryDays = key.optInt("expiryDays", 0);
            int expiryMinutes = key.optInt("expiryMinutes", 0);
            String createdAt = key.optString("createdAt", "");

            String expiryLabel;
            if (expiryMinutes > 0) expiryLabel = expiryMinutes + " мин.";
            else if (expiryDays > 0) expiryLabel = expiryDays + " дн.";
            else expiryLabel = "Навсегда";

            addInfoRow(root, "Устройств:", maxDevices == 0 ? "Без ограничений" : String.valueOf(maxDevices));
            addInfoRow(root, "Срок действия:", expiryLabel);
            if (!createdAt.isEmpty()) addInfoRow(root, "Создан:", formatDate(createdAt));
        } catch (Exception ignored) {}

        // Divider
        addSpace(root, 10);
        View div = new View(this);
        div.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        div.setBackgroundColor(0xFF17202A);
        root.addView(div);
        addSpace(root, 10);

        // User info
        try {
            JSONObject bannedUser = key.optJSONObject("bannedUser");
            JSONArray users = key.optJSONArray("users");
            JSONArray deactivatedUsersArr = key.optJSONArray("deactivatedUsers");

            // Собираем ЕДИНЫЙ список всех пользователей этого ключа (активные +
            // забаненные + деактивированные администратором вручную),
            // независимо от их текущего статуса — чтобы корректно найти среди
            // них самого первого по дате входа.
            java.util.List<JSONObject> allUsersList = new java.util.ArrayList<>();
            if (bannedUser != null) allUsersList.add(bannedUser);
            if (users != null) {
                for (int i = 0; i < users.length(); i++) {
                    JSONObject u = users.optJSONObject(i);
                    if (u != null) allUsersList.add(u);
                }
            }
            if (deactivatedUsersArr != null) {
                for (int i = 0; i < deactivatedUsersArr.length(); i++) {
                    JSONObject du = deactivatedUsersArr.optJSONObject(i);
                    if (du != null) allUsersList.add(du);
                }
            }

            if (allUsersList.isEmpty()) {
                TextView tvNoUser = new TextView(this);
                tvNoUser.setText("Информации о пользователе нет");
                tvNoUser.setTextSize(13);
                tvNoUser.setTextColor(0xFF6C7885);
                tvNoUser.setGravity(Gravity.CENTER);
                root.addView(tvNoUser);
            } else {
                // Находим самого первого пользователя по дате входа (loginAt) —
                // именно его карточка показывается на экране деталей ключа.
                // Все остальные (активные и забаненные) доступны только через
                // кнопку "Полный список" ниже, без отдельных карточек на экране.
                JSONObject firstUser = allUsersList.get(0);
                long firstAt = parseLoginAtSafe(firstUser);
                for (JSONObject u : allUsersList) {
                    long t = parseLoginAtSafe(u);
                    if (t > 0 && (firstAt <= 0 || t < firstAt)) {
                        firstUser = u;
                        firstAt = t;
                    }
                }

                boolean firstIsBanned = firstUser.has("reason") || firstUser.has("viaBan")
                    || firstUser.has("frozenAt") || firstUser.has("bannedAt") || firstUser.has("deactivatedAt");
                // bannedUser (banFreeze на ключах 1 устройство) — это всегда бан
                // (отличительный признак — поле frozenAt). Запись из
                // deactivatedUsers — бан, только если у неё явно выставлен
                // viaBan == true; иначе это ручная деактивация админом.
                boolean firstViaBan = firstUser.has("frozenAt") || firstUser.optBoolean("viaBan", false);

                if (firstIsBanned) {
                    LinearLayout bannedCard = new LinearLayout(this);
                    bannedCard.setOrientation(LinearLayout.VERTICAL);
                    bannedCard.setPadding(dp(12), dp(10), dp(12), dp(10));
                    GradientDrawable bcBg = new GradientDrawable();
                    bcBg.setShape(GradientDrawable.RECTANGLE);
                    bcBg.setCornerRadius(dp(10));
                    bcBg.setColor(0xFF1A0508);
                    bcBg.setStroke(1, 0xFFFF1E4E);
                    bannedCard.setBackground(bcBg);
                    bannedCard.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

                    addBannedMarkerContent(bannedCard, firstUser.optString("reason", ""), firstViaBan);
                    addSpace(bannedCard, 10);
                    buildUserBlock(bannedCard, firstUser, true);

                    root.addView(bannedCard);
                } else {
                    buildUserBlock(root, firstUser, false);
                }

                // Единая кнопка "Полный список" — показываем, если пользователей
                // (суммарно, включая забаненных) больше одного.
                if (allUsersList.size() > 1) {
                    JSONArray combinedForFullList = new JSONArray();
                    for (JSONObject u : allUsersList) combinedForFullList.put(u);
                    addSpace(root, 10);
                    buildUsersListButton(root, combinedForFullList, "Полный список (" + allUsersList.size() + " пользователей)");
                }
            }
        } catch (Exception ignored) {}

        // Divider
        addSpace(root, 12);
        View div2 = new View(this);
        div2.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        div2.setBackgroundColor(0xFF17202A);
        root.addView(div2);
        addSpace(root, 10);

        // Key value + copy
        buildCopyRow(root, "Ключ:", keyValue);

        addSpace(root, 10);

        // ── LIVE TIMERS ──
        final String expiryAt    = key.optString("expiryAt", "");
        final boolean isForeverKey = "forever".equals(expiryAt);
        final boolean hasExpiry    = !isForeverKey && !expiryAt.isEmpty();

        // ── LIVE TIMERS — новая логика ──
        final int usersCount  = key.optInt("usersCount", 0);
        final int maxDevices  = key.optInt("maxDevices", 1);
        final boolean noOneLoggedIn = usersCount == 0;

        // Expiry countdown — показывать только если хотя бы один вошёл
        final TextView tvExpiryTimer;
        final boolean isDeactivatedKeyStatus = "deactivated".equals(status);

        if (hasExpiry && !noOneLoggedIn) {
            tvExpiryTimer = new TextView(this);
            tvExpiryTimer.setTextSize(12);
            tvExpiryTimer.setTextColor(0xFF00FF9D);
            tvExpiryTimer.setTypeface(null, Typeface.BOLD);
            LinearLayout.LayoutParams etlp = new LinearLayout.LayoutParams(MATCH, WRAP);
            etlp.bottomMargin = dp(4);
            tvExpiryTimer.setLayoutParams(etlp);
            root.addView(tvExpiryTimer);
        } else if (isDeactivatedKeyStatus) {
            // Ключ деактивирован администратором — независимо от того, был ли
            // у него ограниченный срок, "навсегда" срок, или вообще никто не
            // успел зайти: показываем именно это, а не "Навсегда"/"Ещё никто
            // не зашёл", т.к. ключ уже не подлежит восстановлению.
            tvExpiryTimer = null;
            TextView tvDeact = new TextView(this);
            tvDeact.setText("Ключ деактивирован, срок ключа истёк");
            tvDeact.setTextSize(12);
            tvDeact.setTextColor(0xFFFF1E4E);
            tvDeact.setTypeface(null, Typeface.BOLD);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(MATCH, WRAP);
            dlp.bottomMargin = dp(4);
            tvDeact.setLayoutParams(dlp);
            root.addView(tvDeact);
        } else if (hasExpiry && noOneLoggedIn) {
            tvExpiryTimer = null;
            TextView tvNotUsed = new TextView(this);
            boolean isExpiredNow = "expired".equals(status);
            boolean isBannedNow  = "banned".equals(status);
            String notUsedLabel = isExpiredNow ? "Срок ключа истёк"
                                : isBannedNow   ? "Срок заморожен"
                                : "Ещё никто не зашёл";
            tvNotUsed.setText(notUsedLabel);
            tvNotUsed.setTextSize(12);
            tvNotUsed.setTextColor((isExpiredNow || isBannedNow) ? 0xFFFF1E4E : 0xFF00E5FF);
            tvNotUsed.setTypeface(null, Typeface.BOLD);
            LinearLayout.LayoutParams nulp = new LinearLayout.LayoutParams(MATCH, WRAP);
            nulp.bottomMargin = dp(4);
            tvNotUsed.setLayoutParams(nulp);
            root.addView(tvNotUsed);
        } else if (isForeverKey) {
            tvExpiryTimer = null;
            TextView tvForever = new TextView(this);
            tvForever.setText("Срок: ♾ Навсегда");
            tvForever.setTextSize(12);
            tvForever.setTextColor(0xFF00FF9D);
            tvForever.setTypeface(null, Typeface.BOLD);
            root.addView(tvForever);
        } else {
            tvExpiryTimer = null;
        }

        // Handler for real-time updates
        final Handler timerHandler = new Handler(Looper.getMainLooper());
        final Runnable[] timerRunnable = {null};
        timerRunnable[0] = new Runnable() {
            public void run() {
                long nowMs = System.currentTimeMillis();

                if (tvExpiryTimer != null && hasExpiry) {
                    try {
                        long expiryMs = parseIso(expiryAt);
                        long diffMs = expiryMs - nowMs;
                        if (diffMs > 0) {
                            long days  = diffMs / (24 * 3600 * 1000L);
                            long hours = (diffMs % (24 * 3600 * 1000L)) / (3600 * 1000L);
                            long mins  = (diffMs % (3600 * 1000L)) / (60 * 1000L);
                            if (days > 0) {
                                tvExpiryTimer.setText("Осталось: " + days + " дн. " + hours + " ч.");
                            } else {
                                tvExpiryTimer.setText("Осталось: " + hours + " ч. " + mins + " мин.");
                            }
                            tvExpiryTimer.setTextColor(days == 0 && hours < 3 ? 0xFFFF1E4E : 0xFF00FF9D);
                        } else {
                            tvExpiryTimer.setText("Срок действия истёк");
                            tvExpiryTimer.setTextColor(0xFFFF1E4E);
                        }
                    } catch (Exception ignored) {}
                }

                timerHandler.postDelayed(timerRunnable[0], 1000);
            }
        };
        timerHandler.post(timerRunnable[0]);

        // Stop timer when dialog closes
        d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            public void onDismiss(android.content.DialogInterface dialog) {
                timerHandler.removeCallbacks(timerRunnable[0]);
            }
        });

        addSpace(root, 6);

        // Buttons: Назад | Удалить ключ
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);

        TextView btnBack = buildDialogBtn("Назад", 0xFF17202A, 0xFFB8C4D0);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lp1.rightMargin = dp(8);
        btnBack.setLayoutParams(lp1);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        btns.addView(btnBack);

        final boolean isExpiredKey     = "expired".equals(status);
        final boolean isBannedKey      = "banned".equals(status);
        final boolean isDeactivatedKey = "deactivated".equals(status);

        String deleteBtnLabel = (isExpiredKey || isBannedKey || isDeactivatedKey) ? "Убрать карточку" : "Удалить ключ";
        TextView btnDelete = buildDialogBtn(deleteBtnLabel, 0xFF1A0508, 0xFFFF1E4E);
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(10));
            bg.setColor(0xFF1A0508);
            bg.setStroke(1, 0xFFFF1E4E);
            btnDelete.setBackground(bg);
        }
        btnDelete.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        btnDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                if (isBannedKey) {
                    // Ключ заблокирован из-за бана пользователя — это ЧИСТО локальное
                    // скрытие карточки. На сервере ключ остаётся как есть и ждёт
                    // возможного разбана администратором — как только пользователя
                    // разблокируют (и ключ восстановится или истечёт), карточка
                    // автоматически появится в списке снова.
                    hideCard(keyValue);
                    loadKeys();
                } else if (isExpiredKey) {
                    // Ключ истёк, пользователей уже нет (всех выкинуло автоматически) —
                    // не нужен диалог с причиной, просто убираем карточку из списка.
                    performDeleteKey(keyValue, "", null, null, null, null, "Карточка ключа удалена");
                } else if (isDeactivatedKey) {
                    // Ключ деактивирован вручную (для ключа на 1 устройство — это
                    // навсегда, без восстановления) — причина уже зафиксирована
                    // в карточке пользователя, повторно спрашивать не нужно.
                    performDeleteKey(keyValue, "", null, null, null, null, "Карточка ключа удалена");
                } else {
                    showDeleteKeyConfirmDialog(keyValue, usersCount);
                }
            }
        });
        btns.addView(btnDelete);

        root.addView(btns);

        sv.addView(root);
        d.setContentView(sv);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            lp.width  = (int)(getResources().getDisplayMetrics().widthPixels * 0.88f);
            lp.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
        }
        d.show();
    }

    // ── МАРКЕР ЗАБЛОКИРОВАННОГО / ДЕАКТИВИРОВАННОГО ПОЛЬЗОВАТЕЛЯ ─────
    // Содержимое маркера бана/деактивации без собственной рамки/фона —
    // используется как отдельным маркером, так и как часть объединённой
    // карточки, где рамку рисует уже сам контейнер (см. showKeyDetailDialog).
    // viaBan == true  → пользователь заблокирован (бан, после разбана может
    //                    восстановиться).
    // viaBan == false → пользователь деактивирован вручную администратором
    //                    через /admin/keys/deactivate-user (без восстановления).
    private void addBannedMarkerContent(LinearLayout container, String reason, boolean viaBan) {
        TextView tvMarker = new TextView(this);
        tvMarker.setText(viaBan
            ? "🚫 Пользователь заблокирован. Доступ к ключу для данного пользователя отключён."
            : "🚫 Пользователь деактивирован. Доступ к ключу для данного пользователя отключён.");
        tvMarker.setTextSize(12);
        tvMarker.setTextColor(0xFFFF1E4E);
        tvMarker.setTypeface(null, Typeface.BOLD);
        container.addView(tvMarker);

        TextView tvReason = new TextView(this);
        String reasonText = (reason == null || reason.trim().isEmpty()) ? "Не указана" : reason;
        tvReason.setText(viaBan
            ? ("Причина: " + reasonText)
            : ("Этот пользователь деактивирован по причине: " + reasonText));
        tvReason.setTextSize(12);
        tvReason.setTextColor(0xFFB8C4D0);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.topMargin = dp(4);
        tvReason.setLayoutParams(rlp);
        container.addView(tvReason);
    }

    // Кнопка-список активных пользователей ключа (открывает showAllUsersDialog).
    // Используется как для "Полный список (N)" когда первый по факту активен,
    // так и для "Активные пользователи (N)" когда настоящий первый уже забанен
    // и показан отдельной карточкой — в обоих случаях логика одна и та же.
    private void buildUsersListButton(LinearLayout root, final JSONArray allUsers, String label) {
        TextView btnFull = new TextView(this);
        btnFull.setText(label);
        btnFull.setTextSize(12);
        btnFull.setTextColor(0xFF00E5FF);
        btnFull.setGravity(Gravity.CENTER);
        btnFull.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(10));
        bg.setColor(0xFF0F1E2E);
        bg.setStroke(1, 0xFF00E5FF);
        btnFull.setBackground(bg);
        btnFull.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showAllUsersDialog(allUsers); }
        });
        root.addView(btnFull);
    }

    private void buildUserBlock(LinearLayout root, JSONObject user, boolean isBannedUser) {
        try {
            String device  = user.optString("device", "");
            String bindId  = user.optString("bindId", "");
            String login   = user.optString("login", "");
            String userId  = user.optString("userId", "");
            String loginAt = user.optString("loginAt", "");

            TextView lbl = new TextView(this);
            lbl.setText("Пользователь:");
            lbl.setTextSize(11);
            lbl.setTextColor(0xFF6C7885);
            lbl.setTypeface(null, Typeface.BOLD);
            lbl.setLetterSpacing(0.1f);
            root.addView(lbl);
            addSpace(root, 6);

            if (!device.isEmpty())  addInfoRow(root, "Устройство:", device);
            if (!bindId.isEmpty())  addInfoRow(root, "ID привязки:", bindId);
            if (!login.isEmpty())   buildCopyRow(root, "Логин:", login);
            if (!userId.isEmpty())  buildCopyRow(root, "Айди:", userId);
            if (!loginAt.isEmpty()) addInfoRow(root, "Дата входа:", formatDate(loginAt));

            // Telegram-блок
            JSONObject tg = user.optJSONObject("telegram");
            if (tg != null) {
                addSpace(root, 10);
                buildTelegramBlock(root, tg);
            }

            // История аккаунтов для этого устройства на этом ключе
            final JSONArray history = user.optJSONArray("accountsHistory");
            final boolean isBannedUserFinal = isBannedUser;
            final String bannedUserId = userId;
            final String bannedLogin  = login;
            if (history != null && history.length() > 0) {
                addSpace(root, 8);
                TextView btnHistory = new TextView(this);
                btnHistory.setText("Все аккаунты, где использовался этот ключ у данного пользователя");
                btnHistory.setTextSize(12);
                btnHistory.setTextColor(0xFF00E5FF);
                btnHistory.setTypeface(null, Typeface.BOLD);
                {
                    GradientDrawable bg = new GradientDrawable();
                    bg.setShape(GradientDrawable.RECTANGLE);
                    bg.setCornerRadius(dp(8));
                    bg.setColor(0xFF091520);
                    bg.setStroke(1, 0xFF00E5FF);
                    btnHistory.setBackground(bg);
                }
                btnHistory.setPadding(dp(10), dp(8), dp(10), dp(8));
                btnHistory.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
                btnHistory.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        showAccountsHistoryDialog(history, isBannedUserFinal, bannedUserId, bannedLogin);
                    }
                });
                root.addView(btnHistory);
            }
        } catch (Exception ignored) {}
    }

    // ── TELEGRAM BLOCK ────────────────────────────────────────────
    // Красивый блок с информацией о Telegram-аккаунте пользователя.
    // Показывается в карточке ключа (buildUserBlock) и в профиле.
    // Если ник или юзернейм менялся — показывает «старое → новое»:
    // старое значение серым (полупрозрачным), стрелка серая, новое — белым.
    private void buildTelegramBlock(LinearLayout root, JSONObject tg) {
        try {
            // Внешний контейнер-карточка с рамкой цвета Telegram
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(MATCH, WRAP);
            card.setLayoutParams(clp);
            {
                GradientDrawable bg = new GradientDrawable();
                bg.setShape(GradientDrawable.RECTANGLE);
                bg.setCornerRadius(dp(10));
                bg.setColor(0xFF0A1929);
                bg.setStroke(1, 0xFF2AABEE); // цвет Telegram
                card.setBackground(bg);
            }

            // Заголовок блока
            LinearLayout headerRow = new LinearLayout(this);
            headerRow.setOrientation(LinearLayout.HORIZONTAL);
            headerRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams hrLp = new LinearLayout.LayoutParams(MATCH, WRAP);
            hrLp.bottomMargin = dp(8);
            headerRow.setLayoutParams(hrLp);

            TextView tvIcon = new TextView(this);
            tvIcon.setText("✈");
            tvIcon.setTextSize(13);
            tvIcon.setTextColor(0xFF2AABEE);
            tvIcon.setPadding(0, 0, dp(6), 0);
            headerRow.addView(tvIcon);

            TextView tvTitle = new TextView(this);
            tvTitle.setText("Telegram");
            tvTitle.setTextSize(12);
            tvTitle.setTextColor(0xFF2AABEE);
            tvTitle.setTypeface(null, Typeface.BOLD);
            tvTitle.setLetterSpacing(0.08f);
            headerRow.addView(tvTitle);
            card.addView(headerRow);

            // Разделитель под заголовком
            View div = new View(this);
            LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(MATCH, 1);
            divLp.bottomMargin = dp(8);
            div.setLayoutParams(divLp);
            div.setBackgroundColor(0x332AABEE);
            card.addView(div);

            // Ник (firstName)
            String firstName = tg.optString("firstName", "");
            JSONObject lastNameChange = tg.optJSONObject("lastFirstNameChange");
            if (!firstName.isEmpty() || lastNameChange != null) {
                addTelegramRow(card, "Ник:", firstName, lastNameChange);
            }

            // Юзернейм
            String username = tg.optString("username", "");
            JSONObject lastUsernameChange = tg.optJSONObject("lastUsernameChange");
            boolean hasUsername = !username.isEmpty() || lastUsernameChange != null;
            if (hasUsername) {
                String displayUsername = username.isEmpty() ? "" : "@" + username;
                JSONObject usernameChangeDisplay = null;
                if (lastUsernameChange != null) {
                    // Добавляем @ к старому и новому значению для отображения
                    try {
                        String oldVal = lastUsernameChange.optString("old", "");
                        String newVal = lastUsernameChange.optString("new", "");
                        org.json.JSONObject copy = new org.json.JSONObject();
                        copy.put("old", oldVal.isEmpty() ? "" : "@" + oldVal);
                        copy.put("new", newVal.isEmpty() ? "" : "@" + newVal);
                        copy.put("changedAt", lastUsernameChange.optString("changedAt", ""));
                        usernameChangeDisplay = copy;
                    } catch (Exception ignored2) {}
                }
                addTelegramRow(card, "Юзернейм:", displayUsername, usernameChangeDisplay);
            }

            // ID Telegram (мелко, серым)
            String tgId = tg.optString("id", "");
            if (!tgId.isEmpty()) {
                TextView tvId = new TextView(this);
                tvId.setText("ID: " + tgId);
                tvId.setTextSize(10);
                tvId.setTextColor(0xFF3A4654);
                LinearLayout.LayoutParams idLp = new LinearLayout.LayoutParams(MATCH, WRAP);
                idLp.topMargin = dp(4);
                tvId.setLayoutParams(idLp);
                card.addView(tvId);
            }

            root.addView(card);
        } catch (Exception ignored) {}
    }

    // Строка внутри Telegram-блока: «Метка: значение» или «Метка: старое → новое»
    private void addTelegramRow(LinearLayout parent, String label, String currentValue, JSONObject lastChange) {
        try {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
            rlp.bottomMargin = dp(4);
            row.setLayoutParams(rlp);

            // Метка (серая)
            TextView tvLabel = new TextView(this);
            tvLabel.setText(label);
            tvLabel.setTextSize(11);
            tvLabel.setTextColor(0xFF6C7885);
            tvLabel.setLayoutParams(new LinearLayout.LayoutParams(dp(90), WRAP));
            row.addView(tvLabel);

            if (lastChange != null) {
                // Формат: «старое (серым) → (серым) новое (белым)»
                String oldVal = lastChange.optString("old", "");
                String newVal = lastChange.optString("new", "");
                // Если newVal пустой — значит данные совпадают с currentValue
                if (newVal.isEmpty()) newVal = currentValue;

                // Старое значение — серое
                if (!oldVal.isEmpty()) {
                    TextView tvOld = new TextView(this);
                    tvOld.setText(oldVal);
                    tvOld.setTextSize(12);
                    tvOld.setTextColor(0xFF3A4654);
                    row.addView(tvOld);

                    // Стрелка
                    TextView tvArrow = new TextView(this);
                    tvArrow.setText(" \u2192 ");
                    tvArrow.setTextSize(12);
                    tvArrow.setTextColor(0xFF3A4654);
                    row.addView(tvArrow);
                }

                // Новое значение — белое, жирное
                TextView tvNew = new TextView(this);
                tvNew.setText(newVal.isEmpty() ? currentValue : newVal);
                tvNew.setTextSize(13);
                tvNew.setTextColor(0xFFFFFFFF);
                tvNew.setTypeface(null, Typeface.BOLD);
                row.addView(tvNew);
            } else {
                // Изменений не было — просто текущее значение
                TextView tvValue = new TextView(this);
                tvValue.setText(currentValue);
                tvValue.setTextSize(13);
                tvValue.setTextColor(0xFFFFFFFF);
                tvValue.setTypeface(null, Typeface.BOLD);
                row.addView(tvValue);
            }

            parent.addView(row);
        } catch (Exception ignored) {}
    }

    // ── ACCOUNTS HISTORY DIALOG ───────────────────────────────────
    private void showAccountsHistoryDialog(JSONArray history, final boolean isKeyBanned, final String bannedUserId, final String bannedLogin) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(true);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = buildDialogRoot(0xFF00E5FF);
        root.setPadding(dp(16), dp(20), dp(16), dp(16));

        TextView title = buildDialogTitle("📋  История аккаунтов (" + history.length() + ")");
        root.addView(title);
        addSpace(root, 6);

        TextView subtitle = new TextView(this);
        subtitle.setText("Все аккаунты, входившие через этот ключ на данном устройстве");
        subtitle.setTextSize(11);
        subtitle.setTextColor(0xFF6C7885);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);
        addSpace(root, 14);

        for (int i = 0; i < history.length(); i++) {
            try {
                JSONObject entry = history.getJSONObject(i);
                String hLogin   = entry.optString("login", "");
                String hUserId  = entry.optString("userId", "");
                String hFirstAt = entry.optString("firstAt", "");
                String hDevice  = entry.optString("device", "");
                String hBindId  = entry.optString("bindId", "");
                boolean hActive = entry.optBoolean("isActive", false);
                boolean hBanned = entry.optBoolean("isBanned", false);

                // Если ключ заблокирован целиком (бан на 1 устройство), доступ
                // отключён для всех аккаунтов в истории этого устройства.
                // Тому аккаунту, на котором именно произошёл бан, ставим
                // "Заблокирован", остальным — "Нет доступа" (ключ всё равно
                // не работает, кто бы ни пытался зайти с этого устройства).
                boolean isBanTarget = !hBanned && (
                    (!bannedUserId.isEmpty() && bannedUserId.equals(hUserId)) ||
                    (bannedUserId.isEmpty() && !bannedLogin.isEmpty() && bannedLogin.equals(hLogin))
                );
                if (isKeyBanned && isBanTarget) hBanned = true;
                boolean hNoAccess = isKeyBanned && !hBanned;

                // Карточка аккаунта в истории
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12), dp(12), dp(12), dp(12));
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(MATCH, WRAP);
                clp.bottomMargin = dp(8);
                card.setLayoutParams(clp);

                int cardBorder = hBanned ? 0xFFFF1E4E : hNoAccess ? 0xFFFF6B00 : (hActive ? 0xFF00FF9D : 0xFF17202A);
                GradientDrawable cb = new GradientDrawable();
                cb.setShape(GradientDrawable.RECTANGLE);
                cb.setCornerRadius(dp(10));
                cb.setColor(0xFF11171D);
                cb.setStroke(1, cardBorder);
                card.setBackground(cb);

                // Статус аккаунта
                String statusText;
                int statusColor;
                if (hBanned) {
                    statusText = "● Заблокирован";
                    statusColor = 0xFFFF1E4E;
                } else if (hNoAccess) {
                    statusText = "● Нет доступа";
                    statusColor = 0xFFFF6B00;
                } else if (hActive) {
                    statusText = "● Активный аккаунт";
                    statusColor = 0xFF00FF9D;
                } else {
                    statusText = "● Неактивный аккаунт";
                    statusColor = 0xFF6C7885;
                }

                TextView tvStatus = new TextView(this);
                tvStatus.setText(statusText);
                tvStatus.setTextSize(11);
                tvStatus.setTextColor(statusColor);
                tvStatus.setTypeface(null, Typeface.BOLD);
                LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(MATCH, WRAP);
                slp.bottomMargin = dp(6);
                tvStatus.setLayoutParams(slp);
                card.addView(tvStatus);

                // Данные аккаунта — те же что в buildUserBlock
                if (!hDevice.isEmpty())  addInfoRow(card, "Устройство:", hDevice);
                if (!hBindId.isEmpty())  addInfoRow(card, "Айди привязки:", hBindId);
                if (!hLogin.isEmpty())   buildCopyRow(card, "Логин:", hLogin);
                if (!hUserId.isEmpty())  buildCopyRow(card, "Айди:", hUserId);
                if (!hFirstAt.isEmpty()) addInfoRow(card, "Первый вход:", formatDate(hFirstAt));

                root.addView(card);
            } catch (Exception ignored) {}
        }

        addSpace(root, 8);
        TextView btnClose = buildDialogBtn("Закрыть", 0xFF17202A, 0xFFB8C4D0);
        btnClose.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        btnClose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        root.addView(btnClose);

        sv.addView(root);
        d.setContentView(sv);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            lp.width  = (int)(getResources().getDisplayMetrics().widthPixels * 0.92f);
            lp.height = (int)(getResources().getDisplayMetrics().heightPixels * 0.75f);
            w.setAttributes(lp);
        }
        d.show();
    }

    // ── ALL USERS DIALOG ──────────────────────────────────────────
    private void showAllUsersDialog(JSONArray users) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(true);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = buildDialogRoot(0xFF00E5FF);
        root.setPadding(dp(16), dp(20), dp(16), dp(16));

        TextView title = buildDialogTitle("👥  Все пользователи (" + users.length() + ")");
        root.addView(title);
        addSpace(root, 14);

        for (int i = 0; i < users.length(); i++) {
            try {
                JSONObject user = users.getJSONObject(i);

                // Определяем, является ли эта запись забаненным/деактивированным
                // пользователем (а не обычным активным) — по характерным полям,
                // которые есть только у записей из bannedUser/deactivatedUsers.
                boolean isBanned = user.has("reason") || user.has("viaBan")
                    || user.has("frozenAt") || user.has("bannedAt") || user.has("deactivatedAt");

                LinearLayout userCard = new LinearLayout(this);
                userCard.setOrientation(LinearLayout.VERTICAL);
                userCard.setPadding(dp(12), dp(12), dp(12), dp(12));
                LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(MATCH, WRAP);
                ulp.bottomMargin = dp(8);
                userCard.setLayoutParams(ulp);
                GradientDrawable ub = new GradientDrawable();
                ub.setShape(GradientDrawable.RECTANGLE);
                ub.setCornerRadius(dp(10));
                ub.setColor(isBanned ? 0xFF1A0508 : 0xFF11171D);
                ub.setStroke(1, isBanned ? 0xFFFF1E4E : 0xFF17202A);
                userCard.setBackground(ub);

                if (isBanned) {
                    boolean viaBan = user.has("frozenAt") || user.optBoolean("viaBan", false);
                    addBannedMarkerContent(userCard, user.optString("reason", ""), viaBan);
                    addSpace(userCard, 10);
                }
                buildUserBlock(userCard, user, isBanned);
                root.addView(userCard);
            } catch (Exception ignored) {}
        }

        addSpace(root, 14);
        TextView btnClose = buildDialogBtn("Закрыть", 0xFF17202A, 0xFFB8C4D0);
        LinearLayout.LayoutParams bclp = new LinearLayout.LayoutParams(MATCH, WRAP);
        btnClose.setLayoutParams(bclp);
        btnClose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        root.addView(btnClose);

        sv.addView(root);
        d.setContentView(sv);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            lp.width  = (int)(getResources().getDisplayMetrics().widthPixels * 0.90f);
            lp.height = (int)(getResources().getDisplayMetrics().heightPixels * 0.75f);
            w.setAttributes(lp);
        }
        d.show();
    }

    // ── DELETE KEY CONFIRM DIALOG ───────────────────────────────────
    private void showDeleteKeyConfirmDialog(final String keyValue, final int usersCount) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(true);

        LinearLayout root = buildDialogRoot(0xFFFF1E4E);
        root.setPadding(dp(20), dp(20), dp(20), dp(16));

        TextView title = buildDialogTitle("🗑  Удалить ключ");
        root.addView(title);
        addSpace(root, 4);

        TextView subtitle = new TextView(this);
        String warnText = usersCount > 0
            ? "Ключ будет удалён, " + usersCount + " " + pluralUsers(usersCount) + " принудительно выйдет с аккаунта."
            : "Ключ будет безвозвратно удалён.";
        subtitle.setText(warnText);
        subtitle.setTextSize(11);
        subtitle.setTextColor(0xFF6C7885);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);
        addSpace(root, 16);

        TextView lbl = buildLabel("Причина удаления (необязательно):");
        root.addView(lbl);
        addSpace(root, 6);
        final EditText etReason = buildInput("Оставьте пустым или укажите причину");
        root.addView(etReason);
        addSpace(root, 20);

        // Buttons
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);

        final TextView btnBack = buildDialogBtn("Отмена", 0xFF17202A, 0xFFB8C4D0);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lp1.rightMargin = dp(8);
        btnBack.setLayoutParams(lp1);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        btns.addView(btnBack);

        final FrameLayout btnApplyFrame = new FrameLayout(this);
        btnApplyFrame.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));

        final TextView btnApply = buildDialogBtn("Удалить", 0xFF1A0508, 0xFFFF1E4E);
        {
            GradientDrawable bg2 = new GradientDrawable();
            bg2.setShape(GradientDrawable.RECTANGLE);
            bg2.setCornerRadius(dp(10));
            bg2.setColor(0xFF1A0508);
            bg2.setStroke(1, 0xFFFF1E4E);
            btnApply.setBackground(bg2);
        }
        btnApply.setLayoutParams(new FrameLayout.LayoutParams(MATCH, WRAP));
        btnApplyFrame.addView(btnApply);

        final ProgressBar spinnerD = new ProgressBar(this);
        FrameLayout.LayoutParams sdlp = new FrameLayout.LayoutParams(dp(28), dp(28));
        sdlp.gravity = Gravity.CENTER;
        spinnerD.setLayoutParams(sdlp);
        spinnerD.setVisibility(View.GONE);
        btnApplyFrame.addView(spinnerD);
        btns.addView(btnApplyFrame);

        root.addView(btns);

        btnApply.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String reasonVal = etReason.getText().toString().trim();
                // Причина необязательна — удаляем даже без неё

                btnApply.setVisibility(View.GONE);
                spinnerD.setVisibility(View.VISIBLE);
                btnBack.setEnabled(false);

                performDeleteKey(keyValue, reasonVal, d, btnApply, btnBack, spinnerD);
            }
        });

        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            lp.width  = (int)(getResources().getDisplayMetrics().widthPixels * 0.88f);
            lp.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
        }
        d.show();
    }

    // ── DELETE KEY ────────────────────────────────────────────────
    private void performDeleteKey(final String keyValue, final String reason, final Dialog dialog,
                                   final TextView btnApply, final TextView btnBack, final ProgressBar spinner) {
        performDeleteKey(keyValue, reason, dialog, btnApply, btnBack, spinner, "Ключ удалён, пользователи отключены");
    }

    private void performDeleteKey(final String keyValue, final String reason, final Dialog dialog,
                                   final TextView btnApply, final TextView btnBack, final ProgressBar spinner,
                                   final String successMessage) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body = "{\"adminLogin\":\"" + esc(adminLogin) + "\","
                        + "\"adminPassword\":\"" + esc(adminPassword) + "\","
                        + "\"key\":\"" + esc(keyValue) + "\","
                        + "\"reason\":\"" + esc(reason) + "\"}";
                    final String resp = httpPost(serverUrl + "/admin/keys/delete", body);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            if (spinner != null) spinner.setVisibility(View.GONE);
                            if (btnApply != null) btnApply.setVisibility(View.VISIBLE);
                            if (btnBack != null) btnBack.setEnabled(true);
                            try {
                                JSONObject obj = new JSONObject(resp);
                                if ("ok".equals(obj.optString("status"))) {
                                    if (dialog != null) dialog.dismiss();
                                    toast(successMessage);
                                    loadKeys();
                                } else {
                                    toast("Ошибка: " + obj.optString("message", resp));
                                }
                            } catch (Exception e) {
                                toast("Ошибка сервера");
                            }
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            if (spinner != null) spinner.setVisibility(View.GONE);
                            if (btnApply != null) btnApply.setVisibility(View.VISIBLE);
                            if (btnBack != null) btnBack.setEnabled(true);
                            toast("Ошибка соединения");
                        }
                    });
                }
            }
        }).start();
    }

    // ── DEACTIVATE USER DIALOG ────────────────────────────────────
    private void showDeactivateUserDialog() {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(true);

        LinearLayout root = buildDialogRoot(0xFFFF1E4E);
        root.setPadding(dp(20), dp(20), dp(20), dp(16));

        TextView title = buildDialogTitle("✕  Деактивировать ключ");
        root.addView(title);
        addSpace(root, 4);

        TextView subtitle = new TextView(this);
        subtitle.setText("Деактивация ключа для конкретного пользователя");
        subtitle.setTextSize(11);
        subtitle.setTextColor(0xFF6C7885);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);
        addSpace(root, 16);

        TextView lbl1 = buildLabel("Логин пользователя:");
        root.addView(lbl1);
        addSpace(root, 6);
        final EditText etLogin = buildInput("Введите логин");
        root.addView(etLogin);
        addSpace(root, 12);

        TextView lbl2 = buildLabel("ID пользователя:");
        root.addView(lbl2);
        addSpace(root, 6);
        final EditText etUserId = buildInput("Введите ID");
        root.addView(etUserId);
        addSpace(root, 12);

        TextView lbl3 = buildLabel("Причина деактивации:");
        root.addView(lbl3);
        addSpace(root, 6);
        final EditText etReason = buildInput("Укажите причину");
        root.addView(etReason);
        addSpace(root, 20);

        // Buttons
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);

        final TextView btnBack = buildDialogBtn("Назад", 0xFF17202A, 0xFFB8C4D0);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lp1.rightMargin = dp(8);
        btnBack.setLayoutParams(lp1);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        btns.addView(btnBack);

        final FrameLayout btnApplyFrame = new FrameLayout(this);
        btnApplyFrame.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));

        final TextView btnApply = buildDialogBtn("Применить", 0xFF1A0508, 0xFFFF1E4E);
        {
            GradientDrawable bg2 = new GradientDrawable();
            bg2.setShape(GradientDrawable.RECTANGLE);
            bg2.setCornerRadius(dp(10));
            bg2.setColor(0xFF1A0508);
            bg2.setStroke(1, 0xFFFF1E4E);
            btnApply.setBackground(bg2);
        }
        btnApply.setLayoutParams(new FrameLayout.LayoutParams(MATCH, WRAP));
        btnApplyFrame.addView(btnApply);

        final ProgressBar spinnerD = new ProgressBar(this);
        FrameLayout.LayoutParams sdlp = new FrameLayout.LayoutParams(dp(28), dp(28));
        sdlp.gravity = Gravity.CENTER;
        spinnerD.setLayoutParams(sdlp);
        spinnerD.setVisibility(View.GONE);
        btnApplyFrame.addView(spinnerD);
        btns.addView(btnApplyFrame);

        root.addView(btns);

        btnApply.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String loginVal  = etLogin.getText().toString().trim();
                String userIdVal = etUserId.getText().toString().trim();
                String reasonVal = etReason.getText().toString().trim();

                if (loginVal.isEmpty())  { toast("Введите логин пользователя"); return; }
                if (userIdVal.isEmpty()) { toast("Введите ID пользователя"); return; }
                if (reasonVal.isEmpty()) { toast("Укажите причину деактивации"); return; }

                btnApply.setVisibility(View.GONE);
                spinnerD.setVisibility(View.VISIBLE);
                btnBack.setEnabled(false);

                final String fLogin  = loginVal;
                final String fUserId = userIdVal;
                final String fReason = reasonVal;
                final TextView fBtnApply  = btnApply;
                final TextView fBtnBack   = btnBack;
                final ProgressBar fSpinner = spinnerD;
                final Dialog fDialog = d;

                new Thread(new Runnable() {
                    public void run() {
                        try {
                            String body = "{\"adminLogin\":\"" + esc(adminLogin) + "\","
                                + "\"adminPassword\":\"" + esc(adminPassword) + "\","
                                + "\"userLogin\":\"" + esc(fLogin) + "\","
                                + "\"userId\":\"" + esc(fUserId) + "\","
                                + "\"reason\":\"" + esc(fReason) + "\"}";
                            final String resp = httpPost(serverUrl + "/admin/keys/deactivate-user", body);
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    fSpinner.setVisibility(View.GONE);
                                    fBtnApply.setVisibility(View.VISIBLE);
                                    fBtnBack.setEnabled(true);
                                    try {
                                        JSONObject obj = new JSONObject(resp);
                                        if ("ok".equals(obj.optString("status"))) {
                                            fDialog.dismiss();
                                            toast("Пользователь деактивирован");
                                            loadKeys();
                                        } else {
                                            toast("Ошибка: " + obj.optString("message", resp));
                                        }
                                    } catch (Exception e) {
                                        toast("Ошибка сервера");
                                    }
                                }
                            });
                        } catch (Exception e) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    fSpinner.setVisibility(View.GONE);
                                    fBtnApply.setVisibility(View.VISIBLE);
                                    fBtnBack.setEnabled(true);
                                    toast("Ошибка соединения");
                                }
                            });
                        }
                    }
                }).start();
            }
        });

        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            lp.width  = (int)(getResources().getDisplayMetrics().widthPixels * 0.88f);
            lp.height = android.view.WindowManager.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
        }
        d.show();
    }

    // ── UI HELPERS ────────────────────────────────────────────────
    private LinearLayout buildDialogRoot(int accentColor) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(16));
        bg.setColor(0xFF0C1014);
        bg.setStroke(1, accentColor);
        root.setBackground(bg);
        return root;
    }

    private TextView buildDialogTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(15);
        tv.setTextColor(0xFFFFFFFF);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);
        return tv;
    }

    private TextView buildLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12);
        tv.setTextColor(0xFF6C7885);
        return tv;
    }

    private EditText buildInput(String hint) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setHintTextColor(0xFF3A4654);
        et.setTextColor(0xFFFFFFFF);
        et.setTextSize(14);
        et.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(10));
        bg.setColor(0xFF080B0E);
        bg.setStroke(1, 0xFF17202A);
        et.setBackground(bg);
        et.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        return et;
    }

    private TextView buildDialogBtn(String text, int bgColor, int textColor) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13);
        tv.setTextColor(textColor);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(10));
        bg.setColor(bgColor);
        tv.setBackground(bg);
        return tv;
    }

    private String pluralUsers(int n) {
        int mod10 = n % 10, mod100 = n % 100;
        if (mod10 == 1 && mod100 != 11) return "пользователь";
        if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return "пользователя";
        return "пользователей";
    }

    private void addInfoRow(LinearLayout parent, String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.bottomMargin = dp(4);
        row.setLayoutParams(rlp);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(12);
        tvLabel.setTextColor(0xFF6C7885);
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(dp(110), WRAP));
        row.addView(tvLabel);

        TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(13);
        tvValue.setTextColor(0xFFFFFFFF);
        tvValue.setTypeface(null, Typeface.BOLD);
        row.addView(tvValue);

        parent.addView(row);
    }

    private void buildCopyRow(LinearLayout parent, String label, final String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.bottomMargin = dp(6);
        row.setLayoutParams(rlp);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(12);
        tvLabel.setTextColor(0xFF6C7885);
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(dp(70), WRAP));
        row.addView(tvLabel);

        TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(12);
        tvValue.setTextColor(0xFF00FF9D);
        tvValue.setTypeface(null, Typeface.BOLD);
        tvValue.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(tvValue);

        TextView btnCopy = new TextView(this);
        btnCopy.setText("⎘  Копировать");
        btnCopy.setTextSize(11);
        btnCopy.setTextColor(0xFF00E5FF);
        btnCopy.setTypeface(null, Typeface.BOLD);
        btnCopy.setPadding(dp(10), dp(5), dp(10), dp(5));
        {
            GradientDrawable copyPill = new GradientDrawable();
            copyPill.setShape(GradientDrawable.RECTANGLE);
            copyPill.setCornerRadius(dp(20));
            copyPill.setColor(0xFF0F1E2E);
            copyPill.setStroke(dp(1), 0xFF00E5FF);
            btnCopy.setBackground(copyPill);
        }
        btnCopy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("copy", value));
                toast("Скопировано");
            }
        });
        row.addView(btnCopy);

        parent.addView(row);
    }

    private void addSpace(LinearLayout parent, int dpVal) {
        View space = new View(this);
        space.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(dpVal)));
        parent.addView(space);
    }

    private String formatDate(String iso) {
        try {
            java.text.SimpleDateFormat parser = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            parser.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            java.util.Date date;
            try {
                date = parser.parse(iso);
            } catch (Exception e2) {
                // Запасной формат без миллисекунд
                java.text.SimpleDateFormat p2 = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                p2.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                date = p2.parse(iso);
            }
            // Форматируем в локальном времени устройства
            java.text.SimpleDateFormat out = new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm");
            out.setTimeZone(java.util.TimeZone.getDefault());
            return out.format(date);
        } catch (Exception e) {
            // Fallback: простая подстрока если парсинг не удался
            try {
                if (iso.length() >= 16) {
                    String datePart = iso.substring(0, 10);
                    String time = iso.substring(11, 16);
                    String[] parts = datePart.split("-");
                    return parts[2] + "." + parts[1] + "." + parts[0] + " " + time;
                }
            } catch (Exception ignored) {}
            return iso;
        }
    }

    private long parseIso(String iso) {
        try {
            // Format: 2025-06-01T14:30:00.000Z
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return sdf.parse(iso).getTime();
        } catch (Exception e) {
            try {
                java.text.SimpleDateFormat sdf2 = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                sdf2.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                return sdf2.parse(iso).getTime();
            } catch (Exception e2) { return 0; }
        }
    }

    // Безопасно извлекает момент входа пользователя для сравнения "кто зашёл раньше".
    // Приоритет: loginAt (реальная дата входа). Если её нет (старые записи или
    // нестандартная структура) — используем дату события бана/деактивации как
    // приближение, чтобы сортировка не ломалась из-за отсутствия поля.
    private long parseLoginAtSafe(JSONObject user) {
        String loginAt = user.optString("loginAt", "");
        if (!loginAt.isEmpty()) {
            long t = parseIso(loginAt);
            if (t > 0) return t;
        }
        String fallback = user.optString("frozenAt", "");
        if (fallback.isEmpty()) fallback = user.optString("bannedAt", "");
        if (fallback.isEmpty()) fallback = user.optString("deactivatedAt", "");
        if (!fallback.isEmpty()) return parseIso(fallback);
        return 0;
    }

    // ── HTTP ──────────────────────────────────────────────────────
    private String httpPost(String urlStr, String body) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        OutputStream os = conn.getOutputStream();
        os.write(body.getBytes("UTF-8"));
        os.flush();
        os.close();
        int code = conn.getResponseCode();
        java.io.InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        if (stream == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        conn.disconnect();
        return sb.toString();
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private int dp(int val) {
        return (int)(val * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
