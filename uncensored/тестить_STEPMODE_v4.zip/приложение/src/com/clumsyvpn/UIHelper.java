package com.clumsyvpn;

import android.content.Context;
import android.widget.Toast;

/**
 * UIHelper - простой класс для унифицированных UI компонентов
 */
public class UIHelper {
    
    // Цветовая палитра Clumsy
    public static final int BG_PRIMARY = 0xFF0A0E1A;
    public static final int BG_SECONDARY = 0xFF141824;
    public static final int BG_CARD = 0xFF1A1F2E;
    public static final int TEXT_PRIMARY = 0xFFFFFFFF;
    public static final int TEXT_SECONDARY = 0xFF6C7885;
    public static final int ACCENT_GREEN = 0xFF00FF88;
    public static final int ACCENT_BLUE = 0xFF00D1FF;
    public static final int ACCENT_RED = 0xFFFF3366;
    public static final int BORDER_COLOR = 0xFF2A3142;
    
    /**
     * Конвертация dp в пиксели
     */
    public static int dp(float dp) {
        return (int) (dp * android.content.res.Resources.getSystem().getDisplayMetrics().density);
    }
    
    /**
     * Показать короткое уведомление
     */
    public static void showToast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
    
    /**
     * Показать длинное уведомление
     */
    public static void showToastLong(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }
}
