package com.clumsyvpn;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class ProfileActivity extends Activity {

    private TextView tvLogin, tvPassword, tvCreatedAt, tvUserId;
    private TextView tvTgUsername, tvTgNickname;
    private View     llTelegramCard;
    private Button   btnCopyPassword, btnCopyLogin, btnCopyUserId, btnLogout, btnDeleteAccount;

    private AccountStatusMonitor accountStatusMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        accountStatusMonitor = new AccountStatusMonitor(this);
        setContentView(R.layout.activity_profile);

        TextView btnBack = (TextView) findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { finish(); }
            });
        }

        tvLogin          = (TextView) findViewById(R.id.tvProfileLogin);
        tvPassword       = (TextView) findViewById(R.id.tvProfilePassword);
        tvCreatedAt      = (TextView) findViewById(R.id.tvProfileCreatedAt);
        tvUserId         = (TextView) findViewById(R.id.tvProfileUserId);
        tvTgUsername     = (TextView) findViewById(R.id.tvProfileTgUsername);
        tvTgNickname     = (TextView) findViewById(R.id.tvProfileTgNickname);
        llTelegramCard   = findViewById(R.id.llProfileTelegramCard);
        btnCopyPassword  = (Button)   findViewById(R.id.btnCopyPassword);
        btnCopyLogin     = (Button)   findViewById(R.id.btnCopyLogin);
        btnCopyUserId    = (Button)   findViewById(R.id.btnCopyUserId);
        btnLogout        = (Button)   findViewById(R.id.btnLogout);
        btnDeleteAccount = (Button)   findViewById(R.id.btnDeleteAccount);

        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        final String login     = prefs.getString(AuthActivity.KEY_LOGIN, "");
        final String password  = prefs.getString(AuthActivity.KEY_PASSWORD, "");
        final String createdAt = prefs.getString(AuthActivity.KEY_CREATED_AT, "");

        // Генерируем или загружаем уникальный ID пользователя
        final String userId = getOrCreateUserId(prefs, login);

        tvLogin.setText(login);
        tvPassword.setText("****");
        tvCreatedAt.setText(formatExactDate(createdAt));
        if (tvUserId != null) tvUserId.setText(userId);

        refreshTelegramCard();

        // Show admin badge if this is admin account
        showAdminBadgeIfNeeded(login);

        // Hide delete button for admin
        if ("admin".equals(login) && btnDeleteAccount != null) {
            btnDeleteAccount.setVisibility(android.view.View.GONE);
        }

        // Копирование логина
        if (btnCopyLogin != null) {
            btnCopyLogin.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cb.setPrimaryClip(ClipData.newPlainText("login", login));
                    Toast.makeText(ProfileActivity.this, "Скопировано", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // Копирование ID
        if (btnCopyUserId != null) {
            btnCopyUserId.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cb.setPrimaryClip(ClipData.newPlainText("user_id", userId));
                    Toast.makeText(ProfileActivity.this, "Скопировано", Toast.LENGTH_SHORT).show();
                }
            });
        }

        btnCopyPassword.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cb.setPrimaryClip(ClipData.newPlainText("password", password));
                Toast.makeText(ProfileActivity.this, "Скопировано", Toast.LENGTH_SHORT).show();
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showLogoutDialog(); }
        });

        btnDeleteAccount.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showDeleteConfirmDialog(login); }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        accountStatusMonitor.start();
        // Перечитываем TG-данные при каждом возврате на экран —
        // они могли обновиться после входа через AuthActivity.
        refreshTelegramCard();
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
    }

    // Читает актуальные TG-данные из SharedPreferences и обновляет карточку.
    // Вызывается из onCreate и onResume чтобы данные всегда были свежими.
    private void refreshTelegramCard() {
        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        String tgUsername    = prefs.getString(AuthActivity.KEY_TG_USERNAME,      "");
        String tgFirstName   = prefs.getString(AuthActivity.KEY_TG_FIRSTNAME,     "");
        String tgId          = prefs.getString(AuthActivity.KEY_TG_ID,            "");
        String prevUsername  = prefs.getString(AuthActivity.KEY_TG_PREV_USERNAME,  "");
        String prevFirstName = prefs.getString(AuthActivity.KEY_TG_PREV_FIRSTNAME, "");

        if (llTelegramCard == null) return;

        if (tgUsername.isEmpty() && tgFirstName.isEmpty()) {
            llTelegramCard.setVisibility(View.GONE);
            return;
        }

        llTelegramCard.setVisibility(View.VISIBLE);

        // Ник
        if (tvTgNickname != null) {
            if (!tgFirstName.isEmpty()) {
                if (!prevFirstName.isEmpty() && !prevFirstName.equals(tgFirstName)) {
                    tvTgNickname.setText(buildChangedSpan("Ник: ", prevFirstName, tgFirstName));
                } else {
                    tvTgNickname.setText("Ник: " + tgFirstName);
                }
                tvTgNickname.setVisibility(View.VISIBLE);
            } else {
                tvTgNickname.setVisibility(View.GONE);
            }
        }

        // Юзернейм
        if (tvTgUsername != null) {
            if (!tgUsername.isEmpty()) {
                if (!prevUsername.isEmpty() && !prevUsername.equals(tgUsername)) {
                    tvTgUsername.setText(buildChangedSpan("Юзернейм: ", "@" + prevUsername, "@" + tgUsername));
                } else {
                    tvTgUsername.setText("Юзернейм: @" + tgUsername);
                }
                tvTgUsername.setVisibility(View.VISIBLE);
            } else if (!tgId.isEmpty()) {
                tvTgUsername.setText("ID: " + tgId);
                tvTgUsername.setVisibility(View.VISIBLE);
            } else {
                tvTgUsername.setVisibility(View.GONE);
            }
        }
    }

    // Строит SpannableString «Метка: старое (серым) → новое (белым жирным)»
    private android.text.SpannableString buildChangedSpan(String label, String oldVal, String newVal) {
        String full = label + oldVal + " \u2192 " + newVal;
        android.text.SpannableString ss = new android.text.SpannableString(full);
        int oldStart = label.length();
        int oldEnd   = oldStart + oldVal.length();
        int arrEnd   = oldEnd + 3; // " \u2192 "
        int newEnd   = arrEnd + newVal.length();
        ss.setSpan(new android.text.style.ForegroundColorSpan(0xFF3A4654), oldStart, arrEnd, 0);
        ss.setSpan(new android.text.style.ForegroundColorSpan(0xFFFFFFFF), arrEnd, newEnd, 0);
        ss.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), arrEnd, newEnd, 0);
        return ss;
    }

    // ══════════════════════════════════════════════════
    //  ДИАЛОГ «ВЫЙТИ»
    // ══════════════════════════════════════════════════
    private void showLogoutDialog() {
        final Dialog dlg = makeDialog();
        LinearLayout root = makeDialogRoot(dlg);

        TextView title = dialogTitle("Выход из аккаунта", 0xFFFFFFFF);
        root.addView(title);
        root.addView(spacer(10));

        TextView msg = new TextView(this);
        msg.setText("Ты точно хочешь выйти?\nАккаунт не будет удалён — ты сможешь войти снова.");
        msg.setTextColor(0xFFB8C4D0);
        msg.setTextSize(14);
        msg.setGravity(Gravity.CENTER);
        root.addView(msg);
        root.addView(spacer(24));

        LinearLayout row = makeButtonRow();
        Button btnNo  = outlineBtn("Нет");
        Button btnYes = neonGreenBtn("Да");

        btnNo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { dlg.dismiss(); }
        });
        btnYes.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { dlg.dismiss(); logout(); }
        });

        row.addView(btnNo);
        row.addView(btnDivider());
        row.addView(btnYes);
        root.addView(row);

        dlg.show();
    }

    // ══════════════════════════════════════════════════
    //  ДИАЛОГ «УДАЛИТЬ АККАУНТ»
    // ══════════════════════════════════════════════════
    private void showDeleteConfirmDialog(final String loginStr) {
        final Dialog dlg = makeDialog();
        LinearLayout root = makeDialogRoot(dlg);

        TextView title = dialogTitle("Удалить аккаунт", 0xFFFF1E4E);
        root.addView(title);
        root.addView(spacer(10));

        TextView msg = new TextView(this);
        msg.setText("Это действие необратимо.\nАккаунт будет удалён безвозвратно.\n\nВведи логин для подтверждения:");
        msg.setTextColor(0xFFB8C4D0);
        msg.setTextSize(14);
        msg.setGravity(Gravity.CENTER);
        root.addView(msg);
        root.addView(spacer(16));

        final EditText input = new EditText(this);
        input.setHint("Твой логин");
        input.setHintTextColor(0xFF3A4654);
        input.setTextColor(0xFFFF668A);
        input.setTextSize(15);
        input.setTypeface(null, Typeface.BOLD);
        input.setBackgroundResource(R.drawable.bg_input);
        input.setPadding(dp(16), dp(12), dp(16), dp(12));
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(input);
        root.addView(spacer(20));

        LinearLayout row     = makeButtonRow();
        Button btnCancel     = outlineBtn("Отмена");
        Button btnDelete     = neonRedBtn("Удалить");

        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { dlg.dismiss(); }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String entered = input.getText().toString().trim();
                if (entered.equals(loginStr)) {
                    dlg.dismiss();
                    deleteAccount(loginStr);
                } else {
                    input.setError("Логин не совпадает");
                    input.requestFocus();
                }
            }
        });

        row.addView(btnCancel);
        row.addView(btnDivider());
        row.addView(btnDelete);
        root.addView(row);

        dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        dlg.show();
    }

    // ══════════════════════════════════════════════════
    //  UI HELPERS
    // ══════════════════════════════════════════════════
    private Dialog makeDialog() {
        Dialog dlg = new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dlg.setCanceledOnTouchOutside(true);
        dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dlg.getWindow().setLayout(
                (int)(getResources().getDisplayMetrics().widthPixels * 0.88f),
                WindowManager.LayoutParams.WRAP_CONTENT);
        return dlg;
    }

    private LinearLayout makeDialogRoot(Dialog dlg) {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundResource(R.drawable.bg_dialog_neon);
        outer.setPadding(dp(24), dp(28), dp(24), dp(24));
        dlg.setContentView(outer);
        return outer;
    }

    private TextView dialogTitle(String text, int color) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(color);
        tv.setTextSize(18);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);
        return tv;
    }

    private LinearLayout makeButtonRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return row;
    }

    private Button outlineBtn(String text) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(0xFFB8C4D0);
        btn.setTextSize(14);
        btn.setTypeface(null, Typeface.BOLD);
        btn.setAllCaps(false);
        btn.setBackgroundResource(R.drawable.btn_neon_outline);
        btn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(44), 1f));
        return btn;
    }

    private Button neonGreenBtn(String text) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(0xFF000000);
        btn.setTextSize(14);
        btn.setTypeface(null, Typeface.BOLD);
        btn.setAllCaps(false);
        btn.setBackgroundResource(R.drawable.btn_neon_green);
        btn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(44), 1f));
        return btn;
    }

    private Button neonRedBtn(String text) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(0xFFFFFFFF);
        btn.setTextSize(14);
        btn.setTypeface(null, Typeface.BOLD);
        btn.setAllCaps(false);
        btn.setBackgroundResource(R.drawable.btn_neon_red);
        btn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(44), 1f));
        return btn;
    }

    private View btnDivider() {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(12), LinearLayout.LayoutParams.MATCH_PARENT));
        return v;
    }

    private View spacer(int dpVal) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(dpVal)));
        return v;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ══════════════════════════════════════════════════
    //  ADMIN BADGE
    // ══════════════════════════════════════════════════
    private void showAdminBadgeIfNeeded(String login) {
        if (!"admin".equals(login)) return;
        // Try to find a container view after tvUserId to insert badge
        // We'll use a post-layout approach: find root and add a floating badge
        // Find the scrollview or root layout
        android.view.ViewGroup root = (android.view.ViewGroup) findViewById(android.R.id.content);
        if (root == null) return;
        // Walk to find a suitable parent (LinearLayout with profile content)
        android.widget.LinearLayout badgeContainer = new android.widget.LinearLayout(this);
        badgeContainer.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        badgeContainer.setGravity(android.view.Gravity.CENTER);
        badgeContainer.setPadding(dp(12), dp(6), dp(12), dp(6));

        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setShape(GradientDrawable.RECTANGLE);
        badgeBg.setCornerRadius(dp(20));
        badgeBg.setColor(0x33FF1E4E);
        badgeBg.setStroke(dp(1), 0xFFFF1E4E);
        badgeContainer.setBackground(badgeBg);

        TextView shieldTv = new TextView(this);
        shieldTv.setText("🛡 ");
        shieldTv.setTextSize(13);
        badgeContainer.addView(shieldTv);

        TextView adminTv = new TextView(this);
        adminTv.setText("Администратор");
        adminTv.setTextSize(12);
        adminTv.setTextColor(0xFFFF1E4E);
        adminTv.setTypeface(null, android.graphics.Typeface.BOLD);
        badgeContainer.addView(adminTv);

        // Insert after tvUserId in its parent
        if (tvUserId != null) {
            android.view.ViewGroup parent = (android.view.ViewGroup) tvUserId.getParent();
            if (parent != null) {
                // Find index of tvUserId's parent row and insert after it
                // Traverse up to find direct child of a LinearLayout
                android.view.View targetRow = tvUserId;
                while (targetRow.getParent() != null && !(targetRow.getParent() instanceof android.widget.ScrollView)
                        && !(targetRow.getParent() instanceof android.widget.LinearLayout && ((android.widget.LinearLayout)targetRow.getParent()).getOrientation() == android.widget.LinearLayout.VERTICAL && ((android.view.ViewGroup)targetRow.getParent()).getChildCount() > 3)) {
                    if (targetRow.getParent() instanceof android.view.View) {
                        targetRow = (android.view.View) targetRow.getParent();
                    } else break;
                }
                android.view.ViewGroup insertParent = (android.view.ViewGroup) targetRow.getParent();
                if (insertParent instanceof android.widget.LinearLayout) {
                    int idx = ((android.widget.LinearLayout) insertParent).indexOfChild(targetRow);
                    android.widget.LinearLayout.LayoutParams badgeLp = new android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                        android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
                    badgeLp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
                    badgeLp.topMargin = dp(8);
                    badgeLp.bottomMargin = dp(8);
                    badgeContainer.setLayoutParams(badgeLp);
                    // Also wrap in a frame to center horizontally
                    android.widget.FrameLayout wrapper = new android.widget.FrameLayout(this);
                    android.widget.LinearLayout.LayoutParams wlp = new android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                        android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
                    wlp.topMargin = dp(8);
                    wrapper.setLayoutParams(wlp);
                    android.widget.FrameLayout.LayoutParams flp = new android.widget.FrameLayout.LayoutParams(
                        android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                        android.widget.FrameLayout.LayoutParams.WRAP_CONTENT);
                    flp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
                    badgeContainer.setLayoutParams(flp);
                    wrapper.addView(badgeContainer);
                    insertParent.addView(wrapper, idx + 1);
                }
            }
        }
    }

    // ══════════════════════════════════════════════════
    //  БИЗНЕС-ЛОГИКА
    // ══════════════════════════════════════════════════
    private void deleteAccount(final String login) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String body     = "{\"login\":\"" + esc(login) + "\"}";
                    String response = httpPost(AuthActivity.SERVER_URL + "/delete", body);
                    handleDeleteResponse(response);
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(ProfileActivity.this, "Ошибка соединения с сервером", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }).start();
    }

    private void handleDeleteResponse(final String response) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (response != null && (response.contains("\"ok\"") || response.contains("success"))) {
                    Toast.makeText(ProfileActivity.this, "Аккаунт удалён", Toast.LENGTH_SHORT).show();
                    logout();
                } else if (response != null && response.contains("ACCOUNT_NOT_FOUND")) {
                    Toast.makeText(ProfileActivity.this, "Аккаунт не найден", Toast.LENGTH_SHORT).show();
                    logout();
                } else {
                    Toast.makeText(ProfileActivity.this, "Ошибка удаления: " + response, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * Возвращает уникальный числовой ID пользователя.
     * Генерируется один раз на основе логина и сохраняется в SharedPreferences.
     */
    private String getOrCreateUserId(SharedPreferences prefs, String login) {
        // Admin always has fixed ID
        if ("admin".equals(login)) return "000001";
        String savedId = prefs.getString(AuthActivity.KEY_USER_ID, "");
        if (!savedId.isEmpty()) return savedId;
        // Генерируем 6-значный ID из хэша логина + случайного числа
        int hash = Math.abs(login.hashCode());
        int rand  = new java.util.Random(System.currentTimeMillis() ^ hash).nextInt(900000) + 100000;
        String newId = String.valueOf(rand);
        prefs.edit().putString(AuthActivity.KEY_USER_ID, newId).apply();
        return newId;
    }

    private void logout() {
        getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE).edit()
            .putBoolean(AuthActivity.KEY_LOGGED_IN, false)
            .putString(AuthActivity.KEY_LOGIN, "")
            .putString(AuthActivity.KEY_PASSWORD, "")
            .putString(AuthActivity.KEY_CREATED_AT, "")
            .apply();
        Intent intent = new Intent(ProfileActivity.this, AuthActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private String formatRelativeTime(String isoDate) {
        if (isoDate == null || isoDate.isEmpty()) return "неизвестно";
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date created;
            try {
                created = sdf.parse(isoDate);
            } catch (Exception e) {
                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
                sdf2.setTimeZone(TimeZone.getTimeZone("UTC"));
                created = sdf2.parse(isoDate);
            }
            if (created == null) return isoDate;
            long diff  = System.currentTimeMillis() - created.getTime();
            long days  = diff / (1000 * 60 * 60 * 24);
            if (days == 0) return "сегодня";
            if (days == 1) return "1 день назад";
            if (days < 5)  return days + " дня назад";
            if (days < 21) return days + " дней назад";
            long weeks = days / 7;
            if (weeks == 1) return "1 неделю назад";
            if (weeks < 5)  return weeks + " недели назад";
            long months = days / 30;
            if (months == 1) return "1 месяц назад";
            if (months < 5)  return months + " месяца назад";
            return months + " месяцев назад";
        } catch (Exception e) {
            return isoDate;
        }
    }

    /** Форматирует ISO дату в точный вид: "14 мая 2026" */
    private String formatExactDate(String isoDate) {
        if (isoDate == null || isoDate.isEmpty()) return "неизвестно";
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US);
            sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            java.util.Date date;
            try {
                date = sdf.parse(isoDate);
            } catch (Exception e) {
                java.text.SimpleDateFormat sdf2 = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US);
                sdf2.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                date = sdf2.parse(isoDate);
            }
            if (date == null) return isoDate;
            java.util.Calendar cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));
            cal.setTime(date);
            int day   = cal.get(java.util.Calendar.DAY_OF_MONTH);
            int month = cal.get(java.util.Calendar.MONTH); // 0-based
            int year  = cal.get(java.util.Calendar.YEAR);
            String[] months = {"января","февраля","марта","апреля","мая","июня",
                               "июля","августа","сентября","октября","ноября","декабря"};
            return day + " " + months[month] + " " + year;
        } catch (Exception e) {
            return isoDate;
        }
    }

    private String httpPost(String urlStr, String jsonBody) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        OutputStream os = conn.getOutputStream();
        os.write(jsonBody.getBytes("UTF-8"));
        os.close();
        int code = conn.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
                code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        conn.disconnect();
        return sb.toString();
    }

    private String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
