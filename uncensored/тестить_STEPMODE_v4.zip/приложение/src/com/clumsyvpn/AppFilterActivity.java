package com.clumsyvpn;

import android.animation.ValueAnimator;
import android.animation.AnimatorSet;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Экран выбора приложений, для которых работает Clumsy.
 *
 * Сохраняет список пакетов в SharedPreferences (ключ PREFS_NAME / KEY_PACKAGES).
 * MyVpnService читает этот список при старте и вызывает addAllowedApplication()
 * для каждого, если список не пуст (иначе — режим "без ограничений" = весь трафик).
 */
public class AppFilterActivity extends Activity {

    public static final String PREFS_NAME   = "cvpn_app_filter";
    public static final String KEY_PACKAGES = "selected_packages";

    private static final int REQUEST_PICK_APP = 1;
    /** true — кнопка "Добавить ещё", false — кнопка "+" на карточке "Без ограничений" */
    private boolean addMoreMode = false;

    private ScrollView    scrollList;
    private LinearLayout listContainer;
    private LinearLayout panelNormal;
    private LinearLayout panelDeleteMode;

    /** Список выбранных пакетов (сохраняется в prefs) */
    private final List<String> selectedPackages = new ArrayList<>();
    /** Индикаторы выбора для каждой карточки в режиме удаления */
    private final List<View>   checkViews       = new ArrayList<>();
    /** Карточки приложений (по индексу совпадают с selectedPackages) */
    private final List<View>   cardViews        = new ArrayList<>();
    /** Внутренняя «карточка» без индикатора выбора — именно она красится/качается */
    private final List<View>   innerCards       = new ArrayList<>();
    private final Set<Integer> markedForDelete  = new HashSet<>();

    private boolean deleteMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_filter);

        scrollList       = (ScrollView)  findViewById(R.id.scrollList);
        listContainer    = (LinearLayout) findViewById(R.id.listContainer);
        panelNormal      = (LinearLayout) findViewById(R.id.panelNormal);
        panelDeleteMode  = (LinearLayout) findViewById(R.id.panelDeleteMode);

        // Назад
        TextView btnBack = (TextView) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });

        // Удалить (нормальный режим)
        TextView btnDelete = (TextView) findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { enterDeleteMode(); }
        });

        // Добавить ещё
        TextView btnAddMore = (TextView) findViewById(R.id.btnAddMore);
        btnAddMore.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                addMoreMode = true;
                openAppPicker();
            }
        });

        // Отмена (режим удаления)
        TextView btnCancelDelete = (TextView) findViewById(R.id.btnCancelDelete);
        btnCancelDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { exitDeleteMode(); }
        });

        // Подтвердить удаление
        TextView btnConfirmDelete = (TextView) findViewById(R.id.btnConfirmDelete);
        btnConfirmDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { confirmDelete(); }
        });

        loadPackages();
        rebuildList();
    }

    // ─── Хранение ──────────────────────────────────────────────────────────

    private void loadPackages() {
        selectedPackages.clear();
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String json = prefs.getString(KEY_PACKAGES, "");
        if (json.isEmpty()) return;
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                selectedPackages.add(arr.getString(i));
            }
        } catch (Exception ignored) {}
    }

    private void savePackages() {
        try {
            JSONArray arr = new JSONArray();
            for (String pkg : selectedPackages) arr.put(pkg);
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putString(KEY_PACKAGES, arr.toString())
                .apply();
        } catch (Exception ignored) {}
    }

    // ─── Построение UI ────────────────────────────────────────────────────

    private void rebuildList() {
        listContainer.removeAllViews();
        cardViews.clear();
        innerCards.clear();
        checkViews.clear();
        markedForDelete.clear();

        if (selectedPackages.isEmpty()) {
            // Карточка "Без ограничений" + кнопка "+"
            addDefaultCard();
            panelNormal.setVisibility(View.GONE);
            panelDeleteMode.setVisibility(View.GONE);
        } else {
            // Карточки выбранных приложений
            for (int i = 0; i < selectedPackages.size(); i++) {
                addAppCard(i, selectedPackages.get(i));
            }
            panelNormal.setVisibility(View.VISIBLE);
            panelDeleteMode.setVisibility(View.GONE);
        }
    }

    /** Карточка "Без ограничений" с кнопкой "+" */
    private void addDefaultCard() {
        LinearLayout card = makeCardView();

        // Иконка 🌐
        TextView icon = new TextView(this);
        icon.setText("🌐");
        icon.setTextSize(22);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(
            dp(40), dp(40));
        iconLp.rightMargin = dp(12);
        icon.setLayoutParams(iconLp);
        icon.setGravity(Gravity.CENTER);
        card.addView(icon);

        // Текст
        TextView label = new TextView(this);
        label.setText("Без ограничений");
        label.setTextSize(15);
        label.setTextColor(0xFFB8C4D0);
        label.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        label.setLayoutParams(labelLp);
        label.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(label);

        // Кнопка "+" — рисуем крест двумя полосками вместо текстового символа "+":
        // у символа шрифта неровный оптический центр (баг с кривым позиционированием).
        FrameLayout plusBtn = new FrameLayout(this);
        int btnSz = dp(38);
        LinearLayout.LayoutParams plusLp = new LinearLayout.LayoutParams(btnSz, btnSz);
        plusBtn.setLayoutParams(plusLp);
        plusBtn.setBackground(getResources().getDrawable(R.drawable.btn_add_circle_green));
        plusBtn.addView(makePlusCross(0xFF001A0E));
        plusBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                addMoreMode = false;
                openAppPicker();
            }
        });
        card.addView(plusBtn);

        // Оборачиваем в контейнер с отступом
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams wrapLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        wrapLp.bottomMargin = dp(8);
        wrapper.setLayoutParams(wrapLp);
        wrapper.addView(card);

        listContainer.addView(wrapper);
    }

    /** Карточка одного выбранного приложения */
    private void addAppCard(final int index, final String packageName) {
        // Получаем иконку и название
        PackageManager pm = getPackageManager();
        String appName = packageName;
        Drawable appIcon = null;
        try {
            ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
            appName = pm.getApplicationLabel(ai).toString();
            appIcon = pm.getApplicationIcon(ai);
        } catch (Exception ignored) {}

        // Обёртка для карточки + индикатор выбора
        LinearLayout rowWrapper = new LinearLayout(this);
        rowWrapper.setOrientation(LinearLayout.HORIZONTAL);
        rowWrapper.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams wrapLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        wrapLp.bottomMargin = dp(8);
        rowWrapper.setLayoutParams(wrapLp);

        // Индикатор выбора (круг), изначально скрыт
        View checkView = new View(this);
        int chkSz = dp(22);
        LinearLayout.LayoutParams chkLp = new LinearLayout.LayoutParams(chkSz, chkSz);
        chkLp.rightMargin = dp(10);
        chkLp.gravity = Gravity.CENTER_VERTICAL;
        checkView.setLayoutParams(chkLp);
        checkView.setBackground(getResources().getDrawable(R.drawable.bg_app_check_off));
        checkView.setVisibility(View.GONE);
        rowWrapper.addView(checkView);
        checkViews.add(checkView);

        // Сама карточка
        LinearLayout card = makeCardView();
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        card.setLayoutParams(cardLp);
        innerCards.add(card);

        // Иконка приложения
        if (appIcon != null) {
            ImageView iconView = new ImageView(this);
            int iconSz = dp(40);
            LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(iconSz, iconSz);
            iconLp.rightMargin = dp(12);
            iconView.setLayoutParams(iconLp);
            iconView.setImageDrawable(appIcon);
            iconView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            card.addView(iconView);
        } else {
            // Placeholder
            TextView ph = new TextView(this);
            ph.setText("📱");
            ph.setTextSize(22);
            int phSz = dp(40);
            LinearLayout.LayoutParams phLp = new LinearLayout.LayoutParams(phSz, phSz);
            phLp.rightMargin = dp(12);
            ph.setLayoutParams(phLp);
            ph.setGravity(Gravity.CENTER);
            card.addView(ph);
        }

        // Имя приложения
        final String finalAppName = appName;
        TextView nameView = new TextView(this);
        nameView.setText(finalAppName);
        nameView.setTextSize(14);
        nameView.setTextColor(0xFFFFFFFF);
        nameView.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        nameView.setLayoutParams(nameLp);
        nameView.setGravity(Gravity.CENTER_VERTICAL);
        nameView.setMaxLines(1);
        nameView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(nameView);

        rowWrapper.addView(card);
        cardViews.add(rowWrapper);

        // Клик по карточке в режиме удаления
        final int[] indexHolder = {index};
        rowWrapper.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (!deleteMode) return;
                int i = cardViews.indexOf(v);
                if (i < 0) return;
                toggleMark(i);
            }
        });

        listContainer.addView(rowWrapper);
    }

    /** Крест "+" из двух полосок, идеально отцентрованный (в отличие от текстового глифа). */
    private View makePlusCross(int colorArgb) {
        FrameLayout box = new FrameLayout(this);

        View hBar = new View(this);
        FrameLayout.LayoutParams hLp = new FrameLayout.LayoutParams(dp(14), dp(2));
        hLp.gravity = Gravity.CENTER;
        hBar.setLayoutParams(hLp);
        hBar.setBackgroundColor(colorArgb);
        box.addView(hBar);

        View vBar = new View(this);
        FrameLayout.LayoutParams vLp = new FrameLayout.LayoutParams(dp(2), dp(14));
        vLp.gravity = Gravity.CENTER;
        vBar.setLayoutParams(vLp);
        vBar.setBackgroundColor(colorArgb);
        box.addView(vBar);

        return box;
    }

    private LinearLayout makeCardView() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setBackground(getResources().getDrawable(R.drawable.bg_card));
        int padH = dp(14);
        int padV = dp(14);
        card.setPadding(padH, padV, padH, padV);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        card.setLayoutParams(lp);
        return card;
    }

    // ─── Выбор приложения ─────────────────────────────────────────────────

    private void openAppPicker() {
        Intent intent = new Intent(this, AppPickerActivity.class);
        // передаём уже выбранные пакеты, чтобы не показывать их повторно
        try {
            JSONArray arr = new JSONArray();
            for (String p : selectedPackages) arr.put(p);
            intent.putExtra("excluded", arr.toString());
        } catch (Exception ignored) {}
        startActivityForResult(intent, REQUEST_PICK_APP);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_PICK_APP && resultCode == RESULT_OK && data != null) {
            String pkg = data.getStringExtra("packageName");
            if (pkg != null && !pkg.isEmpty() && !selectedPackages.contains(pkg)) {
                selectedPackages.add(pkg);
                savePackages();
                rebuildList();
            }
        }
    }

    // ─── Режим удаления ───────────────────────────────────────────────────

    private void enterDeleteMode() {
        if (selectedPackages.isEmpty()) return;
        deleteMode = true;
        markedForDelete.clear();
        panelNormal.setVisibility(View.GONE);
        panelDeleteMode.setVisibility(View.VISIBLE);

        TextView btnConfirmDelete = (TextView) findViewById(R.id.btnConfirmDelete);
        TextView btnCancelDelete  = (TextView) findViewById(R.id.btnCancelDelete);
        if (btnConfirmDelete != null) btnConfirmDelete.setEnabled(true);
        if (btnCancelDelete  != null) btnCancelDelete.setEnabled(true);

        // Показываем индикаторы (без анимации покачивания)
        for (int i = 0; i < checkViews.size(); i++) {
            checkViews.get(i).setVisibility(View.VISIBLE);
        }
    }

    private void exitDeleteMode() {
        deleteMode = false;
        markedForDelete.clear();
        panelDeleteMode.setVisibility(View.GONE);
        panelNormal.setVisibility(View.VISIBLE);

        // Сбрасываем индикаторы
        for (int i = 0; i < checkViews.size(); i++) {
            checkViews.get(i).setVisibility(View.GONE);
            checkViews.get(i).setBackground(
                getResources().getDrawable(R.drawable.bg_app_check_off));
        }
        // Сбрасываем подсветку карточек
        for (int i = 0; i < cardViews.size(); i++) {
            resetCardStyle(i);
        }
    }

    private void confirmDelete() {
        if (markedForDelete.isEmpty()) {
            Toast.makeText(this, "Выберите приложения для удаления", Toast.LENGTH_SHORT).show();
            return;
        }

        final TextView btnConfirmDelete = (TextView) findViewById(R.id.btnConfirmDelete);
        final TextView btnCancelDelete  = (TextView) findViewById(R.id.btnCancelDelete);
        if (btnConfirmDelete != null) btnConfirmDelete.setEnabled(false);
        if (btnCancelDelete  != null) btnCancelDelete.setEnabled(false);

        // Удаляем в обратном порядке, чтобы индексы не съехали
        final List<Integer> sorted = new ArrayList<>(markedForDelete);
        Collections.sort(sorted, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return b - a; }
        });

        // Сначала карточки красиво "улетают" в сторону и растворяются,
        // затем их высота плавно схлопывается до нуля (вместо мгновенного
        // рывка при removeView), и только после этого они пропадают
        // из списка/памяти.
        final int[] remaining = { 0 };
        for (int idx : sorted) {
            if (idx >= 0 && idx < cardViews.size()) remaining[0]++;
        }
        if (remaining[0] == 0) {
            finishDelete(sorted);
            return;
        }
        for (int idx : sorted) {
            if (idx < 0 || idx >= cardViews.size()) continue;
            final View row = cardViews.get(idx);
            row.animate()
                .alpha(0f)
                .scaleX(0.85f)
                .scaleY(0.85f)
                .translationX(dp(60))
                .setDuration(220)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .withEndAction(new Runnable() {
                    public void run() {
                        collapseHeight(row, new Runnable() {
                            public void run() {
                                remaining[0]--;
                                if (remaining[0] <= 0) {
                                    finishDelete(sorted);
                                }
                            }
                        });
                    }
                })
                .start();
        }
    }

    /**
     * Плавно схлопывает высоту строки до 0 перед её удалением из
     * listContainer — без этого LinearLayout мгновенно "схлопывает"
     * пустое место одним кадром, и соседние карточки резко прыгают
     * вниз (визуально похоже на "карточка уехала под низ интерфейса").
     */
    private void collapseHeight(final View row, final Runnable onDone) {
        final int startHeight = row.getHeight();
        if (startHeight <= 0) {
            onDone.run();
            return;
        }
        ViewGroup.LayoutParams lpRaw = row.getLayoutParams();
        if (!(lpRaw instanceof LinearLayout.LayoutParams)) {
            onDone.run();
            return;
        }
        final LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) lpRaw;
        ValueAnimator collapse = ValueAnimator.ofInt(startHeight, 0);
        collapse.setDuration(160);
        collapse.setInterpolator(new AccelerateDecelerateInterpolator());
        collapse.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator animation) {
                lp.height = (Integer) animation.getAnimatedValue();
                row.setLayoutParams(lp);
            }
        });
        collapse.addListener(new android.animation.AnimatorListenerAdapter() {
            public void onAnimationEnd(android.animation.Animator animation) {
                onDone.run();
            }
        });
        collapse.start();
    }

    /** Фактическое удаление из данных — вызывается после того, как карточки доанимировались. */
    private void finishDelete(List<Integer> sorted) {
        for (int idx : sorted) {
            if (idx >= 0 && idx < selectedPackages.size()) {
                selectedPackages.remove(idx);
            }
        }
        savePackages();
        deleteMode = false;
        rebuildList();
        // После пересборки списка возвращаем скролл к началу — иначе,
        // если список стал короче, ScrollView может остаться прокрученным
        // так, что видимые карточки "поджаты" под нижнюю панель кнопок.
        if (scrollList != null) {
            scrollList.post(new Runnable() {
                public void run() {
                    scrollList.scrollTo(0, 0);
                }
            });
        }
    }

    private void toggleMark(int index) {
        if (markedForDelete.contains(index)) {
            markedForDelete.remove(index);
            // Снять подсветку
            checkViews.get(index).setBackground(
                getResources().getDrawable(R.drawable.bg_app_check_off));
            resetCardStyle(index);
        } else {
            markedForDelete.add(index);
            // Подсветить красным — именно карточку, а не всю строку с кружком,
            // иначе красный фон "просвечивает" в зазоре вокруг индикатора.
            checkViews.get(index).setBackground(
                getResources().getDrawable(R.drawable.bg_app_check_on));
            innerCards.get(index).setBackground(
                getResources().getDrawable(R.drawable.bg_app_card_selected));
        }
    }

    private void resetCardStyle(int index) {
        // Возвращаем карточке её обычный (не выделенный) фон
        if (index < innerCards.size()) {
            innerCards.get(index).setBackground(
                getResources().getDrawable(R.drawable.bg_card));
        }
    }

    // ─── Утилиты ──────────────────────────────────────────────────────────

    private int dp(int val) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(val * density);
    }

    @Override
    public void onBackPressed() {
        if (deleteMode) {
            exitDeleteMode();
        } else {
            super.onBackPressed();
        }
    }
}
