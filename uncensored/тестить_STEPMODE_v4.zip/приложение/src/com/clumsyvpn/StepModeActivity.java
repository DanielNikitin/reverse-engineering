package com.clumsyvpn;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * StepModeActivity — экран «Пошаговый режим».
 *
 * Показывает карточки шагов конфигурации, позволяет добавлять новые шаги,
 * открывать окно настройки шага (StepEditDialog) и настраивать поведение
 * после завершения всех шагов (Сброс / Следующий шаг).
 *
 * Логика:
 *   Сброс          — всегда работает только шаг №1.
 *   Следующий шаг  — по истечении времени шага запускается следующий,
 *                     после последнего — цикл возвращается к первому.
 *
 * На этом экране переключение между шагами по времени визуализируется
 * подсветкой активной карточки — синхронно с длительностью каждого шага
 * ("Время до следующего шага").
 */
public class StepModeActivity extends Activity {

    public static final String EXTRA_CONFIG_INDEX = "config_index";

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    private ConfigsActivity.Config cfg;
    private int configIndex;

    private LinearLayout stepsContainer;
    private Button btnAfterReset, btnAfterNext;

    private AccountStatusMonitor accountStatusMonitor;

    // ── Визуализация переключения по таймеру внутри экрана ────────────────
    private final Handler stepTimerHandler = new Handler();
    private int activeStepIndex = 0;
    private Runnable stepTimerRunnable;
    private boolean timersRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        accountStatusMonitor = new AccountStatusMonitor(this);

        configIndex = getIntent().getIntExtra(EXTRA_CONFIG_INDEX, -1);
        if (configIndex < 0 || configIndex >= ConfigsActivity.configs.size()) {
            Toast.makeText(this, "Ошибка: конфиг не найден", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        cfg = ConfigsActivity.configs.get(configIndex);
        if (cfg.steps == null) cfg.steps = new ArrayList<ConfigsActivity.Step>();
        if (cfg.steps.isEmpty()) cfg.steps.add(new ConfigsActivity.Step());

        setContentView(buildLayout());
        refreshSteps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
        stopStepTimers();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopStepTimers();
    }

    // ════════════════════════════════════════════════════════════════════
    //  LAYOUT
    // ════════════════════════════════════════════════════════════════════

    private View buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF030507);
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));
        root.addView(buildHeader());
        root.addView(divider());
        root.addView(buildScrollArea());
        return root;
    }

    private View buildHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(14), 0, dp(18), 0);
        h.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(64)));

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(26);
        back.setTypeface(null, Typeface.BOLD);
        back.setTextColor(0xFF00FF9D);
        back.setGravity(Gravity.CENTER);
        back.setBackgroundResource(R.drawable.bg_header_icon);
        back.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        tlp.leftMargin = dp(12);
        titleBox.setLayoutParams(tlp);

        TextView title = new TextView(this);
        title.setText(cfg.name.toUpperCase());
        title.setTextSize(14);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.22f);
        title.setShadowLayer(10, 0, 0, 0xFF00CFFF);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);

        TextView subtitle = new TextView(this);
        subtitle.setText("// STEP MODE");
        subtitle.setTextSize(9);
        subtitle.setTextColor(0xFFFF1E4E);
        subtitle.setTypeface(Typeface.MONOSPACE);
        subtitle.setLetterSpacing(0.2f);

        titleBox.addView(title);
        titleBox.addView(subtitle);

        View rightSpacer = new View(this);
        rightSpacer.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));

        h.addView(back);
        h.addView(titleBox);
        h.addView(rightSpacer);
        return h;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(0xFF1A2430);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(1)));
        return v;
    }

    private View buildScrollArea() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(20), dp(18), dp(24));
        form.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        stepsContainer = new LinearLayout(this);
        stepsContainer.setOrientation(LinearLayout.VERTICAL);
        stepsContainer.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        form.addView(stepsContainer);

        form.addView(spacer(16));
        form.addView(buildAddStepButton());
        form.addView(spacer(20));
        form.addView(buildAfterAllStepsRow());

        sv.addView(form);
        return sv;
    }

    private View buildAddStepButton() {
        TextView btn = new TextView(this);
        btn.setText("+ Добавить шаг");
        btn.setTextSize(15);
        btn.setTypeface(null, Typeface.BOLD);
        btn.setTextColor(0xFF00CFFF);
        btn.setShadowLayer(10, 0, 0, 0xFF00CFFF);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(12), 0, dp(12));
        btn.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                cfg.steps.add(new ConfigsActivity.Step());
                persist();
                refreshSteps();
            }
        });
        return btn;
    }

    private View buildAfterAllStepsRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView lbl = new TextView(this);
        lbl.setText("После завершения:");
        lbl.setTextSize(13);
        lbl.setTextColor(0xFF6C7885);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lbl.setLayoutParams(llp);
        row.addView(lbl);

        btnAfterReset = makeToggleBtn("Сброс");
        btnAfterNext  = makeToggleBtn("Следующий шаг");

        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(WRAP, dp(38));
        b1.rightMargin = dp(8);
        btnAfterReset.setLayoutParams(b1);
        btnAfterNext.setLayoutParams(new LinearLayout.LayoutParams(WRAP, dp(38)));

        btnAfterReset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { setAfterMode(0); }
        });
        btnAfterNext.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { setAfterMode(1); }
        });

        row.addView(btnAfterReset);
        row.addView(btnAfterNext);

        applyAfterModeStyle(cfg.stepsAfterMode);
        return row;
    }

    private Button makeToggleBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setTypeface(null, Typeface.BOLD);
        b.setTextColor(0xFFB8C4D0);
        b.setBackgroundResource(R.drawable.bg_secondary_btn);
        b.setStateListAnimator(null);
        b.setAllCaps(false);
        b.setPadding(dp(14), 0, dp(14), 0);
        return b;
    }

    private void setAfterMode(int mode) {
        cfg.stepsAfterMode = mode;
        persist();
        applyAfterModeStyle(mode);
        restartStepTimers();
    }

    private void applyAfterModeStyle(int mode) {
        if (btnAfterReset == null || btnAfterNext == null) return;
        int active   = 0xFF1A6FE0;
        int inactive = 0xFF1A2430;
        btnAfterReset.setBackgroundColor(mode == 0 ? active : inactive);
        btnAfterReset.setTextColor(mode == 0 ? 0xFFFFFFFF : 0xFFB8C4D0);
        btnAfterNext.setBackgroundColor(mode == 1 ? active : inactive);
        btnAfterNext.setTextColor(mode == 1 ? 0xFFFFFFFF : 0xFFB8C4D0);
    }

    // ════════════════════════════════════════════════════════════════════
    //  Карточки шагов
    // ════════════════════════════════════════════════════════════════════

    private void refreshSteps() {
        stepsContainer.removeAllViews();
        for (int i = 0; i < cfg.steps.size(); i++) {
            stepsContainer.addView(buildStepCard(i));
            if (i < cfg.steps.size() - 1) {
                stepsContainer.addView(spacer(12));
            }
        }
        restartStepTimers();
    }

    private View buildStepCard(final int index) {
        final ConfigsActivity.Step step = cfg.steps.get(index);

        final LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        card.setTag("step_card_" + index);

        // Индикатор номера шага (полоса слева)
        View bar = new View(this);
        bar.setBackgroundColor(0xFF00CFFF);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(dp(3), dp(38));
        barLp.rightMargin = dp(14);
        bar.setLayoutParams(barLp);
        card.addView(bar);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));

        TextView tvNum = new TextView(this);
        tvNum.setText("Шаг " + (index + 1));
        tvNum.setTextSize(12);
        tvNum.setTypeface(null, Typeface.BOLD);
        tvNum.setTextColor(0xFF6C7885);
        info.addView(tvNum);

        TextView tvSummary = new TextView(this);
        tvSummary.setText(summaryLine(step));
        tvSummary.setTextSize(14);
        tvSummary.setTypeface(null, Typeface.BOLD);
        tvSummary.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams sumLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        sumLp.topMargin = dp(2);
        tvSummary.setLayoutParams(sumLp);
        info.addView(tvSummary);

        TextView tvDuration = new TextView(this);
        tvDuration.setText("⏱ " + formatDurationSec(step.duration));
        tvDuration.setTextSize(12);
        tvDuration.setTextColor(0xFF6C7885);
        LinearLayout.LayoutParams durLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        durLp.topMargin = dp(3);
        tvDuration.setLayoutParams(durLp);
        info.addView(tvDuration);

        card.addView(info);

        // Кнопка удаления шага (только если шагов больше одного)
        if (cfg.steps.size() > 1) {
            TextView del = new TextView(this);
            del.setText("✕");
            del.setTextSize(16);
            del.setTypeface(null, Typeface.BOLD);
            del.setTextColor(0xFFFF5C7A);
            del.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(dp(36), dp(36));
            delLp.leftMargin = dp(6);
            del.setLayoutParams(delLp);
            del.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    cfg.steps.remove(index);
                    persist();
                    refreshSteps();
                }
            });
            card.addView(del);
        }

        // Иконка редактирования
        TextView edit = new TextView(this);
        edit.setText("✎");
        edit.setTextSize(18);
        edit.setTypeface(null, Typeface.BOLD);
        edit.setTextColor(0xFF00CFFF);
        edit.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams editLp = new LinearLayout.LayoutParams(dp(36), dp(36));
        editLp.leftMargin = dp(4);
        edit.setLayoutParams(editLp);
        card.addView(edit);

        View.OnClickListener openEditor = new View.OnClickListener() {
            public void onClick(View v) {
                new StepEditDialog(StepModeActivity.this, step, new StepEditDialog.OnSaveListener() {
                    public void onSave() {
                        persist();
                        refreshSteps();
                    }
                }).show();
            }
        };
        card.setOnClickListener(openEditor);
        edit.setOnClickListener(openEditor);

        highlightCard(card, index == activeStepIndex);
        return card;
    }

    private String summaryLine(ConfigsActivity.Step s) {
        return "К: " + s.clientDelay + "ms " + s.clientLoss + "%   С: " + s.serverDelay + "ms " + s.serverLoss + "%";
    }

    private String formatDurationSec(int durationMs) {
        int sec = durationMs / 1000;
        int frac = (durationMs % 1000) / 100;
        return sec + "," + frac + "s";
    }

    private void highlightCard(LinearLayout card, boolean active) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(12));
        if (active && timersRunning) {
            bg.setColor(0xFF0D1B24);
            bg.setStroke(dp(1), 0xFF00CFFF);
        } else {
            bg.setColor(0xFF0D1520);
        }
        card.setBackground(bg);
    }

    // ════════════════════════════════════════════════════════════════════
    //  Визуализация автопереключения между шагами на экране
    // ════════════════════════════════════════════════════════════════════

    /**
     * Перезапускает цикл подсветки карточек в соответствии с режимом "После завершения".
     * Сброс         — активной всегда остаётся только карточка шага №1 (без переключений).
     * Следующий шаг — карточки подсвечиваются по очереди согласно длительности каждого шага,
     *                 по кругу.
     */
    private void restartStepTimers() {
        stopStepTimers();
        if (cfg.steps.isEmpty()) return;

        activeStepIndex = 0;
        timersRunning = (cfg.stepsAfterMode == 1) && (cfg.steps.size() > 1);
        applyHighlightToAllCards();

        if (!timersRunning) return;
        scheduleNextStepAdvance();
    }

    private void scheduleNextStepAdvance() {
        if (cfg.steps.isEmpty()) return;
        ConfigsActivity.Step current = cfg.steps.get(activeStepIndex);
        long delayMs = Math.max(300, current.duration); // нижний порог для наглядности UI
        stepTimerRunnable = new Runnable() {
            public void run() {
                if (cfg.steps.isEmpty()) return;
                activeStepIndex = (activeStepIndex + 1) % cfg.steps.size();
                applyHighlightToAllCards();
                scheduleNextStepAdvance();
            }
        };
        stepTimerHandler.postDelayed(stepTimerRunnable, delayMs);
    }

    private void applyHighlightToAllCards() {
        for (int i = 0; i < stepsContainer.getChildCount(); i++) {
            View child = stepsContainer.getChildAt(i);
            Object tag = child.getTag();
            if (tag == null || !(child instanceof LinearLayout)) continue;
            String tagStr = tag.toString();
            if (!tagStr.startsWith("step_card_")) continue;
            int idx = Integer.parseInt(tagStr.substring("step_card_".length()));
            highlightCard((LinearLayout) child, idx == activeStepIndex);
        }
    }

    private void stopStepTimers() {
        if (stepTimerRunnable != null) {
            stepTimerHandler.removeCallbacks(stepTimerRunnable);
            stepTimerRunnable = null;
        }
        timersRunning = false;
    }

    // ════════════════════════════════════════════════════════════════════
    //  Сохранение
    // ════════════════════════════════════════════════════════════════════

    private void persist() {
        ConfigsActivity.saveConfigsStatic(this);
        pushLiveUpdateIfActive();
    }

    /**
     * Если этот конфиг сейчас установлен (installed) — сразу же обновляет
     * MainActivity.cur* поля и, если VPN уже запущен, пересылает свежие шаги
     * в MyVpnService и FloatService, чтобы изменения применялись «на лету»
     * без переоткрытия туннеля (как того требует ТЗ: «После сохранения
     * изменения сразу применяются к выбранной карточке»).
     */
    private void pushLiveUpdateIfActive() {
        if (!cfg.installed) return;

        String serialized = ConfigsActivity.serializeStepsStatic(cfg.steps);
        MainActivity.curConfigMode       = cfg.configMode;
        MainActivity.curStepsAfterMode   = cfg.stepsAfterMode;
        MainActivity.curStepsSerialized  = serialized;

        // Отправляем обновление в сервисы ТОЛЬКО если туннель уже реально работает —
        // иначе просто сохраняем в MainActivity.cur*, и настройки применятся
        // естественным образом при следующем запуске VPN.
        if (!MyVpnService.isTunnelActive) return;

        Intent vpnI = new Intent(this, MyVpnService.class);
        vpnI.setAction(MyVpnService.ACTION_START_STEP_MODE);
        vpnI.putExtra(MyVpnService.EXTRA_STEPS_SERIALIZED, serialized);
        try { startService(vpnI); } catch (Exception ignored) {}

        Intent flI = new Intent(this, FloatService.class);
        flI.setAction(FloatService.ACTION_START_STEP_MODE);
        flI.putExtra(FloatService.EXTRA_STEP_DURATIONS, extractStepDurations(serialized));
        flI.putExtra(FloatService.EXTRA_STEPS_AFTER_MODE, cfg.stepsAfterMode);
        flI.putExtra(FloatService.EXTRA_BTN_SIZE,  MainActivity.curBtnSize);
        flI.putExtra(FloatService.EXTRA_BTN_COLOR, MainActivity.curBtnColor);
        flI.putExtra(FloatService.EXTRA_BTN_ALPHA, MainActivity.curBtnAlpha);
        flI.putExtra(FloatService.EXTRA_COUNTER_ENABLED, MainActivity.curCounterEnabled);
        try { startService(flI); } catch (Exception ignored) {}
    }

    /** Извлекает длительности шагов (13-е поле) из строки serializeStepsStatic() в формат "3000,5000,2000" */
    private String extractStepDurations(String stepsSerialized) {
        if (stepsSerialized == null || stepsSerialized.isEmpty()) return "";
        StringBuilder out = new StringBuilder();
        for (String step : stepsSerialized.split(";")) {
            if (step.isEmpty()) continue;
            String[] f = step.split(",");
            if (f.length < 13) continue;
            if (out.length() > 0) out.append(",");
            out.append(f[12]);
        }
        return out.toString();
    }

    // ── helpers ───────────────────────────────────────────────────────────
    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private View spacer(int dpVal) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(dpVal)));
        return v;
    }
}
