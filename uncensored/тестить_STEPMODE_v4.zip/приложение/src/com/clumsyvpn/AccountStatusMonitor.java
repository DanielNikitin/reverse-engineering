package com.clumsyvpn;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;

/**
 * Общий периодический опрос бана / деактивации / удаления ключа.
 *
 * Раньше эту проверку умела делать только MainActivity (heartbeat каждые
 * 15 секунд, пока пользователь на главном экране). Из-за этого наказание
 * (бан, деактивация, удаление ключа), выданное администратором, применялось
 * СРАЗУ только если пользователь в этот момент находился именно в главном
 * меню. Если он был в настройках, чате, кастомизации и т.д. — MainActivity
 * была на паузе и heartbeat не выполнялся, поэтому пользователь продолжал
 * пользоваться приложением, пока сам не вернётся на главный экран или не
 * перезапустит приложение.
 *
 * Этот класс инкапсулирует ту же самую проверку (используя уже
 * существующий KeyStatusChecker.check(...)) так, чтобы её можно было
 * запускать из onResume()/onPause() ЛЮБОЙ активности приложения — тогда
 * наказание применяется независимо от того, на каком экране находится
 * пользователь.
 *
 * Использование в активности:
 *
 *   private AccountStatusMonitor statusMonitor;
 *
 *   onCreate:  statusMonitor = new AccountStatusMonitor(this);
 *   onResume:  statusMonitor.start();
 *   onPause:   statusMonitor.stop();
 */
public class AccountStatusMonitor {

    private static final long INTERVAL_MS = 15000;

    private final Activity activity;
    private final Handler handler = new Handler();
    private Runnable runnable;

    public AccountStatusMonitor(Activity activity) {
        this.activity = activity;
    }

    public void start() {
        if (runnable != null) return; // уже запущено

        final SharedPreferences prefs = activity.getSharedPreferences(AuthActivity.PREFS, Activity.MODE_PRIVATE);
        final String login = prefs.getString(AuthActivity.KEY_LOGIN, "");
        if ("admin".equals(login) || login.isEmpty()) return; // admin никогда не банится/не удаляется

        final String deviceId = getDeviceId(prefs);

        runnable = new Runnable() {
            public void run() {
                checkNow(login, deviceId);
                handler.postDelayed(this, INTERVAL_MS);
            }
        };
        // Проверяем сразу же при входе на экран, не дожидаясь первого
        // интервала — иначе первые 15 секунд на новом экране пользователь
        // всё ещё "защищён" старой активностью.
        handler.post(runnable);
    }

    public void stop() {
        if (handler != null && runnable != null) {
            handler.removeCallbacks(runnable);
        }
        runnable = null;
    }

    private String getDeviceId(SharedPreferences prefs) {
        try {
            String androidId = android.provider.Settings.Secure.getString(
                activity.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
            if (androidId != null && !androidId.isEmpty() && !androidId.equals("9774d56d682e549c")) {
                return androidId;
            }
        } catch (Exception ignored) {}
        return prefs.getString("device_id", "");
    }

    private void checkNow(final String login, final String deviceId) {
        KeyStatusChecker.check(activity, login, deviceId, new KeyStatusChecker.ResultCallback() {
            public void onResult(String status, String reason) {
                if (activity.isFinishing()) return;
                if ("deactivated".equals(status)) {
                    setLoggedOut();
                    Intent intent = new Intent(activity, AuthActivity.class);
                    intent.putExtra("deactivated_reason", reason);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    activity.startActivity(intent);
                } else if ("key_deleted".equals(status)) {
                    setLoggedOut();
                    Intent intent = new Intent(activity, AuthActivity.class);
                    intent.putExtra("key_deleted_reason", reason);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    activity.startActivity(intent);
                } else if ("key_expired".equals(status)) {
                    setLoggedOut();
                    Intent intent = new Intent(activity, AuthActivity.class);
                    intent.putExtra("key_expired", true);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    activity.startActivity(intent);
                }
                // "banned" обрабатывается в onBanned(...) ниже — там есть срок и причина
            }

            public void onBanned(String until, String reason, String userId, String keyValue, int keyMaxDevices,
                                  boolean selfBanned, String bannedLogin, String bannedUserId) {
                if (activity.isFinishing()) return;
                setLoggedOut();
                if (selfBanned) {
                    Intent banIntent = new Intent(activity, BannedActivity.class);
                    banIntent.putExtra(BannedActivity.EXTRA_LOGIN,   login);
                    banIntent.putExtra(BannedActivity.EXTRA_USER_ID, userId != null ? userId : "");
                    banIntent.putExtra(BannedActivity.EXTRA_UNTIL,   until != null ? until : "");
                    banIntent.putExtra(BannedActivity.EXTRA_REASON,  reason != null ? reason : "");
                    banIntent.putExtra(BannedActivity.EXTRA_KEY_VALUE, keyValue != null ? keyValue : "");
                    banIntent.putExtra(BannedActivity.EXTRA_KEY_MAX_DEVICES, keyMaxDevices);
                    banIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    activity.startActivity(banIntent);
                } else {
                    // Ключ заблокирован не из-за бана ЭТОГО аккаунта, а из-за
                    // бана другого (например, старого) логина на этом же
                    // устройстве/ключе — выкидываем на экран регистрации.
                    Intent intent = new Intent(activity, AuthActivity.class);
                    intent.putExtra("account_banned_login",  bannedLogin != null ? bannedLogin : "");
                    intent.putExtra("account_banned_userId", bannedUserId != null ? bannedUserId : "");
                    intent.putExtra("account_banned_reason", reason != null ? reason : "");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    activity.startActivity(intent);
                }
            }

            private void setLoggedOut() {
                activity.getSharedPreferences(AuthActivity.PREFS, Activity.MODE_PRIVATE)
                    .edit()
                    .putBoolean(AuthActivity.KEY_LOGGED_IN, false)
                    .apply();
            }
        });
    }
}
