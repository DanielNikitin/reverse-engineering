package com.clumsyvpn;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.util.Log;
import android.widget.Toast;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class AuthActivity extends Activity {

    // ==== ВСТАВЬТЕ ВАШ URL СЕРВЕРА СЮДА ====
    public static final String SERVER_URL = "https://galaxy-clumsy-production-29c9.up.railway.app";

    public static final String PREFS          = "cvpn_auth";
    public static final String KEY_LOGGED_IN  = "logged_in";
    public static final String KEY_LOGIN      = "user_login";
    public static final String KEY_PASSWORD   = "user_password";
    public static final String KEY_CREATED_AT = "user_created_at";
    public static final String KEY_USER_ID    = "user_id";

    // Привязка Telegram — флаг и данные относятся к УСТРОЙСТВУ (а не к
    // конкретному аккаунту): один раз пройдя привязку на этом устройстве,
    // пользователь больше не видит диалог Telegram для последующих
    // регистраций/входов с того же устройства. Сервер при этом всё равно
    // самостоятельно перепроверяет привязку для каждого запроса.
    public static final String KEY_TG_VERIFIED   = "telegram_verified_device";
    public static final String KEY_TG_ID         = "telegram_id";
    public static final String KEY_TG_USERNAME   = "telegram_username";
    public static final String KEY_TG_FIRSTNAME  = "telegram_first_name";
    // Последнее изменение ника/юзернейма: JSON-строка {old, new} или пустая
    public static final String KEY_TG_PREV_USERNAME   = "telegram_prev_username";
    public static final String KEY_TG_PREV_FIRSTNAME  = "telegram_prev_first_name";

    private LinearLayout panelRegister, panelLogin;
    private EditText etRegLogin, etRegPwd, etRegPwd2;
    private EditText etLoginLogin, etLoginPwd;
    private Button   btnRegister, btnLogin;
    private TextView tvMode, tvSwitchToLogin, tvSwitchToRegister;

    // ── Вход: ошибки в UI ──────────────────
    private TextView tvLoginNotFound;   // между полем логина и паролем
    private TextView tvLoginWrongPwd;   // между полем пароля и кнопкой
    private TextView tvLoginError;      // устаревший (совместимость, скрыт)

    // ── Регистрация: ошибки / статус ───────
    private TextView tvRegLoginError;   // «Логин занят» между логином и паролем
    private TextView tvPwdStrength;     // под полем пароля

    private View bgView;
    private Handler bgHandler = new Handler();
    private int bgStep = 0;

    private static final int[] BG_COLORS = {
        0xFF030507, 0xFF050A12, 0xFF070C0E,
        0xFF080A04, 0xFF0A0507, 0xFF060410,
    };

    private final Runnable bgAnimRunnable = new Runnable() {
        public void run() {
            if (bgView == null) return;
            int from = BG_COLORS[bgStep % BG_COLORS.length];
            int to   = BG_COLORS[(bgStep + 1) % BG_COLORS.length];
            bgStep++;
            animateBgColor(from, to);
            bgHandler.postDelayed(this, 2800);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Проверяем, не отключено ли приложение администратором, ДО того как
        // показывать форму входа/регистрации или пытаться авто-войти. Раньше
        // эта проверка была только в MainActivity — то есть уже вошедшие
        // пользователи блокировались, а новые/разлогиненные могли свободно
        // регистрироваться и входить, даже когда приложение "выключено".
        // Также: если сервер вообще недоступен (сеть, авария, заблокирован
        // DNS и т.п.) — считаем это тем же самым, что и намеренное отключение,
        // т.к. без сервера приложение всё равно не может ничего проверить.
        checkAppDisabledOrUnreachable();

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.getBoolean(KEY_LOGGED_IN, false)) {
            // Перед тем как пускать пользователя в MainActivity по сохранённой
            // локальной сессии — спрашиваем сервер, не деактивирован ли он и не
            // удалён ли его ключ. Это покрывает случай, когда приложение было
            // полностью закрыто (heartbeat не работал) и ключ удалили в это время:
            // без этой проверки человек просто открывал бы приложение и оставался
            // залогинен, хотя ключ уже недействителен.
            final String myLogin = prefs.getString(KEY_LOGIN, "");
            final String myDeviceId = getDeviceId();
            setContentView(R.layout.activity_auth);
            initViews();

            final StartupCheckDialog checkDialog = StartupCheckDialog.show(this);

            KeyStatusChecker.checkStartup(this, myLogin, myDeviceId,
                new KeyStatusChecker.StageListener() {
                    public void onStage(String stageText) {
                        checkDialog.setStage(stageText);
                    }
                },
                new KeyStatusChecker.ResultCallback() {
                public void onResult(String status, String reason) {
                    if ("ok".equals(status)) {
                        // Фоново обновляем TG-данные с сервера при каждом запуске.
                        // Это покрывает случай когда пользователь уже залогинен
                        // (автологин) — /login не вызывается, но данные могли
                        // измениться. Запрос асинхронный, не блокирует открытие.
                        final String autoLogin    = myLogin;
                        final String autoDeviceId = myDeviceId;
                        final String autoPassword = getSharedPreferences(PREFS, MODE_PRIVATE)
                            .getString(KEY_PASSWORD, "");
                        new Thread(new Runnable() {
                            public void run() {
                                try {
                                    String q = "\"";
                                    String body = "{" + q + "login" + q + ":" + q + esc(autoLogin) + q
                                        + "," + q + "password" + q + ":" + q + esc(autoPassword) + q
                                        + "," + q + "deviceId" + q + ":" + q + esc(autoDeviceId) + q + "}";
                                    String resp = httpPost(SERVER_URL + "/login", body);
                                    if (resp == null) return;
                                    final String srvFirstName     = extractField(resp, "tg_firstName");
                                    final String srvUsername      = extractField(resp, "tg_username");
                                    final String srvId            = extractField(resp, "tg_id");
                                    final String srvPrevFirstName = extractField(resp, "tg_prev_firstName");
                                    final String srvPrevUsername  = extractField(resp, "tg_prev_username");
                                    if (srvFirstName != null && !srvFirstName.isEmpty()) {
                                        SharedPreferences.Editor ed = getSharedPreferences(PREFS, MODE_PRIVATE).edit();
                                        ed.putString(KEY_TG_FIRSTNAME, srvFirstName);
                                        ed.putString(KEY_TG_USERNAME,  srvUsername  != null ? srvUsername  : "");
                                        ed.putString(KEY_TG_ID,        srvId        != null ? srvId        : "");
                                        if (srvPrevFirstName != null && !srvPrevFirstName.isEmpty())
                                            ed.putString(KEY_TG_PREV_FIRSTNAME, srvPrevFirstName);
                                        if (srvPrevUsername != null && !srvPrevUsername.isEmpty())
                                            ed.putString(KEY_TG_PREV_USERNAME, srvPrevUsername);
                                        ed.apply();
                                    }
                                } catch (Exception ignored) {}
                            }
                        }).start();
                        checkDialog.showSuccessAndDismiss(new Runnable() {
                            public void run() { openMain(); }
                        });
                    } else if ("deactivated".equals(status)) {
                        checkDialog.dismiss();
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_LOGGED_IN, false).apply();
                        showDeactivatedNotice(reason);
                    } else if ("key_deleted".equals(status)) {
                        checkDialog.dismiss();
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_LOGGED_IN, false).apply();
                        KeyDeletedDialog.show(AuthActivity.this, reason, null);
                    } else if ("key_expired".equals(status)) {
                        checkDialog.dismiss();
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_LOGGED_IN, false).apply();
                        KeyExpiredDialog.show(AuthActivity.this, null);
                    } else if ("account_deleted".equals(status) || "no_key".equals(status)) {
                        // Аккаунта больше нет в системе, либо по нему вообще не
                        // найдено ни одного ключа (например, после обновления
                        // сервера) — без отдельного диалога, просто разлогиниваем
                        // и остаёмся на экране входа.
                        checkDialog.dismiss();
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_LOGGED_IN, false).apply();
                    } else if (!"banned".equals(status)) {
                        checkDialog.dismiss();
                        openMain();
                    }
                    // "banned" обрабатывается в onBanned(...) ниже — там есть срок и причина
                }

                public void onBanned(String until, String reason, String userId, String keyValue, int keyMaxDevices,
                                      boolean selfBanned, String bannedLogin, String bannedUserId) {
                    checkDialog.dismiss();
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_LOGGED_IN, false).apply();
                    if (selfBanned) {
                        android.content.Intent banIntent = new android.content.Intent(AuthActivity.this, BannedActivity.class);
                        banIntent.putExtra(BannedActivity.EXTRA_LOGIN,  myLogin);
                        banIntent.putExtra(BannedActivity.EXTRA_USER_ID, userId != null ? userId : "");
                        banIntent.putExtra(BannedActivity.EXTRA_UNTIL,  until != null ? until : "");
                        banIntent.putExtra(BannedActivity.EXTRA_REASON, reason != null ? reason : "");
                        banIntent.putExtra(BannedActivity.EXTRA_KEY_VALUE, keyValue != null ? keyValue : "");
                        banIntent.putExtra(BannedActivity.EXTRA_KEY_MAX_DEVICES, keyMaxDevices);
                        startActivity(banIntent);
                    } else {
                        // Этот аккаунт сам не забанен — пострадал ключ из-за бана
                        // другого (например, старого) логина на этом же
                        // устройстве. Уже находимся на экране регистрации —
                        // просто показываем компактное уведомление.
                        AccountBannedNoticeDialog.show(AuthActivity.this,
                            bannedLogin != null ? bannedLogin : "",
                            bannedUserId != null ? bannedUserId : "",
                            reason, null);
                    }
                }
            });
            return;
        }

        setContentView(R.layout.activity_auth);
        initViews();

        // Show deactivation notice if redirected from MainActivity
        String deactivatedReason = getIntent().getStringExtra("deactivated_reason");
        if (deactivatedReason != null && !deactivatedReason.isEmpty()) {
            showDeactivatedNotice(deactivatedReason);
            // Убираем extra, чтобы при пересоздании Activity (поворот экрана и т.п.)
            // окно не показалось повторно из того же самого Intent.
            getIntent().removeExtra("deactivated_reason");
        }

        // Show key-deleted notice if redirected from MainActivity (key removed by admin)
        String keyDeletedReason = getIntent().getStringExtra("key_deleted_reason");
        if (keyDeletedReason != null) {
            KeyDeletedDialog.show(this, keyDeletedReason, null);
            getIntent().removeExtra("key_deleted_reason");
        }

        // Show key-expired notice if redirected from MainActivity
        if (getIntent().getBooleanExtra("key_expired", false)) {
            KeyExpiredDialog.show(this, null);
            getIntent().removeExtra("key_expired");
        }

        // Show "account banned" notice if redirected from MainActivity —
        // это случай, когда ТЕКУЩИЙ аккаунт сам не забанен, но пользовался
        // ключом, заблокированным из-за бана другого (например, старого)
        // логина на этом же устройстве (см. MainActivity.onBanned).
        String accountBannedLogin = getIntent().getStringExtra("account_banned_login");
        if (accountBannedLogin != null && !accountBannedLogin.isEmpty()) {
            String accountBannedUserId = getIntent().getStringExtra("account_banned_userId");
            String accountBannedReason = getIntent().getStringExtra("account_banned_reason");
            AccountBannedNoticeDialog.show(this, accountBannedLogin,
                accountBannedUserId != null ? accountBannedUserId : "",
                accountBannedReason, null);
            getIntent().removeExtra("account_banned_login");
            getIntent().removeExtra("account_banned_userId");
            getIntent().removeExtra("account_banned_reason");
        }
    }

    /**
     * Проверяет флаг "приложение отключено администратором" (/app-status),
     * а также саму доступность сервера. Админ (по сохранённому флагу
     * is_admin — тому же, что использует AppBlockedActivity для показа
     * кнопки "Выйти") не блокируется, чтобы не оказаться запертым вне
     * собственной админ-панели.
     */
    private void checkAppDisabledOrUnreachable() {
        final SharedPreferences prefsForCheck = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefsForCheck.getBoolean("is_admin", false)) return;
        final String serverUrl = SERVER_URL;
        new Thread(new Runnable() {
            public void run() {
                boolean shouldBlock = false;
                try {
                    java.net.URL url = new java.net.URL(serverUrl + "/app-status");
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    java.io.BufferedReader br = new java.io.BufferedReader(
                        new java.io.InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    conn.disconnect();
                    if (sb.toString().contains("\"appDisabled\":true")) {
                        shouldBlock = true;
                    }
                } catch (Exception e) {
                    // Сервер недоступен — по требованию считаем это тем же
                    // самым, что и намеренное отключение приложения.
                    shouldBlock = true;
                }
                if (shouldBlock) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            android.content.Intent intent =
                                new android.content.Intent(AuthActivity.this, AppBlockedActivity.class);
                            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
                                | android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            finish();
                        }
                    });
                }
            }
        }).start();
    }

    /**
     * Показывает окно "ключ деактивирован" в едином стиле с окном удаления ключа:
     * причина — крупно сверху, поясняющая фраза — снизу.
     */
    private void showDeactivatedNotice(final String reason) {
        final String myLogin   = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_LOGIN, "");
        final String myDeviceId = getDeviceId();
        KeyNoticeDialog.show(
            this,
            "⏸",
            reason,
            "Ваш ключ деактивирован администратором.",
            null,
            0xFFFF6B00,
            new KeyNoticeDialog.Callback() {
                public void onOk() {
                    // Подтверждаем серверу что пользователь увидел окно деактивации.
                    // После этого heartbeat перестанет его выкидывать повторно.
                    new Thread(new Runnable() {
                        public void run() {
                            try {
                                String body = "{\"login\":\"" + myLogin + "\","
                                    + "\"deviceId\":\"" + myDeviceId + "\"}";
                                java.net.URL url = new java.net.URL(SERVER_URL + "/keys/deactivated-ack");
                                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                                conn.setRequestMethod("POST");
                                conn.setRequestProperty("Content-Type", "application/json");
                                conn.setDoOutput(true);
                                conn.setConnectTimeout(5000);
                                conn.setReadTimeout(5000);
                                conn.getOutputStream().write(body.getBytes("UTF-8"));
                                conn.getResponseCode();
                                conn.disconnect();
                            } catch (Exception ignored) {}
                        }
                    }).start();
                }
            }
        );
    }

    /**
     * Инициализация полей экрана авторизации и обработчиков. Вынесено в отдельный
     * метод, потому что вызывается из двух мест в onCreate: при обычном открытии
     * экрана и при автологине по сохранённой сессии (там экран показывается на
     * время асинхронной проверки статуса ключа).
     */
    private void initViews() {
        bgView             = findViewById(R.id.authBg);
        panelRegister      = (LinearLayout) findViewById(R.id.panelRegister);
        panelLogin         = (LinearLayout) findViewById(R.id.panelLogin);
        tvMode             = (TextView) findViewById(R.id.tvAuthMode);
        tvSwitchToLogin    = (TextView) findViewById(R.id.tvSwitchToLogin);
        tvSwitchToRegister = (TextView) findViewById(R.id.tvSwitchToRegister);
        tvLoginError       = (TextView) findViewById(R.id.tvLoginError);

        // Поля регистрации
        etRegLogin  = (EditText) findViewById(R.id.etRegLogin);
        etRegPwd    = (EditText) findViewById(R.id.etRegPwd);
        etRegPwd2   = (EditText) findViewById(R.id.etRegPwd2);
        btnRegister = (Button)   findViewById(R.id.btnRegister);

        // UI-ошибки регистрации
        tvRegLoginError = (TextView) findViewById(R.id.tvRegLoginError);
        tvPwdStrength   = (TextView) findViewById(R.id.tvPwdStrength);

        // Поля входа
        etLoginLogin  = (EditText) findViewById(R.id.etLoginLogin);
        etLoginPwd    = (EditText) findViewById(R.id.etLoginPwd);
        btnLogin      = (Button)   findViewById(R.id.btnLogin);

        // UI-ошибки входа
        tvLoginNotFound  = (TextView) findViewById(R.id.tvLoginNotFound);
        tvLoginWrongPwd  = (TextView) findViewById(R.id.tvLoginWrongPwd);

        bgHandler.post(bgAnimRunnable);
        showRegister();

        // ── Кнопки ─────────────────────────────────────────────
        btnRegister.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Сначала проверяем регистрацию, ключ показываем только после успеха
                doRegister();
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Сначала проверяем вход, ключ показываем только после успеха
                doLogin();
            }
        });
        tvSwitchToLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showLogin(); }
        });
        tvSwitchToRegister.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showRegister(); }
        });

        // ── TextWatcher: сила пароля при регистрации ───────────
        etRegPwd.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) {
                updatePasswordStrength(s.toString());
            }
        });

        // ── TextWatcher: сброс ошибки «Аккаунт не найден» при вводе логина ──
        etLoginLogin.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) {
                hideView(tvLoginNotFound);
            }
        });

        // ── TextWatcher: сброс ошибки «Неверный пароль» при вводе пароля ──
        etLoginPwd.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) {
                hideView(tvLoginWrongPwd);
            }
        });

        // ── TextWatcher: сброс ошибки «Логин занят» при изменении логина ──
        etRegLogin.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            public void afterTextChanged(Editable s) {
                hideView(tvRegLoginError);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bgHandler.removeCallbacks(bgAnimRunnable);
    }

    // ══════════════════════════════════════════════════
    //  ПЕРЕКЛЮЧЕНИЕ ЭКРАНОВ
    // ══════════════════════════════════════════════════
    private void showRegister() {
        tvMode.setText("РЕГИСТРАЦИЯ");
        panelRegister.setVisibility(View.VISIBLE);
        panelLogin.setVisibility(View.GONE);
        tvSwitchToLogin.setVisibility(View.VISIBLE);
        if (tvSwitchToRegister != null) tvSwitchToRegister.setVisibility(View.GONE);
        hideView(tvRegLoginError);
        hideView(tvPwdStrength);
    }

    private void showLogin() {
        tvMode.setText("ВХОД");
        panelRegister.setVisibility(View.GONE);
        panelLogin.setVisibility(View.VISIBLE);
        tvSwitchToLogin.setVisibility(View.GONE);
        if (tvSwitchToRegister != null) tvSwitchToRegister.setVisibility(View.VISIBLE);
        hideView(tvLoginNotFound);
        hideView(tvLoginWrongPwd);
        if (tvLoginError != null) tvLoginError.setVisibility(View.GONE);
    }

    // ══════════════════════════════════════════════════
    //  DEVICE ID
    // ══════════════════════════════════════════════════
    private String getDeviceId() {
        try {
            String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            if (androidId != null && !androidId.isEmpty() && !androidId.equals("9774d56d682e549c")) {
                return androidId;
            }
        } catch (Exception ignored) {}
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String saved = prefs.getString("device_id", "");
        if (!saved.isEmpty()) return saved;
        String generated = "dev_" + Long.toHexString(Double.doubleToLongBits(Math.random()));
        prefs.edit().putString("device_id", generated).apply();
        return generated;
    }

    // ══════════════════════════════════════════════════
    //  РЕГИСТРАЦИЯ
    // ══════════════════════════════════════════════════
    private void doRegister() {
        final String login = etRegLogin.getText().toString().trim();
        final String pwd1  = etRegPwd.getText().toString();
        final String pwd2  = etRegPwd2.getText().toString();

        // ── Шаг 1: локальная валидация ─────────────────────────────────────
        if (login.isEmpty() || pwd1.isEmpty() || pwd2.isEmpty()) { toast("Заполните все поля"); return; }
        if (login.length() < 3) { toast("Логин минимум 3 символа"); return; }
        if (pwd1.length() < 6)  { toast("Пароль минимум 6 символов"); return; }
        if (calcStrength(pwd1) < 1) { toast("Пароль слишком слабый — используй буквы и цифры"); return; }
        if (!pwd1.equals(pwd2)) { toast("Пароли не совпадают"); return; }

        // ── Шаг 2: pre-check на сервере — ДО Telegram-диалога ──────────────
        // Пользователь узнаёт о бане или занятом логине сразу, без лишних
        // всплывающих окон.
        btnRegister.setEnabled(false);
        hideView(tvRegLoginError);
        final String deviceId = getDeviceId();
        new Thread(new Runnable() {
            public void run() {
                try {
                    String preBody = "{\"login\":\"" + esc(login) + "\",\"deviceId\":\"" + esc(deviceId) + "\"}";
                    final String preResp = httpPost(SERVER_URL + "/pre-check", preBody);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            if (preResp == null) {
                                toast("Ошибка соединения с сервером");
                                btnRegister.setEnabled(true);
                                return;
                            }
                            if (preResp.contains("\"device_banned\"") || preResp.contains("\"perm_banned\"")) {
                                String msg = extractField(preResp, "message");
                                if (msg == null || msg.isEmpty()) msg = "У вас есть активный бан. Создавать новые аккаунты запрещено.";
                                showText(tvRegLoginError, msg, 0xFFFF1E4E);
                                btnRegister.setEnabled(true);
                                return;
                            }
                            if (preResp.contains("\"already_exists\"")) {
                                showText(tvRegLoginError, "Логин уже занят", 0xFFFF1E4E);
                                btnRegister.setEnabled(true);
                                return;
                            }
                            if (!preResp.contains("\"ok\"")) {
                                String msg = extractField(preResp, "message");
                                toast(msg != null ? msg : "Ошибка проверки");
                                btnRegister.setEnabled(true);
                                return;
                            }
                            // ── Шаг 3: pre-check прошёл — теперь Telegram (если нужно) ──
                            if (isTelegramVerifiedOnThisDevice()) {
                                doRegisterWithKey(login, pwd1, deviceId);
                            } else {
                                TelegramLinkDialog.show(AuthActivity.this, deviceId, new TelegramLinkDialog.Callback() {
                                    public void onVerified(String telegramId, String username, String firstName) {
                                        saveTelegramVerified(telegramId, username, firstName);
                                        doRegisterWithKey(login, pwd1, deviceId);
                                    }
                                    public void onCancelled() {
                                        btnRegister.setEnabled(true);
                                    }
                                });
                            }
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            toast("Ошибка соединения с сервером");
                            btnRegister.setEnabled(true);
                        }
                    });
                }
            }
        }).start();
    }

    private boolean isTelegramVerifiedOnThisDevice() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_TG_VERIFIED, false);
    }

    private void saveTelegramVerified(String telegramId, String username, String firstName) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String safeUsername  = username  != null ? username  : "";
        String safeFirstName = firstName != null ? firstName : "";

        // Фиксируем предыдущие значения, если они изменились
        String prevUsername  = prefs.getString(KEY_TG_USERNAME,  "");
        String prevFirstName = prefs.getString(KEY_TG_FIRSTNAME, "");

        SharedPreferences.Editor ed = prefs.edit()
            .putBoolean(KEY_TG_VERIFIED, true)
            .putString(KEY_TG_ID,        telegramId != null ? telegramId : "")
            .putString(KEY_TG_USERNAME,  safeUsername)
            .putString(KEY_TG_FIRSTNAME, safeFirstName);

        // Сохраняем «предыдущее» только если значение реально изменилось
        // и предыдущее не пустое — чтобы не показывать пустое «→ новое».
        if (!prevUsername.isEmpty() && !prevUsername.equals(safeUsername)) {
            ed.putString(KEY_TG_PREV_USERNAME, prevUsername);
        }
        if (!prevFirstName.isEmpty() && !prevFirstName.equals(safeFirstName)) {
            ed.putString(KEY_TG_PREV_FIRSTNAME, prevFirstName);
        }

        ed.apply();
    }

    /** Никнейм для приветствия/конфетти: предпочитаем имя (firstName), иначе @username. */
    private String getTelegramDisplayName() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String username  = p.getString(KEY_TG_USERNAME, "");
        String firstName = p.getString(KEY_TG_FIRSTNAME, "");
        if (!firstName.isEmpty()) return firstName;
        if (!username.isEmpty()) return "@" + username;
        return "друг";
    }

    /**
     * Вызывается из handleRegisterResponse когда сервер вернул telegram_required
     * (локальный флаг устарел). Pre-check уже был пройден ранее в doRegister(),
     * поэтому здесь просто сразу переходим к вводу ключа.
     */
    private void doRegisterAfterTelegram() {
        final String login    = etRegLogin.getText().toString().trim();
        final String pwd1     = etRegPwd.getText().toString();
        final String deviceId = getDeviceId();
        if (login.isEmpty() || pwd1.isEmpty()) { toast("Заполните все поля"); return; }
        doRegisterWithKey(login, pwd1, deviceId);
    }

    /** Показывает KeyInputDialog и выполняет финальный POST /register. */
    private void doRegisterWithKey(final String login, final String pwd1, final String deviceId) {
        KeyInputDialog.show(AuthActivity.this, deviceId, login, new KeyInputDialog.Callback() {
            public void onKeyAccepted(final String key) {
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            String body = "{\"login\":\"" + esc(login) + "\",\"password\":\"" + esc(pwd1)
                                + "\",\"deviceId\":\"" + esc(deviceId) + "\",\"key\":\"" + esc(key) + "\"}";
                            String response = httpPost(SERVER_URL + "/register", body);
                            handleRegisterResponse(response, login, pwd1, key);
                        } catch (Exception e) {
                            Log.e("AUTH", "Register error: " + e.getClass().getSimpleName() + ": " + e.getMessage(), e);
                            final String errMsg = buildErrorMessage(e);
                            showErrorUI(errMsg);
                        }
                    }
                }).start();
            }
            public void onCancelled() {
                btnRegister.setEnabled(true);
            }
        });
    }

    private void handleRegisterResponse(final String response, final String login, final String password, final String key) {
        runOnUiThread(new Runnable() {
            public void run() {
                btnRegister.setEnabled(true);
                if (response == null) { toast("Ошибка соединения с сервером"); return; }

                if (response.contains("\"status\":\"telegram_required\"")) {
                    // Сервер не нашёл подтверждённую привязку Telegram для этого
                    // устройства (например, локальный флаг устарел) — сбрасываем
                    // его и заново показываем привязку.
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_TG_VERIFIED, false).apply();
                    TelegramLinkDialog.show(AuthActivity.this, getDeviceId(), new TelegramLinkDialog.Callback() {
                        public void onVerified(String telegramId, String username, String firstName) {
                            saveTelegramVerified(telegramId, username, firstName);
                            doRegisterAfterTelegram();
                        }
                        public void onCancelled() {}
                    });
                } else if (response.contains("\"status\":\"device_banned\"") || response.contains("\"status\":\"perm_banned\"")) {
                    String msg = extractField(response, "message");
                    if (msg == null || msg.isEmpty()) {
                        msg = "У вас есть активный бан, из-за которого вам запрещено создавать новые аккаунты.";
                    }
                    showText(tvRegLoginError, msg, 0xFFFF1E4E);
                } else if (response.contains("already_exists") || response.contains("Логин уже занят")) {
                    showText(tvRegLoginError, "Логин занят", 0xFFFF1E4E);
                } else if (response.contains("short_password") || response.contains("Пароль слишком короткий")) {
                    toast("Пароль слишком короткий");
                } else if (response.contains("\"key_not_found\"") || response.contains("Ключ не найден")) {
                    toast("Ключ не найден");
                } else if (response.contains("\"key_deleted\"")) {
                    toast("Ключ был удалён администратором");
                } else if (response.contains("\"key_expired\"") || response.contains("истёк")) {
                    toast("Срок действия ключа истёк");
                } else if (response.contains("\"deactivated\"")) {
                    toast("Ключ деактивирован администратором");
                } else if (response.contains("\"ok\"") || response.contains("success") || response.contains("registered")) {
                    // Регистрация и ключ подтверждены — сохраняем сессию
                    final String createdAt = extractField(response, "created_at");
                    final String regUserId = extractField(response, "user_id");
                    final String deviceId = getDeviceId();
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putBoolean(KEY_LOGGED_IN, true)
                        .putString(KEY_LOGIN, login)
                        .putString(KEY_PASSWORD, password)
                        .putString(KEY_CREATED_AT, createdAt != null ? createdAt : "")
                        .apply();
                    // Привязываем логин и userId к ключу на сервере
                    new Thread(new Runnable() {
                        public void run() {
                            try {
                                String uid = (regUserId != null && !regUserId.isEmpty()) ? regUserId : "";
                                String body = "{\"key\":\"" + esc(key) + "\",\"deviceId\":\"" + esc(deviceId) + "\",\"login\":\"" + esc(login) + "\",\"userId\":\"" + esc(uid) + "\"}";
                                httpPost(SERVER_URL + "/keys/update-user", body);
                            } catch (Exception ignored) {}
                        }
                    }).start();
                    toast("Регистрация успешна!");
                    showWelcomeThenOpenMain(true);
                } else {
                    toast("Ошибка регистрации: " + response);
                }
            }
        });
    }

    // ══════════════════════════════════════════════════
    //  ВХОД
    // ══════════════════════════════════════════════════
    private void doLogin() {
        // Всегда идём на сервер сразу — сервер теперь проверяет учётные
        // данные ДО Telegram-гейта и вернёт wrong_password / not_found /
        // banned ещё до того, как потребует привязку. Диалог Telegram
        // появится только если данные верные (статус telegram_required).
        doLoginAfterTelegram();
    }

    private void doLoginAfterTelegram() {
        final String login = etLoginLogin.getText().toString().trim();
        final String pwd   = etLoginPwd.getText().toString();

        if (login.isEmpty() || pwd.isEmpty()) { toast("Заполните все поля"); return; }

        hideView(tvLoginNotFound);
        hideView(tvLoginWrongPwd);
        btnLogin.setEnabled(false);

        new Thread(new Runnable() {
            public void run() {
                try {
                    String body     = "{\"login\":\"" + esc(login) + "\",\"password\":\"" + esc(pwd) + "\",\"deviceId\":\"" + esc(getDeviceId()) + "\"}";
                    String response = httpPost(SERVER_URL + "/login", body);
                    handleLoginResponse(response, login, pwd);
                } catch (Exception e) {
                    Log.e("AUTH", "Login error: " + e.getClass().getSimpleName() + ": " + e.getMessage(), e);
                    final String errMsg = buildErrorMessage(e);
                    showErrorUI(errMsg);
                }
            }
        }).start();
    }

    private void handleLoginResponse(final String response, final String login, final String password) {
        runOnUiThread(new Runnable() {
            public void run() {
                btnLogin.setEnabled(true);
                if (response == null) { toast("Ошибка соединения с сервером"); return; }

                if (response.contains("\"status\":\"telegram_required\"")) {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_TG_VERIFIED, false).apply();
                    TelegramLinkDialog.show(AuthActivity.this, getDeviceId(), new TelegramLinkDialog.Callback() {
                        public void onVerified(String telegramId, String username, String firstName) {
                            saveTelegramVerified(telegramId, username, firstName);
                            doLoginAfterTelegram();
                        }
                        public void onCancelled() {}
                    });
                } else if (response.contains("ACCOUNT_NOT_FOUND") || response.contains("not_found")) {
                    showText(tvLoginNotFound, "Аккаунт не найден", 0xFFFF1E4E);
                } else if (response.contains("wrong_password") || response.contains("Неверный пароль")) {
                    showText(tvLoginWrongPwd, "Неверный пароль", 0xFFFF1E4E);
                } else if (response.contains("\"status\":\"banned\"")) {
                    // Пользователь забанен — ключ НЕ показываем, сразу открываем экран бана
                    // KEY_LOGGED_IN НЕ сохраняем — забаненный не считается вошедшим
                    String userId    = extractField(response, "user_id");
                    String banUntil  = extractBanField(response, "until");
                    String banReason = extractBanField(response, "reason");
                    String banKeyValue = extractBanKeyInfoField(response, "key");
                    int banKeyMaxDevices = extractBanKeyInfoMaxDevices(response);
                    android.content.Intent intent = new android.content.Intent(AuthActivity.this, BannedActivity.class);
                    intent.putExtra(BannedActivity.EXTRA_LOGIN,   login);
                    intent.putExtra(BannedActivity.EXTRA_USER_ID, userId != null ? userId : "");
                    intent.putExtra(BannedActivity.EXTRA_UNTIL,   banUntil != null ? banUntil : "");
                    intent.putExtra(BannedActivity.EXTRA_REASON,  banReason != null ? banReason : "");
                    intent.putExtra(BannedActivity.EXTRA_KEY_VALUE, banKeyValue != null ? banKeyValue : "");
                    intent.putExtra(BannedActivity.EXTRA_KEY_MAX_DEVICES, banKeyMaxDevices);
                    startActivity(intent);
                    // НЕ вызываем finish() — пользователь должен вернуться на экран входа из BannedActivity
                } else if (response.contains("\"ok\"") || response.contains("success") || response.contains("logged_in")) {
                    // Вход подтверждён сервером — теперь запрашиваем ключ
                    final String createdAt = extractField(response, "created_at");
                    final boolean isAdmin = response.contains("\"is_admin\":true");
                    final String deviceId = getDeviceId();
                    final String userId = extractField(response, "user_id");

                    // Синхронизируем Telegram-данные с сервером при каждом входе.
                    // Сервер возвращает актуальные данные из verifiedDevices и
                    // tg_prev_* — предыдущее значение поля, если оно изменилось.
                    // Это обновляет ник/юзернейм в профиле без повторной верификации.
                    {
                        SharedPreferences tgPrefs = getSharedPreferences(PREFS, MODE_PRIVATE);
                        String srvFirstName    = extractField(response, "tg_firstName");
                        String srvUsername     = extractField(response, "tg_username");
                        String srvId           = extractField(response, "tg_id");
                        String srvPrevFirstName = extractField(response, "tg_prev_firstName");
                        String srvPrevUsername  = extractField(response, "tg_prev_username");

                        if (srvFirstName != null && !srvFirstName.isEmpty()) {
                            SharedPreferences.Editor ed = tgPrefs.edit()
                                .putString(KEY_TG_FIRSTNAME, srvFirstName)
                                .putString(KEY_TG_USERNAME,  srvUsername  != null ? srvUsername  : "")
                                .putString(KEY_TG_ID,        srvId        != null ? srvId        : "")
                                .putBoolean(KEY_TG_VERIFIED, true);
                            // Сохраняем предыдущее значение (для «старое → новое»)
                            // только если сервер сообщил об изменении
                            if (srvPrevFirstName != null && !srvPrevFirstName.isEmpty()) {
                                ed.putString(KEY_TG_PREV_FIRSTNAME, srvPrevFirstName);
                            }
                            if (srvPrevUsername != null && !srvPrevUsername.isEmpty()) {
                                ed.putString(KEY_TG_PREV_USERNAME, srvPrevUsername);
                            }
                            ed.apply();
                        } else if (srvUsername != null && !srvUsername.isEmpty()) {
                            SharedPreferences.Editor ed = tgPrefs.edit()
                                .putString(KEY_TG_USERNAME,  srvUsername)
                                .putString(KEY_TG_ID,        srvId != null ? srvId : "")
                                .putBoolean(KEY_TG_VERIFIED, true);
                            if (srvPrevUsername != null && !srvPrevUsername.isEmpty()) {
                                ed.putString(KEY_TG_PREV_USERNAME, srvPrevUsername);
                            }
                            ed.apply();
                        }
                    }

                    // Исключение для admin: пропускаем диалог ключа
                    if ("admin".equals(login)) {
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putBoolean(KEY_LOGGED_IN, true)
                            .putString(KEY_LOGIN, login)
                            .putString(KEY_PASSWORD, password)
                            .putString(KEY_CREATED_AT, createdAt != null ? createdAt : "")
                            .putBoolean("is_admin", isAdmin)
                            .apply();
                        openMain();
                        return;
                    }

                    KeyInputDialog.show(AuthActivity.this, deviceId, login, new KeyInputDialog.Callback() {
                        public void onKeyAccepted(final String key) {
                            // Ключ принят — только теперь сохраняем сессию и открываем приложение
                            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                .putBoolean(KEY_LOGGED_IN, true)
                                .putString(KEY_LOGIN, login)
                                .putString(KEY_PASSWORD, password)
                                .putString(KEY_CREATED_AT, createdAt != null ? createdAt : "")
                                .putBoolean("is_admin", isAdmin)
                                .apply();
                            // Сохраняем логин и userId в ключ на сервере
                            new Thread(new Runnable() {
                                public void run() {
                                    try {
                                        String uid = (userId != null && !userId.isEmpty()) ? userId : "";
                                        String body = "{\"key\":\"" + esc(key) + "\",\"deviceId\":\"" + esc(deviceId) + "\",\"login\":\"" + esc(login) + "\",\"userId\":\"" + esc(uid) + "\"}";
                                        httpPost(SERVER_URL + "/keys/update-user", body);
                                    } catch (Exception ignored) {}
                                }
                            }).start();
                            showWelcomeThenOpenMain(false);
                        }
                        public void onCancelled() {
                            // Пользователь отменил ввод ключа — остаёмся на экране авторизации
                        }
                    });
                } else {
                    toast("Ошибка входа: " + response);
                }
            }
        });
    }

    /** Extracts a field from the nested "ban":{...} JSON object */
    private String extractBanField(String json, String field) {
        try {
            int banIdx = json.indexOf("\"ban\":");
            if (banIdx < 0) banIdx = 0;
            return extractField(json.substring(banIdx), field);
        } catch (Exception e) { return null; }
    }

    /** Достаёт строковое поле из вложенного ban.keyInfo.{field}. Пусто, если ключа нет. */
    private String extractBanKeyInfoField(String json, String field) {
        try {
            org.json.JSONObject obj = new org.json.JSONObject(json);
            org.json.JSONObject ban = obj.optJSONObject("ban");
            if (ban == null) return "";
            org.json.JSONObject keyInfo = ban.optJSONObject("keyInfo");
            if (keyInfo == null) return "";
            return keyInfo.optString(field, "");
        } catch (Exception e) { return ""; }
    }

    /** Достаёт ban.keyInfo.maxDevices. -1, если ключа не было привязано. */
    private int extractBanKeyInfoMaxDevices(String json) {
        try {
            org.json.JSONObject obj = new org.json.JSONObject(json);
            org.json.JSONObject ban = obj.optJSONObject("ban");
            if (ban == null) return -1;
            org.json.JSONObject keyInfo = ban.optJSONObject("keyInfo");
            if (keyInfo == null) return -1;
            return keyInfo.optInt("maxDevices", -1);
        } catch (Exception e) { return -1; }
    }

    // ══════════════════════════════════════════════════
    //  СИЛА ПАРОЛЯ
    // ══════════════════════════════════════════════════

    /**
     * 0 = Слабый (< 6 символов или только один тип символов)
     * 1 = Сильный
     * 2 = Очень сильный
     */
    private int calcStrength(String pwd) {
        if (pwd.length() < 6) return 0;
        boolean hasLower   = pwd.matches(".*[a-z].*");
        boolean hasUpper   = pwd.matches(".*[A-Z].*");
        boolean hasDigit   = pwd.matches(".*[0-9].*");
        boolean hasSpecial = pwd.matches(".*[^a-zA-Z0-9].*");

        int types = (hasLower ? 1 : 0) + (hasUpper ? 1 : 0)
                  + (hasDigit ? 1 : 0) + (hasSpecial ? 1 : 0);

        if (pwd.length() >= 10 && types >= 3) return 2; // Очень сильный
        if (types >= 2)                        return 1; // Сильный
        return 0;                                        // Слабый
    }

    private void updatePasswordStrength(String pwd) {
        if (pwd.isEmpty()) {
            hideView(tvPwdStrength);
            return;
        }
        int level = calcStrength(pwd);
        String label;
        int color;
        switch (level) {
            case 2:
                label = "● Очень сильный";
                color = 0xFFFF1E4E; // красный
                break;
            case 1:
                label = "● Сильный";
                color = 0xFFFFD600; // жёлтый
                break;
            default:
                label = "● Слабый";
                color = 0xFF00FF9D; // зелёный
                break;
        }
        showText(tvPwdStrength, label, color);
    }

    // ══════════════════════════════════════════════════
    //  UI HELPERS
    // ══════════════════════════════════════════════════
    private void showText(TextView tv, String text, int color) {
        if (tv == null) return;
        tv.setText(text);
        tv.setTextColor(color);
        tv.setVisibility(View.VISIBLE);
    }

    private void hideView(View v) {
        if (v != null) v.setVisibility(View.GONE);
    }

    /** Устаревший метод — оставлен для совместимости */
    private void showRedError(final String msg) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (tvLoginError != null) {
                    tvLoginError.setText(msg);
                    tvLoginError.setTextColor(Color.RED);
                    tvLoginError.setVisibility(View.VISIBLE);
                } else {
                    toast(msg);
                }
            }
        });
    }

    private void showErrorUI(final String msg) {
        runOnUiThread(new Runnable() {
            public void run() {
                btnRegister.setEnabled(true);
                btnLogin.setEnabled(true);
                toast(msg);
            }
        });
    }

    // ══════════════════════════════════════════════════
    //  ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    // ══════════════════════════════════════════════════
    private String extractField(String json, String field) {
        try {
            String key = "\"" + field + "\"";
            int idx = json.indexOf(key);
            if (idx < 0) return null;
            int colon = json.indexOf(':', idx + key.length());
            if (colon < 0) return null;
            int start = json.indexOf('"', colon + 1);
            if (start < 0) return null;
            int end = json.indexOf('"', start + 1);
            if (end < 0) return null;
            return json.substring(start + 1, end);
        } catch (Exception e) { return null; }
    }

    /** Converts exception to a human-readable Russian error message with details */
    private String buildErrorMessage(Exception e) {
        String cls = e.getClass().getSimpleName();
        String msg = e.getMessage() != null ? e.getMessage() : "";
        if (cls.contains("UnknownHostException")) {
            return "Сервер недоступен: не удалось найти хост\n(" + msg + ")";
        } else if (cls.contains("ConnectException")) {
            return "Не удалось подключиться к серверу\n(" + msg + ")";
        } else if (cls.contains("SocketTimeoutException") || cls.contains("ConnectTimeoutException")) {
            return "Превышено время ожидания\n(таймаут 15 сек)";
        } else if (cls.contains("SSLException") || cls.contains("SSLHandshakeException")) {
            return "Ошибка SSL/HTTPS\n(" + msg + ")";
        } else if (cls.contains("MalformedURLException")) {
            return "Неверный URL сервера:\n" + SERVER_URL;
        } else {
            return "Ошибка соединения: " + cls + "\n" + msg;
        }
    }

    private String httpPost(String urlStr, String jsonBody) throws Exception {
        Log.d("AUTH", "POST " + urlStr);
        Log.d("AUTH", "Body: " + jsonBody);
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setRequestProperty("Accept", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        OutputStream os = conn.getOutputStream();
        os.write(jsonBody.getBytes("UTF-8"));
        os.flush();
        os.close();
        int code = conn.getResponseCode();
        Log.d("AUTH", "HTTP code: " + code);
        java.io.InputStream stream = (code >= 200 && code < 300)
                ? conn.getInputStream()
                : conn.getErrorStream();
        if (stream == null) {
            Log.e("AUTH", "Response stream is null for code " + code);
            throw new Exception("Server returned code " + code + " with no body");
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        conn.disconnect();
        String response = sb.toString();
        Log.d("AUTH", "Response: " + response);
        return response;
    }

    private String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private void openMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    /**
     * Конфетти + приветствие после успешной регистрации/входа.
     * @param isNewUser true — регистрация («Добро пожаловать»),
     *                  false — вход («С возвращением»).
     */
    private void showWelcomeThenOpenMain(final boolean isNewUser) {
        String name = getTelegramDisplayName();
        String welcomeText = isNewUser
            ? "Добро пожаловать, " + name + "!"
            : "С возвращением, " + name + "!";
        ConfettiView.launch(this, welcomeText, 2200, new Runnable() {
            public void run() { openMain(); }
        });
    }

    private void animateBgColor(final int from, final int to) {
        final int steps = 56;
        final float fR = Color.red(from),   tR = Color.red(to);
        final float fG = Color.green(from), tG = Color.green(to);
        final float fB = Color.blue(from),  tB = Color.blue(to);
        final Handler h = new Handler();
        for (int i = 0; i <= steps; i++) {
            final int step = i;
            h.postDelayed(new Runnable() {
                public void run() {
                    if (bgView == null) return;
                    float t = step / (float) steps;
                    bgView.setBackgroundColor(Color.rgb(
                        (int)(fR + (tR - fR) * t),
                        (int)(fG + (tG - fG) * t),
                        (int)(fB + (tB - fB) * t)
                    ));
                }
            }, i * 40);
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
