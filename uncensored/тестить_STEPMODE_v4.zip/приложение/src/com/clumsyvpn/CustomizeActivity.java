package com.clumsyvpn;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * CustomizeActivity V11 — Gaming Neon
 * Fixes: SV-marker clipping; adds custom button photo picker + crop editor.
 */
public class CustomizeActivity extends Activity {

    // ── Prefs keys ──
    static final String PREFS_CUSTOM = "clumsy_float";
    static final String KEY_BTN_IMAGE_PATH = "btn_image_path"; // путь к сохранённому изображению

    // ── Permission request ──
    private static final int PERM_REQ = 3001;

    // ── Состояние кнопки ──
    private BtnPreview preview;
    private TextView   tvBtnSize;
    private TextView   tvHexColor;
    private View       btnColorSwatch;

    private float hue        = 140f;
    private float saturation = 1.0f;
    private float brightness = 1.0f;
    private int   btnAlpha   = 255;

    private SeekBar sbAlpha;

    // Пользовательское фото на кнопку
    private String btnImagePath = null; // null = нет фото
    private ImageView btnPhotoPreview;
    private TextView  tvPhotoHint;
    private View      colorSection;   // секция цвета (блокируется при наличии фото)

    // ── Состояние счётчика ──
    private CounterPreview counterPreview;
    private TextView       tvCounterSize;
    private TextView       tvCounterHex;
    private View           counterColorSwatch;
    private LinearLayout   counterSettingsContainer; // показывается только если счётчик включён

    private int   counterBgScale    = 100;
    private float counterHue        = 0f;
    private float counterSat        = 0f;
    private float counterBright     = 0f;
    private int   counterAlpha      = 255;

    private SharedPreferences prefs;

    // ── Галерея (picker) ──
    private List<Uri> galleryUris       = new ArrayList<>();
    private Dialog    galleryDialog     = null;
    private LinearLayout galleryGrid    = null;
    private Uri       pickedImageUri    = null; // единственный выбор
    private View      pickedCellOverlay = null; // overlay для выбранного cell

    // ─── Crop editor ─────────────────────────────────────────────────────
    private Dialog      cropDialog      = null;
    private CropView    cropView        = null;

    private AccountStatusMonitor accountStatusMonitor;

    // ─────────────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        accountStatusMonitor = new AccountStatusMonitor(this);

        MainActivity.loadFloatSettings(this);
        prefs = getSharedPreferences(MainActivity.PREFS_FLOAT, MODE_PRIVATE);

        // Загружаем цвет кнопки
        float[] hsv = new float[3];
        Color.colorToHSV(MainActivity.curBtnColor, hsv);
        hue        = hsv[0];
        saturation = Math.max(0.7f, hsv[1]);
        brightness = Math.max(0.4f, hsv[2]);
        btnAlpha   = MainActivity.curBtnAlpha;
        if (btnAlpha < 60)  btnAlpha = 60;
        if (btnAlpha > 255) btnAlpha = 255;

        // Загружаем сохранённое фото кнопки
        btnImagePath = prefs.getString(KEY_BTN_IMAGE_PATH, null);

        // Загружаем настройки счётчика
        counterBgScale = prefs.getInt(FloatService.KEY_COUNTER_BG_SCALE, 100);
        int savedBgColor = prefs.getInt("ctr_bg_color_raw", 0xFF000000);
        counterAlpha = prefs.getInt("ctr_bg_alpha", 255);
        float[] cHsv = new float[3];
        Color.colorToHSV(savedBgColor, cHsv);
        counterHue    = cHsv[0];
        counterSat    = cHsv[1];
        counterBright = cHsv[2];

        setContentView(buildLayout());
        applyPhotoState(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        accountStatusMonitor.start();
        // Обновляем видимость настроек счётчика при возврате из VpnMenuActivity
        if (counterSettingsContainer != null) {
            boolean enabled = prefs.getBoolean(VpnMenuActivity.KEY_COUNTER_ENABLED, false);
            int targetVis = enabled ? View.VISIBLE : View.GONE;
            if (counterSettingsContainer.getVisibility() != targetVis) {
                if (enabled) {
                    counterSettingsContainer.setAlpha(0f);
                    counterSettingsContainer.setVisibility(View.VISIBLE);
                    counterSettingsContainer.animate().alpha(1f).setDuration(250).start();
                } else {
                    counterSettingsContainer.animate().alpha(0f).setDuration(180)
                        .withEndAction(new Runnable() {
                            public void run() {
                                counterSettingsContainer.setVisibility(View.GONE);
                                counterSettingsContainer.setAlpha(1f);
                            }
                        }).start();
                }
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
    }

    // ═════════════════════════════════════════════════════════════════════
    // LAYOUT
    // ═════════════════════════════════════════════════════════════════════

    private View buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF030507);

        // ── Шапка ──
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), 0, dp(20), 0);
        header.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(64)));

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(32);
        back.setTypeface(null, Typeface.BOLD);
        back.setTextColor(0xFFFFFFFF);
        back.setGravity(Gravity.CENTER);
        back.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });

        View accent = new View(this);
        accent.setBackgroundColor(0xFF00FF9D);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(dp(3), dp(18));
        alp.leftMargin = dp(4); alp.rightMargin = dp(8);
        accent.setLayoutParams(alp);

        TextView title = new TextView(this);
        title.setText("КАСТОМИЗАЦИЯ");
        title.setTextSize(15);
        title.setLetterSpacing(0.18f);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, Typeface.BOLD);

        header.addView(back); header.addView(accent); header.addView(title);
        root.addView(header);

        View div = new View(this);
        div.setBackgroundColor(0xFF17202A);
        div.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        root.addView(div);

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(20), dp(18), dp(20), dp(18));

        // ════ КНОПКА: превью ════
        FrameLayout previewHolder = new FrameLayout(this);
        GradientDrawable previewBg = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF0E141B, 0xFF020305});
        previewBg.setCornerRadius(dp(16));
        previewBg.setStroke(dp(1), 0xFF17202A);
        previewHolder.setBackground(previewBg);
        LinearLayout.LayoutParams phLp = new LinearLayout.LayoutParams(MATCH, dp(220));
        phLp.bottomMargin = dp(20);

        preview = new BtnPreview(this, MainActivity.curBtnSize, currentBtnColor(), btnAlpha, loadBitmapFromPath(btnImagePath));
        previewHolder.addView(preview, new FrameLayout.LayoutParams(MATCH, dp(220)));
        inner.addView(previewHolder, phLp);

        // ════ РАЗМЕР КНОПКИ ════
        inner.addView(sectionLabel("РАЗМЕР КНОПКИ"));
        LinearLayout sizeCard = card();

        tvBtnSize = new TextView(this);
        tvBtnSize.setText(MainActivity.curBtnSize + " PX");
        tvBtnSize.setTextSize(15);
        tvBtnSize.setTypeface(null, Typeface.BOLD);
        tvBtnSize.setTextColor(0xFF00FF9D);
        tvBtnSize.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        tvLp.bottomMargin = dp(8);
        tvBtnSize.setLayoutParams(tvLp);
        sizeCard.addView(tvBtnSize);

        SeekBar sbSize = new SeekBar(this);
        sbSize.setMax(240);
        sbSize.setProgress(MainActivity.curBtnSize - 80);
        applySeekStyle(sbSize);
        sbSize.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(40)));
        sbSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int v, boolean u) {
                int size = v + 80; tvBtnSize.setText(size + " PX"); preview.setSize(size);
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        sizeCard.addView(sbSize);
        inner.addView(sizeCard);
        inner.addView(spacer(dp(20)));

        // ════ ЦВЕТ КНОПКИ (блокируется при фото) ════
        colorSection = buildColorSection();
        inner.addView(colorSection);
        inner.addView(spacer(dp(28)));

        // ════ СЧЁТЧИК ════
        // Контейнер настроек счётчика — виден только если счётчик включён (включая заголовок)
        counterSettingsContainer = new LinearLayout(this);
        counterSettingsContainer.setOrientation(LinearLayout.VERTICAL);
        counterSettingsContainer.addView(sectionLabel("СЧЁТЧИК"));

        FrameLayout cph = new FrameLayout(this);
        GradientDrawable cpBg = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF0E141B, 0xFF020305});
        cpBg.setCornerRadius(dp(16)); cpBg.setStroke(dp(1), 0xFF17202A);
        cph.setBackground(cpBg);
        counterPreview = new CounterPreview(this, counterBgScale, currentCounterBgColor(), counterAlpha);
        counterPreview.setLayoutParams(new FrameLayout.LayoutParams(MATCH, dp(160)));
        cph.addView(counterPreview);
        LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(MATCH, dp(160));
        cpLp.bottomMargin = dp(16);
        counterSettingsContainer.addView(cph, cpLp);

        counterSettingsContainer.addView(sectionLabel("РАЗМЕР СЧЁТЧИКА"));
        LinearLayout ctrSizeCard = card();
        tvCounterSize = new TextView(this);
        tvCounterSize.setText(counterBgScale + "%");
        tvCounterSize.setTextSize(15); tvCounterSize.setTypeface(null, Typeface.BOLD);
        tvCounterSize.setTextColor(0xFF00FF9D); tvCounterSize.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams ctsLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        ctsLp.bottomMargin = dp(8);
        tvCounterSize.setLayoutParams(ctsLp);
        ctrSizeCard.addView(tvCounterSize);

        SeekBar sbCtrSize = new SeekBar(this);
        sbCtrSize.setMax(150); sbCtrSize.setProgress(counterBgScale - 50);
        applySeekStyle(sbCtrSize);
        sbCtrSize.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(40)));
        sbCtrSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int v, boolean u) {
                counterBgScale = v + 50; tvCounterSize.setText(counterBgScale + "%");
                if (counterPreview != null) counterPreview.setScale(counterBgScale);
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        ctrSizeCard.addView(sbCtrSize);
        counterSettingsContainer.addView(ctrSizeCard);
        counterSettingsContainer.addView(spacer(dp(14)));

        counterSettingsContainer.addView(sectionLabel("ЦВЕТ ФОНА СЧЁТЧИКА"));
        counterSettingsContainer.addView(buildCounterColorSection());
        counterSettingsContainer.addView(spacer(dp(28)));

        // Применяем начальную видимость по текущему состоянию счётчика
        boolean counterEnabled = prefs.getBoolean(VpnMenuActivity.KEY_COUNTER_ENABLED, false);
        counterSettingsContainer.setVisibility(counterEnabled ? View.VISIBLE : View.GONE);

        inner.addView(counterSettingsContainer);

        // ════ ФОТО НА КНОПКУ ════
        inner.addView(buildPhotoSection());
        inner.addView(spacer(dp(28)));

        scroll.addView(inner);
        root.addView(scroll);

        // ── Кнопка сохранить ──
        FrameLayout saveWrap = new FrameLayout(this);
        saveWrap.setPadding(dp(20), dp(10), dp(20), dp(20));
        saveWrap.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        Button btnSave = new Button(this);
        btnSave.setText("СОХРАНИТЬ");
        btnSave.setTextSize(15); btnSave.setLetterSpacing(0.2f);
        btnSave.setTypeface(null, Typeface.BOLD);
        btnSave.setTextColor(0xFF001A0E);
        btnSave.setBackgroundResource(R.drawable.btn_neon_green);
        btnSave.setStateListAnimator(null);
        btnSave.setLayoutParams(new FrameLayout.LayoutParams(MATCH, dp(56)));
        btnSave.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { saveAndClose(); }
        });
        saveWrap.addView(btnSave);
        root.addView(saveWrap);

        return root;
    }

    // ── Секция цвета кнопки ──────────────────────────────────────────────

    private View buildColorSection() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);

        wrap.addView(sectionLabel("ЦВЕТ КНОПКИ"));

        LinearLayout colorCard = card();

        LinearLayout colorRow = new LinearLayout(this);
        colorRow.setOrientation(LinearLayout.HORIZONTAL);
        colorRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams crLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        crLp.bottomMargin = dp(12);
        colorRow.setLayoutParams(crLp);

        btnColorSwatch = new View(this);
        GradientDrawable swatchBg = new GradientDrawable();
        swatchBg.setColor(currentBtnColor()); swatchBg.setCornerRadius(dp(8));
        swatchBg.setStroke(dp(1), 0xFF2A3540);
        btnColorSwatch.setBackground(swatchBg);
        LinearLayout.LayoutParams swatchLp = new LinearLayout.LayoutParams(dp(40), dp(40));
        swatchLp.rightMargin = dp(12);
        btnColorSwatch.setLayoutParams(swatchLp);
        colorRow.addView(btnColorSwatch);

        tvHexColor = new TextView(this);
        tvHexColor.setText(hexFor(currentBtnColor())); tvHexColor.setTextSize(14);
        tvHexColor.setTypeface(null, Typeface.BOLD); tvHexColor.setTextColor(0xFF00FF9D);
        tvHexColor.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        colorRow.addView(tvHexColor);

        Button btnPickColor = new Button(this);
        btnPickColor.setText("Изменить цвет"); btnPickColor.setTextSize(12);
        btnPickColor.setTypeface(null, Typeface.BOLD); btnPickColor.setTextColor(0xFF001A0E);
        btnPickColor.setBackgroundResource(R.drawable.btn_neon_cyan);
        btnPickColor.setStateListAnimator(null);
        btnPickColor.setPadding(dp(12), 0, dp(12), 0);
        btnPickColor.setLayoutParams(new LinearLayout.LayoutParams(WRAP, dp(40)));
        btnPickColor.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showColorPicker(false); }
        });
        colorRow.addView(btnPickColor);
        colorCard.addView(colorRow);

        colorCard.addView(smallLabel("ПРОЗРАЧНОСТЬ"));
        sbAlpha = new SeekBar(this);
        sbAlpha.setMax(195); sbAlpha.setProgress(btnAlpha - 60);
        applySeekStyle(sbAlpha);
        sbAlpha.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(40)));
        sbAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int v, boolean u) {
                btnAlpha = v + 60; if (preview != null) preview.setBtnAlpha(btnAlpha);
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        colorCard.addView(sbAlpha);
        wrap.addView(colorCard);
        return wrap;
    }

    // ── Секция цвета счётчика ────────────────────────────────────────────

    private View buildCounterColorSection() {
        LinearLayout colorCard = card();

        LinearLayout ctrColorRow = new LinearLayout(this);
        ctrColorRow.setOrientation(LinearLayout.HORIZONTAL);
        ctrColorRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams ccrLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        ccrLp.bottomMargin = dp(12);
        ctrColorRow.setLayoutParams(ccrLp);

        counterColorSwatch = new View(this);
        GradientDrawable ctrSwatchBg = new GradientDrawable();
        ctrSwatchBg.setColor(currentCounterBgColor()); ctrSwatchBg.setCornerRadius(dp(8));
        ctrSwatchBg.setStroke(dp(1), 0xFF2A3540);
        counterColorSwatch.setBackground(ctrSwatchBg);
        LinearLayout.LayoutParams ctrSLp = new LinearLayout.LayoutParams(dp(40), dp(40));
        ctrSLp.rightMargin = dp(12);
        counterColorSwatch.setLayoutParams(ctrSLp);
        ctrColorRow.addView(counterColorSwatch);

        tvCounterHex = new TextView(this);
        tvCounterHex.setText(hexFor(currentCounterBgColor())); tvCounterHex.setTextSize(14);
        tvCounterHex.setTypeface(null, Typeface.BOLD); tvCounterHex.setTextColor(0xFF00FF9D);
        tvCounterHex.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        ctrColorRow.addView(tvCounterHex);

        Button btnPickCtr = new Button(this);
        btnPickCtr.setText("Изменить цвет"); btnPickCtr.setTextSize(12);
        btnPickCtr.setTypeface(null, Typeface.BOLD); btnPickCtr.setTextColor(0xFF001A0E);
        btnPickCtr.setBackgroundResource(R.drawable.btn_neon_cyan);
        btnPickCtr.setStateListAnimator(null);
        btnPickCtr.setPadding(dp(12), 0, dp(12), 0);
        btnPickCtr.setLayoutParams(new LinearLayout.LayoutParams(WRAP, dp(40)));
        btnPickCtr.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showColorPicker(true); }
        });
        ctrColorRow.addView(btnPickCtr);
        colorCard.addView(ctrColorRow);

        colorCard.addView(smallLabel("ПРОЗРАЧНОСТЬ"));
        SeekBar sbCtrAlpha = new SeekBar(this);
        sbCtrAlpha.setMax(255); sbCtrAlpha.setProgress(counterAlpha);
        applySeekStyle(sbCtrAlpha);
        sbCtrAlpha.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(40)));
        sbCtrAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int v, boolean u) {
                counterAlpha = v; if (counterPreview != null) counterPreview.setBgAlpha(counterAlpha);
            }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        colorCard.addView(sbCtrAlpha);
        return colorCard;
    }

    // ── Секция фото ──────────────────────────────────────────────────────

    private View buildPhotoSection() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);

        wrap.addView(sectionLabel("СВОЁ ФОТО НА КНОПКУ"));

        LinearLayout photoCard = card();

        // Описание
        tvPhotoHint = new TextView(this);
        tvPhotoHint.setText("При нажатии на кнопку «Добавить фото» вы можете выбрать изображение, которое хотите видеть на плавающей кнопке.");
        tvPhotoHint.setTextSize(13);
        tvPhotoHint.setTextColor(0xFF8A9BAC);
        tvPhotoHint.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        hintLp.bottomMargin = dp(16);
        tvPhotoHint.setLayoutParams(hintLp);
        photoCard.addView(tvPhotoHint);

        // Превью выбранного фото (скрыто если фото нет)
        btnPhotoPreview = new ImageView(this);
        btnPhotoPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        btnPhotoPreview.setAdjustViewBounds(false);
        GradientDrawable imgBg = new GradientDrawable();
        imgBg.setColor(0xFF111820); imgBg.setCornerRadius(dp(14));
        imgBg.setStroke(dp(1), 0xFF00FF9D);
        btnPhotoPreview.setBackground(imgBg);
        btnPhotoPreview.setClipToOutline(true);
        LinearLayout.LayoutParams imgLp = new LinearLayout.LayoutParams(dp(90), dp(90));
        imgLp.gravity = Gravity.CENTER_HORIZONTAL;
        imgLp.bottomMargin = dp(14);
        btnPhotoPreview.setLayoutParams(imgLp);
        if (btnImagePath != null) {
            Bitmap bmp = loadBitmapFromPath(btnImagePath);
            if (bmp != null) btnPhotoPreview.setImageBitmap(bmp);
        }
        btnPhotoPreview.setVisibility(btnImagePath != null ? View.VISIBLE : View.GONE);
        photoCard.addView(btnPhotoPreview);

        // Кнопки: "Добавить фото" и "Удалить фото"
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.CENTER);

        Button btnAddPhoto = new Button(this);
        btnAddPhoto.setText("Добавить фото");
        btnAddPhoto.setTextSize(13); btnAddPhoto.setTypeface(null, Typeface.BOLD);
        btnAddPhoto.setTextColor(0xFF001A0E);
        btnAddPhoto.setBackgroundResource(R.drawable.btn_neon_green);
        btnAddPhoto.setStateListAnimator(null);
        LinearLayout.LayoutParams addBtnLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        addBtnLp.rightMargin = dp(8);
        btnAddPhoto.setLayoutParams(addBtnLp);
        btnAddPhoto.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { openPhotoPicker(); }
        });
        btnRow.addView(btnAddPhoto);

        Button btnDelPhoto = new Button(this);
        btnDelPhoto.setText("Удалить");
        btnDelPhoto.setTextSize(13); btnDelPhoto.setTypeface(null, Typeface.BOLD);
        btnDelPhoto.setTextColor(0xFFFF4466);
        btnDelPhoto.setBackgroundResource(R.drawable.bg_secondary_btn);
        btnDelPhoto.setStateListAnimator(null);
        btnDelPhoto.setLayoutParams(new LinearLayout.LayoutParams(WRAP, dp(48)));
        btnDelPhoto.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { removePhoto(); }
        });
        btnDelPhoto.setVisibility(btnImagePath != null ? View.VISIBLE : View.GONE);
        btnRow.addView(btnDelPhoto);

        // Store ref for visibility toggle
        btnDelPhoto.setTag("del_photo_btn");
        photoCard.addView(btnRow);
        wrap.addView(photoCard);
        return wrap;
    }

    // ── Применить/убрать состояние фото ─────────────────────────────────

    private void applyPhotoState(boolean animate) {
        boolean hasPhoto = (btnImagePath != null);
        colorSection.setAlpha(hasPhoto ? 0.38f : 1f);
        colorSection.setEnabled(!hasPhoto);
        setChildrenEnabled(colorSection, !hasPhoto);

        if (btnPhotoPreview != null)
            btnPhotoPreview.setVisibility(hasPhoto ? View.VISIBLE : View.GONE);

        // Refresh del btn
        View delBtn = btnPhotoPreview != null ? (View)btnPhotoPreview.getParent() : null;
        // Find del btn by tag in photoCard
        if (getWindow().getDecorView() != null) {
            View root = (View)btnPhotoPreview.getParent();
            if (root instanceof LinearLayout) {
                for (int i = 0; i < ((LinearLayout)root).getChildCount(); i++) {
                    View ch = ((LinearLayout)root).getChildAt(i);
                    if (ch instanceof LinearLayout) {
                        for (int j = 0; j < ((LinearLayout)ch).getChildCount(); j++) {
                            View btn = ((LinearLayout)ch).getChildAt(j);
                            if ("del_photo_btn".equals(btn.getTag()))
                                btn.setVisibility(hasPhoto ? View.VISIBLE : View.GONE);
                        }
                    }
                }
            }
        }
    }

    private void setChildrenEnabled(View v, boolean enabled) {
        v.setEnabled(enabled);
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            for (int i = 0; i < vg.getChildCount(); i++)
                setChildrenEnabled(vg.getChildAt(i), enabled);
        }
    }

    // ── Удаление фото ────────────────────────────────────────────────────

    private void removePhoto() {
        btnImagePath = null;
        if (preview != null) preview.setBtnImage(null);
        if (btnPhotoPreview != null) {
            btnPhotoPreview.setImageBitmap(null);
        }
        applyPhotoState(true);
        Toast.makeText(this, "Фото удалено", Toast.LENGTH_SHORT).show();
    }

    // ═════════════════════════════════════════════════════════════════════
    // PHOTO PICKER (bottom-sheet style, single select, same as RankShare)
    // ═════════════════════════════════════════════════════════════════════

    private void openPhotoPicker() {
        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERM_REQ);
            return;
        }
        loadDevicePhotos();
        showPickerSheet();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(req, perms, grants);
        if (req == PERM_REQ && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) {
            loadDevicePhotos();
            showPickerSheet();
        } else {
            Toast.makeText(this, "Для выбора фото необходимо разрешение", Toast.LENGTH_LONG).show();
        }
    }

    private void loadDevicePhotos() {
        galleryUris.clear();
        try {
            String[] proj = {MediaStore.Images.Media._ID};
            Cursor cursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj,
                null, null, MediaStore.Images.Media.DATE_ADDED + " DESC");
            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                int count = 0;
                while (cursor.moveToNext() && count < 90) {
                    long id = cursor.getLong(idCol);
                    galleryUris.add(Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, String.valueOf(id)));
                    count++;
                }
                cursor.close();
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void showPickerSheet() {
        pickedImageUri    = null;
        pickedCellOverlay = null;

        galleryDialog = new Dialog(this);
        galleryDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable containerBg = new GradientDrawable();
        containerBg.setShape(GradientDrawable.RECTANGLE);
        containerBg.setCornerRadii(new float[]{dp(22),dp(22),dp(22),dp(22),0,0,0,0});
        containerBg.setColor(0xFF0D1520);
        containerBg.setStroke(dp(1), 0xFF1E3040);
        container.setBackground(containerBg);

        // Handle bar
        FrameLayout handleWrap = new FrameLayout(this);
        handleWrap.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(28)));
        View handle = new View(this);
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(dp(40), dp(4));
        hlp.gravity = Gravity.CENTER;
        handle.setLayoutParams(hlp);
        GradientDrawable hBg = new GradientDrawable();
        hBg.setShape(GradientDrawable.RECTANGLE); hBg.setCornerRadius(dp(2)); hBg.setColor(0xFF2E4460);
        handle.setBackground(hBg);
        handleWrap.addView(handle);
        container.addView(handleWrap);

        // Header
        LinearLayout headerRow = new LinearLayout(this);
        LinearLayout.LayoutParams hrLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        hrLp.setMargins(dp(20), 0, dp(16), dp(12));
        headerRow.setLayoutParams(hrLp);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        View headerAccent = new View(this);
        LinearLayout.LayoutParams haLp = new LinearLayout.LayoutParams(dp(3), dp(16));
        haLp.rightMargin = dp(8);
        headerAccent.setLayoutParams(haLp);
        headerAccent.setBackgroundColor(0xFF00FF9D);
        headerRow.addView(headerAccent);

        TextView ttv = new TextView(this);
        ttv.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        ttv.setText("Выберите фото");
        ttv.setTextSize(16); ttv.setTypeface(null, Typeface.BOLD); ttv.setTextColor(0xFFFFFFFF);
        headerRow.addView(ttv);
        container.addView(headerRow);

        // Gallery grid
        ScrollView vScroll = new ScrollView(this);
        int screenH = getResources().getDisplayMetrics().heightPixels;
        LinearLayout.LayoutParams vsLp = new LinearLayout.LayoutParams(MATCH, (int)(screenH * 0.47f));
        vScroll.setLayoutParams(vsLp);
        vScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        galleryGrid = new LinearLayout(this);
        galleryGrid.setOrientation(LinearLayout.VERTICAL);
        galleryGrid.setPadding(dp(12), 0, dp(12), dp(8));

        int screenW = getResources().getDisplayMetrics().widthPixels;
        int cols = 3, spacing = dp(4);
        int cellSize = (screenW - dp(24) - spacing * (cols - 1)) / cols;

        for (int i = 0; i < galleryUris.size(); i += cols) {
            LinearLayout row = new LinearLayout(this);
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(MATCH, WRAP);
            if (i > 0) rowLp.topMargin = spacing;
            row.setLayoutParams(rowLp);
            row.setOrientation(LinearLayout.HORIZONTAL);

            for (int j = 0; j < cols; j++) {
                int idx = i + j;
                if (idx < galleryUris.size()) {
                    final Uri uri = galleryUris.get(idx);
                    FrameLayout cell = new FrameLayout(this);
                    LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(cellSize, cellSize);
                    if (j > 0) cLp.leftMargin = spacing;
                    cell.setLayoutParams(cLp);

                    ImageView iv = new ImageView(this);
                    iv.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
                    iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    GradientDrawable ivBg = new GradientDrawable();
                    ivBg.setShape(GradientDrawable.RECTANGLE); ivBg.setCornerRadius(dp(8)); ivBg.setColor(0xFF1A2430);
                    iv.setBackground(ivBg); iv.setClipToOutline(true);

                    final ImageView fIv = iv;
                    final int fCellSize = cellSize;
                    new AsyncTask<Void, Void, Bitmap>() {
                        protected Bitmap doInBackground(Void... v) {
                            try {
                                // Загружаем сначала только размеры изображения
                                android.graphics.BitmapFactory.Options opts = new android.graphics.BitmapFactory.Options();
                                opts.inJustDecodeBounds = true;
                                String[] pathCol = { MediaStore.Images.Media.DATA };
                                Cursor c = getContentResolver().query(uri, pathCol, null, null, null);
                                String imgPath = null;
                                if (c != null) {
                                    if (c.moveToFirst()) imgPath = c.getString(0);
                                    c.close();
                                }
                                if (imgPath != null) {
                                    android.graphics.BitmapFactory.decodeFile(imgPath, opts);
                                    int srcW = opts.outWidth;
                                    int srcH = opts.outHeight;
                                    // Вычисляем inSampleSize для целевого размера (2× от cellSize для чёткости на Retina)
                                    int targetPx = fCellSize * 2;
                                    int sampleSize = 1;
                                    int half = Math.min(srcW, srcH) / 2;
                                    while (half / sampleSize > targetPx) sampleSize *= 2;
                                    opts.inJustDecodeBounds = false;
                                    opts.inSampleSize = sampleSize;
                                    opts.inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888;
                                    Bitmap sampled = android.graphics.BitmapFactory.decodeFile(imgPath, opts);
                                    return resizeBitmap(sampled, targetPx);
                                }
                                // Запасной вариант — через ContentResolver
                                android.graphics.BitmapFactory.Options fallbackOpts = new android.graphics.BitmapFactory.Options();
                                fallbackOpts.inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888;
                                android.content.res.AssetFileDescriptor afd =
                                    getContentResolver().openAssetFileDescriptor(uri, "r");
                                if (afd == null) return null;
                                android.graphics.BitmapFactory.decodeFileDescriptor(
                                    afd.getFileDescriptor(), null, fallbackOpts);
                                afd.close();
                                // Decode с правильным inSampleSize
                                android.graphics.BitmapFactory.Options fallbackOpts2 = new android.graphics.BitmapFactory.Options();
                                fallbackOpts2.inJustDecodeBounds = true;
                                afd = getContentResolver().openAssetFileDescriptor(uri, "r");
                                if (afd == null) return null;
                                android.graphics.BitmapFactory.decodeFileDescriptor(afd.getFileDescriptor(), null, fallbackOpts2);
                                afd.close();
                                int targetPx2 = fCellSize * 2;
                                int ss = 1;
                                int half2 = Math.min(fallbackOpts2.outWidth, fallbackOpts2.outHeight) / 2;
                                while (half2 / ss > targetPx2) ss *= 2;
                                fallbackOpts2.inJustDecodeBounds = false;
                                fallbackOpts2.inSampleSize = ss;
                                fallbackOpts2.inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888;
                                afd = getContentResolver().openAssetFileDescriptor(uri, "r");
                                if (afd == null) return null;
                                Bitmap result = android.graphics.BitmapFactory.decodeFileDescriptor(afd.getFileDescriptor(), null, fallbackOpts2);
                                afd.close();
                                return resizeBitmap(result, targetPx2);
                            } catch (Exception e) { return null; }
                        }
                        protected void onPostExecute(Bitmap bmp) { if (bmp != null) fIv.setImageBitmap(bmp); }
                    }.execute();
                    cell.addView(iv);

                    // Selection overlay
                    final View selOverlay = new View(this);
                    selOverlay.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
                    GradientDrawable selBg = new GradientDrawable();
                    selBg.setShape(GradientDrawable.RECTANGLE); selBg.setCornerRadius(dp(8)); selBg.setColor(0x9000FF9D);
                    selOverlay.setBackground(selBg);
                    selOverlay.setVisibility(View.GONE);
                    cell.addView(selOverlay);

                    // Check mark
                    TextView checkMark = new TextView(this);
                    FrameLayout.LayoutParams ckLp = new FrameLayout.LayoutParams(dp(26), dp(26));
                    ckLp.gravity = Gravity.TOP | Gravity.END;
                    ckLp.topMargin = dp(4); ckLp.rightMargin = dp(4);
                    checkMark.setLayoutParams(ckLp);
                    checkMark.setGravity(Gravity.CENTER);
                    checkMark.setText("✓"); checkMark.setTextSize(13);
                    checkMark.setTypeface(null, Typeface.BOLD); checkMark.setTextColor(0xFF001A0E);
                    GradientDrawable ckBg = new GradientDrawable();
                    ckBg.setShape(GradientDrawable.OVAL); ckBg.setColor(0xFF00FF9D);
                    checkMark.setBackground(ckBg);
                    checkMark.setVisibility(View.GONE);
                    cell.addView(checkMark);

                    final View fSelOverlay = selOverlay;
                    final TextView fCheckMark = checkMark;
                    cell.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                        // Deselect previous
                        if (pickedCellOverlay != null) pickedCellOverlay.setVisibility(View.GONE);
                        // Find and hide checkmark of prev — simpler: hide all
                        hideAllCheckmarks(galleryGrid);

                        if (pickedImageUri != null && pickedImageUri.equals(uri)) {
                            pickedImageUri = null; pickedCellOverlay = null;
                        } else {
                            pickedImageUri = uri;
                            pickedCellOverlay = fSelOverlay;
                            fSelOverlay.setVisibility(View.VISIBLE);
                            fCheckMark.setVisibility(View.VISIBLE);
                        }
                        updatePickerNextBtn();
                        }
                    });

                    row.addView(cell);
                } else {
                    View sp = new View(this);
                    LinearLayout.LayoutParams spLp = new LinearLayout.LayoutParams(cellSize, cellSize);
                    if (j > 0) spLp.leftMargin = spacing;
                    sp.setLayoutParams(spLp);
                    row.addView(sp);
                }
            }
            galleryGrid.addView(row);
        }

        if (galleryUris.isEmpty()) {
            TextView emptyTv = new TextView(this);
            emptyTv.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(120)));
            emptyTv.setText("Фото не найдены"); emptyTv.setTextSize(14);
            emptyTv.setTextColor(0xFF4A6A8A); emptyTv.setGravity(Gravity.CENTER);
            galleryGrid.addView(emptyTv);
        }

        vScroll.addView(galleryGrid);
        container.addView(vScroll);

        // Bottom buttons
        LinearLayout bottomBtns = new LinearLayout(this);
        LinearLayout.LayoutParams bbLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        bbLp.setMargins(dp(16), dp(12), dp(16), dp(20));
        bottomBtns.setLayoutParams(bbLp);
        bottomBtns.setOrientation(LinearLayout.HORIZONTAL);
        bottomBtns.setGravity(Gravity.CENTER_VERTICAL);

        Button cancelBtn = new Button(this);
        LinearLayout.LayoutParams cnLp = new LinearLayout.LayoutParams(0, dp(50), 1f);
        cnLp.rightMargin = dp(8);
        cancelBtn.setLayoutParams(cnLp);
        cancelBtn.setText("Назад"); cancelBtn.setTextSize(14);
        cancelBtn.setTypeface(null, Typeface.BOLD); cancelBtn.setTextColor(0xFFAAAAAA);
        cancelBtn.setBackgroundResource(R.drawable.bg_secondary_btn);
        cancelBtn.setStateListAnimator(null);
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { galleryDialog.dismiss(); }
        });
        bottomBtns.addView(cancelBtn);

        // "Далее" button — заблокирован пока не выбрано фото
        final Button nextBtn = new Button(this);
        nextBtn.setTag("picker_next");
        nextBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(50), 2f));
        nextBtn.setText("Далее →"); nextBtn.setTextSize(14);
        nextBtn.setTypeface(null, Typeface.BOLD); nextBtn.setTextColor(0xFF001A0E);
        nextBtn.setBackgroundResource(R.drawable.btn_neon_green);
        nextBtn.setStateListAnimator(null);
        nextBtn.setAlpha(0.4f); nextBtn.setEnabled(false);
        nextBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (pickedImageUri == null) return;
                galleryDialog.dismiss();
                openCropEditor(pickedImageUri);
            }
        });
        bottomBtns.addView(nextBtn);
        container.addView(bottomBtns);

        galleryDialog.setContentView(container);
        Window w = galleryDialog.getWindow();
        if (w != null) {
            w.setLayout(MATCH, WRAP);
            w.setGravity(Gravity.BOTTOM);
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.getAttributes().windowAnimations = android.R.style.Animation_Dialog;
        }
        galleryDialog.show();
    }

    private void hideAllCheckmarks(LinearLayout grid) {
        for (int i = 0; i < grid.getChildCount(); i++) {
            View row = grid.getChildAt(i);
            if (!(row instanceof LinearLayout)) continue;
            LinearLayout r = (LinearLayout) row;
            for (int j = 0; j < r.getChildCount(); j++) {
                View cell = r.getChildAt(j);
                if (!(cell instanceof FrameLayout)) continue;
                FrameLayout fl = (FrameLayout) cell;
                for (int k = 0; k < fl.getChildCount(); k++) {
                    View ch = fl.getChildAt(k);
                    if (ch instanceof TextView) ch.setVisibility(View.GONE);
                    if (!(ch instanceof ImageView) && !(ch instanceof TextView)) ch.setVisibility(View.GONE);
                }
            }
        }
    }

    private void updatePickerNextBtn() {
        if (galleryDialog == null) return;
        View root = galleryDialog.findViewById(android.R.id.content);
        // find by tag
        findAndUpdateNextBtn((ViewGroup) galleryDialog.getWindow().getDecorView());
    }

    private void findAndUpdateNextBtn(ViewGroup vg) {
        for (int i = 0; i < vg.getChildCount(); i++) {
            View ch = vg.getChildAt(i);
            if ("picker_next".equals(ch.getTag())) {
                boolean ok = (pickedImageUri != null);
                ch.setAlpha(ok ? 1f : 0.4f); ch.setEnabled(ok);
                return;
            }
            if (ch instanceof ViewGroup) findAndUpdateNextBtn((ViewGroup) ch);
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // CROP EDITOR
    // ═════════════════════════════════════════════════════════════════════

    private void openCropEditor(final Uri uri) {
        new AsyncTask<Void, Void, Bitmap>() {
            protected Bitmap doInBackground(Void... v) {
                try {
                    Bitmap bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                    return resizeBitmap(bmp, 800);
                } catch (Exception e) { return null; }
            }
            protected void onPostExecute(Bitmap bmp) {
                if (bmp == null) { Toast.makeText(CustomizeActivity.this, "Не удалось загрузить фото", Toast.LENGTH_SHORT).show(); return; }
                showCropDialog(bmp);
            }
        }.execute();
    }

    private void showCropDialog(Bitmap sourceBmp) {
        cropDialog = new Dialog(this);
        cropDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        Window w = cropDialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(null);
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            lp.height = WindowManager.LayoutParams.MATCH_PARENT;
            w.setAttributes(lp);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF030507);
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), 0, dp(20), 0);
        header.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(64)));

        View headerAccent = new View(this);
        LinearLayout.LayoutParams haLp = new LinearLayout.LayoutParams(dp(3), dp(18));
        haLp.rightMargin = dp(10);
        headerAccent.setLayoutParams(haLp);
        headerAccent.setBackgroundColor(0xFF00FF9D);
        header.addView(headerAccent);

        TextView htitle = new TextView(this);
        htitle.setText("РЕДАКТОР ФОТО");
        htitle.setTextSize(15); htitle.setLetterSpacing(0.18f);
        htitle.setTypeface(null, Typeface.BOLD); htitle.setTextColor(0xFFFFFFFF);
        header.addView(htitle);
        root.addView(header);

        View divider = new View(this);
        divider.setBackgroundColor(0xFF17202A);
        divider.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 1));
        root.addView(divider);

        // Hint
        TextView hint = new TextView(this);
        hint.setText("Двигайте и масштабируйте фото");
        hint.setTextSize(12); hint.setTextColor(0xFF6C8FA8);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        hintLp.setMargins(0, dp(14), 0, dp(10));
        hint.setLayoutParams(hintLp);
        root.addView(hint);

        // Crop view — square, centered
        FrameLayout cropHolder = new FrameLayout(this);
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int cropSize = (int)(screenW * 0.78f);
        FrameLayout.LayoutParams chLp = new FrameLayout.LayoutParams(cropSize, cropSize);
        chLp.gravity = Gravity.CENTER_HORIZONTAL;
        LinearLayout.LayoutParams cropHolderLp = new LinearLayout.LayoutParams(MATCH, 0, 1f);
        cropHolderLp.gravity = Gravity.CENTER_HORIZONTAL;

        cropView = new CropView(this, sourceBmp, cropSize);
        cropView.setLayoutParams(chLp);

        // Border around crop
        GradientDrawable cropBorder = new GradientDrawable();
        cropBorder.setShape(GradientDrawable.RECTANGLE);
        cropBorder.setCornerRadius(dp(18));
        cropBorder.setStroke(dp(2), 0xFF00FF9D);
        cropBorder.setColor(0x00000000);
        View borderOverlay = new View(this);
        borderOverlay.setBackground(cropBorder);
        borderOverlay.setLayoutParams(chLp);

        FrameLayout cropFrame = new FrameLayout(this);
        cropFrame.setLayoutParams(new LinearLayout.LayoutParams(cropSize, cropSize));
        cropFrame.addView(cropView);
        cropFrame.addView(borderOverlay);

        LinearLayout cropCenterWrap = new LinearLayout(this);
        cropCenterWrap.setGravity(Gravity.CENTER);
        cropCenterWrap.setLayoutParams(cropHolderLp);
        cropCenterWrap.addView(cropFrame);
        root.addView(cropCenterWrap);

        // Bottom buttons
        LinearLayout btmRow = new LinearLayout(this);
        btmRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams btmLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        btmLp.setMargins(dp(20), dp(16), dp(20), dp(24));
        btmRow.setLayoutParams(btmLp);
        btmRow.setGravity(Gravity.CENTER_VERTICAL);

        Button backBtn = new Button(this);
        LinearLayout.LayoutParams bbk = new LinearLayout.LayoutParams(0, dp(52), 1f);
        bbk.rightMargin = dp(10);
        backBtn.setLayoutParams(bbk);
        backBtn.setText("Назад"); backBtn.setTextSize(14);
        backBtn.setTypeface(null, Typeface.BOLD); backBtn.setTextColor(0xFFB8C4D0);
        backBtn.setBackgroundResource(R.drawable.bg_secondary_btn);
        backBtn.setStateListAnimator(null);
        backBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                cropDialog.dismiss();
                openPhotoPicker(); // вернуться к выбору
            }
        });
        btmRow.addView(backBtn);

        Button applyBtn = new Button(this);
        applyBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(52), 2f));
        applyBtn.setText("Применить"); applyBtn.setTextSize(14);
        applyBtn.setTypeface(null, Typeface.BOLD); applyBtn.setTextColor(0xFF001A0E);
        applyBtn.setBackgroundResource(R.drawable.btn_neon_green);
        applyBtn.setStateListAnimator(null);
        applyBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Bitmap cropped = cropView.getCroppedBitmap();
                if (cropped == null) { Toast.makeText(CustomizeActivity.this, "Ошибка", Toast.LENGTH_SHORT).show(); return; }
                String path = saveBitmapToFile(cropped);
                if (path == null) { Toast.makeText(CustomizeActivity.this, "Не удалось сохранить", Toast.LENGTH_SHORT).show(); return; }
                btnImagePath = path;
                if (preview != null) preview.setBtnImage(cropped);
                if (btnPhotoPreview != null) {
                    btnPhotoPreview.setImageBitmap(cropped);
                }
                applyPhotoState(true);
                cropDialog.dismiss();
                Toast.makeText(CustomizeActivity.this, "Фото установлено", Toast.LENGTH_SHORT).show();
            }
        });
        btmRow.addView(applyBtn);

        root.addView(btmRow);
        cropDialog.setContentView(root);
        cropDialog.show();
    }

    // ─── Сохранение файла ────────────────────────────────────────────────

    private String saveBitmapToFile(Bitmap bmp) {
        try {
            java.io.File dir = getFilesDir();
            java.io.File f = new java.io.File(dir, "btn_custom_photo.png");
            FileOutputStream fos = new FileOutputStream(f);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush(); fos.close();
            return f.getAbsolutePath();
        } catch (Exception e) { e.printStackTrace(); return null; }
    }

    private Bitmap loadBitmapFromPath(String path) {
        if (path == null) return null;
        try { return BitmapFactory.decodeFile(path); } catch (Exception e) { return null; }
    }

    // ═════════════════════════════════════════════════════════════════════
    // COLOR PICKER DIALOG
    // ═════════════════════════════════════════════════════════════════════

    private void showColorPicker(final boolean isCounter) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(null);
            window.setDimAmount(0.7f);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.88f);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            window.setAttributes(lp);
        }

        float initHue = isCounter ? counterHue : hue;
        float initSat = isCounter ? counterSat : saturation;
        float initBri = isCounter ? counterBright : brightness;

        LinearLayout dialogRoot = new LinearLayout(this);
        dialogRoot.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable dialogBg = new GradientDrawable();
        dialogBg.setColor(0xFF0C1014); dialogBg.setCornerRadius(dp(20));
        dialogBg.setStroke(dp(1), 0xFF1E2D3A);
        dialogRoot.setBackground(dialogBg);
        dialogRoot.setPadding(dp(20), dp(20), dp(20), dp(20));

        // Header
        LinearLayout dh = new LinearLayout(this);
        dh.setOrientation(LinearLayout.HORIZONTAL); dh.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams dhLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        dhLp.bottomMargin = dp(16); dh.setLayoutParams(dhLp);
        View dAccent = new View(this);
        LinearLayout.LayoutParams daLp = new LinearLayout.LayoutParams(dp(3), dp(16));
        daLp.rightMargin = dp(8); dAccent.setLayoutParams(daLp); dAccent.setBackgroundColor(0xFF00FF9D);
        dh.addView(dAccent);
        TextView dtitle = new TextView(this);
        dtitle.setText("ВЫБОР ЦВЕТА"); dtitle.setTextSize(13);
        dtitle.setLetterSpacing(0.15f); dtitle.setTypeface(null, Typeface.BOLD); dtitle.setTextColor(0xFFFFFFFF);
        dtitle.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        dh.addView(dtitle);
        dialogRoot.addView(dh);

        final float[] currentHsv = {initHue, initSat, initBri};

        final ColorSVPanel svPanel = new ColorSVPanel(this, currentHsv);
        dialogRoot.addView(svPanel, new LinearLayout.LayoutParams(MATCH, dp(220)));
        dialogRoot.addView(spacer(dp(16)));

        // Color preview
        final View colorPreviewBar = new View(this);
        GradientDrawable cpBarBg = new GradientDrawable();
        cpBarBg.setColor(Color.HSVToColor(currentHsv)); cpBarBg.setCornerRadius(dp(10));
        cpBarBg.setStroke(dp(1), 0xFF1E2D3A);
        colorPreviewBar.setBackground(cpBarBg);
        LinearLayout.LayoutParams cpBarLp = new LinearLayout.LayoutParams(MATCH, dp(44));
        cpBarLp.bottomMargin = dp(10); colorPreviewBar.setLayoutParams(cpBarLp);
        dialogRoot.addView(colorPreviewBar);

        final TextView tvPickerHex = new TextView(this);
        tvPickerHex.setText(hexFor(Color.HSVToColor(currentHsv))); tvPickerHex.setTextSize(13);
        tvPickerHex.setTypeface(null, Typeface.BOLD); tvPickerHex.setTextColor(0xFF6C8FA8);
        tvPickerHex.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hexLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        hexLp.bottomMargin = dp(14); tvPickerHex.setLayoutParams(hexLp);
        dialogRoot.addView(tvPickerHex);

        // Hue picker
        final HuePicker huePicker = new HuePicker(this);
        huePicker.setHue(initHue);
        LinearLayout.LayoutParams hueLp = new LinearLayout.LayoutParams(MATCH, dp(40));
        hueLp.bottomMargin = dp(20); huePicker.setLayoutParams(hueLp);
        dialogRoot.addView(huePicker);

        // Update lambda
        final View fColorPreviewBar = colorPreviewBar;
        final TextView fTvPickerHex = tvPickerHex;
        final float[] fCurrentHsv = currentHsv;
        final Runnable refreshPreview = new Runnable() {
            public void run() {
                int c = Color.HSVToColor(fCurrentHsv);
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(c); bg.setCornerRadius(dp(10)); bg.setStroke(dp(1), 0xFF1E2D3A);
                fColorPreviewBar.setBackground(bg);
                fTvPickerHex.setText(hexFor(c));
            }
        };

        svPanel.setListener(new ColorSVPanel.Listener() {
            public void onSVChanged(float s, float v) {
                fCurrentHsv[1] = s; fCurrentHsv[2] = v; refreshPreview.run();
            }
        });
        huePicker.setListener(new HuePicker.Listener() {
            public void onHueChanged(float h) {
                fCurrentHsv[0] = h; svPanel.setHue(h); refreshPreview.run();
            }
        });

        // Buttons
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL); btnRow.setGravity(Gravity.CENTER);

        Button btnCancel = new Button(this);
        btnCancel.setText("ОТМЕНА"); btnCancel.setTextSize(12); btnCancel.setLetterSpacing(0.1f);
        btnCancel.setTypeface(null, Typeface.BOLD); btnCancel.setTextColor(0xFFB8C4D0);
        btnCancel.setBackgroundResource(R.drawable.bg_secondary_btn); btnCancel.setStateListAnimator(null);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        cancelLp.rightMargin = dp(8); btnCancel.setLayoutParams(cancelLp);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { dialog.dismiss(); }
        });
        btnRow.addView(btnCancel);

        Button btnApply = new Button(this);
        btnApply.setText("ПРИМЕНИТЬ"); btnApply.setTextSize(12); btnApply.setLetterSpacing(0.1f);
        btnApply.setTypeface(null, Typeface.BOLD); btnApply.setTextColor(0xFF001A0E);
        btnApply.setBackgroundResource(R.drawable.btn_neon_green); btnApply.setStateListAnimator(null);
        btnApply.setLayoutParams(new LinearLayout.LayoutParams(0, dp(48), 1f));
        btnApply.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                float h = fCurrentHsv[0]; float s = fCurrentHsv[1]; float b = fCurrentHsv[2];
                if (isCounter) {
                    counterHue = h; counterSat = s; counterBright = b; refreshCounterBgColor();
                } else {
                    hue = h; saturation = s; brightness = b; refreshBtnColor();
                }
                dialog.dismiss();
            }
        });
        btnRow.addView(btnApply);
        dialogRoot.addView(btnRow);

        dialog.setContentView(dialogRoot);
        dialog.show();
    }

    // ─── Цвет ─────────────────────────────────────────────────────────────

    private int currentBtnColor() {
        int rgb = Color.HSVToColor(new float[]{hue, saturation, brightness});
        return 0xFF000000 | (rgb & 0x00FFFFFF);
    }

    private int currentCounterBgColor() {
        int rgb = Color.HSVToColor(new float[]{counterHue, counterSat, counterBright});
        return 0xFF000000 | (rgb & 0x00FFFFFF);
    }

    private void refreshBtnColor() {
        int c = currentBtnColor();
        if (preview != null) preview.setBtnColor(c);
        if (tvHexColor != null) tvHexColor.setText(hexFor(c));
        if (btnColorSwatch != null) {
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(c); bg.setCornerRadius(dp(8)); bg.setStroke(dp(1), 0xFF2A3540);
            btnColorSwatch.setBackground(bg);
        }
    }

    private void refreshCounterBgColor() {
        int c = currentCounterBgColor();
        if (counterPreview != null) counterPreview.setBgColor(c);
        if (tvCounterHex != null) tvCounterHex.setText(hexFor(c));
        if (counterColorSwatch != null) {
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(c); bg.setCornerRadius(dp(8)); bg.setStroke(dp(1), 0xFF2A3540);
            counterColorSwatch.setBackground(bg);
        }
    }

    private static String hexFor(int color) {
        return String.format("#%06X", (0xFFFFFF & color));
    }

    // ─── Сохранение ───────────────────────────────────────────────────────

    private void saveAndClose() {
        MainActivity.curBtnSize  = preview.getSize();
        MainActivity.curBtnColor = currentBtnColor();
        MainActivity.curBtnAlpha = btnAlpha;
        MainActivity.saveFloatSettings(this);

        int bgColor = currentCounterBgColor();
        int scaledTextSp = Math.max(8, Math.min(48, Math.round(16f * counterBgScale / 100f)));
        SharedPreferences.Editor ed = prefs.edit()
            .putInt(FloatService.KEY_COUNTER_BG_SCALE, counterBgScale)
            .putInt(FloatService.KEY_COUNTER_TEXT_SIZE, scaledTextSp)
            .putInt("ctr_bg_color_raw", bgColor)
            .putInt("ctr_bg_alpha", counterAlpha);

        if (btnImagePath != null) ed.putString(KEY_BTN_IMAGE_PATH, btnImagePath);
        else ed.remove(KEY_BTN_IMAGE_PATH);
        ed.apply();

        try {
            android.content.Intent i = new android.content.Intent(this, FloatService.class);
            i.setAction(FloatService.ACTION_UPDATE_SETTINGS);
            i.putExtra(FloatService.EXTRA_BTN_ALPHA,         btnAlpha);
            i.putExtra(FloatService.EXTRA_COUNTER_TEXT_SIZE, scaledTextSp);
            i.putExtra(FloatService.EXTRA_COUNTER_BG_SCALE,  counterBgScale);
            if (btnImagePath != null) i.putExtra(FloatService.EXTRA_BTN_IMAGE_PATH, btnImagePath);
            else i.putExtra(FloatService.EXTRA_BTN_IMAGE_PATH, "");
            startService(i);
        } catch (Exception ignored) {}

        Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show();
        finish();
    }

    // ─── UI helpers ───────────────────────────────────────────────────────

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF0C1014); bg.setCornerRadius(dp(14)); bg.setStroke(dp(1), 0xFF17202A);
        c.setBackground(bg);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        return c;
    }

    private TextView sectionLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text); tv.setTextSize(11); tv.setLetterSpacing(0.15f);
        tv.setTextColor(0xFFB8C4D0); tv.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.bottomMargin = dp(8); lp.leftMargin = dp(4);
        tv.setLayoutParams(lp);
        return tv;
    }

    private TextView smallLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text); tv.setTextSize(10); tv.setLetterSpacing(0.15f);
        tv.setTextColor(0xFF6C7885);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.bottomMargin = dp(4);
        tv.setLayoutParams(lp);
        return tv;
    }

    private void applySeekStyle(SeekBar sb) {
        sb.setProgressDrawable(getResources().getDrawable(R.drawable.seekbar_progress));
        sb.setThumb(getResources().getDrawable(R.drawable.seekbar_thumb));
        sb.setSplitTrack(false);
        sb.setPadding(dp(16), 0, dp(16), 0);
    }

    private View spacer(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, h));
        return v;
    }

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private Bitmap resizeBitmap(Bitmap src, int maxSize) {
        if (src == null) return null;
        int w = src.getWidth(), h = src.getHeight();
        if (w <= maxSize && h <= maxSize) return src;
        float scale = (float) maxSize / Math.max(w, h);
        return Bitmap.createScaledBitmap(src, Math.round(w * scale), Math.round(h * scale), true);
    }

    // ═════════════════════════════════════════════════════════════════════
    // INNER VIEWS
    // ═════════════════════════════════════════════════════════════════════

    // ─── Превью кнопки ────────────────────────────────────────────────────

    static final class BtnPreview extends View {
        private int size;
        private int color;
        private int alphaVal;
        private Bitmap customImage;
        private Bitmap roundedCache;

        private final Paint bgPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint imgPaint    = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final RectF drawRect    = new RectF();

        BtnPreview(Context ctx, int size, int color, int alpha, Bitmap img) {
            super(ctx);
            this.size     = size;
            this.color    = color;
            this.alphaVal = alpha;
            setCustomImage(img, false);
            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(3f);
        }

        void setSize(int s)  { size = s; invalidate(); }
        void setBtnColor(int c) { color = c; invalidate(); }
        void setBtnAlpha(int a) { alphaVal = a; invalidate(); }
        void setBtnImage(Bitmap bmp) { setCustomImage(bmp, true); }
        int  getSize() { return size; }

        private void setCustomImage(Bitmap bmp, boolean redraw) {
            customImage  = bmp;
            roundedCache = null;
            if (redraw) invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float half = size / 2f, r = size * 0.22f;
            drawRect.set(cx - half, cy - half, cx + half, cy + half);

            if (customImage != null) {
                // Build rounded bitmap cache
                if (roundedCache == null || roundedCache.getWidth() != size) {
                    roundedCache = makeRounded(customImage, size, r);
                }
                imgPaint.setAlpha(alphaVal);
                canvas.drawBitmap(roundedCache, cx - half, cy - half, imgPaint);
                // Border
                borderPaint.setColor(0xFF00FF9D);
                borderPaint.setAlpha(alphaVal);
                canvas.drawRoundRect(drawRect, r, r, borderPaint);
            } else {
                bgPaint.setColor(color | 0xFF000000);
                bgPaint.setAlpha(alphaVal);
                canvas.drawRoundRect(drawRect, r, r, bgPaint);
                int br = lighten(color, 0.35f);
                borderPaint.setColor(br | 0xFF000000);
                borderPaint.setAlpha(alphaVal);
                canvas.drawRoundRect(drawRect, r, r, borderPaint);
            }
        }

        private static Bitmap makeRounded(Bitmap src, int size, float r) {
            Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(out);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            RectF rf = new RectF(0, 0, size, size);
            c.drawRoundRect(rf, r, r, p);
            p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
            // Scale src to fill square
            float scale = (float) size / Math.min(src.getWidth(), src.getHeight());
            int sw = Math.round(src.getWidth() * scale);
            int sh = Math.round(src.getHeight() * scale);
            Bitmap scaled = Bitmap.createScaledBitmap(src, sw, sh, true);
            int dx = (sw - size) / 2, dy = (sh - size) / 2;
            c.drawBitmap(scaled, -dx, -dy, p);
            return out;
        }

        private static int lighten(int color, float amount) {
            int a = (color >> 24) & 0xFF;
            int r = Math.min(255, (int)(((color >> 16) & 0xFF) + 255 * amount));
            int g = Math.min(255, (int)(((color >> 8)  & 0xFF) + 255 * amount));
            int b = Math.min(255, (int)((color & 0xFF) + 255 * amount));
            return (a << 24) | (r << 16) | (g << 8) | b;
        }
    }

    // ─── Предпросмотр счётчика ─────────────────────────────────────────

    static final class CounterPreview extends View {
        private int scalePct, bgColor, bgAlpha;
        private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        CounterPreview(Context ctx, int scalePct, int bgColor, int bgAlpha) {
            super(ctx); this.scalePct = scalePct; this.bgColor = bgColor; this.bgAlpha = bgAlpha;
            textPaint.setColor(0xFFFFFFFF); textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            textPaint.setAntiAlias(true); textPaint.setTextAlign(Paint.Align.CENTER);
        }
        void setScale(int p) { scalePct = p; invalidate(); }
        void setBgColor(int c) { bgColor = c; invalidate(); }
        void setBgAlpha(int a) { bgAlpha = a; invalidate(); }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth(), h = getHeight();
            float density = getResources().getDisplayMetrics().density;
            float scale = scalePct / 100f;
            float boxW = 120f * density * scale, boxH = 36f * density * scale, textPx = 14f * density * scale;
            if (boxW > w * 0.95f) { float rat = w * 0.95f / boxW; boxW*=rat; boxH*=rat; textPx*=rat; }
            if (boxH > h * 0.85f) { float rat = h * 0.85f / boxH; boxW*=rat; boxH*=rat; textPx*=rat; }
            float left=(w-boxW)/2f, top=(h-boxH)/2f;
            bgPaint.setColor(bgColor | 0xFF000000); bgPaint.setAlpha(bgAlpha);
            canvas.drawRoundRect(new RectF(left, top, left+boxW, top+boxH), boxH*0.28f, boxH*0.28f, bgPaint);
            textPaint.setTextSize(textPx);
            canvas.drawText("Пауза", w/2f, top+boxH/2f-(textPaint.descent()+textPaint.ascent())/2f, textPaint);
        }
    }

    // ─── CropView — drag & pinch-to-zoom ─────────────────────────────────

    static final class CropView extends View {
        private final Bitmap source;
        private float offsetX = 0f, offsetY = 0f;
        private float scale   = 1f;
        private float minScale, maxScale;
        private final int viewSize;

        // Touch tracking
        private float lastX, lastY;
        private float lastDist = -1f;

        private final Paint imgPaint  = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint overlayP  = new Paint();
        private final Paint borderP   = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF imgRect   = new RectF();

        CropView(Context ctx, Bitmap src, int size) {
            super(ctx);
            source   = src;
            viewSize = size;

            // fit bitmap to view initially
            float scaleW = (float) size / src.getWidth();
            float scaleH = (float) size / src.getHeight();
            minScale = Math.min(scaleW, scaleH);
            maxScale = minScale * 6f;
            scale = Math.max(scaleW, scaleH);

            // center
            offsetX = (size - src.getWidth()  * scale) / 2f;
            offsetY = (size - src.getHeight() * scale) / 2f;

            borderP.setStyle(Paint.Style.STROKE);
            borderP.setStrokeWidth(2f);
            borderP.setColor(0x4400FF9D);

            overlayP.setColor(0xBB000000);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight();

            // Draw image
            imgRect.set(offsetX, offsetY,
                        offsetX + source.getWidth() * scale,
                        offsetY + source.getHeight() * scale);
            canvas.drawBitmap(source, null, imgRect, imgPaint);

            // Grid overlay (rule-of-thirds)
            float third = w / 3f;
            for (int i = 1; i <= 2; i++) {
                canvas.drawLine(i * third, 0, i * third, h, borderP);
                canvas.drawLine(0, i * third, w, i * third, borderP);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            int action = ev.getActionMasked();
            if (ev.getPointerCount() == 1) {
                float x = ev.getX(), y = ev.getY();
                if (action == MotionEvent.ACTION_DOWN) { lastX = x; lastY = y; lastDist = -1f; }
                else if (action == MotionEvent.ACTION_MOVE) {
                    offsetX += x - lastX; offsetY += y - lastY;
                    lastX = x; lastY = y;
                    clampOffset(); invalidate();
                }
            } else if (ev.getPointerCount() == 2) {
                float dx = ev.getX(0) - ev.getX(1);
                float dy = ev.getY(0) - ev.getY(1);
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                float midX = (ev.getX(0) + ev.getX(1)) / 2f;
                float midY = (ev.getY(0) + ev.getY(1)) / 2f;
                if (action == MotionEvent.ACTION_POINTER_DOWN || lastDist < 0) { lastDist = dist; }
                else if (action == MotionEvent.ACTION_MOVE && lastDist > 0) {
                    float factor = dist / lastDist;
                    float newScale = Math.max(minScale, Math.min(maxScale, scale * factor));
                    if (newScale != scale) {
                        offsetX = midX - (midX - offsetX) * (newScale / scale);
                        offsetY = midY - (midY - offsetY) * (newScale / scale);
                        scale = newScale;
                    }
                    lastDist = dist;
                    clampOffset(); invalidate();
                }
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP)
                lastDist = -1f;
            getParent().requestDisallowInterceptTouchEvent(true);
            return true;
        }

        private void clampOffset() {
            float bmpW = source.getWidth() * scale;
            float bmpH = source.getHeight() * scale;
            // Don't let the image leave the crop area
            if (bmpW >= viewSize) {
                offsetX = Math.min(0f, Math.max(viewSize - bmpW, offsetX));
            } else {
                offsetX = Math.max(0f, Math.min(viewSize - bmpW, offsetX));
            }
            if (bmpH >= viewSize) {
                offsetY = Math.min(0f, Math.max(viewSize - bmpH, offsetY));
            } else {
                offsetY = Math.max(0f, Math.min(viewSize - bmpH, offsetY));
            }
        }

        Bitmap getCroppedBitmap() {
            try {
                Bitmap out = Bitmap.createBitmap(viewSize, viewSize, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(out);
                c.drawBitmap(source, null, new RectF(offsetX, offsetY,
                    offsetX + source.getWidth() * scale,
                    offsetY + source.getHeight() * scale), imgPaint);
                return out;
            } catch (Exception e) { return null; }
        }
    }

    // ─── SV-квадрат (FIXED: маркер всегда внутри) ─────────────────────────

    static final class ColorSVPanel extends View {
        interface Listener { void onSVChanged(float s, float v); }

        private float hue, sat, val;
        private Listener listener;
        private Bitmap bitmap;

        private final Paint bitmapPaint  = new Paint(Paint.DITHER_FLAG);
        private final Paint markerFill   = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint markerOuter  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint markerInner  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint markerShadow = new Paint(Paint.ANTI_ALIAS_FLAG);

        private static final float MARKER_R = 12f; // dp, will be scaled

        ColorSVPanel(Context ctx, float[] hsv) {
            super(ctx);
            hue = hsv[0]; sat = hsv[1]; val = hsv[2];
            markerFill.setStyle(Paint.Style.FILL);
            markerOuter.setStyle(Paint.Style.STROKE);
            markerOuter.setColor(0xFFFFFFFF);
            markerOuter.setStrokeWidth(2.5f);
            markerInner.setStyle(Paint.Style.STROKE);
            markerInner.setColor(0x55000000);
            markerInner.setStrokeWidth(1f);
            markerShadow.setStyle(Paint.Style.STROKE);
            markerShadow.setColor(0x40000000);
            markerShadow.setStrokeWidth(4f);
            markerShadow.setMaskFilter(new android.graphics.BlurMaskFilter(8f, android.graphics.BlurMaskFilter.Blur.NORMAL));
        }

        void setHue(float h) { hue = h; bitmap = null; invalidate(); }
        void setListener(Listener l) { listener = l; }

        private void buildBitmap(int w, int h) {
            bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bitmap);
            LinearGradient satGrad = new LinearGradient(0, 0, w, 0,
                0xFFFFFFFF, Color.HSVToColor(new float[]{hue, 1f, 1f}), Shader.TileMode.CLAMP);
            Paint sP = new Paint(); sP.setShader(satGrad);
            c.drawRect(0, 0, w, h, sP);
            LinearGradient valGrad = new LinearGradient(0, 0, 0, h,
                0x00000000, 0xFF000000, Shader.TileMode.CLAMP);
            Paint vP = new Paint(); vP.setShader(valGrad);
            c.drawRect(0, 0, w, h, vP);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) { bitmap = null; }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth(), h = getHeight();
            if (w == 0 || h == 0) return;
            if (bitmap == null || bitmap.getWidth() != w || bitmap.getHeight() != h) buildBitmap(w, h);
            canvas.drawBitmap(bitmap, 0, 0, bitmapPaint);

            // ── FIXED: маркер полностью внутри bounds ──
            float mr = MARKER_R * getResources().getDisplayMetrics().density;
            float cx = mr + sat * (w - 2 * mr);
            float cy = mr + (1f - val) * (h - 2 * mr);

            // Shadow
            canvas.drawCircle(cx, cy + 1f, mr, markerShadow);
            // Fill — текущий цвет
            markerFill.setColor(Color.HSVToColor(new float[]{hue, sat, val}));
            canvas.drawCircle(cx, cy, mr, markerFill);
            // Outer white ring
            canvas.drawCircle(cx, cy, mr - 1f, markerOuter);
            // Inner dark ring
            canvas.drawCircle(cx, cy, mr - 3.5f, markerInner);
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            int w = getWidth(), h = getHeight();
            float mr = MARKER_R * getResources().getDisplayMetrics().density;
            // Clamp touch within the valid margin so marker stays inside
            float x = Math.max(mr, Math.min(w - mr, ev.getX()));
            float y = Math.max(mr, Math.min(h - mr, ev.getY()));
            sat = (x - mr) / (w - 2 * mr);
            val = 1f - (y - mr) / (h - 2 * mr);
            sat = Math.max(0f, Math.min(1f, sat));
            val = Math.max(0f, Math.min(1f, val));
            invalidate();
            if (listener != null) listener.onSVChanged(sat, val);
            getParent().requestDisallowInterceptTouchEvent(true);
            return true;
        }
    }

    // ─── HSV-полоса оттенка ────────────────────────────────────────────

    static final class HuePicker extends View {
        interface Listener { void onHueChanged(float hue); }

        private final Paint barPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint thumbFill   = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint thumbOuter  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint thumbInner  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private LinearGradient gradient;
        private float hue = 140f;
        private Listener listener;

        HuePicker(Context ctx) {
            super(ctx);
            thumbFill.setStyle(Paint.Style.FILL);
            thumbOuter.setStyle(Paint.Style.STROKE); thumbOuter.setColor(0xFFFFFFFF); thumbOuter.setStrokeWidth(2.5f);
            thumbInner.setStyle(Paint.Style.STROKE); thumbInner.setColor(0x55000000); thumbInner.setStrokeWidth(1f);
        }

        void setHue(float h) { hue = h; invalidate(); }
        void setListener(Listener l) { listener = l; }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            int[] colors = new int[7];
            for (int i = 0; i < 7; i++) colors[i] = Color.HSVToColor(new float[]{i * 60f, 1f, 1f});
            gradient = new LinearGradient(0, 0, w, 0, colors, null, Shader.TileMode.CLAMP);
            barPaint.setShader(gradient);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float barH = h * 0.48f;
            float top  = (h - barH) / 2f;
            c.drawRoundRect(new RectF(0, top, w, top + barH), barH / 2, barH / 2, barPaint);

            float thumbR = h / 2f - 2f;
            float x = (hue / 360f) * w;
            x = Math.max(thumbR, Math.min(w - thumbR, x)); // keep inside

            thumbFill.setColor(Color.HSVToColor(new float[]{hue, 1f, 1f}));
            c.drawCircle(x, h / 2f, thumbR,        thumbFill);
            c.drawCircle(x, h / 2f, thumbR - 1f,   thumbOuter);
            c.drawCircle(x, h / 2f, thumbR - 3.5f, thumbInner);
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            float w = getWidth();
            float x = Math.max(0, Math.min(w, ev.getX()));
            hue = (x / w) * 360f;
            if (hue >= 360f) hue = 359.9f;
            invalidate();
            if (listener != null) listener.onHueChanged(hue);
            getParent().requestDisallowInterceptTouchEvent(true);
            return true;
        }
    }
}
