package com.clumsyvpn;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Экран со списком всех установленных приложений и поиском.
 * При выборе — возвращает packageName через setResult(RESULT_OK, intent).
 *
 * ИСПРАВЛЕНО: убраны setTag(android.R.id.*, view) — системные ID нельзя
 * использовать как ключи для View.setTag(int, Object). Вместо этого
 * ViewHolder хранит ссылки напрямую и вешается через setTag(Object).
 */
public class AppPickerActivity extends Activity {

    private ListView appList;
    private AppAdapter adapter;
    private View loadingContainer;
    private LoadingSpinnerView loadingSpinner;
    private final List<AppInfo> allApps  = new ArrayList<>();
    private final List<AppInfo> filtered = new ArrayList<>();
    private final Set<String>   excluded = new HashSet<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_picker);

        // Парсим исключённые пакеты
        String excludedJson = getIntent().getStringExtra("excluded");
        if (excludedJson != null) {
            try {
                JSONArray arr = new JSONArray(excludedJson);
                for (int i = 0; i < arr.length(); i++) {
                    excluded.add(arr.getString(i));
                }
            } catch (Exception ignored) {}
        }

        // Назад
        TextView btnBack = (TextView) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { setResult(RESULT_CANCELED); finish(); }
        });

        appList = (ListView) findViewById(R.id.appList);
        adapter = new AppAdapter();
        appList.setAdapter(adapter);
        // Убираем системный (жёлтый) селектор списка — подсветку и клик
        // теперь полностью рисует и обрабатывает сама карточка строки.
        appList.setSelector(new ColorDrawable(Color.TRANSPARENT));

        loadingContainer = findViewById(R.id.loadingContainer);
        loadingSpinner = new LoadingSpinnerView(this);
        int spinnerSz = dp(22);
        LinearLayout.LayoutParams spinnerLp = new LinearLayout.LayoutParams(spinnerSz, spinnerSz);
        spinnerLp.topMargin = dp(12);
        spinnerLp.gravity = Gravity.CENTER_HORIZONTAL;
        loadingSpinner.setLayoutParams(spinnerLp);
        ((LinearLayout) loadingContainer).addView(loadingSpinner);
        loadingSpinner.start();

        // Поиск
        EditText searchInput = (EditText) findViewById(R.id.searchInput);
        searchInput.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterApps(s.toString().trim());
            }
            public void afterTextChanged(Editable s) {}
        });

        // Загрузка приложений в фоне
        new LoadAppsTask().execute();
    }

    private void filterApps(String query) {
        filtered.clear();
        String lq = query.toLowerCase();
        for (AppInfo info : allApps) {
            if (lq.isEmpty()
                    || info.name.toLowerCase().contains(lq)
                    || info.packageName.toLowerCase().contains(lq)) {
                filtered.add(info);
            }
        }
        adapter.notifyDataSetChanged();
    }

    // ─── Async loader ─────────────────────────────────────────────────────

    private class LoadAppsTask extends AsyncTask<Void, Void, List<AppInfo>> {
        @Override
        protected List<AppInfo> doInBackground(Void... params) {
            PackageManager pm = getPackageManager();
            List<AppInfo> list = new ArrayList<>();

            Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
            mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> resolveInfos = pm.queryIntentActivities(mainIntent, 0);

            Set<String> added = new HashSet<>();
            for (ResolveInfo ri : resolveInfos) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName())) continue;
                if (excluded.contains(pkg)) continue;
                if (added.contains(pkg)) continue;
                added.add(pkg);

                AppInfo info = new AppInfo();
                info.packageName = pkg;
                try {
                    ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                    info.name = pm.getApplicationLabel(ai).toString();
                    info.icon = pm.getApplicationIcon(ai);
                } catch (Exception e) {
                    info.name = pkg;
                    info.icon = null;
                }
                list.add(info);
            }

            Collections.sort(list, new Comparator<AppInfo>() {
                public int compare(AppInfo a, AppInfo b) {
                    return a.name.compareToIgnoreCase(b.name);
                }
            });
            return list;
        }

        @Override
        protected void onPostExecute(List<AppInfo> result) {
            allApps.clear();
            allApps.addAll(result);
            filtered.clear();
            filtered.addAll(result);
            adapter.notifyDataSetChanged();
            if (loadingContainer != null) {
                loadingContainer.setVisibility(View.GONE);
            }
            if (loadingSpinner != null) {
                loadingSpinner.stop();
            }
        }
    }

    // ─── Адаптер ──────────────────────────────────────────────────────────

    private class AppAdapter extends BaseAdapter {
        @Override public int getCount()          { return filtered.size(); }
        @Override public Object getItem(int pos) { return filtered.get(pos); }
        @Override public long getItemId(int pos) { return pos; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView == null) {
                // Создаём строку и сразу кладём ViewHolder в setTag(Object) —
                // это безопасно, в отличие от setTag(int systemId, Object).
                holder = new ViewHolder();
                convertView = buildItemView(holder);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            AppInfo info = filtered.get(position);
            holder.position = position;
            holder.locked = false;
            holder.name.setText(info.name);
            holder.pkgTxt.setText(info.packageName);
            if (info.icon != null) {
                holder.icon.setImageDrawable(info.icon);
            } else {
                holder.icon.setImageDrawable(null);
            }
            // Сбрасываем визуальное состояние — вид переиспользуется списком,
            // без этого чужое "нажатие"/подсветка могли бы прилипнуть к новой строке.
            holder.row.setBackground(null);
            holder.row.setScaleX(1f);
            holder.row.setScaleY(1f);
            holder.row.setClickable(true);
            return convertView;
        }

        /** Строит View элемента списка и заполняет holder ссылками на дочерние View. */
        private View buildItemView(final ViewHolder holder) {
            final LinearLayout row = new LinearLayout(AppPickerActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(10), dp(14), dp(10));
            row.setClickable(true);
            row.setFocusable(false);
            holder.row = row;

            // ── Эффект «прожатия» при касании ──
            row.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start();
                            break;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            v.animate().scaleX(1f).scaleY(1f).setDuration(150).start();
                            break;
                        default:
                            break;
                    }
                    return false; // не перехватываем — клик должен дойти дальше
                }
            });

            // ── Выбор приложения: плавно подсвечиваем серым и возвращаемся ──
            row.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (holder.locked) return; // защита от двойного нажатия
                    holder.locked = true;
                    v.setClickable(false);

                    Drawable[] layers = new Drawable[] {
                        new ColorDrawable(Color.TRANSPARENT),
                        getResources().getDrawable(R.drawable.bg_app_row_selected)
                    };
                    TransitionDrawable transition = new TransitionDrawable(layers);
                    v.setBackground(transition);
                    transition.startTransition(220);

                    v.postDelayed(new Runnable() {
                        public void run() {
                            int pos = holder.position;
                            if (pos < 0 || pos >= filtered.size()) {
                                finish();
                                return;
                            }
                            AppInfo info = filtered.get(pos);
                            Intent result = new Intent();
                            result.putExtra("packageName", info.packageName);
                            setResult(RESULT_OK, result);
                            finish();
                        }
                    }, 260);
                }
            });

            // Фон строки не задаём заранее — подсветка появляется только при нажатии

            // Иконка приложения
            ImageView icon = new ImageView(AppPickerActivity.this);
            int iconSz = dp(44);
            LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(iconSz, iconSz);
            iconLp.rightMargin = dp(14);
            icon.setLayoutParams(iconLp);
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            row.addView(icon);
            holder.icon = icon;          // <-- сохраняем напрямую в holder

            // Текстовый блок (название + пакет)
            LinearLayout textBlock = new LinearLayout(AppPickerActivity.this);
            textBlock.setOrientation(LinearLayout.VERTICAL);
            textBlock.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            TextView nameView = new TextView(AppPickerActivity.this);
            nameView.setTextSize(14);
            nameView.setTextColor(0xFFFFFFFF);
            nameView.setTypeface(null, android.graphics.Typeface.BOLD);
            nameView.setMaxLines(1);
            nameView.setEllipsize(android.text.TextUtils.TruncateAt.END);
            textBlock.addView(nameView);
            holder.name = nameView;      // <-- сохраняем напрямую в holder

            TextView pkgView = new TextView(AppPickerActivity.this);
            pkgView.setTextSize(11);
            pkgView.setTextColor(0xFF3A4654);
            pkgView.setMaxLines(1);
            pkgView.setEllipsize(android.text.TextUtils.TruncateAt.END);
            textBlock.addView(pkgView);
            holder.pkgTxt = pkgView;     // <-- сохраняем напрямую в holder

            row.addView(textBlock);
            return row;
        }
    }

    private static class ViewHolder {
        ImageView icon;
        TextView  name;
        TextView  pkgTxt;
        LinearLayout row;
        int     position;
        boolean locked;
    }

    private static class AppInfo {
        String   packageName;
        String   name;
        Drawable icon;
    }

    private int dp(int val) {
        return Math.round(val * getResources().getDisplayMetrics().density);
    }
}
