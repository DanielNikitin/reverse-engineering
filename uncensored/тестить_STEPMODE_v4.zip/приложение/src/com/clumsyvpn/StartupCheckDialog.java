package com.clumsyvpn;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * Небольшое квадратное окно (не на весь экран), которое показывается при
 * автологине по сохранённой сессии (например, после переустановки приложения
 * или восстановления данных из бэкапа). Внутри — крутящийся индикатор и
 * подпись, которая меняется по этапам:
 *   "Проверка есть ли аккаунт в системе..."
 *   "Проверка на блокировку аккаунта..."
 *   "Проверка ключа..."
 * Если всё в порядке — индикатор сменяется галочкой/текстом "Все успешно",
 * и окно закрывается само. Если что-то не так — вызывающий код сам решает,
 * что показать (окно бана, деактивации, удаления ключа и т.п.) — это окно
 * просто закрывается перед этим через dismiss().
 */
public class StartupCheckDialog {

    private final Dialog dialog;
    private final TextView tvStage;
    private final ProgressBar spinner;
    private final TextView tvSuccess;
    private boolean dismissed = false;

    private StartupCheckDialog(Context ctx) {
        dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(ctx, 26), dp(ctx, 28), dp(ctx, 26), dp(ctx, 26));
        {
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(ctx, 16));
            bg.setColor(0xFF0C1014);
            bg.setStroke(1, 0xFF1FE5B0);
            root.setBackground(bg);
        }

        FrameLayout indicatorFrame = new FrameLayout(ctx);
        indicatorFrame.setLayoutParams(new LinearLayout.LayoutParams(dp(ctx, 48), dp(ctx, 48)));

        spinner = new ProgressBar(ctx);
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(dp(ctx, 48), dp(ctx, 48));
        spinner.setLayoutParams(slp);
        indicatorFrame.addView(spinner);

        tvSuccess = new TextView(ctx);
        tvSuccess.setText("✓");
        tvSuccess.setTextSize(28f);
        tvSuccess.setTextColor(0xFF1FE5B0);
        tvSuccess.setTypeface(null, Typeface.BOLD);
        tvSuccess.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(dp(ctx, 48), dp(ctx, 48));
        tvSuccess.setLayoutParams(tlp);
        tvSuccess.setVisibility(View.GONE);
        indicatorFrame.addView(tvSuccess);

        root.addView(indicatorFrame);

        View spacer = new View(ctx);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 16)));
        root.addView(spacer);

        tvStage = new TextView(ctx);
        tvStage.setText("Проверка...");
        tvStage.setTextSize(13f);
        tvStage.setTextColor(0xFFB7C2CC);
        tvStage.setGravity(Gravity.CENTER);
        root.addView(tvStage);

        dialog.setContentView(root);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            android.view.WindowManager.LayoutParams lp = w.getAttributes();
            int screenW = ctx.getResources().getDisplayMetrics().widthPixels;
            int size = Math.min((int) (screenW * 0.62f), dp(ctx, 260));
            lp.width = size;
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
        }
    }

    public static StartupCheckDialog show(Context ctx) {
        StartupCheckDialog d = new StartupCheckDialog(ctx);
        d.dialog.show();
        return d;
    }

    /** Меняет текст текущего этапа проверки. */
    public void setStage(String text) {
        if (dismissed || !dialog.isShowing()) return;
        tvStage.setText(text);
    }

    /**
     * Показывает "Все успешно" вместо спиннера и закрывает окно через
     * короткую паузу, после чего вызывает onDone.
     */
    public void showSuccessAndDismiss(final Runnable onDone) {
        if (dismissed || !dialog.isShowing()) {
            if (onDone != null) onDone.run();
            return;
        }
        spinner.setVisibility(View.GONE);
        tvSuccess.setVisibility(View.VISIBLE);
        tvStage.setText("Все успешно");
        tvStage.setTextColor(0xFF1FE5B0);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                dismiss();
                if (onDone != null) onDone.run();
            }
        }, 500);
    }

    public void dismiss() {
        dismissed = true;
        try {
            if (dialog.isShowing()) dialog.dismiss();
        } catch (Exception ignored) {}
    }

    private static int dp(Context ctx, int val) {
        return (int) (val * ctx.getResources().getDisplayMetrics().density + 0.5f);
    }
}
