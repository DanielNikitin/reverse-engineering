package com.clumsyvpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.animation.ValueAnimator;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.Build;
import android.os.SystemClock;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.content.res.Configuration;

/**
 * FloatService V9 — Gaming Neon redesign + настраиваемый счётчик
 *
 * Новые возможности счётчика:
 *   • Изменение размера текста
 *   • Изменение цвета текста
 *   • Изменение прозрачности текста
 *   • Изменение прозрачности чёрного фона
 *   • Изменение размера чёрного фона (ширина/высота)
 *   • Перетаскивание по экрану (было и раньше)
 *
 * Переключатель:
 *   • Заменён круг → квадрат (через drawable)
 *   • Зелёная галочка при включении, пусто при выключении
 */
public class FloatService extends Service {

    public static final String ACTION_START        = "com.clumsyvpn.FLOAT_START";
    public static final String ACTION_STOP              = "com.clumsyvpn.FLOAT_STOP";
    public static final String ACTION_UPDATE_SETTINGS   = "com.clumsyvpn.FLOAT_UPDATE";
    /** Запускает плавающую кнопку в «Пошаговом режиме» — обратный отсчёт идёт по шагам */
    public static final String ACTION_START_STEP_MODE  = "com.clumsyvpn.FLOAT_START_STEP_MODE";
    public static final String EXTRA_SECONDS       = "seconds";
    public static final String EXTRA_BTN_SIZE      = "btn_size";
    public static final String EXTRA_BTN_COLOR     = "btn_color";
    public static final String EXTRA_BTN_ALPHA     = "btn_alpha";
    public static final String EXTRA_AFTER_TIMER_MODE  = "after_timer_mode";
    public static final String EXTRA_AFTER_TIMER_DELAY = "after_timer_delay";
    public static final String EXTRA_COUNTER_ENABLED   = "counter_enabled";
    public static final String EXTRA_BTN_IMAGE_PATH   = "btn_image_path";

    // ── Пошаговый режим ──────────────────────────────────────────────────
    /** Список длительностей шагов в мс, через запятую: "3000,5000,2000" */
    public static final String EXTRA_STEP_DURATIONS    = "step_durations";
    /** 0 = Сброс (работает только шаг №1), 1 = Следующий шаг (цикл по всем шагам) */
    public static final String EXTRA_STEPS_AFTER_MODE  = "steps_after_mode";

    // Настройки счётчика — передаются при старте
    public static final String EXTRA_COUNTER_TEXT_SIZE    = "counter_text_size";   // sp * 10 (int)
    public static final String EXTRA_COUNTER_TEXT_COLOR   = "counter_text_color";  // ARGB int
    public static final String EXTRA_COUNTER_TEXT_ALPHA   = "counter_text_alpha";  // 0..255
    public static final String EXTRA_COUNTER_BG_ALPHA     = "counter_bg_alpha";    // 0..255
    public static final String EXTRA_COUNTER_BG_SCALE     = "counter_bg_scale";    // 50..200 (%)

    // Ключи SharedPreferences для настроек счётчика
    public static final String KEY_COUNTER_TEXT_SIZE  = "ctr_text_size";
    public static final String KEY_COUNTER_TEXT_COLOR = "ctr_text_color";
    public static final String KEY_COUNTER_TEXT_ALPHA = "ctr_text_alpha";
    public static final String KEY_COUNTER_BG_ALPHA   = "ctr_bg_alpha";
    public static final String KEY_COUNTER_BG_SCALE   = "ctr_bg_scale";

    private WindowManager wm;
    private FloatView     floatView;
    private boolean       shown = false;

    private int     totalMs       = 0;
    private int     remainMs      = 0;
    private int     btnSize       = 190;
    private int     runColor      = 0xFF00FF99;
    private int     btnAlpha      = 255;
    private String  btnImagePath  = null;  // путь к кастомному фото кнопки
    private boolean simActive     = false;
    private int     afterTimerMode    = 0;
    private int     afterTimerDelayMs = 0;

    // Счётчик авто отключения
    private boolean        counterEnabled = false;
    private CounterView    counterView    = null;
    private boolean        counterShown   = false;
    private WindowManager.LayoutParams counterLp = null;

    // Настройки счётчика
    private int   counterTextSizeSp  = 16;    // размер текста в sp
    private int   counterTextColor   = 0xFFFFFFFF; // цвет текста (без альфа-канала)
    private int   counterTextAlpha   = 255;   // прозрачность текста 0..255
    private int   counterBgAlpha     = 220;   // прозрачность фона 0..255
    private int   counterBgScale     = 100;   // масштаб фона в % (100 = стандартный)

    // Данные для перетаскивания счётчика
    private int   ctrTrackedPtr    = -1;
    private int   ctrDragStartX, ctrDragStartY;
    private float ctrDragStartRawX, ctrDragStartRawY;
    private boolean ctrWasDragged  = false;
    static final String KEY_COUNTER_X = "counter_x";
    static final String KEY_COUNTER_Y = "counter_y";

    private Runnable timerRunnable = null;
    private long     timerEndElapsed = 0;

    // ── Пошаговый режим ──────────────────────────────────────────────────
    // FloatService — единственный источник времени для переключения шагов:
    // именно здесь считается обратный отсчёт (тот же механизм, что и у
    // обычного таймера конфига), а MyVpnService только получает команду
    // "примени параметры шага N" при каждом переключении.
    private boolean stepModeActive     = false;
    private java.util.ArrayList<Integer> stepDurationsMs = new java.util.ArrayList<Integer>();
    private int stepsAfterMode   = 0;  // 0=Сброс, 1=Следующий шаг
    private int currentStepIndex = 0;

    private final Handler  handler   = new Handler(Looper.getMainLooper());

    // ── TCP/UDP статистика из VPN ─────────────────────────────────────────
    private volatile long ctrTcpPkts = 0;
    private volatile long ctrUdpPkts = 0;
    private String        ctrTimerText = "Пауза"; // текущий текст таймера

    private android.content.BroadcastReceiver statsReceiver = null;

    private WindowManager.LayoutParams layoutParams;

    private int screenW = 1080;
    private int screenH = 1920;

    private int   trackedPointerId  = -1;
    private int   dragStartX, dragStartY;
    private float dragStartRawX, dragStartRawY;
    private boolean wasDragged = false;
    private static final int DRAG_THRESHOLD = 10;

    @Override public IBinder onBind(Intent i) { return null; }

    /** Парсит "3000,5000,2000" в список длительностей шагов (мс) */
    private void parseStepDurations(String s) {
        stepDurationsMs.clear();
        if (s == null || s.isEmpty()) return;
        for (String part : s.split(",")) {
            if (part.isEmpty()) continue;
            try {
                int v = Integer.parseInt(part.trim());
                stepDurationsMs.add(Math.max(200, v)); // защита от нулевой/некорректной длительности
            } catch (NumberFormatException ignored) {}
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        if (ACTION_START.equals(intent.getAction())) {
            stepModeActive = false;
            totalMs           = intent.getIntExtra(EXTRA_SECONDS,   0);
            btnSize           = intent.getIntExtra(EXTRA_BTN_SIZE,  190);
            runColor          = intent.getIntExtra(EXTRA_BTN_COLOR, 0xFF00FF99);
            btnAlpha          = intent.getIntExtra(EXTRA_BTN_ALPHA, 255);
            if (btnAlpha < 60)  btnAlpha = 60;
            if (btnAlpha > 255) btnAlpha = 255;
            afterTimerMode    = intent.getIntExtra(EXTRA_AFTER_TIMER_MODE,  0);
            afterTimerDelayMs = intent.getIntExtra(EXTRA_AFTER_TIMER_DELAY, 0);
            counterEnabled    = intent.getBooleanExtra(EXTRA_COUNTER_ENABLED, false);

            // Загружаем настройки счётчика из SharedPreferences (они сохраняются из VpnMenuActivity)
            // Загружаем путь к кастомному фото кнопки
            android.content.SharedPreferences fp = getSharedPreferences(MainActivity.PREFS_FLOAT, MODE_PRIVATE);
            btnImagePath = fp.getString(CustomizeActivity.KEY_BTN_IMAGE_PATH, null);
            loadCounterSettings();

            runColor = (runColor & 0x00FFFFFF) | (btnAlpha << 24);
            remainMs      = totalMs;
            simActive     = false;
            readScreenSize();
            makeFloatChannel();
            startForeground(78, buildFloatNotif());
            showButton();
            if (counterEnabled) showCounter();
            setLabel("", runColor);
            registerStatsReceiver();

        } else if (ACTION_START_STEP_MODE.equals(intent.getAction())) {
            stepModeActive = true;
            String durationsStr = intent.getStringExtra(EXTRA_STEP_DURATIONS);
            parseStepDurations(durationsStr);
            stepsAfterMode    = intent.getIntExtra(EXTRA_STEPS_AFTER_MODE, 0);
            currentStepIndex  = 0;

            btnSize           = intent.getIntExtra(EXTRA_BTN_SIZE,  190);
            runColor          = intent.getIntExtra(EXTRA_BTN_COLOR, 0xFF00FF99);
            btnAlpha          = intent.getIntExtra(EXTRA_BTN_ALPHA, 255);
            if (btnAlpha < 60)  btnAlpha = 60;
            if (btnAlpha > 255) btnAlpha = 255;
            // В пошаговом режиме "после таймера" (Удалить/Задержка) не применяется —
            // там своя логика (Сброс/Следующий шаг), поэтому фиксируем 0.
            afterTimerMode    = 0;
            afterTimerDelayMs = 0;
            counterEnabled    = intent.getBooleanExtra(EXTRA_COUNTER_ENABLED, false);

            android.content.SharedPreferences fp = getSharedPreferences(MainActivity.PREFS_FLOAT, MODE_PRIVATE);
            btnImagePath = fp.getString(CustomizeActivity.KEY_BTN_IMAGE_PATH, null);
            loadCounterSettings();

            runColor = (runColor & 0x00FFFFFF) | (btnAlpha << 24);
            totalMs   = stepDurationsMs.isEmpty() ? 0 : stepDurationsMs.get(0);
            remainMs  = totalMs;
            simActive = false;
            readScreenSize();
            makeFloatChannel();
            startForeground(78, buildFloatNotif());
            showButton();
            if (counterEnabled) showCounter();
            setLabel("", runColor);
            registerStatsReceiver();

        } else if (ACTION_STOP.equals(intent.getAction())) {
            stopTimer();
            hideButton();
            hideCounter();
            unregisterStatsReceiver();
            ctrTcpPkts = 0;
            ctrUdpPkts = 0;
            stepModeActive = false;
            stopSelf();
        } else if (ACTION_UPDATE_SETTINGS.equals(intent.getAction())) {
            afterTimerMode    = intent.getIntExtra(EXTRA_AFTER_TIMER_MODE,  afterTimerMode);
            afterTimerDelayMs = intent.getIntExtra(EXTRA_AFTER_TIMER_DELAY, afterTimerDelayMs);
            int newMs         = intent.getIntExtra(EXTRA_SECONDS, totalMs);
            if (newMs != totalMs) totalMs = newMs;
            // Обновляем настройки счётчика если переданы
            // Обновление пути к фото кнопки
            if (intent.hasExtra(EXTRA_BTN_IMAGE_PATH)) {
                String imgPath = intent.getStringExtra(EXTRA_BTN_IMAGE_PATH);
                btnImagePath = (imgPath != null && !imgPath.isEmpty()) ? imgPath : null;
                if (floatView != null) {
                    android.graphics.Bitmap bmp = btnImagePath != null ? android.graphics.BitmapFactory.decodeFile(btnImagePath) : null;
                    floatView.setCustomImage(bmp);
                }
            }
            if (intent.hasExtra(EXTRA_COUNTER_TEXT_SIZE)) {
                counterTextSizeSp = intent.getIntExtra(EXTRA_COUNTER_TEXT_SIZE, counterTextSizeSp);
                counterTextColor  = intent.getIntExtra(EXTRA_COUNTER_TEXT_COLOR, counterTextColor);
                counterTextAlpha  = intent.getIntExtra(EXTRA_COUNTER_TEXT_ALPHA, counterTextAlpha);
                counterBgAlpha    = intent.getIntExtra(EXTRA_COUNTER_BG_ALPHA, counterBgAlpha);
                counterBgScale    = intent.getIntExtra(EXTRA_COUNTER_BG_SCALE, counterBgScale);
                applyCounterSettings();
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Пересчитываем размеры экрана после смены ориентации
        handler.postDelayed(new Runnable() {
            public void run() {
                updateScreenBounds();
            }
        }, 100); // небольшая задержка, чтобы WindowManager успел обновить метрики
    }

    /**
     * Обновляет размеры экрана и корректирует позиции плавающих элементов.
     * Вызывается после поворота экрана.
     */
    private void updateScreenBounds() {
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        try {
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
        } catch (Exception ignored) { return; }

        // Корректируем позицию плавающей кнопки
        if (shown && floatView != null && layoutParams != null) {
            layoutParams.x = clamp(layoutParams.x, 0, Math.max(0, screenW - btnSize));
            layoutParams.y = clamp(layoutParams.y, 0, Math.max(0, screenH - btnSize));
            try { wm.updateViewLayout(floatView, layoutParams); } catch (Exception ignored) {}
        }

        // Корректируем позицию счётчика
        if (counterShown && counterView != null && counterLp != null) {
            int cW = counterLp.width;
            int cH = counterLp.height;
            counterLp.x = clamp(counterLp.x, 0, Math.max(0, screenW - cW));
            counterLp.y = clamp(counterLp.y, 0, Math.max(0, screenH - cH));
            try { wm.updateViewLayout(counterView, counterLp); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onDestroy() {
        stopTimer();
        hideButton();
        hideCounter();
        unregisterStatsReceiver();
        super.onDestroy();
    }

    private void loadCounterSettings() {
        android.content.SharedPreferences p =
            getSharedPreferences(MainActivity.PREFS_FLOAT, MODE_PRIVATE);
        counterTextSizeSp = p.getInt(KEY_COUNTER_TEXT_SIZE,  16);
        counterTextColor  = p.getInt(KEY_COUNTER_TEXT_COLOR, 0xFFFFFFFF);
        counterTextAlpha  = p.getInt(KEY_COUNTER_TEXT_ALPHA, 255);
        counterBgAlpha    = p.getInt(KEY_COUNTER_BG_ALPHA,   220);
        counterBgScale    = p.getInt(KEY_COUNTER_BG_SCALE,   100);
        // Ограничения
        counterTextSizeSp = clamp(counterTextSizeSp, 8,  48);
        counterTextAlpha  = clamp(counterTextAlpha,  0,  255);
        counterBgAlpha    = clamp(counterBgAlpha,    0,  255);
        counterBgScale    = clamp(counterBgScale,    50, 200);
    }

    /** Применяет новые настройки к уже отображаемому CounterView */
    private void applyCounterSettings() {
        if (!counterShown || counterView == null) return;
        handler.post(new Runnable() {
            public void run() {
                if (counterView != null) {
                    counterView.applyStyle(counterTextSizeSp, counterTextColor,
                        counterTextAlpha, counterBgAlpha);
                    // Обновляем размер окна если масштаб изменился
                    if (counterLp != null && wm != null) {
                        float density = getResources().getDisplayMetrics().density;
                        int baseW = Math.round(160 * density);
                        int baseH = Math.round(80  * density);
                        counterLp.width  = Math.round(baseW * counterBgScale / 100f);
                        counterLp.height = Math.round(baseH * counterBgScale / 100f);
                        try { wm.updateViewLayout(counterView, counterLp); }
                        catch (Exception ignored) {}
                    }
                }
            }
        });
    }

    private void readScreenSize() {
        try {
            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
        } catch (Exception ignored) {}
    }

    private void showButton() {
        if (shown) return;
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        android.graphics.Bitmap initBmp = (btnImagePath != null) ? android.graphics.BitmapFactory.decodeFile(btnImagePath) : null;
        floatView = new FloatView(this, btnSize, "", runColor, initBmp);

        layoutParams = new WindowManager.LayoutParams(
            btnSize, btnSize,
            android.os.Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
            PixelFormat.TRANSLUCENT
        );
        layoutParams.gravity = Gravity.TOP | Gravity.LEFT;
        android.content.SharedPreferences fp =
            getSharedPreferences(MainActivity.PREFS_FLOAT, MODE_PRIVATE);
        int savedX = fp.getInt(MainActivity.KEY_F_X, 60);
        int savedY = fp.getInt(MainActivity.KEY_F_Y, 300);
        layoutParams.x = clamp(savedX, 0, Math.max(0, screenW - btnSize));
        layoutParams.y = clamp(savedY, 0, Math.max(0, screenH - btnSize));

        floatView.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent ev) {
                return handleTouch(ev);
            }
        });

        try {
            wm.addView(floatView, layoutParams);
            shown = true;
        } catch (Exception ignored) {}
    }

    private boolean handleTouch(MotionEvent ev) {
        int action = ev.getActionMasked();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                trackedPointerId = ev.getPointerId(0);
                dragStartX    = layoutParams.x;
                dragStartY    = layoutParams.y;
                dragStartRawX = ev.getRawX();
                dragStartRawY = ev.getRawY();
                wasDragged    = false;
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                onButtonClick();
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (trackedPointerId == -1) return true;
                int pi = ev.findPointerIndex(trackedPointerId);
                if (pi < 0) return true;
                float curRawX = ev.getRawX() - ev.getX(0) + ev.getX(pi);
                float curRawY = ev.getRawY() - ev.getY(0) + ev.getY(pi);
                float dx = curRawX - dragStartRawX;
                float dy = curRawY - dragStartRawY;
                if (!wasDragged && (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD))
                    wasDragged = true;
                if (wasDragged) {
                    int newX = clamp(dragStartX + (int) dx, 0, screenW - btnSize);
                    int newY = clamp(dragStartY + (int) dy, 0, screenH - btnSize);
                    layoutParams.x = newX;
                    layoutParams.y = newY;
                    if (wm != null && floatView != null) {
                        try { wm.updateViewLayout(floatView, layoutParams); }
                        catch (Exception ignored) {}
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_POINTER_UP:
                return true;
            case MotionEvent.ACTION_UP:
                if (!wasDragged) onButtonClick();
                else {
                    try {
                        getSharedPreferences(MainActivity.PREFS_FLOAT, MODE_PRIVATE)
                            .edit()
                            .putInt(MainActivity.KEY_F_X, layoutParams.x)
                            .putInt(MainActivity.KEY_F_Y, layoutParams.y)
                            .apply();
                    } catch (Exception ignored) {}
                }
                trackedPointerId = -1;
                wasDragged       = false;
                return true;
            case MotionEvent.ACTION_CANCEL:
                trackedPointerId = -1;
                wasDragged       = false;
                return true;
        }
        return false;
    }

    private void onButtonClick() {
        if (!simActive) startSimulation();
        else            pauseSimulation();
    }

    private void startSimulation() {
        simActive = true;
        sendVpn(MyVpnService.ACTION_SIM_START);
        if (stepModeActive) {
            startStepTimer();
        } else {
            remainMs = totalMs;
            if (totalMs > 0) startTimer();
            else {
                setLabel("ON", runColor);
                updateCounterText("∞");
            }
        }
    }

    private void pauseSimulation() {
        simActive = false;
        stopTimer();
        handler.post(new Runnable() {
            public void run() {
                if (floatView != null) floatView.stopDrainAnimation();
            }
        });
        remainMs  = totalMs;
        sendVpn(MyVpnService.ACTION_SIM_STOP);
        setLabel("", runColor);
        updateCounterText("Пауза");
    }

    /**
     * Обратный отсчёт до следующего шага «Пошагового режима».
     * Работает так же, как обычный startTimer(), но по истечении не
     * останавливает симуляцию, а переключается на следующий шаг (режим
     * «Следующий шаг») или перезапускает шаг №1 с тем же временем (режим
     * «Сброс» — работает только один шаг, но таймер продолжает идти по кругу).
     */
    private void startStepTimer() {
        stopTimer();
        if (stepDurationsMs.isEmpty()) {
            setLabel("ON", runColor);
            updateCounterText("∞");
            return;
        }

        totalMs = stepDurationsMs.get(currentStepIndex);
        remainMs = totalMs;
        timerEndElapsed = SystemClock.elapsedRealtime() + totalMs;

        final long animTotalMs = totalMs;
        handler.post(new Runnable() {
            public void run() {
                if (floatView != null) floatView.startDrainAnimation(animTotalMs);
            }
        });

        updateCounterText(formatCounterMs(totalMs, totalMs));
        setLabel("ON", runColor);

        timerRunnable = new Runnable() {
            @Override
            public void run() {
                long now       = SystemClock.elapsedRealtime();
                long remaining = timerEndElapsed - now;

                if (remaining <= 0) {
                    advanceToNextStep();
                    return;
                }

                remainMs = (int) remaining;
                updateCounterText(formatCounterMs(remaining, totalMs));
                handler.postDelayed(this, 250);
            }
        };
        handler.postDelayed(timerRunnable, 250);
    }

    /** Переключается на следующий шаг (или перезапускает шаг №1 в режиме «Сброс») и сбрасывает таймер на новое время */
    private void advanceToNextStep() {
        if (!simActive || !stepModeActive || stepDurationsMs.isEmpty()) return;

        if (stepsAfterMode == 1 && stepDurationsMs.size() > 1) {
            currentStepIndex = (currentStepIndex + 1) % stepDurationsMs.size();
        }
        // Режим «Сброс» (stepsAfterMode == 0) — currentStepIndex остаётся 0,
        // шаг №1 просто перезапускается с тем же временем.

        sendVpnApplyStep(currentStepIndex);
        startStepTimer(); // пересчитывает totalMs/remainMs на длительность нового шага и сбрасывает анимацию
    }

    /** Отправляет MyVpnService команду применить параметры шага с данным индексом */
    private void sendVpnApplyStep(int stepIndex) {
        Intent i = new Intent(this, MyVpnService.class);
        i.setAction(MyVpnService.ACTION_APPLY_STEP);
        i.putExtra(MyVpnService.EXTRA_STEP_INDEX, stepIndex);
        try { startService(i); } catch (Exception ignored) {}
    }

    private void startTimer() {
        stopTimer();
        timerEndElapsed = SystemClock.elapsedRealtime() + totalMs;

        final long animTotalMs = totalMs;
        handler.post(new Runnable() {
            public void run() {
                if (floatView != null) floatView.startDrainAnimation(animTotalMs);
            }
        });

        updateCounterText(formatCounterMs(totalMs, totalMs));

        timerRunnable = new Runnable() {
            @Override
            public void run() {
                long now       = SystemClock.elapsedRealtime();
                long remaining = timerEndElapsed - now;

                if (remaining <= 0) {
                    handler.post(new Runnable() {
                        public void run() {
                            if (floatView != null) floatView.stopDrainAnimation();
                        }
                    });
                    updateCounterText("Пауза");
                    simActive = false;
                    remainMs  = totalMs;
                    sendVpn(MyVpnService.ACTION_TIMER_FINISHED);
                    setLabel("", runColor);
                    timerRunnable = null;
                    return;
                }

                updateCounterText(formatCounterMs(remaining, totalMs));
                // 250 мс вместо 16 мс: счётчик обновляется 4 раза в секунду,
                // что достаточно для отображения и снижает нагрузку в 15 раз.
                handler.postDelayed(this, 250);
            }
        };
        handler.postDelayed(timerRunnable, 250);
    }

    private void stopTimer() {
        if (timerRunnable != null) {
            handler.removeCallbacks(timerRunnable);
            timerRunnable = null;
        }
    }

    private void setLabel(final String text, final int color) {
        handler.post(new Runnable() {
            public void run() {
                if (floatView != null) floatView.update(text, color);
            }
        });
    }

    private void sendVpn(String action) {
        Intent i = new Intent(this, MyVpnService.class);
        i.setAction(action);
        startService(i);
    }

    // ─── Плавающий счётчик ────────────────────────────────────────────────

    private void showCounter() {
        if (counterShown) return;
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        counterView = new CounterView(this);
        counterView.applyStyle(counterTextSizeSp, counterTextColor, counterTextAlpha, counterBgAlpha);

        float density = getResources().getDisplayMetrics().density;
        int baseW = Math.round(160 * density);
        int baseH = Math.round(80  * density); // 3 строки: таймер + TCP + UDP
        int cW = Math.round(baseW * counterBgScale / 100f);
        int cH = Math.round(baseH * counterBgScale / 100f);

        counterLp = new WindowManager.LayoutParams(
            cW, cH,
            android.os.Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
            android.graphics.PixelFormat.TRANSLUCENT
        );
        counterLp.gravity = android.view.Gravity.TOP | android.view.Gravity.LEFT;

        android.content.SharedPreferences fp =
            getSharedPreferences(MainActivity.PREFS_FLOAT, MODE_PRIVATE);
        int defX = (screenW - cW) / 2;
        int defY = screenH - cH - Math.round(120 * density);
        counterLp.x = fp.getInt(KEY_COUNTER_X, defX);
        counterLp.y = fp.getInt(KEY_COUNTER_Y, defY);
        counterLp.x = clamp(counterLp.x, 0, Math.max(0, screenW - cW));
        counterLp.y = clamp(counterLp.y, 0, Math.max(0, screenH - cH));

        counterView.setText("Пауза\nTCP: 0\nUDP: 0");

        counterView.setOnTouchListener(new android.view.View.OnTouchListener() {
            public boolean onTouch(android.view.View v, android.view.MotionEvent ev) {
                return handleCounterTouch(ev);
            }
        });

        try {
            wm.addView(counterView, counterLp);
            counterShown = true;
        } catch (Exception ignored) {}
    }

    private boolean handleCounterTouch(android.view.MotionEvent ev) {
        int action = ev.getActionMasked();
        switch (action) {
            case android.view.MotionEvent.ACTION_DOWN:
                ctrTrackedPtr    = ev.getPointerId(0);
                ctrDragStartX    = counterLp.x;
                ctrDragStartY    = counterLp.y;
                ctrDragStartRawX = ev.getRawX();
                ctrDragStartRawY = ev.getRawY();
                ctrWasDragged    = false;
                return true;
            case android.view.MotionEvent.ACTION_MOVE: {
                if (ctrTrackedPtr == -1) return true;
                int pi = ev.findPointerIndex(ctrTrackedPtr);
                if (pi < 0) return true;
                float dx = ev.getRawX() - ctrDragStartRawX;
                float dy = ev.getRawY() - ctrDragStartRawY;
                if (!ctrWasDragged && (Math.abs(dx) > 10 || Math.abs(dy) > 10))
                    ctrWasDragged = true;
                if (ctrWasDragged && counterLp != null) {
                    int cW = counterLp.width;
                    int cH = counterLp.height;
                    counterLp.x = clamp(ctrDragStartX + (int) dx, 0, screenW - cW);
                    counterLp.y = clamp(ctrDragStartY + (int) dy, 0, screenH - cH);
                    if (wm != null && counterView != null) {
                        try { wm.updateViewLayout(counterView, counterLp); }
                        catch (Exception ignored) {}
                    }
                }
                return true;
            }
            case android.view.MotionEvent.ACTION_UP:
                if (ctrWasDragged && counterLp != null) {
                    try {
                        getSharedPreferences(MainActivity.PREFS_FLOAT, MODE_PRIVATE)
                            .edit()
                            .putInt(KEY_COUNTER_X, counterLp.x)
                            .putInt(KEY_COUNTER_Y, counterLp.y)
                            .apply();
                    } catch (Exception ignored) {}
                }
                ctrTrackedPtr = -1;
                ctrWasDragged = false;
                return true;
            case android.view.MotionEvent.ACTION_CANCEL:
                ctrTrackedPtr = -1;
                ctrWasDragged = false;
                return true;
        }
        return false;
    }

    private void hideCounter() {
        if (counterShown && wm != null && counterView != null) {
            try { wm.removeView(counterView); } catch (Exception ignored) {}
            counterView  = null;
            counterShown = false;
        }
    }

    // Обновить счётчик: принимаем текст таймера отдельно и TCP/UDP отдельно,
    // собираем многострочную строку и передаём в CounterView.
    private void updateCounterText(final String timerText) {
        ctrTimerText = timerText;
        refreshCounterView();
    }

    private void refreshCounterView() {
        if (!counterEnabled) return;
        final String combined = ctrTimerText
            + "\nTCP: " + formatPkts(ctrTcpPkts)
            + "\nUDP: " + formatPkts(ctrUdpPkts);
        handler.post(new Runnable() {
            public void run() {
                if (counterView != null) counterView.setText(combined);
            }
        });
    }

    private static String formatPkts(long n) {
        if (n < 1000) return String.valueOf(n);
        if (n < 1_000_000L) return String.format(java.util.Locale.US, "%.1fK", n / 1000.0);
        return String.format(java.util.Locale.US, "%.1fM", n / 1_000_000.0);
    }

    // Регистрируем приёмник широковещательной статистики от MyVpnService
    private void registerStatsReceiver() {
        if (statsReceiver != null) return;
        statsReceiver = new android.content.BroadcastReceiver() {
            @Override
            public void onReceive(android.content.Context ctx, android.content.Intent intent) {
                if (!MyVpnService.BROADCAST_STATS.equals(intent.getAction())) return;
                ctrTcpPkts = intent.getLongExtra("tcp", ctrTcpPkts);
                ctrUdpPkts = intent.getLongExtra("udp", ctrUdpPkts);
                refreshCounterView();
            }
        };
        try {
            android.content.IntentFilter f =
                new android.content.IntentFilter(MyVpnService.BROADCAST_STATS);
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                // 4 == Context.RECEIVER_NOT_EXPORTED (константа недоступна при targetSdkVersion < 33,
                // поэтому используем её числовое значение напрямую)
                registerReceiver(statsReceiver, f, 4);
            } else {
                registerReceiver(statsReceiver, f);
            }
        } catch (Exception ignored) {}
    }

    private void unregisterStatsReceiver() {
        if (statsReceiver != null) {
            try { unregisterReceiver(statsReceiver); } catch (Exception ignored) {}
            statsReceiver = null;
        }
    }

    private static String formatCounterMs(long remainingMs, long totalMs) {
        if (totalMs >= 10000) {
            long secs = (remainingMs + 999) / 1000;
            return String.valueOf(secs);
        } else {
            long secs = remainingMs / 1000;
            long ms   = remainingMs % 1000;
            return String.format(java.util.Locale.US, "%d.%03d", secs, ms);
        }
    }

    private void hideButton() {
        if (shown && wm != null && floatView != null) {
            try { wm.removeView(floatView); } catch (Exception ignored) {}
            floatView = null;
            shown     = false;
        }
    }

    private static int clamp(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }

    private void makeFloatChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                "cvpn_float", "Galaxy Clumsy Float", NotificationManager.IMPORTANCE_MIN);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildFloatNotif() {
        PendingIntent pi = PendingIntent.getActivity(this, 0,
            new Intent(this, MainActivity.class),
            Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return new Notification.Builder(this, "cvpn_float")
                .setContentTitle("Galaxy Clumsy").setContentText("Кнопка активна")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pi).setOngoing(true).build();
        } else {
            return new Notification.Builder(this)
                .setContentTitle("Galaxy Clumsy").setContentText("Кнопка активна")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pi).setOngoing(true).build();
        }
    }

    // ─── Neon FloatView с анимацией «стекающего» таймера ─────────────────

    static final class FloatView extends View {
        private String label;
        private int    bgColor;
        private final int size;
        private android.graphics.Bitmap customImage = null;
        private android.graphics.Bitmap roundedImg  = null;

        private float drainFraction = 0f;
        private boolean draining    = false;
        private long    drainStartMs   = 0;
        private long    drainTotalMs   = 0;

        private final Paint bgPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint drainPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txtPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint imgPaint    = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        // Pre-allocated to avoid GC pressure during onDraw
        private final RectF drawRect    = new RectF();
        private final RectF greyRect    = new RectF();
        private final Paint linePaint   = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final android.os.Handler uiHandler = new android.os.Handler(android.os.Looper.getMainLooper());
        private Runnable animRunnable = null;

        FloatView(android.content.Context ctx, int size, String lbl, int color, android.graphics.Bitmap img) {
            super(ctx);
            this.size    = size;
            this.label   = lbl;
            this.bgColor = color;
            if (img != null) setCustomImage(img);

            txtPaint.setColor(Color.WHITE);
            txtPaint.setTextAlign(Paint.Align.CENTER);
            txtPaint.setFakeBoldText(true);

            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(2.5f);

            drainPaint.setColor(0xA6606060); // будет переопределён в onDraw

            // Pre-configure linePaint once
            linePaint.setColor(0x88FFFFFF);
            linePaint.setStrokeWidth(1.5f);
        }

        void setCustomImage(android.graphics.Bitmap img) {
            customImage = img;
            roundedImg  = null; // invalidate cache
            invalidate();
        }

        void update(String newLabel, int newColor) {
            label   = newLabel;
            bgColor = newColor;
            invalidate();
        }

        void startDrainAnimation(long totalMs) {
            draining      = true;
            drainFraction = 1.0f;
            drainStartMs  = android.os.SystemClock.elapsedRealtime();
            drainTotalMs  = totalMs;
            label         = "";

            if (animRunnable != null) uiHandler.removeCallbacks(animRunnable);
            animRunnable = new Runnable() {
                @Override public void run() {
                    if (!draining) return;
                    long elapsed = android.os.SystemClock.elapsedRealtime() - drainStartMs;
                    drainFraction = Math.max(0f, 1f - (float) elapsed / drainTotalMs);
                    invalidate();
                    // 33 мс = ~30 fps вместо 60 fps — анимация плавная,
                    // нагрузка на рендеринг вдвое меньше.
                    if (drainFraction > 0f) uiHandler.postDelayed(this, 33);
                }
            };
            uiHandler.postDelayed(animRunnable, 33);
            invalidate();
        }

        void stopDrainAnimation() {
            draining      = false;
            drainFraction = 0f;
            if (animRunnable != null) {
                uiHandler.removeCallbacks(animRunnable);
                animRunnable = null;
            }
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth();
            float h = getHeight();
            float r = size * 0.22f;
            float pad = 4f;

            drawRect.set(pad, pad, w - pad, h - pad);

            bgPaint.setColor(bgColor | 0xFF000000);
            canvas.drawRoundRect(drawRect, r, r, bgPaint);

            // Custom image overlay
            if (customImage != null) {
                if (roundedImg == null || roundedImg.getWidth() != (int)(w - 2*pad)) {
                    int sz = (int)(w - 2 * pad);
                    android.graphics.Bitmap out = android.graphics.Bitmap.createBitmap(sz, sz, android.graphics.Bitmap.Config.ARGB_8888);
                    Canvas tmp = new Canvas(out);
                    Paint mp = new Paint(Paint.ANTI_ALIAS_FLAG);
                    tmp.drawRoundRect(new RectF(0, 0, sz, sz), r, r, mp);
                    mp.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SRC_IN));
                    float sc = (float) sz / Math.min(customImage.getWidth(), customImage.getHeight());
                    int sw = Math.round(customImage.getWidth() * sc);
                    int sh = Math.round(customImage.getHeight() * sc);
                    android.graphics.Bitmap scaled = android.graphics.Bitmap.createScaledBitmap(customImage, sw, sh, true);
                    tmp.drawBitmap(scaled, -(sw - sz) / 2f, -(sh - sz) / 2f, mp);
                    roundedImg = out;
                }
                canvas.drawBitmap(roundedImg, pad, pad, imgPaint);
            }

            if (draining && drainFraction > 0f) {
                float greyTop = pad + (h - 2 * pad) * (1f - drainFraction);
                greyRect.set(pad, greyTop, w - pad, h - pad);
                canvas.save();
                canvas.clipRect(greyRect);
                // Полупрозрачная серая заливка: фото слегка просвечивает
                // С фото — 75% непрозрачности (немного заметнее, но фото угадывается)
                // Без фото — 90% (насыщенный, чёткий индикатор)
                int drainAlpha = (customImage != null) ? 0xC0 : 0xE6;
                drainPaint.setColor((drainAlpha << 24) | 0x606060); // нейтральный серый
                canvas.drawRoundRect(drawRect, r, r, drainPaint);
                canvas.restore();
                if (drainFraction > 0.02f && drainFraction < 0.98f) {
                    // Линия-граница: при фото — более заметная белая, без фото — стандартная
                    linePaint.setColor(customImage != null ? 0xCCFFFFFF : 0x88FFFFFF);
                    linePaint.setStrokeWidth(customImage != null ? 2f : 1.5f);
                    canvas.drawLine(pad + r * 0.3f, greyTop, w - pad - r * 0.3f, greyTop, linePaint);
                }
            }

            int br = lighten(bgColor, 0.30f);
            borderPaint.setColor(br | 0xFF000000);
            canvas.drawRoundRect(drawRect, r, r, borderPaint);

            if (customImage == null && (!draining || label.length() > 0)) {
                txtPaint.setColor(textColorFor(bgColor));
                txtPaint.setTextSize(size * 0.36f);
                float ty = h / 2f - (txtPaint.descent() + txtPaint.ascent()) / 2f;
                canvas.drawText(label, w / 2f, ty, txtPaint);
            }
        }

        private static int lighten(int color, float amount) {
            int a = (color >> 24) & 0xFF;
            int r = Math.min(255, (int)(((color >> 16) & 0xFF) + 255 * amount));
            int g = Math.min(255, (int)(((color >> 8)  & 0xFF) + 255 * amount));
            int b = Math.min(255, (int)((color & 0xFF) + 255 * amount));
            return (a << 24) | (r << 16) | (g << 8) | b;
        }

        private static int textColorFor(int color) {
            int r = (color >> 16) & 0xFF;
            int g = (color >> 8)  & 0xFF;
            int b = color & 0xFF;
            double luminance = (0.299 * r + 0.587 * g + 0.114 * b);
            return luminance > 160 ? 0xFF001A0E : 0xFFFFFFFF;
        }
    }

    // ─── Маленький плавающий счётчик — настраиваемый ─────────────────────

    static final class CounterView extends android.view.View {
        private String text = "Пауза";

        private int textSizeSp  = 16;
        private int textColor   = 0xFFFFFFFF;
        private int textAlpha   = 255;
        private int bgAlpha     = 220;

        private final android.graphics.Paint bgPaint   = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint txtPaint  = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint brdPaint  = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        // Pre-allocated to avoid per-frame GC
        private final android.graphics.RectF drawRect  = new android.graphics.RectF();
        // Cached density — never changes at runtime
        private float density = 1f;

        CounterView(android.content.Context ctx) {
            super(ctx);
            density = ctx.getResources().getDisplayMetrics().density;
            refreshPaints();
        }

        /** Применяет стиль: размер/цвет/прозрачность текста и прозрачность фона */
        void applyStyle(int textSizeSp, int textColor, int textAlpha, int bgAlpha) {
            this.textSizeSp = textSizeSp;
            this.textColor  = textColor;
            this.textAlpha  = textAlpha;
            this.bgAlpha    = bgAlpha;
            refreshPaints();
            invalidate();
        }

        private void refreshPaints() {
            // Фон — чёрный с настраиваемой прозрачностью
            bgPaint.setColor((bgAlpha << 24) | 0x000000);

            // Рамка — адаптируется к прозрачности фона
            brdPaint.setStyle(android.graphics.Paint.Style.STROKE);
            brdPaint.setStrokeWidth(1.5f);
            int brdAlpha = Math.max(40, bgAlpha - 40);
            brdPaint.setColor((brdAlpha << 24) | 0x2A3A4A);

            // Текст — цвет + прозрачность
            int finalTextColor = (textAlpha << 24) | (textColor & 0x00FFFFFF);
            txtPaint.setColor(finalTextColor);
            txtPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
            txtPaint.setFakeBoldText(true);
            txtPaint.setAntiAlias(true);
        }

        void setText(String t) {
            this.text = t;
            invalidate();
        }

        @Override
        protected void onDraw(android.graphics.Canvas canvas) {
            float w = getWidth();
            float h = getHeight();
            float r = h * 0.18f;

            drawRect.set(2, 2, w - 2, h - 2);
            canvas.drawRoundRect(drawRect, r, r, bgPaint);
            canvas.drawRoundRect(drawRect, r, r, brdPaint);

            // Разбиваем текст на строки
            String[] lines = text.split("\n", -1);
            int n = lines.length;

            if (n == 1) {
                // Одна строка — центрируем как раньше
                float pxSize = textSizeSp * density;
                float maxPx  = h * 0.65f;
                if (pxSize > maxPx) pxSize = maxPx;
                txtPaint.setTextSize(pxSize);
                float textW = txtPaint.measureText(lines[0]);
                if (textW > w - 16) {
                    pxSize *= (w - 16) / textW;
                    txtPaint.setTextSize(pxSize);
                }
                float ty = h / 2f - (txtPaint.descent() + txtPaint.ascent()) / 2f;
                canvas.drawText(lines[0], w / 2f, ty, txtPaint);
            } else {
                // Несколько строк: первая чуть крупнее (таймер), остальные мельче
                float pad  = h * 0.08f;
                float usableH = h - 2 * pad;
                float rowH  = usableH / n;

                for (int i = 0; i < n; i++) {
                    float scale = (i == 0) ? 1.0f : 0.75f;
                    float pxSize = textSizeSp * density * scale;
                    float maxPx  = rowH * 0.72f;
                    if (pxSize > maxPx) pxSize = maxPx;
                    txtPaint.setTextSize(pxSize);

                    // Уменьшаем если не влезает по ширине
                    float textW = txtPaint.measureText(lines[i]);
                    if (textW > w - 12) {
                        pxSize *= (w - 12) / textW;
                        txtPaint.setTextSize(pxSize);
                    }

                    // Центр строки
                    float rowMid = pad + rowH * i + rowH / 2f;
                    float ty = rowMid - (txtPaint.descent() + txtPaint.ascent()) / 2f;
                    canvas.drawText(lines[i], w / 2f, ty, txtPaint);
                }
            }
        }
    }
}
