package com.clumsyvpn;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.view.View;

/**
 * Компактный вращающийся индикатор загрузки — дуга на Canvas, крутится сама
 * по себе через Handler-цикл. Не завязан на системную тему ProgressBar,
 * которая в некоторых сборках AIDE рисуется одним статичным кругом без
 * анимации и в цвет, который не подчиняется тонировке.
 */
public class LoadingSpinnerView extends View {

    private static final float SWEEP_DEG = 100f; // длина видимой дуги
    private static final float SPEED_DEG = 9f;   // градусов за кадр (~60fps)
    private static final int   FRAME_MS  = 16;

    private final Paint  paint = new Paint();
    private final RectF  oval  = new RectF();
    private final Handler handler = new Handler();

    private float angle = 0f;
    private boolean running = false;

    public LoadingSpinnerView(Context ctx) {
        super(ctx);
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(0xFF00E5FF);
    }

    public void setColor(int colorArgb) {
        paint.setColor(colorArgb);
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        float stroke = Math.min(w, h) * 0.14f;
        paint.setStrokeWidth(stroke);
        float inset = stroke / 2f + 1f;
        oval.set(inset, inset, w - inset, h - inset);
    }

    private final Runnable frame = new Runnable() {
        public void run() {
            if (!running) return;
            angle = (angle + SPEED_DEG) % 360f;
            invalidate();
            handler.postDelayed(this, FRAME_MS);
        }
    };

    public void start() {
        if (running) return;
        running = true;
        handler.post(frame);
    }

    public void stop() {
        running = false;
        handler.removeCallbacks(frame);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawArc(oval, angle, SWEEP_DEG, false, paint);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (running) handler.post(frame);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        handler.removeCallbacks(frame);
    }
}
