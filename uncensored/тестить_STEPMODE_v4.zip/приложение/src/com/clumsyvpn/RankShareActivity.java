package com.clumsyvpn;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * RankShareActivity - раздел "Поделитесь вашим максимальным званием"
 * Позволяет загружать до 3 фото с описанием и отображает ленту всех постов
 */
public class RankShareActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int PICK_IMAGES = 1001;
    private static final int PERMISSION_REQUEST_CODE = 1002;
    private static final int MAX_IMAGES = 3;
    private static final int POLL_INTERVAL_MS = 3000;

    private String myLogin = "Гость";
    private String myCreatedAt = "";
    private String myPassword = "";
    private String serverUrl;
    private boolean isMyAdmin = false;

    private LinearLayout postsContainer;
    private ScrollView scrollView;
    private LinearLayout selectedImagesPreview;
    private EditText descriptionField;
    private TextView btnUploadPhoto;
    private TextView btnSubmit;
    private Handler pollHandler;
    private Runnable pollRunnable;
    private long lastPostTime = 0;

    private List<Uri> selectedImageUris = new ArrayList<>();
    private boolean isMuted = false;
    private FrameLayout contentFrame;

    // Режим удаления постов (только для админа)
    private boolean deleteModeActiveRank = false;
    private java.util.HashMap<String, Boolean> selectedPostIds = new java.util.HashMap<>();
    private java.util.HashMap<View, String> postViewToId = new java.util.HashMap<>();
    private LinearLayout rankDeleteModeBar;
    private TextView rankDeleteCountLabel;

    // Анимация фона
    private static final int[] BG_COLORS = {
        0xFF0A0F1A, 0xFF0D1A2E, 0xFF0A1A2A, 0xFF0D1529, 0xFF0A0F1A
    };
    private LinearLayout bgView;
    private Handler bgHandler;
    private int bgStep = 0;

    private AccountStatusMonitor accountStatusMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences(AuthActivity.PREFS, MODE_PRIVATE);
        myLogin = prefs.getString(AuthActivity.KEY_LOGIN, "Гость");
        if (myLogin == null || myLogin.isEmpty()) myLogin = "Гость";
        myCreatedAt = prefs.getString(AuthActivity.KEY_CREATED_AT, "");
        myPassword  = prefs.getString(AuthActivity.KEY_PASSWORD, "");
        isMyAdmin   = prefs.getBoolean("is_admin", false);
        serverUrl = AuthActivity.SERVER_URL;

        accountStatusMonitor = new AccountStatusMonitor(this);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        buildUI();
        startBgAnimation();
        checkMuteStatus();
        startPolling();
    }

    private void buildUI() {
        // Корневой layout
        LinearLayout root = new LinearLayout(this);
        root.setLayoutParams(new ViewGroup.LayoutParams(MATCH, MATCH));
        root.setOrientation(LinearLayout.VERTICAL);

        // Анимированный фон
        bgView = new LinearLayout(this);
        bgView.setLayoutParams(new ViewGroup.LayoutParams(MATCH, MATCH));
        bgView.setOrientation(LinearLayout.VERTICAL);
        bgView.setBackgroundColor(BG_COLORS[0]);

        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new ViewGroup.LayoutParams(MATCH, MATCH));
        frameLayout.addView(bgView);

        LinearLayout contentLayout = new LinearLayout(this);
        contentLayout.setLayoutParams(new ViewGroup.LayoutParams(MATCH, MATCH));
        contentLayout.setOrientation(LinearLayout.VERTICAL);

        // Шапка
        RelativeLayout header = buildHeader();
        contentLayout.addView(header);

        // Разделитель
        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(MATCH, UIHelper.dp(1)));
        divider.setBackgroundColor(0xFF1A2430);
        contentLayout.addView(divider);

        // Frame для контента (может быть заменён на mute-баннер)
        contentFrame = new FrameLayout(this);
        contentFrame.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));

        // Основной контент
        LinearLayout mainContent = buildMainContent();
        contentFrame.addView(mainContent);

        contentLayout.addView(contentFrame);

        // Панель удаления (скрыта по умолчанию)
        rankDeleteModeBar = buildRankDeleteModeBar();
        rankDeleteModeBar.setVisibility(View.GONE);
        contentLayout.addView(rankDeleteModeBar);

        frameLayout.addView(contentLayout);
        root.addView(frameLayout);

        setContentView(root);
    }

    private RelativeLayout buildHeader() {
        RelativeLayout header = new RelativeLayout(this);
        LinearLayout.LayoutParams headerParams = new LinearLayout.LayoutParams(MATCH, UIHelper.dp(68));
        header.setLayoutParams(headerParams);
        header.setPadding(UIHelper.dp(12), 0, UIHelper.dp(16), 0);

        // Кнопка назад
        FrameLayout backFrame = new FrameLayout(this);
        RelativeLayout.LayoutParams backParams = new RelativeLayout.LayoutParams(UIHelper.dp(44), UIHelper.dp(44));
        backParams.addRule(RelativeLayout.CENTER_VERTICAL);
        backFrame.setLayoutParams(backParams);
        GradientDrawable backBg = new GradientDrawable();
        backBg.setShape(GradientDrawable.RECTANGLE);
        backBg.setCornerRadius(UIHelper.dp(12));
        backBg.setColor(0xFF1A2430);
        backFrame.setBackground(backBg);

        TextView btnBack = new TextView(this);
        btnBack.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        btnBack.setText("‹");
        btnBack.setTextSize(26);
        btnBack.setTypeface(null, Typeface.BOLD);
        btnBack.setTextColor(0xFF00FF9D);
        btnBack.setGravity(Gravity.CENTER);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        backFrame.addView(btnBack);
        header.addView(backFrame);

        // Заголовок
        LinearLayout titleLayout = new LinearLayout(this);
        RelativeLayout.LayoutParams titleParams = new RelativeLayout.LayoutParams(WRAP, WRAP);
        titleParams.addRule(RelativeLayout.CENTER_IN_PARENT);
        titleLayout.setLayoutParams(titleParams);
        titleLayout.setOrientation(LinearLayout.HORIZONTAL);
        titleLayout.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setLayoutParams(new LinearLayout.LayoutParams(WRAP, WRAP));
        title.setText("🏆 ЗВАНИЯ");
        title.setTextSize(16);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.25f);
        title.setTextColor(0xFFFFFFFF);
        titleLayout.addView(title);

        header.addView(titleLayout);

        // Кнопка «Удалить сообщения» — только для администратора
        if (isMyAdmin) {
            FrameLayout deleteBtn = new FrameLayout(this);
            GradientDrawable delBg = new GradientDrawable();
            delBg.setShape(GradientDrawable.OVAL);
            delBg.setColor(0xFF1A0A0A);
            delBg.setStroke(1, 0xFFFF1E4E);
            deleteBtn.setBackground(delBg);
            RelativeLayout.LayoutParams dblp = new RelativeLayout.LayoutParams(UIHelper.dp(44), UIHelper.dp(44));
            dblp.addRule(RelativeLayout.CENTER_VERTICAL);
            dblp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
            deleteBtn.setLayoutParams(dblp);
            TextView delIcon = new TextView(this);
            delIcon.setText("🗑");
            delIcon.setTextSize(16);
            delIcon.setGravity(Gravity.CENTER);
            delIcon.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
            deleteBtn.addView(delIcon);
            deleteBtn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { toggleRankDeleteMode(); }
            });
            header.addView(deleteBtn);
        }

        return header;
    }

    private LinearLayout buildMainContent() {
        LinearLayout mainContent = new LinearLayout(this);
        mainContent.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        mainContent.setOrientation(LinearLayout.VERTICAL);

        // Предупреждение сверху
        LinearLayout warningBanner = buildWarningBanner();
        mainContent.addView(warningBanner);

        // ScrollView с постами
        scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));
        scrollView.setFillViewport(true);

        postsContainer = new LinearLayout(this);
        postsContainer.setLayoutParams(new ScrollView.LayoutParams(MATCH, WRAP));
        postsContainer.setOrientation(LinearLayout.VERTICAL);
        postsContainer.setPadding(UIHelper.dp(16), UIHelper.dp(12), UIHelper.dp(16), UIHelper.dp(12));

        scrollView.addView(postsContainer);
        mainContent.addView(scrollView);

        // Блок загрузки
        LinearLayout uploadSection = buildUploadSection();
        mainContent.addView(uploadSection);

        return mainContent;
    }

    private LinearLayout buildWarningBanner() {
        LinearLayout banner = new LinearLayout(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(MATCH, WRAP);
        params.setMargins(UIHelper.dp(16), UIHelper.dp(8), UIHelper.dp(16), UIHelper.dp(8)); // Уменьшили верхний отступ с 16 до 8
        banner.setLayoutParams(params);
        banner.setOrientation(LinearLayout.VERTICAL);
        banner.setPadding(UIHelper.dp(16), UIHelper.dp(14), UIHelper.dp(16), UIHelper.dp(14));

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(UIHelper.dp(12));
        bg.setColor(0xFF2A1F1F);
        bg.setStroke(UIHelper.dp(2), 0xFFFF1E4E);
        banner.setBackground(bg);

        // Иконка + заголовок
        LinearLayout headerLine = new LinearLayout(this);
        headerLine.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        headerLine.setOrientation(LinearLayout.HORIZONTAL);
        headerLine.setGravity(Gravity.CENTER_VERTICAL);

        TextView icon = new TextView(this);
        icon.setLayoutParams(new LinearLayout.LayoutParams(WRAP, WRAP));
        icon.setText("⚠️");
        icon.setTextSize(18);
        LinearLayout.LayoutParams iconParams = (LinearLayout.LayoutParams) icon.getLayoutParams();
        iconParams.setMargins(0, 0, UIHelper.dp(10), 0);
        icon.setLayoutParams(iconParams);

        TextView warningTitle = new TextView(this);
        warningTitle.setLayoutParams(new LinearLayout.LayoutParams(WRAP, WRAP));
        warningTitle.setText("ВНИМАНИЕ");
        warningTitle.setTextSize(14);
        warningTitle.setTypeface(null, Typeface.BOLD);
        warningTitle.setTextColor(0xFFFF1E4E);

        headerLine.addView(icon);
        headerLine.addView(warningTitle);
        banner.addView(headerLine);

        // Текст предупреждения
        TextView warningText = new TextView(this);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(MATCH, WRAP);
        textParams.setMargins(0, UIHelper.dp(8), 0, 0);
        warningText.setLayoutParams(textParams);
        warningText.setText("Если вы будете отправлять рекламу или фото сексуального характера — вы получите мут в этом разделе навсегда");
        warningText.setTextSize(13);
        warningText.setTextColor(0xFFCCCCCC);
        warningText.setLineSpacing(UIHelper.dp(4), 1f);

        banner.addView(warningText);

        return banner;
    }

    private LinearLayout buildUploadSection() {
        LinearLayout uploadSection = new LinearLayout(this);
        uploadSection.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        uploadSection.setOrientation(LinearLayout.VERTICAL);
        uploadSection.setPadding(UIHelper.dp(16), UIHelper.dp(12), UIHelper.dp(16), UIHelper.dp(16));

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(0);
        bg.setColor(0xFF0F1419);
        uploadSection.setBackground(bg);

        // Кнопка загрузки фото
        btnUploadPhoto = new TextView(this);
        LinearLayout.LayoutParams uploadBtnParams = new LinearLayout.LayoutParams(MATCH, UIHelper.dp(50));
        btnUploadPhoto.setLayoutParams(uploadBtnParams);
        btnUploadPhoto.setText("📷 Загрузить фото");
        btnUploadPhoto.setTextSize(15);
        btnUploadPhoto.setTypeface(null, Typeface.BOLD);
        btnUploadPhoto.setTextColor(0xFFFFFFFF);
        btnUploadPhoto.setGravity(Gravity.CENTER);

        GradientDrawable uploadBg = new GradientDrawable();
        uploadBg.setShape(GradientDrawable.RECTANGLE);
        uploadBg.setCornerRadius(UIHelper.dp(12));
        uploadBg.setColor(0xFF1A2430);
        btnUploadPhoto.setBackground(uploadBg);
        btnUploadPhoto.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openImagePicker();
            }
        });

        uploadSection.addView(btnUploadPhoto);

        // Превью выбранных фото
        selectedImagesPreview = new LinearLayout(this);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(MATCH, WRAP);
        previewParams.setMargins(0, UIHelper.dp(12), 0, 0);
        selectedImagesPreview.setLayoutParams(previewParams);
        selectedImagesPreview.setOrientation(LinearLayout.HORIZONTAL);
        selectedImagesPreview.setVisibility(View.GONE);
        uploadSection.addView(selectedImagesPreview);

        // Поле описания
        descriptionField = new EditText(this);
        LinearLayout.LayoutParams descParams = new LinearLayout.LayoutParams(MATCH, UIHelper.dp(80));
        descParams.setMargins(0, UIHelper.dp(12), 0, 0);
        descriptionField.setLayoutParams(descParams);
        descriptionField.setHint("Добавьте описание (необязательно)");
        descriptionField.setTextSize(14);
        descriptionField.setTextColor(0xFFFFFFFF);
        descriptionField.setHintTextColor(0xFF666666);
        descriptionField.setPadding(UIHelper.dp(16), UIHelper.dp(12), UIHelper.dp(16), UIHelper.dp(12));
        descriptionField.setGravity(Gravity.TOP | Gravity.START);
        descriptionField.setMaxLines(4);

        GradientDrawable descBg = new GradientDrawable();
        descBg.setShape(GradientDrawable.RECTANGLE);
        descBg.setCornerRadius(UIHelper.dp(12));
        descBg.setColor(0xFF1A2430);
        descriptionField.setBackground(descBg);
        descriptionField.setVisibility(View.GONE);

        uploadSection.addView(descriptionField);

        // Кнопка отправить
        btnSubmit = new TextView(this);
        LinearLayout.LayoutParams submitParams = new LinearLayout.LayoutParams(MATCH, UIHelper.dp(50));
        submitParams.setMargins(0, UIHelper.dp(12), 0, 0);
        btnSubmit.setLayoutParams(submitParams);
        btnSubmit.setText("🚀 Отправить");
        btnSubmit.setTextSize(15);
        btnSubmit.setTypeface(null, Typeface.BOLD);
        btnSubmit.setTextColor(0xFFFFFFFF);
        btnSubmit.setGravity(Gravity.CENTER);

        GradientDrawable submitBg = new GradientDrawable();
        submitBg.setShape(GradientDrawable.RECTANGLE);
        submitBg.setCornerRadius(UIHelper.dp(12));
        submitBg.setColor(0xFF00FF9D);
        btnSubmit.setBackground(submitBg);
        btnSubmit.setVisibility(View.GONE);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                submitPost();
            }
        });

        uploadSection.addView(btnSubmit);

        return uploadSection;
    }

    // ── Встроенный bottom-sheet галерея ──────────────────────────────────────
    private Dialog galleryDialog;
    private List<Uri> galleryUris = new ArrayList<>();
    private List<Uri> tempSelectedUris = new ArrayList<>();
    private LinearLayout galleryGrid;
    private TextView galleryConfirmBtn;

    private void openImagePicker() {
        // Проверяем разрешение перед открытием галереи
        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
            return;
        }
        
        tempSelectedUris = new ArrayList<>(selectedImageUris);
        loadDevicePhotos();
        showGalleryBottomSheet();
    }
    
    /**
     * Обработка результата запроса разрешений
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Разрешение выдано - сразу открываем галерею
                tempSelectedUris = new ArrayList<>(selectedImageUris);
                loadDevicePhotos();
                showGalleryBottomSheet();
            } else {
                // Разрешение не выдано
                Toast.makeText(this, "Для загрузки фото необходимо разрешение", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void loadDevicePhotos() {
        galleryUris.clear();
        try {
            String[] proj = { MediaStore.Images.Media._ID };
            android.database.Cursor cursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj,
                null, null, MediaStore.Images.Media.DATE_ADDED + " DESC");
            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                int count = 0;
                while (cursor.moveToNext() && count < 60) {
                    long id = cursor.getLong(idCol);
                    Uri uri = android.net.Uri.withAppendedPath(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, String.valueOf(id));
                    galleryUris.add(uri);
                    count++;
                }
                cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showGalleryBottomSheet() {
        galleryDialog = new Dialog(this);
        galleryDialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);

        // Root container
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);

        GradientDrawable containerBg = new GradientDrawable();
        containerBg.setShape(GradientDrawable.RECTANGLE);
        containerBg.setCornerRadii(new float[]{UIHelper.dp(22), UIHelper.dp(22), UIHelper.dp(22), UIHelper.dp(22), 0, 0, 0, 0});
        containerBg.setColor(0xFF0D1520);
        containerBg.setStroke(UIHelper.dp(1), 0xFF1E3040);
        container.setBackground(containerBg);

        // Handle bar
        FrameLayout handleWrap = new FrameLayout(this);
        LinearLayout.LayoutParams handleWrapLp = new LinearLayout.LayoutParams(MATCH, UIHelper.dp(28));
        handleWrap.setLayoutParams(handleWrapLp);
        View handle = new View(this);
        FrameLayout.LayoutParams handleLp = new FrameLayout.LayoutParams(UIHelper.dp(40), UIHelper.dp(4));
        handleLp.gravity = Gravity.CENTER;
        handle.setLayoutParams(handleLp);
        GradientDrawable handleBg = new GradientDrawable();
        handleBg.setShape(GradientDrawable.RECTANGLE);
        handleBg.setCornerRadius(UIHelper.dp(2));
        handleBg.setColor(0xFF2E4460);
        handle.setBackground(handleBg);
        handleWrap.addView(handle);
        container.addView(handleWrap);

        // Header row
        LinearLayout headerRow = new LinearLayout(this);
        LinearLayout.LayoutParams headerLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        headerLp.setMargins(UIHelper.dp(20), 0, UIHelper.dp(16), UIHelper.dp(12));
        headerRow.setLayoutParams(headerLp);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView titleTv = new TextView(this);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        titleTv.setText("Выберите фото");
        titleTv.setTextSize(17);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setTextColor(0xFFFFFFFF);
        headerRow.addView(titleTv);

        TextView subtitleTv = new TextView(this);
        subtitleTv.setLayoutParams(new LinearLayout.LayoutParams(WRAP, WRAP));
        subtitleTv.setText("до 3 шт.");
        subtitleTv.setTextSize(13);
        subtitleTv.setTextColor(0xFF4A6A8A);
        headerRow.addView(subtitleTv);
        container.addView(headerRow);

        // Gallery grid inside ScrollView
        android.widget.HorizontalScrollView hScroll = null;
        ScrollView vScroll = new ScrollView(this);
        LinearLayout.LayoutParams vScrollLp = new LinearLayout.LayoutParams(MATCH, 0);
        // Half screen
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        vScrollLp.height = (int)(screenHeight * 0.45f);
        vScroll.setLayoutParams(vScrollLp);
        vScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        galleryGrid = new LinearLayout(this);
        galleryGrid.setOrientation(LinearLayout.VERTICAL);
        galleryGrid.setPadding(UIHelper.dp(12), 0, UIHelper.dp(12), UIHelper.dp(8));

        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int cols = 3;
        int spacing = UIHelper.dp(4);
        int cellSize = (screenWidth - UIHelper.dp(24) - spacing * (cols - 1)) / cols;

        for (int i = 0; i < galleryUris.size(); i += cols) {
            LinearLayout row = new LinearLayout(this);
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(MATCH, WRAP);
            if (i > 0) rowLp.topMargin = spacing;
            row.setLayoutParams(rowLp);
            row.setOrientation(LinearLayout.HORIZONTAL);

            for (int j = 0; j < cols; j++) {
                int idx = i + j;
                if (idx < galleryUris.size()) {
                    final Uri uri = galleryUris.get(idx);
                    FrameLayout cell = new FrameLayout(this);
                    LinearLayout.LayoutParams cellLp = new LinearLayout.LayoutParams(cellSize, cellSize);
                    if (j > 0) cellLp.leftMargin = spacing;
                    cell.setLayoutParams(cellLp);

                    ImageView iv = new ImageView(this);
                    iv.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
                    iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    GradientDrawable ivBg = new GradientDrawable();
                    ivBg.setShape(GradientDrawable.RECTANGLE);
                    ivBg.setCornerRadius(UIHelper.dp(8));
                    ivBg.setColor(0xFF1A2430);
                    iv.setBackground(ivBg);
                    iv.setClipToOutline(true);

                    // Load thumbnail async
                    final ImageView finalIv = iv;
                    new AsyncTask<Void, Void, Bitmap>() {
                        @Override protected Bitmap doInBackground(Void... v) {
                            try {
                                return MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                            } catch (Exception e) { return null; }
                        }
                        @Override protected void onPostExecute(Bitmap bmp) {
                            if (bmp != null) finalIv.setImageBitmap(resizeBitmap(bmp, 200));
                        }
                    }.execute();

                    cell.addView(iv);

                    // Selection overlay
                    final View selOverlay = new View(this);
                    selOverlay.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
                    GradientDrawable selBg = new GradientDrawable();
                    selBg.setShape(GradientDrawable.RECTANGLE);
                    selBg.setCornerRadius(UIHelper.dp(8));
                    selBg.setColor(0x8000FF9D);
                    selOverlay.setBackground(selBg);
                    selOverlay.setVisibility(tempSelectedUris.contains(uri) ? View.VISIBLE : View.GONE);
                    cell.addView(selOverlay);

                    // Selection number badge
                    final TextView numBadge = new TextView(this);
                    FrameLayout.LayoutParams badgeLp = new FrameLayout.LayoutParams(UIHelper.dp(22), UIHelper.dp(22));
                    badgeLp.gravity = Gravity.TOP | Gravity.END;
                    badgeLp.topMargin = UIHelper.dp(4);
                    badgeLp.rightMargin = UIHelper.dp(4);
                    numBadge.setLayoutParams(badgeLp);
                    numBadge.setGravity(Gravity.CENTER);
                    numBadge.setTextSize(11);
                    numBadge.setTypeface(null, Typeface.BOLD);
                    numBadge.setTextColor(0xFF000000);
                    GradientDrawable numBg = new GradientDrawable();
                    numBg.setShape(GradientDrawable.OVAL);
                    numBg.setColor(0xFF00FF9D);
                    numBadge.setBackground(numBg);
                    numBadge.setVisibility(View.GONE);
                    cell.addView(numBadge);

                    updateCellSelection(uri, selOverlay, numBadge);

                    cell.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            if (tempSelectedUris.contains(uri)) {
                                tempSelectedUris.remove(uri);
                            } else {
                                if (tempSelectedUris.size() >= MAX_IMAGES) {
                                    Toast.makeText(RankShareActivity.this, "Максимум 3 фото", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                tempSelectedUris.add(uri);
                            }
                            updateCellSelection(uri, selOverlay, numBadge);
                            updateGalleryConfirmBtn();
                        }
                    });

                    row.addView(cell);
                } else {
                    // Empty placeholder
                    View spacer = new View(this);
                    LinearLayout.LayoutParams spLp = new LinearLayout.LayoutParams(cellSize, cellSize);
                    if (j > 0) spLp.leftMargin = spacing;
                    spacer.setLayoutParams(spLp);
                    row.addView(spacer);
                }
            }
            galleryGrid.addView(row);
        }

        if (galleryUris.isEmpty()) {
            TextView emptyTv = new TextView(this);
            emptyTv.setLayoutParams(new LinearLayout.LayoutParams(MATCH, UIHelper.dp(120)));
            emptyTv.setText("Фото не найдены");
            emptyTv.setTextSize(14);
            emptyTv.setTextColor(0xFF4A6A8A);
            emptyTv.setGravity(Gravity.CENTER);
            galleryGrid.addView(emptyTv);
        }

        vScroll.addView(galleryGrid);
        container.addView(vScroll);

        // Bottom buttons
        LinearLayout bottomBtns = new LinearLayout(this);
        LinearLayout.LayoutParams bbLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        bbLp.setMargins(UIHelper.dp(16), UIHelper.dp(12), UIHelper.dp(16), UIHelper.dp(20));
        bottomBtns.setLayoutParams(bbLp);
        bottomBtns.setOrientation(LinearLayout.HORIZONTAL);
        bottomBtns.setGravity(Gravity.CENTER_VERTICAL);

        TextView cancelBtn = new TextView(this);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, UIHelper.dp(48), 1f);
        cancelLp.rightMargin = UIHelper.dp(8);
        cancelBtn.setLayoutParams(cancelLp);
        cancelBtn.setText("Отмена");
        cancelBtn.setTextSize(14);
        cancelBtn.setTypeface(null, Typeface.BOLD);
        cancelBtn.setTextColor(0xFFAAAAAA);
        cancelBtn.setGravity(Gravity.CENTER);
        GradientDrawable cancelBg = new GradientDrawable();
        cancelBg.setShape(GradientDrawable.RECTANGLE);
        cancelBg.setCornerRadius(UIHelper.dp(12));
        cancelBg.setColor(0xFF1A2430);
        cancelBtn.setBackground(cancelBg);
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { galleryDialog.dismiss(); }
        });
        bottomBtns.addView(cancelBtn);

        galleryConfirmBtn = new TextView(this);
        LinearLayout.LayoutParams confirmLp = new LinearLayout.LayoutParams(0, UIHelper.dp(48), 2f);
        galleryConfirmBtn.setLayoutParams(confirmLp);
        galleryConfirmBtn.setTextSize(14);
        galleryConfirmBtn.setTypeface(null, Typeface.BOLD);
        galleryConfirmBtn.setTextColor(0xFF000000);
        galleryConfirmBtn.setGravity(Gravity.CENTER);
        GradientDrawable confirmBg = new GradientDrawable();
        confirmBg.setShape(GradientDrawable.RECTANGLE);
        confirmBg.setCornerRadius(UIHelper.dp(12));
        confirmBg.setColor(0xFF00FF9D);
        galleryConfirmBtn.setBackground(confirmBg);
        updateGalleryConfirmBtn();
        galleryConfirmBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (tempSelectedUris.isEmpty()) return;
                selectedImageUris = new ArrayList<>(tempSelectedUris);
                galleryDialog.dismiss();
                updateImagePreview();
            }
        });
        bottomBtns.addView(galleryConfirmBtn);

        container.addView(bottomBtns);

        galleryDialog.setContentView(container);
        android.view.Window window = galleryDialog.getWindow();
        if (window != null) {
            window.setLayout(MATCH, WRAP);
            window.setGravity(Gravity.BOTTOM);
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.getAttributes().windowAnimations = android.R.style.Animation_Dialog;
        }
        galleryDialog.show();
    }

    private void updateCellSelection(Uri uri, View overlay, TextView badge) {
        int idx = tempSelectedUris.indexOf(uri);
        if (idx >= 0) {
            overlay.setVisibility(View.VISIBLE);
            badge.setVisibility(View.VISIBLE);
            badge.setText(String.valueOf(idx + 1));
        } else {
            overlay.setVisibility(View.GONE);
            badge.setVisibility(View.GONE);
        }
    }

    private void updateGalleryConfirmBtn() {
        if (galleryConfirmBtn == null) return;
        int n = tempSelectedUris.size();
        if (n == 0) {
            galleryConfirmBtn.setText("Выбрать");
        } else {
            galleryConfirmBtn.setText("Готово (" + n + ")");
        }
    }

    // onActivityResult не нужен — используем встроенный галерея пикер

    private void updateImagePreview() {
        selectedImagesPreview.removeAllViews();

        if (selectedImageUris.isEmpty()) {
            selectedImagesPreview.setVisibility(View.GONE);
            descriptionField.setVisibility(View.GONE);
            btnSubmit.setVisibility(View.GONE);
            return;
        }

        selectedImagesPreview.setVisibility(View.VISIBLE);
        descriptionField.setVisibility(View.VISIBLE);
        btnSubmit.setVisibility(View.VISIBLE);

        int imageSize = UIHelper.dp(80);
        int margin = UIHelper.dp(8);

        for (int i = 0; i < selectedImageUris.size(); i++) {
            Uri uri = selectedImageUris.get(i);

            FrameLayout imageFrame = new FrameLayout(this);
            LinearLayout.LayoutParams frameParams = new LinearLayout.LayoutParams(imageSize, imageSize);
            if (i > 0) frameParams.setMargins(margin, 0, 0, 0);
            imageFrame.setLayoutParams(frameParams);

            ImageView imageView = new ImageView(this);
            imageView.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);

            GradientDrawable imageBg = new GradientDrawable();
            imageBg.setShape(GradientDrawable.RECTANGLE);
            imageBg.setCornerRadius(UIHelper.dp(8));
            imageBg.setColor(0xFF1A2430);
            imageView.setBackground(imageBg);
            imageView.setClipToOutline(true);

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                imageView.setImageBitmap(bitmap);
            } catch (Exception e) {
                e.printStackTrace();
            }

            imageFrame.addView(imageView);

            // Кнопка удаления
            final int index = i;
            TextView removeBtn = new TextView(this);
            FrameLayout.LayoutParams removeParams = new FrameLayout.LayoutParams(UIHelper.dp(24), UIHelper.dp(24));
            removeParams.gravity = Gravity.TOP | Gravity.END;
            removeParams.setMargins(0, UIHelper.dp(4), UIHelper.dp(4), 0);
            removeBtn.setLayoutParams(removeParams);
            removeBtn.setText("✕");
            removeBtn.setTextSize(14);
            removeBtn.setTypeface(null, Typeface.BOLD);
            removeBtn.setTextColor(0xFFFFFFFF);
            removeBtn.setGravity(Gravity.CENTER);

            GradientDrawable removeBg = new GradientDrawable();
            removeBg.setShape(GradientDrawable.OVAL);
            removeBg.setColor(0xFFFF1E4E);
            removeBtn.setBackground(removeBg);
            removeBtn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    selectedImageUris.remove(index);
                    updateImagePreview();
                }
            });

            imageFrame.addView(removeBtn);
            selectedImagesPreview.addView(imageFrame);
        }
    }

    private void submitPost() {
        if (selectedImageUris.isEmpty()) {
            Toast.makeText(this, "Выберите хотя бы одно фото", Toast.LENGTH_SHORT).show();
            return;
        }

        String description = descriptionField.getText().toString().trim();

        btnSubmit.setEnabled(false);
        btnSubmit.setText("Отправка...");

        new UploadPostTask().execute(description);
    }

    private class UploadPostTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String description = params[0];

            try {
                JSONArray imagesArray = new JSONArray();

                for (Uri uri : selectedImageUris) {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                    // Уменьшаем до 800px для оптимального баланса качества и размера
                    Bitmap resized = resizeBitmap(bitmap, 800);
                    String base64 = bitmapToBase64(resized);
                    imagesArray.put(base64);
                    // Освобождаем память
                    if (bitmap != resized) bitmap.recycle();
                }

                JSONObject json = new JSONObject();
                json.put("login", myLogin);
                json.put("createdAt", myCreatedAt);
                json.put("description", description);
                json.put("images", imagesArray);

                URL url = new URL(serverUrl + "/rank/send");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                os.write(json.toString().getBytes("UTF-8"));
                os.close();

                int code = conn.getResponseCode();
                if (code == 200) {
                    return "OK";
                } else if (code == 413) {
                    // 413 Payload Too Large - файл слишком большой
                    return "ERROR:TOO_LARGE";
                } else {
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    
                    String error = sb.toString();
                    // Проверяем, содержит ли ответ HTML с "Payload Too Large"
                    if (error.contains("Payload Too Large") || error.contains("payload too large")) {
                        return "ERROR:TOO_LARGE";
                    }
                    return "ERROR: " + error;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "ERROR: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            btnSubmit.setEnabled(true);
            btnSubmit.setText("🚀 Отправить");

            if ("OK".equals(result)) {
                Toast.makeText(RankShareActivity.this, "Пост опубликован!", Toast.LENGTH_SHORT).show();
                selectedImageUris.clear();
                updateImagePreview();
                descriptionField.setText("");
                // Обновить ленту
                fetchPosts();
            } else if (result.equals("ERROR:TOO_LARGE")) {
                Toast.makeText(RankShareActivity.this, "Фото слишком большие. Попробуйте выбрать меньше фото или фото меньшего размера", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(RankShareActivity.this, "Ошибка: " + result, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private Bitmap resizeBitmap(Bitmap bitmap, int maxSize) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        // Вычисляем соотношение сторон
        float ratio = Math.min((float) maxSize / width, (float) maxSize / height);
        int newWidth = Math.round(width * ratio);
        int newHeight = Math.round(height * ratio);

        // Используем более качественный resize с фильтром
        // true = использовать билинейный фильтр для лучшего качества
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true);
    }

    private String bitmapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        // Качество 75% для баланса между чёткостью и размером файла
        bitmap.compress(Bitmap.CompressFormat.JPEG, 75, baos);
        byte[] bytes = baos.toByteArray();
        return Base64.encodeToString(bytes, Base64.NO_WRAP);
    }

    private void checkMuteStatus() {
        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(serverUrl + "/rank/mute-status?login=" + myLogin + "&createdAt=" + myCreatedAt);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    int code = conn.getResponseCode();
                    if (code == 200) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = br.readLine()) != null) sb.append(line);
                        br.close();
                        return sb.toString();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(String response) {
                if (response != null) {
                    try {
                        JSONObject json = new JSONObject(response);
                        isMuted = json.optBoolean("muted", false);
                        if (isMuted) {
                            showMutedUI(json.optString("reason", ""));
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }.execute();
    }

    private void showMutedUI(String reason) {
        contentFrame.removeAllViews();

        LinearLayout muteLayout = new LinearLayout(this);
        muteLayout.setLayoutParams(new FrameLayout.LayoutParams(MATCH, MATCH));
        muteLayout.setOrientation(LinearLayout.VERTICAL);
        muteLayout.setGravity(Gravity.CENTER);
        muteLayout.setPadding(UIHelper.dp(32), UIHelper.dp(32), UIHelper.dp(32), UIHelper.dp(32));

        TextView muteIcon = new TextView(this);
        muteIcon.setLayoutParams(new LinearLayout.LayoutParams(WRAP, WRAP));
        muteIcon.setText("🔇");
        muteIcon.setTextSize(64);
        muteLayout.addView(muteIcon);

        TextView muteTitle = new TextView(this);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(WRAP, WRAP);
        titleParams.setMargins(0, UIHelper.dp(16), 0, 0);
        muteTitle.setLayoutParams(titleParams);
        muteTitle.setText("Вы получили мут");
        muteTitle.setTextSize(20);
        muteTitle.setTypeface(null, Typeface.BOLD);
        muteTitle.setTextColor(0xFFFF1E4E);
        muteLayout.addView(muteTitle);

        if (!TextUtils.isEmpty(reason)) {
            TextView muteReason = new TextView(this);
            LinearLayout.LayoutParams reasonParams = new LinearLayout.LayoutParams(WRAP, WRAP);
            reasonParams.setMargins(0, UIHelper.dp(12), 0, 0);
            muteReason.setLayoutParams(reasonParams);
            muteReason.setText("Причина: " + reason);
            muteReason.setTextSize(14);
            muteReason.setTextColor(0xFFCCCCCC);
            muteReason.setGravity(Gravity.CENTER);
            muteLayout.addView(muteReason);
        }

        TextView muteInfo = new TextView(this);
        LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(WRAP, WRAP);
        infoParams.setMargins(0, UIHelper.dp(8), 0, 0);
        muteInfo.setLayoutParams(infoParams);
        muteInfo.setText("Вы не можете публиковать посты в этом разделе");
        muteInfo.setTextSize(13);
        muteInfo.setTextColor(0xFF999999);
        muteInfo.setGravity(Gravity.CENTER);
        muteLayout.addView(muteInfo);

        contentFrame.addView(muteLayout);
    }

    private int pollCount = 0;
    private int fullReloadInterval = 20; // Каждые 20 циклов (~60с) — полная перезагрузка

    private void startPolling() {
        pollHandler = new Handler();
        pollRunnable = new Runnable() {
            @Override
            public void run() {
                pollCount++;
                // Каждые 20 циклов (~60с) — полная перезагрузка (чтобы отражать удаления при бане)
                if (pollCount % fullReloadInterval == 0) {
                    lastPostTime = 0; // Сбрасываем чтобы fetchPosts сделал полный reload
                }
                fetchPosts();
                // Каждые 10 циклов (~30с) перепроверяем мут-статус
                if (pollCount % 10 == 0) {
                    checkMuteStatus();
                }
                pollHandler.postDelayed(this, POLL_INTERVAL_MS);
            }
        };
        pollHandler.post(pollRunnable);
    }

    private void fetchPosts() {
        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(serverUrl + "/rank/posts?since=" + lastPostTime);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    int code = conn.getResponseCode();
                    if (code == 200) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = br.readLine()) != null) sb.append(line);
                        br.close();
                        return sb.toString();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(String response) {
                if (response != null) {
                    try {
                        // При первой загрузке (lastPostTime==0) — полная замена ленты
                        if (lastPostTime == 0) {
                            postsContainer.removeAllViews();
                        }
                        JSONArray posts = new JSONArray(response);
                        for (int i = 0; i < posts.length(); i++) {
                            JSONObject post = posts.getJSONObject(i);
                            addPostToUI(post);
                            long timestamp = post.optLong("timestamp", 0);
                            if (timestamp > lastPostTime) {
                                lastPostTime = timestamp;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }.execute();
    }

    private void addPostToUI(final JSONObject post) {
        try {
            final String login = post.getString("login");
            String description = post.optString("description", "");
            final JSONArray imagesBase64 = post.getJSONArray("images");
            long timestamp = post.getLong("timestamp");
            final String postId = post.optString("id", "");

            LinearLayout postCard = new LinearLayout(this);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(MATCH, WRAP);
            cardParams.setMargins(0, 0, 0, UIHelper.dp(16));
            postCard.setLayoutParams(cardParams);
            postCard.setOrientation(LinearLayout.VERTICAL);
            postCard.setPadding(UIHelper.dp(16), UIHelper.dp(16), UIHelper.dp(16), UIHelper.dp(16));

            GradientDrawable cardBg = new GradientDrawable();
            cardBg.setShape(GradientDrawable.RECTANGLE);
            cardBg.setCornerRadius(UIHelper.dp(12));
            cardBg.setColor(0xFF1A2430);
            postCard.setBackground(cardBg);

            // Заголовок поста
            LinearLayout postHeader = new LinearLayout(this);
            postHeader.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
            postHeader.setOrientation(LinearLayout.HORIZONTAL);
            postHeader.setGravity(Gravity.CENTER_VERTICAL);

            // Кликабельный кружок пользователя
            TextView userIcon = new TextView(this);
            userIcon.setLayoutParams(new LinearLayout.LayoutParams(UIHelper.dp(36), UIHelper.dp(36)));
            userIcon.setText("🏆");
            userIcon.setTextSize(20);
            userIcon.setGravity(Gravity.CENTER);

            GradientDrawable iconBg = new GradientDrawable();
            iconBg.setShape(GradientDrawable.OVAL);
            iconBg.setColor(0xFF00FF9D);
            userIcon.setBackground(iconBg);

            LinearLayout.LayoutParams iconParams = (LinearLayout.LayoutParams) userIcon.getLayoutParams();
            iconParams.setMargins(0, 0, UIHelper.dp(12), 0);
            userIcon.setLayoutParams(iconParams);

            final String finalLogin = login;
            userIcon.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    showRankUserProfile(finalLogin);
                }
            });

            postHeader.addView(userIcon);

            LinearLayout userInfo = new LinearLayout(this);
            userInfo.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
            userInfo.setOrientation(LinearLayout.VERTICAL);

            TextView userName = new TextView(this);
            userName.setLayoutParams(new LinearLayout.LayoutParams(WRAP, WRAP));
            userName.setText(login);
            userName.setTextSize(15);
            userName.setTypeface(null, Typeface.BOLD);
            userName.setTextColor(0xFFFFFFFF);

            TextView postTime = new TextView(this);
            postTime.setLayoutParams(new LinearLayout.LayoutParams(WRAP, WRAP));
            postTime.setText(formatTimestamp(timestamp));
            postTime.setTextSize(12);
            postTime.setTextColor(0xFF999999);

            userInfo.addView(userName);
            userInfo.addView(postTime);
            postHeader.addView(userInfo);

            postCard.addView(postHeader);

            // Галерея фото
            LinearLayout imagesContainer = new LinearLayout(this);
            LinearLayout.LayoutParams imagesParams = new LinearLayout.LayoutParams(MATCH, WRAP);
            imagesParams.setMargins(0, UIHelper.dp(12), 0, 0);
            imagesContainer.setLayoutParams(imagesParams);
            imagesContainer.setOrientation(LinearLayout.HORIZONTAL);

            int imageWidth = (getResources().getDisplayMetrics().widthPixels - UIHelper.dp(64)) / 3;

            for (int i = 0; i < imagesBase64.length(); i++) {
                String base64 = imagesBase64.getString(i);

                ImageView imageView = new ImageView(this);
                LinearLayout.LayoutParams imgParams = new LinearLayout.LayoutParams(imageWidth, imageWidth);
                if (i > 0) imgParams.setMargins(UIHelper.dp(4), 0, 0, 0);
                imageView.setLayoutParams(imgParams);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);

                GradientDrawable imgBg = new GradientDrawable();
                imgBg.setShape(GradientDrawable.RECTANGLE);
                imgBg.setCornerRadius(UIHelper.dp(8));
                imgBg.setColor(0xFF0F1419);
                imageView.setBackground(imgBg);
                imageView.setClipToOutline(true);

                try {
                    byte[] bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    imageView.setImageBitmap(bitmap);

                    final Bitmap finalBitmap = bitmap;
                    final String finalBase64 = base64;
                    imageView.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            showFullScreenImage(finalBitmap);
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }

                imagesContainer.addView(imageView);
            }

            postCard.addView(imagesContainer);

            // Описание
            if (!TextUtils.isEmpty(description)) {
                TextView descText = new TextView(this);
                LinearLayout.LayoutParams descParams = new LinearLayout.LayoutParams(MATCH, WRAP);
                descParams.setMargins(0, UIHelper.dp(12), 0, 0);
                descText.setLayoutParams(descParams);
                descText.setText(description);
                descText.setTextSize(14);
                descText.setTextColor(0xFFCCCCCC);
                descText.setLineSpacing(UIHelper.dp(4), 1f);
                postCard.addView(descText);
            }

            // Зажатие карточки — репорт
            final String finalDescription = description;
            postCard.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) {
                    if (!finalLogin.equals(myLogin)) {
                        showRankReportMenu(finalLogin, postId, finalDescription, imagesBase64);
                    }
                    return true;
                }
            });

            // Нажатие на карточку в режиме удаления
            final View finalPostCard = postCard;
            final String finalPostId = postId;
            postCard.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (deleteModeActiveRank) {
                        togglePostSelection(finalPostCard, finalPostId);
                    }
                }
            });

            // Регистрируем карточку для режима удаления
            if (!postId.isEmpty()) {
                postViewToId.put(postCard, postId);
            }

            postsContainer.addView(postCard, 0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showRankUserProfile(final String login) {
        // Используем существующую логику ChatActivity — запрос к /user/:login
        new AsyncTask<Void, Void, String[]>() {
            @Override
            protected String[] doInBackground(Void... v) {
                try {
                    java.net.URL url = new java.net.URL(serverUrl + "/user/" + login);
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    if (conn.getResponseCode() == 200) {
                        java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(conn.getInputStream()));
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = br.readLine()) != null) sb.append(line);
                        br.close();
                        JSONObject obj = new JSONObject(sb.toString());
                        String uid = obj.optString("user_id", "—");
                        String ca  = obj.optString("created_at", "");
                        return new String[]{ uid, ca };
                    }
                } catch (Exception e) { e.printStackTrace(); }
                return null;
            }

            @Override
            protected void onPostExecute(String[] result) {
                String uid = result != null ? result[0] : "—";
                String ca  = result != null ? result[1] : "";
                showRankProfileDialog(login, uid, ca);
            }
        }.execute();
    }

    private void showRankProfileDialog(String login, String userId, String createdAt) {
        final android.app.Dialog d = new android.app.Dialog(this);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UIHelper.dp(24), UIHelper.dp(24), UIHelper.dp(24), UIHelper.dp(24));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(UIHelper.dp(16));
        bg.setColor(0xFF0C1014);
        bg.setStroke(UIHelper.dp(1), 0xFF00FF9D);
        root.setBackground(bg);

        // Иконка
        TextView icon = new TextView(this);
        icon.setLayoutParams(new LinearLayout.LayoutParams(UIHelper.dp(56), UIHelper.dp(56)));
        icon.setText("🏆");
        icon.setTextSize(28);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(0x2200FF9D);
        icon.setBackground(iconBg);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(UIHelper.dp(56), UIHelper.dp(56));
        iconLp.gravity = Gravity.CENTER_HORIZONTAL;
        iconLp.bottomMargin = UIHelper.dp(16);
        icon.setLayoutParams(iconLp);
        root.addView(icon);

        addProfileRow(root, "Логин", login, 0xFFFFFFFF, true);
        addProfileRowSpacer(root);
        addProfileRow(root, "ID", userId, 0xFF00FF9D, true);
        addProfileRowSpacer(root);
        String dateStr = formatCreatedAt(createdAt);
        addProfileRow(root, "Дата регистрации", TextUtils.isEmpty(dateStr) ? "—" : dateStr, 0xFF6C7885);

        // Кнопка закрыть
        TextView btnClose = new TextView(this);
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(MATCH, UIHelper.dp(44));
        closeLp.topMargin = UIHelper.dp(20);
        btnClose.setLayoutParams(closeLp);
        btnClose.setText("Закрыть");
        btnClose.setTextSize(14);
        btnClose.setTypeface(null, Typeface.BOLD);
        btnClose.setTextColor(0xFF00FF9D);
        btnClose.setGravity(Gravity.CENTER);
        GradientDrawable closeBg = new GradientDrawable();
        closeBg.setShape(GradientDrawable.RECTANGLE);
        closeBg.setCornerRadius(UIHelper.dp(10));
        closeBg.setColor(0xFF1A2430);
        btnClose.setBackground(closeBg);
        btnClose.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        root.addView(btnClose);

        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.82f), WRAP);
        d.show();
        // Плавная анимация появления карточки
        root.setAlpha(0f);
        root.setScaleX(0.92f);
        root.setScaleY(0.92f);
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220)
            .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
    }

    private void addProfileRow(LinearLayout parent, String label, String value, int valueColor) {
        addProfileRow(parent, label, value, valueColor, false);
    }

    private void addProfileRow(LinearLayout parent, String label, String value, int valueColor, boolean copyable) {
        LinearLayout row = new LinearLayout(this);
        row.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        TextView lbl = new TextView(this);
        lbl.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        lbl.setText(label);
        lbl.setTextSize(13);
        lbl.setTextColor(0xFF4A6A8A);
        row.addView(lbl);

        TextView val = new TextView(this);
        LinearLayout.LayoutParams vallp = new LinearLayout.LayoutParams(WRAP, WRAP);
        vallp.rightMargin = copyable ? UIHelper.dp(8) : 0;
        val.setLayoutParams(vallp);
        val.setText(value);
        val.setTextSize(13);
        val.setTypeface(null, Typeface.BOLD);
        val.setTextColor(valueColor);
        row.addView(val);

        if (copyable && value != null && !value.isEmpty()) {
            final String copyValue = value;
            final String copyLabel = label;
            TextView copyBtn = new TextView(this);
            copyBtn.setText("⎘");
            copyBtn.setTextSize(14);
            copyBtn.setTextColor(0xFF00FF9D);
            copyBtn.setPadding(UIHelper.dp(8), UIHelper.dp(4), UIHelper.dp(8), UIHelper.dp(4));
            android.graphics.drawable.GradientDrawable copyBg = new android.graphics.drawable.GradientDrawable();
            copyBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
            copyBg.setCornerRadius(UIHelper.dp(8));
            copyBg.setColor(0x2200FF9D);
            copyBg.setStroke(UIHelper.dp(1), 0x6600FF9D);
            copyBtn.setBackground(copyBg);
            copyBtn.setLayoutParams(new LinearLayout.LayoutParams(WRAP, WRAP));
            copyBtn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    android.content.ClipboardManager cm = (android.content.ClipboardManager)
                        getSystemService(android.content.Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText(copyLabel, copyValue));
                    android.widget.Toast.makeText(RankShareActivity.this, "Скопировано", android.widget.Toast.LENGTH_SHORT).show();
                }
            });
            row.addView(copyBtn);
        }

        parent.addView(row);
    }

    private void addProfileRowSpacer(LinearLayout parent) {
        View sep = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, UIHelper.dp(1));
        lp.topMargin = UIHelper.dp(8);
        lp.bottomMargin = UIHelper.dp(8);
        sep.setLayoutParams(lp);
        sep.setBackgroundColor(0xFF1A2430);
        parent.addView(sep);
    }

    private String formatCreatedAt(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        try {
            java.text.SimpleDateFormat iso = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.getDefault());
            java.util.Date date = iso.parse(raw);
            return new java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.getDefault()).format(date);
        } catch (Exception e) {
            return raw.length() > 10 ? raw.substring(0, 10) : raw;
        }
    }

    private void showRankReportMenu(final String targetLogin, final String postId,
                                     final String description, final JSONArray imagesBase64) {
        final android.app.Dialog d = new android.app.Dialog(this);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UIHelper.dp(20), UIHelper.dp(20), UIHelper.dp(20), UIHelper.dp(20));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(UIHelper.dp(16));
        bg.setColor(0xFF0C1014);
        bg.setStroke(UIHelper.dp(1), 0xFFFF1E4E);
        root.setBackground(bg);

        TextView title = new TextView(this);
        title.setText("Пост от " + targetLogin);
        title.setTextSize(13);
        title.setTextColor(0xFF6C7885);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        View sep = new View(this);
        LinearLayout.LayoutParams sepLp = new LinearLayout.LayoutParams(MATCH, UIHelper.dp(1));
        sepLp.topMargin = UIHelper.dp(10);
        sepLp.bottomMargin = UIHelper.dp(10);
        sep.setLayoutParams(sepLp);
        sep.setBackgroundColor(0xFF17202A);
        root.addView(sep);

        if (!TextUtils.isEmpty(description)) {
            TextView preview = new TextView(this);
            String prev = description.length() > 80 ? description.substring(0, 80) + "…" : description;
            preview.setText("\"" + prev + "\"");
            preview.setTextSize(13);
            preview.setTextColor(0xFFB8C4D0);
            preview.setTypeface(null, Typeface.ITALIC);
            preview.setGravity(Gravity.CENTER);
            root.addView(preview);

            View gap = new View(this);
            gap.setLayoutParams(new LinearLayout.LayoutParams(MATCH, UIHelper.dp(12)));
            root.addView(gap);
        }

        TextView btnReport = new TextView(this);
        btnReport.setText("🚩  Репорт");
        btnReport.setTextSize(14);
        btnReport.setTextColor(0xFFFFFFFF);
        btnReport.setTypeface(null, Typeface.BOLD);
        btnReport.setGravity(Gravity.CENTER);
        btnReport.setPadding(UIHelper.dp(16), UIHelper.dp(14), UIHelper.dp(16), UIHelper.dp(14));
        GradientDrawable reportBg = new GradientDrawable();
        reportBg.setShape(GradientDrawable.RECTANGLE);
        reportBg.setCornerRadius(UIHelper.dp(12));
        reportBg.setColor(0xFFFF1E4E);
        btnReport.setBackground(reportBg);
        btnReport.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        btnReport.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                d.dismiss();
                sendRankReport(targetLogin, postId, description, imagesBase64);
            }
        });
        root.addView(btnReport);

        View gap2 = new View(this);
        gap2.setLayoutParams(new LinearLayout.LayoutParams(MATCH, UIHelper.dp(8)));
        root.addView(gap2);

        TextView btnCancel = new TextView(this);
        btnCancel.setText("Отмена");
        btnCancel.setTextSize(14);
        btnCancel.setTextColor(0xFF6C7885);
        btnCancel.setGravity(Gravity.CENTER);
        btnCancel.setPadding(0, UIHelper.dp(10), 0, UIHelper.dp(10));
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });
        root.addView(btnCancel);

        d.setContentView(root);
        d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.82f), WRAP);
        d.show();
    }

    private void sendRankReport(final String targetLogin, final String postId,
                                 final String description, final JSONArray imagesBase64) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    // Берём первое фото для репорта
                    String firstImage = "";
                    if (imagesBase64 != null && imagesBase64.length() > 0) {
                        firstImage = imagesBase64.optString(0, "");
                    }

                    JSONObject json = new JSONObject();
                    json.put("reporterLogin", myLogin);
                    json.put("targetLogin", targetLogin);
                    json.put("postId", postId);
                    json.put("description", description);
                    json.put("imageBase64", firstImage);

                    java.net.URL url = new java.net.URL(serverUrl + "/rank/report");
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setDoOutput(true);
                    java.io.OutputStream os = conn.getOutputStream();
                    os.write(json.toString().getBytes("UTF-8"));
                    os.close();

                    int code = conn.getResponseCode();
                    java.io.InputStream is = (code >= 200 && code < 300)
                        ? conn.getInputStream() : conn.getErrorStream();
                    java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(is));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();

                    final String resp = sb.toString();
                    final String result;
                    if (resp.contains("already_reported")) {
                        result = "Вы уже репортили этот пост";
                    } else if (resp.contains("limit_reached")) {
                        result = "Лимит репортов исчерпан";
                    } else if (resp.contains("\"ok\"") || resp.contains("success")) {
                        result = "Репорт отправлен";
                    } else {
                        result = "Ошибка отправки";
                    }

                    runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(RankShareActivity.this, result, Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        public void run() {
                            Toast.makeText(RankShareActivity.this, "Ошибка соединения", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }).start();
    }

    private void showFullScreenImage(Bitmap bitmap) {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);

        LinearLayout layout = new LinearLayout(this);
        layout.setLayoutParams(new ViewGroup.LayoutParams(MATCH, MATCH));
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(0xE6000000);
        layout.setGravity(Gravity.CENTER);
        layout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        ImageView imageView = new ImageView(this);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        imageView.setAdjustViewBounds(true);
        imageView.setImageBitmap(bitmap);

        layout.addView(imageView);
        dialog.setContentView(layout);
        dialog.show();
    }

    private String formatTimestamp(long timestamp) {
        try {
            Date date = new Date(timestamp);
            SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());
            return sdf.format(date);
        } catch (Exception e) {
            return "";
        }
    }

    private void startBgAnimation() {
        bgHandler = new Handler();
        bgHandler.post(new Runnable() {
            @Override
            public void run() {
                int from = BG_COLORS[bgStep % BG_COLORS.length];
                int to = BG_COLORS[(bgStep + 1) % BG_COLORS.length];
                animateBackgroundColor(from, to, 3000);
                bgStep++;
                bgHandler.postDelayed(this, 3000);
            }
        });
    }

    private void animateBackgroundColor(final int fromColor, final int toColor, final long duration) {
        final long startTime = System.currentTimeMillis();
        bgHandler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = System.currentTimeMillis() - startTime;
                float fraction = Math.min((float) elapsed / duration, 1f);
                int color = blendColors(fromColor, toColor, fraction);
                bgView.setBackgroundColor(color);
                if (fraction < 1f) {
                    bgHandler.postDelayed(this, 16);
                }
            }
        });
    }

    private int blendColors(int from, int to, float ratio) {
        int r = (int) (Color.red(from) * (1 - ratio) + Color.red(to) * ratio);
        int g = (int) (Color.green(from) * (1 - ratio) + Color.green(to) * ratio);
        int b = (int) (Color.blue(from) * (1 - ratio) + Color.blue(to) * ratio);
        return Color.rgb(r, g, b);
    }

    @Override
    protected void onResume() {
        super.onResume();
        accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pollHandler != null && pollRunnable != null) {
            pollHandler.removeCallbacks(pollRunnable);
        }
        if (bgHandler != null) {
            bgHandler.removeCallbacksAndMessages(null);
        }
    }

    // ── Режим удаления постов (только для админа) ────────────────────────

    private LinearLayout buildRankDeleteModeBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(UIHelper.dp(16), UIHelper.dp(10), UIHelper.dp(16), UIHelper.dp(10));
        bar.setBackgroundColor(0xCC1A0808);
        bar.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        rankDeleteCountLabel = new TextView(this);
        rankDeleteCountLabel.setText("Выбрано: 0");
        rankDeleteCountLabel.setTextSize(13);
        rankDeleteCountLabel.setTextColor(0xFFFFFFFF);
        rankDeleteCountLabel.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        rankDeleteCountLabel.setLayoutParams(lp);
        bar.addView(rankDeleteCountLabel);

        TextView cancelBtn = new TextView(this);
        cancelBtn.setText("Отмена");
        cancelBtn.setTextSize(13);
        cancelBtn.setTextColor(0xFF00FF9D);
        cancelBtn.setPadding(UIHelper.dp(14), UIHelper.dp(8), UIHelper.dp(14), UIHelper.dp(8));
        GradientDrawable cancelBg = new GradientDrawable();
        cancelBg.setShape(GradientDrawable.RECTANGLE);
        cancelBg.setCornerRadius(UIHelper.dp(20));
        cancelBg.setColor(0xFF0C2010);
        cancelBg.setStroke(1, 0xFF00FF9D);
        cancelBtn.setBackground(cancelBg);
        LinearLayout.LayoutParams clp2 = new LinearLayout.LayoutParams(WRAP, WRAP);
        clp2.rightMargin = UIHelper.dp(10);
        cancelBtn.setLayoutParams(clp2);
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { exitRankDeleteMode(); }
        });
        bar.addView(cancelBtn);

        TextView deleteBtn = new TextView(this);
        deleteBtn.setText("Удалить");
        deleteBtn.setTextSize(13);
        deleteBtn.setTextColor(0xFFFFFFFF);
        deleteBtn.setTypeface(null, Typeface.BOLD);
        deleteBtn.setPadding(UIHelper.dp(14), UIHelper.dp(8), UIHelper.dp(14), UIHelper.dp(8));
        GradientDrawable deleteBg = new GradientDrawable();
        deleteBg.setShape(GradientDrawable.RECTANGLE);
        deleteBg.setCornerRadius(UIHelper.dp(20));
        deleteBg.setColor(0xFFCC1030);
        deleteBg.setStroke(1, 0xFFFF1E4E);
        deleteBtn.setBackground(deleteBg);
        deleteBtn.setLayoutParams(new LinearLayout.LayoutParams(WRAP, WRAP));
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { executeDeletePosts(); }
        });
        bar.addView(deleteBtn);

        return bar;
    }

    private void toggleRankDeleteMode() {
        if (deleteModeActiveRank) {
            exitRankDeleteMode();
        } else {
            deleteModeActiveRank = true;
            selectedPostIds.clear();
            rankDeleteModeBar.setVisibility(View.VISIBLE);
            updateRankDeleteCount();
        }
    }

    private void exitRankDeleteMode() {
        deleteModeActiveRank = false;
        selectedPostIds.clear();
        for (View card : postViewToId.keySet()) {
            card.setAlpha(1f);
            card.setScaleX(1f);
            card.setScaleY(1f);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(UIHelper.dp(12));
            bg.setColor(0xFF1A2430);
            card.setBackground(bg);
        }
        rankDeleteModeBar.setVisibility(View.GONE);
    }

    private void togglePostSelection(View card, String postId) {
        if (postId == null || postId.isEmpty()) return;
        boolean isSelected = Boolean.TRUE.equals(selectedPostIds.get(postId));
        if (isSelected) {
            selectedPostIds.remove(postId);
            card.setAlpha(1f);
            card.setScaleX(1f);
            card.setScaleY(1f);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(UIHelper.dp(12));
            bg.setColor(0xFF1A2430);
            card.setBackground(bg);
        } else {
            selectedPostIds.put(postId, true);
            card.setAlpha(0.85f);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.RECTANGLE);
            bg.setCornerRadius(UIHelper.dp(12));
            bg.setColor(0xFF1A2430);
            bg.setStroke(UIHelper.dp(2), 0xFF00C853);
            card.setBackground(bg);
            // Покачивание
            android.animation.ObjectAnimator anim = android.animation.ObjectAnimator.ofFloat(card, "translationX", 0f, -8f, 8f, -5f, 5f, 0f);
            anim.setDuration(300);
            anim.start();
        }
        updateRankDeleteCount();
    }

    private void updateRankDeleteCount() {
        if (rankDeleteCountLabel != null) {
            rankDeleteCountLabel.setText("Выбрано: " + selectedPostIds.size());
        }
    }

    private void executeDeletePosts() {
        if (selectedPostIds.isEmpty()) {
            Toast.makeText(this, "Выберите посты для удаления", Toast.LENGTH_SHORT).show();
            return;
        }
        final java.util.ArrayList<String> ids = new java.util.ArrayList<>(selectedPostIds.keySet());
        new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected Boolean doInBackground(Void... v) {
                try {
                    StringBuilder sb = new StringBuilder("{\"adminLogin\":\"");
                    sb.append(esc(myLogin)).append("\",\"adminPassword\":\"").append(esc(myPassword));
                    sb.append("\",\"postIds\":[");
                    for (int i = 0; i < ids.size(); i++) {
                        if (i > 0) sb.append(",");
                        sb.append("\"").append(esc(ids.get(i))).append("\"");
                    }
                    sb.append("]}");
                    java.net.URL url = new java.net.URL(serverUrl + "/admin/rank/delete-posts");
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setDoOutput(true);
                    byte[] bytes = sb.toString().getBytes("UTF-8");
                    conn.getOutputStream().write(bytes);
                    int code = conn.getResponseCode();
                    return code == 200;
                } catch (Exception e) {
                    return false;
                }
            }
            @Override
            protected void onPostExecute(Boolean ok) {
                if (ok) {
                    // Удалить карточки из UI
                    java.util.ArrayList<View> toRemove = new java.util.ArrayList<View>();
                    for (java.util.Map.Entry<View, String> entry : postViewToId.entrySet()) {
                        if (selectedPostIds.containsKey(entry.getValue())) {
                            toRemove.add(entry.getKey());
                        }
                    }
                    for (View rv : toRemove) {
                        postsContainer.removeView(rv);
                        postViewToId.remove(rv);
                    }
                    exitRankDeleteMode();
                    Toast.makeText(RankShareActivity.this, "Удалено: " + ids.size(), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(RankShareActivity.this, "Ошибка при удалении", Toast.LENGTH_SHORT).show();
                }
            }
        }.execute();
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }
}

