package com.clumsyvpn;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Небольшая праздничная анимация (конфетти), показывается после успешной
 * регистрации/входа вместе с текстом "Добро пожаловать, {ник}!".
 * Реализована без сторонних библиотек — простая частичная симуляция на Canvas.
 */
public class ConfettiView extends View {

    private static final int[] COLORS = {
        0xFF00FF9D, 0xFF00E5FF, 0xFFFFD400, 0xFFFF4D6D, 0xFF7B61FF, 0xFFFFFFFF
    };

    private final List<Particle> particles = new ArrayList<>();
    private final Paint paint = new Paint();
    private final Random rnd = new Random();
    private final Handler handler = new Handler();
    private boolean running = true;
    private long lastFrameTime;

    private static class Particle {
        float x, y;
        float vx, vy;
        float size;
        float rotation, rotationSpeed;
        int color;
    }

    public ConfettiView(Context ctx) {
        super(ctx);
        paint.setAntiAlias(true);
        setLayerType(LAYER_TYPE_HARDWARE, null);
    }

    private void spawn(int w, int h) {
        int count = 90;
        for (int i = 0; i < count; i++) {
            Particle p = new Particle();
            p.x = rnd.nextFloat() * w;
            p.y = -rnd.nextFloat() * h * 0.5f - 20;
            p.vx = (rnd.nextFloat() - 0.5f) * 260f;
            p.vy = 260f + rnd.nextFloat() * 340f;
            p.size = 6f + rnd.nextFloat() * 8f;
            p.rotation = rnd.nextFloat() * 360f;
            p.rotationSpeed = (rnd.nextFloat() - 0.5f) * 420f;
            p.color = COLORS[rnd.nextInt(COLORS.length)];
            particles.add(p);
        }
    }

    private final Runnable frame = new Runnable() {
        public void run() {
            if (!running) return;
            invalidate();
            handler.postDelayed(frame, 16);
        }
    };

    public void start() {
        post(new Runnable() {
            public void run() {
                spawn(getWidth() > 0 ? getWidth() : 1080, getHeight() > 0 ? getHeight() : 1920);
                lastFrameTime = System.currentTimeMillis();
                handler.post(frame);
            }
        });
    }

    public void stop() {
        running = false;
        handler.removeCallbacks(frame);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long nowMs = System.currentTimeMillis();
        float dt = Math.min(0.05f, (nowMs - lastFrameTime) / 1000f);
        lastFrameTime = nowMs;

        int h = getHeight();
        for (Particle p : particles) {
            p.vy += 480f * dt; // гравитация
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.rotation += p.rotationSpeed * dt;

            canvas.save();
            canvas.translate(p.x, p.y);
            canvas.rotate(p.rotation);
            paint.setColor(p.color);
            RectF r = new RectF(-p.size / 2f, -p.size / 3.2f, p.size / 2f, p.size / 3.2f);
            canvas.drawRect(r, paint);
            canvas.restore();
        }

        // Сбрасываем частицы, ушедшие за нижнюю границу, обратно наверх —
        // создаёт непрерывный эффект "дождя из конфетти" на всю длительность анимации.
        if (h > 0) {
            for (Particle p : particles) {
                if (p.y > h + 40) {
                    p.y = -20f - rnd.nextFloat() * 80f;
                    p.x = rnd.nextFloat() * getWidth();
                    p.vy = 260f + rnd.nextFloat() * 340f;
                }
            }
        }
    }

    /**
     * Показывает конфетти + приветственный текст над текущим экраном Activity
     * на duration мс, затем убирает оверлей и вызывает onDone.
     */
    public static void launch(final Activity activity, final String welcomeText, final long durationMs, final Runnable onDone) {
        if (activity == null || activity.isFinishing()) {
            if (onDone != null) onDone.run();
            return;
        }
        final ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();

        final FrameLayout overlay = new FrameLayout(activity);
        overlay.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        final ConfettiView confetti = new ConfettiView(activity);
        confetti.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overlay.addView(confetti);

        TextView tvWelcome = new TextView(activity);
        tvWelcome.setText(welcomeText);
        tvWelcome.setTextSize(20);
        tvWelcome.setTypeface(null, Typeface.BOLD);
        tvWelcome.setTextColor(Color.WHITE);
        tvWelcome.setGravity(Gravity.CENTER);
        tvWelcome.setShadowLayer(12f, 0, 0, 0xFF00FF9D);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.gravity = Gravity.CENTER;
        tlp.leftMargin = dp(activity, 32);
        tlp.rightMargin = dp(activity, 32);
        tvWelcome.setLayoutParams(tlp);
        overlay.addView(tvWelcome);

        decor.addView(overlay);
        confetti.start();

        new Handler().postDelayed(new Runnable() {
            public void run() {
                confetti.stop();
                try { decor.removeView(overlay); } catch (Exception ignored) {}
                if (onDone != null) onDone.run();
            }
        }, durationMs);
    }

    private static int dp(Context ctx, int val) {
        return (int) (val * ctx.getResources().getDisplayMetrics().density + 0.5f);
    }
}
