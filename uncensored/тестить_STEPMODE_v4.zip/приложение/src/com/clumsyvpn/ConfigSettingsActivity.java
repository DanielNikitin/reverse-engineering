package com.clumsyvpn;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.view.Window;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * ConfigSettingsActivity — V10.1
 *
 * Изменения V10.1:
 *   1. Ползунки задержек: шаг 1 (плавные), диапазон 0–5000 без скачков
 *   2. "Задержка после таймера": ограничена диапазоном 0–500 мс
 *   3. Сохранение конфига через SharedPreferences (не пропадает)
 *   4. При нажатии "Сохранить" — немедленно применяет настройки в VPN/FloatService
 */
public class ConfigSettingsActivity extends Activity {

    public static final String EXTRA_CONFIG_INDEX = "config_index";

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    // Максимумы ползунков
    private static final int MAX_DELAY        = 5000;  // серверные/клиентские задержки
    private static final int MAX_AFTER_DELAY  = 500;   // задержка ПОСЛЕ таймера (ограничена!)
    private static final int MAX_LOSS         = 100;
    private static final int MAX_DURATION_SEC = 30;

    private ConfigsActivity.Config cfg;
    private int configIndex;

    private SeekBar  sbServerDelay;  private TextView tvServerDelayVal;
    private SeekBar  sbServerLoss;   private TextView tvServerLossVal;
    private SeekBar  sbClientDelay;  private TextView tvClientDelayVal;
    private SeekBar  sbClientLoss;   private TextView tvClientLossVal;
    private EditText etDuration;

    // После таймера
    private Button       btnAfterReset, btnAfterDrop, btnAfterDelay;
    private LinearLayout afterDelaySliderRow;
    private SeekBar      sbAfterDelay;
    private TextView     tvAfterDelayVal;
    private SeekBar      sbAfterDuration;
    private TextView     tvAfterDurationVal;
    private int          afterTimerMode = 0; // 0=Сброс,1=Удалить,2=Задержка

    // Фильтр по размеру пакета
    private Button       btnClientSzAll, btnClientSzIn, btnClientSzOut;
    private Button       btnServerSzAll, btnServerSzIn, btnServerSzOut;
    private LinearLayout clientSzSliders, serverSzSliders;
    private SeekBar      sbClientSzMin, sbClientSzMax;
    private TextView     tvClientSzMin, tvClientSzMax;
    private SeekBar      sbServerSzMin, sbServerSzMax;
    private TextView     tvServerSzMin, tvServerSzMax;
    private int          clientSizeFilterMode = 0; // 0=Все,1=В диап.,2=Вне диап.
    private int          serverSizeFilterMode = 0;

    private AccountStatusMonitor accountStatusMonitor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        accountStatusMonitor = new AccountStatusMonitor(this);

        configIndex = getIntent().getIntExtra(EXTRA_CONFIG_INDEX, -1);
        if (configIndex < 0 || configIndex >= ConfigsActivity.configs.size()) {
            Toast.makeText(this, "Ошибка: конфиг не найден", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        cfg = ConfigsActivity.configs.get(configIndex);

        setContentView(buildLayout());
        loadValues();
        setupListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        accountStatusMonitor.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        accountStatusMonitor.stop();
    }

    private View buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF030507);
        root.setLayoutParams(new LinearLayout.LayoutParams(MATCH, MATCH));
        root.addView(buildHeader());
        root.addView(divider());
        root.addView(buildScrollArea());
        root.addView(buildSaveButton());
        return root;
    }

    private View buildHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(14), 0, dp(18), 0);
        h.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(64)));

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextSize(26);
        back.setTypeface(null, Typeface.BOLD);
        back.setTextColor(0xFF00FF9D);
        back.setGravity(Gravity.CENTER);
        back.setBackgroundResource(R.drawable.bg_header_icon);
        back.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        tlp.leftMargin = dp(12);
        titleBox.setLayoutParams(tlp);

        TextView title = new TextView(this);
        title.setText(cfg.name.toUpperCase());
        title.setTextSize(14);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.22f);
        title.setShadowLayer(10, 0, 0, 0xFF00FF9D);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);

        TextView subtitle = new TextView(this);
        subtitle.setText("// CONFIG TUNING");
        subtitle.setTextSize(9);
        subtitle.setTextColor(0xFFFF1E4E);
        subtitle.setTypeface(Typeface.MONOSPACE);
        subtitle.setLetterSpacing(0.2f);

        titleBox.addView(title);
        titleBox.addView(subtitle);

        View rightSpacer = new View(this);
        rightSpacer.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));

        h.addView(back);
        h.addView(titleBox);
        h.addView(rightSpacer);
        return h;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(0xFF1A2430);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(1)));
        return v;
    }

    private View buildScrollArea() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(20), dp(18), dp(20));
        form.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        // 1. Задержка серверных (100 шагов = одинаковая чувствительность с потерями)
        sbServerDelay    = neonSeekBarDelay(MAX_DELAY, 1);
        tvServerDelayVal = neonValueLabel("0 ms", 0xFF00FF9D);
        form.addView(sliderCardDelay("ЗАДЕРЖКА СЕРВЕРНЫХ ПАКЕТОВ", 0xFF00FF9D, tvServerDelayVal, sbServerDelay, MAX_DELAY));
        form.addView(spacer(14));

        // 2. Удаление серверных
        sbServerLoss    = neonSeekBar(MAX_LOSS);
        tvServerLossVal = neonValueLabel("0%", 0xFFFF1E4E);
        form.addView(sliderCard("УДАЛЕНИЕ СЕРВЕРНЫХ ПАКЕТОВ", 0xFFFF1E4E, tvServerLossVal, sbServerLoss, "%", MAX_LOSS));
        form.addView(spacer(14));

        // 3. Задержка клиентских (100 шагов = одинаковая чувствительность с потерями)
        sbClientDelay    = neonSeekBarDelay(MAX_DELAY, 1);
        tvClientDelayVal = neonValueLabel("0 ms", 0xFF00FF9D);
        form.addView(sliderCardDelay("ЗАДЕРЖКА КЛИЕНТСКИХ ПАКЕТОВ", 0xFF00FF9D, tvClientDelayVal, sbClientDelay, MAX_DELAY));
        form.addView(spacer(14));

        // 4. Удаление клиентских
        sbClientLoss    = neonSeekBar(MAX_LOSS);
        tvClientLossVal = neonValueLabel("0%", 0xFFFF1E4E);
        form.addView(sliderCard("УДАЛЕНИЕ КЛИЕНТСКИХ ПАКЕТОВ", 0xFFFF1E4E, tvClientLossVal, sbClientLoss, "%", MAX_LOSS));
        form.addView(spacer(14));

        // 5. После таймера
        form.addView(buildAfterTimerCard());
        form.addView(spacer(14));

        // 6. Время работы
        form.addView(buildDurationCard());
        form.addView(spacer(14));

        form.addView(buildPacketSizeFilterCard());
        form.addView(spacer(14));

        sv.addView(form);
        return sv;
    }

    /**
     * Карточка-слайдер для задержек (scaled). maxMs — реальный максимум в мс.
     */
    private View sliderCardDelay(String labelText, int accent,
                                  final TextView valView, final SeekBar sb,
                                  final int maxMs) {
        return sliderCard(labelText, accent, valView, sb, "ms", maxMs);
    }

    /**
     * Карточка-слайдер с кнопкой ручного ввода по тапу на значение.
     */
    private View sliderCard(String labelText, int accent,
                             final TextView valView, final SeekBar sb,
                             final String unit, final int maxVal) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(18), dp(16), dp(18), dp(14));
        card.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        RelativeLayout topRow = new RelativeLayout(this);
        topRow.setLayoutParams(new RelativeLayout.LayoutParams(MATCH, WRAP));

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.HORIZONTAL);
        left.setGravity(Gravity.CENTER_VERTICAL);
        RelativeLayout.LayoutParams llp = new RelativeLayout.LayoutParams(WRAP, WRAP);
        llp.addRule(RelativeLayout.CENTER_VERTICAL);
        left.setLayoutParams(llp);

        View bar = new View(this);
        bar.setBackgroundColor(accent);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(3), dp(14));
        blp.rightMargin = dp(8);
        bar.setLayoutParams(blp);

        TextView lbl = new TextView(this);
        lbl.setText(labelText);
        lbl.setTextSize(11);
        lbl.setTypeface(null, Typeface.BOLD);
        lbl.setLetterSpacing(0.18f);
        lbl.setTextColor(0xFFB8C4D0);

        left.addView(bar);
        left.addView(lbl);

        RelativeLayout.LayoutParams vrp = new RelativeLayout.LayoutParams(WRAP, WRAP);
        vrp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        vrp.addRule(RelativeLayout.CENTER_VERTICAL);
        valView.setLayoutParams(vrp);

        valView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showInputDialog(sb, valView, unit, maxVal);
            }
        });

        topRow.addView(left);
        topRow.addView(valView);

        card.addView(topRow);
        card.addView(spacer(12));

        LinearLayout.LayoutParams sblp = new LinearLayout.LayoutParams(MATCH, dp(40));
        sb.setLayoutParams(sblp);
        card.addView(sb);

        TextView hint = new TextView(this);
        hint.setText("↑ тапни на значение для точного ввода");
        hint.setTextSize(9);
        hint.setTextColor(0xFF3A4654);
        hint.setTypeface(Typeface.MONOSPACE);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        hlp.topMargin = dp(4);
        hint.setLayoutParams(hlp);
        card.addView(hint);

        return card;
    }

    /** Диалог ручного ввода значения ползунка */
    private void showInputDialog(final SeekBar sb, final TextView valView,
                                  final String unit, final int maxVal) {
        final Dialog dlg = new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dlg.setCanceledOnTouchOutside(true);
        dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dlg.getWindow().setLayout(
                (int)(getResources().getDisplayMetrics().widthPixels * 0.88f),
                WindowManager.LayoutParams.WRAP_CONTENT);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundResource(R.drawable.bg_dialog_neon);
        root.setPadding(dp(24), dp(28), dp(24), dp(24));
        dlg.setContentView(root);

        TextView title = new TextView(this);
        title.setText("Значение (0–" + maxVal + ")");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(17);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        root.addView(dialogSpacer(14));

        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setTextColor(0xFF00FF9D);
        et.setHintTextColor(0xFF3A4654);
        et.setHint("0");
        et.setTextSize(20);
        et.setTypeface(null, Typeface.BOLD);
        et.setBackgroundResource(R.drawable.bg_input);
        et.setPadding(dp(16), dp(12), dp(16), dp(12));
        et.setText(String.valueOf(delayValue(sb)));
        et.selectAll();
        et.setGravity(Gravity.CENTER);
        et.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(et);
        root.addView(dialogSpacer(20));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        Button btnCancel = new Button(this);
        btnCancel.setText("Отмена");
        btnCancel.setTextColor(0xFFB8C4D0);
        btnCancel.setTextSize(14);
        btnCancel.setTypeface(null, Typeface.BOLD);
        btnCancel.setAllCaps(false);
        btnCancel.setBackgroundResource(R.drawable.btn_neon_outline);
        btnCancel.setLayoutParams(new LinearLayout.LayoutParams(0, dp(44), 1f));
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { dlg.dismiss(); }
        });

        View gap = new View(this);
        gap.setLayoutParams(new LinearLayout.LayoutParams(dp(12), MATCH));

        Button btnApply = new Button(this);
        btnApply.setText("Изменить");
        btnApply.setTextColor(0xFF000000);
        btnApply.setTextSize(14);
        btnApply.setTypeface(null, Typeface.BOLD);
        btnApply.setAllCaps(false);
        btnApply.setBackgroundResource(R.drawable.btn_neon_green);
        btnApply.setLayoutParams(new LinearLayout.LayoutParams(0, dp(44), 1f));
        btnApply.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String s = et.getText().toString().trim();
                int val = 0;
                try { val = Integer.parseInt(s); } catch (NumberFormatException ignored) {}
                val = Math.max(0, Math.min(val, maxVal));
                setDelayValue(sb, val);
                valView.setText(val + (unit.equals("%") ? "%" : " " + unit));
                dlg.dismiss();
            }
        });

        row.addView(btnCancel);
        row.addView(gap);
        row.addView(btnApply);
        root.addView(row);

        dlg.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        dlg.show();
    }

    private View dialogSpacer(int dpVal) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(dpVal)));
        return v;
    }

    private View buildAfterTimerCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(18), dp(16), dp(18), dp(14));
        card.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView title = new TextView(this);
        title.setText("После таймера");
        title.setTextSize(14);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFFFFFFFF);
        title.setLetterSpacing(0.1f);
        card.addView(title);
        card.addView(spacer(4));

        TextView subtitle = new TextView(this);
        subtitle.setText("Что делать с задержанными пакетами клиента");
        subtitle.setTextSize(11);
        subtitle.setTextColor(0xFF7A8899);
        card.addView(subtitle);
        card.addView(spacer(12));

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(44)));

        btnAfterReset = makeToggleBtn("Сброс");
        btnAfterDrop  = makeToggleBtn("Удалить");
        btnAfterDelay = makeToggleBtn("Задержка");

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, MATCH, 1f);
        bp.rightMargin = dp(6);
        btnAfterReset.setLayoutParams(bp);

        LinearLayout.LayoutParams bp2 = new LinearLayout.LayoutParams(0, MATCH, 1f);
        bp2.rightMargin = dp(6);
        btnAfterDrop.setLayoutParams(bp2);

        btnAfterDelay.setLayoutParams(new LinearLayout.LayoutParams(0, MATCH, 1f));

        btnRow.addView(btnAfterReset);
        btnRow.addView(btnAfterDrop);
        btnRow.addView(btnAfterDelay);
        card.addView(btnRow);

        LinearLayout afterDelaySliderRowLL = new LinearLayout(this);
        afterDelaySliderRowLL.setOrientation(LinearLayout.VERTICAL);
        afterDelaySliderRowLL.setVisibility(View.GONE);
        afterDelaySliderRow = afterDelaySliderRowLL;

        afterDelaySliderRowLL.addView(spacer(12));

        // ЗАДЕРЖКА ПОСЛЕ ТАЙМЕРА: 100 шагов (шаг 5 мс, диапазон 0-500 мс)
        sbAfterDelay    = neonSeekBarDelay(MAX_AFTER_DELAY, 1);
        tvAfterDelayVal = neonValueLabel("0 ms", 0xFF00BFFF);
        afterDelaySliderRowLL.addView(
            sliderCardDelay("ЗАДЕРЖКА ПОСЛЕ ТАЙМЕРА (макс 500ms)", 0xFF00BFFF, tvAfterDelayVal, sbAfterDelay, MAX_AFTER_DELAY));

        afterDelaySliderRowLL.addView(spacer(10));

        // Длительность применения (сек)
        sbAfterDuration    = neonSeekBar(MAX_DURATION_SEC);
        tvAfterDurationVal = neonValueLabel("3,0s", 0xFF00BFFF);
        afterDelaySliderRowLL.addView(
            sliderCard("ДЛИТЕЛЬНОСТЬ", 0xFF00BFFF, tvAfterDurationVal, sbAfterDuration, "s", MAX_DURATION_SEC));

        sbAfterDelay.setOnSeekBarChangeListener(new SBL() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                int realMs = delayValue(s);
                int clamped = Math.max(0, Math.min(realMs, MAX_AFTER_DELAY));
                tvAfterDelayVal.setText(clamped + " ms");
            }
        });

        sbAfterDuration.setOnSeekBarChangeListener(new SBL() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tvAfterDurationVal.setText(v + ",0s");
            }
        });

        card.addView(afterDelaySliderRowLL);

        btnAfterReset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { selectAfterMode(0); }
        });
        btnAfterDrop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { selectAfterMode(1); }
        });
        btnAfterDelay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { selectAfterMode(2); }
        });

        return card;
    }

    private Button makeToggleBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setTypeface(null, Typeface.BOLD);
        b.setTextColor(0xFFB8C4D0);
        b.setBackgroundResource(R.drawable.bg_secondary_btn);
        b.setStateListAnimator(null);
        b.setPadding(dp(4), 0, dp(4), 0);
        return b;
    }

    private void selectAfterMode(int mode) {
        afterTimerMode = mode;
        int activeColor   = 0xFF1A6FE0;
        int inactiveColor = 0xFF1A2430;

        btnAfterReset.setBackgroundColor(mode == 0 ? activeColor : inactiveColor);
        btnAfterReset.setTextColor(mode == 0 ? 0xFFFFFFFF : 0xFFB8C4D0);

        btnAfterDrop.setBackgroundColor(mode == 1 ? activeColor : inactiveColor);
        btnAfterDrop.setTextColor(mode == 1 ? 0xFFFFFFFF : 0xFFB8C4D0);

        btnAfterDelay.setBackgroundColor(mode == 2 ? activeColor : inactiveColor);
        btnAfterDelay.setTextColor(mode == 2 ? 0xFFFFFFFF : 0xFFB8C4D0);

        afterDelaySliderRow.setVisibility(mode == 2 ? View.VISIBLE : View.GONE);
    }

    private View buildDurationCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(18), dp(16), dp(18), dp(18));
        card.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        topRow.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        View bar = new View(this);
        bar.setBackgroundColor(0xFF00FF9D);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(3), dp(14));
        blp.rightMargin = dp(8);
        bar.setLayoutParams(blp);

        TextView lbl = new TextView(this);
        lbl.setText("ТАЙМЕР (СЕК.МС, 0 = ∞)");
        lbl.setTextSize(11);
        lbl.setTypeface(null, Typeface.BOLD);
        lbl.setLetterSpacing(0.18f);
        lbl.setTextColor(0xFFB8C4D0);

        topRow.addView(bar);
        topRow.addView(lbl);
        card.addView(topRow);
        card.addView(spacer(12));

        etDuration = new EditText(this);
        etDuration.setHint("0 или 1.700");
        etDuration.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etDuration.setTextColor(0xFF00FF9D);
        etDuration.setHintTextColor(0xFF3A4654);
        etDuration.setTextSize(22);
        etDuration.setTypeface(null, Typeface.BOLD);
        etDuration.setShadowLayer(8, 0, 0, 0xFF00FF9D);
        etDuration.setBackgroundResource(R.drawable.bg_input);
        etDuration.setPadding(dp(18), dp(14), dp(18), dp(14));
        etDuration.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(58)));
        card.addView(etDuration);

        return card;
    }

    private View buildSaveButton() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(10), dp(18), dp(18));
        panel.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        Button btnSave = new Button(this);
        btnSave.setText("СОХРАНИТЬ");
        btnSave.setTextSize(15);
        btnSave.setLetterSpacing(0.26f);
        btnSave.setTypeface(null, Typeface.BOLD);
        btnSave.setTextColor(0xFF001A0E);
        btnSave.setBackgroundResource(R.drawable.btn_neon_green);
        btnSave.setStateListAnimator(null);
        btnSave.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(58)));
        btnSave.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { saveConfig(); }
        });

        panel.addView(btnSave);
        return panel;
    }

    private void loadValues() {
        setDelayValue(sbServerDelay, cfg.serverDelay);
        tvServerDelayVal.setText(cfg.serverDelay + " ms");

        sbServerLoss.setProgress(cfg.serverLoss);
        tvServerLossVal.setText(cfg.serverLoss + "%");

        setDelayValue(sbClientDelay, cfg.clientDelay);
        tvClientDelayVal.setText(cfg.clientDelay + " ms");

        sbClientLoss.setProgress(cfg.clientLoss);
        tvClientLossVal.setText(cfg.clientLoss + "%");

        selectAfterMode(cfg.afterTimerMode);

        // Загружаем задержку после таймера (ограничиваем 0–500)
        int afterDelay = Math.max(0, Math.min(cfg.afterTimerDelayMs, MAX_AFTER_DELAY));
        setDelayValue(sbAfterDelay, afterDelay);
        tvAfterDelayVal.setText(afterDelay + " ms");

        int savedDur = cfg.afterTimerDurationSec;
        sbAfterDuration.setProgress(savedDur);
        tvAfterDurationVal.setText(savedDur + ",0s");

        if (cfg.duration > 0) {
            // cfg.duration хранится в миллисекундах
            int sec = cfg.duration / 1000;
            int ms  = cfg.duration % 1000;
            if (ms == 0) {
                etDuration.setText(String.valueOf(sec));
            } else {
                etDuration.setText(sec + "." + String.format("%03d", ms));
            }
        }

        // Загрузить фильтр по размеру пакета
        clientSizeFilterMode = cfg.clientSizeFilterMode;
        serverSizeFilterMode = cfg.serverSizeFilterMode;
        updateSzBtnStates(true);
        updateSzBtnStates(false);
        if (sbClientSzMin != null) {
            sbClientSzMin.setProgress(cfg.clientSizeMin);
            tvClientSzMin.setText(String.valueOf(cfg.clientSizeMin));
            sbClientSzMax.setProgress(cfg.clientSizeMax);
            tvClientSzMax.setText(String.valueOf(cfg.clientSizeMax));
            clientSzSliders.setVisibility(clientSizeFilterMode == 0 ? View.GONE : View.VISIBLE);
        }
        if (sbServerSzMin != null) {
            sbServerSzMin.setProgress(cfg.serverSizeMin);
            tvServerSzMin.setText(String.valueOf(cfg.serverSizeMin));
            sbServerSzMax.setProgress(cfg.serverSizeMax);
            tvServerSzMax.setText(String.valueOf(cfg.serverSizeMax));
            serverSzSliders.setVisibility(serverSizeFilterMode == 0 ? View.GONE : View.VISIBLE);
        }
    }

    private void setupListeners() {
        sbServerDelay.setOnSeekBarChangeListener(new SBL() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tvServerDelayVal.setText(delayValue(s) + " ms");
            }
        });
        sbServerLoss.setOnSeekBarChangeListener(new SBL() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tvServerLossVal.setText(v + "%");
            }
        });
        sbClientDelay.setOnSeekBarChangeListener(new SBL() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tvClientDelayVal.setText(delayValue(s) + " ms");
            }
        });
        sbClientLoss.setOnSeekBarChangeListener(new SBL() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                tvClientLossVal.setText(v + "%");
            }
        });
    }

    private void saveConfig() {
        // ── Сохраняем значения в объект конфига ─────────────────────
        cfg.serverDelay = delayValue(sbServerDelay);
        cfg.serverLoss  = sbServerLoss.getProgress();
        cfg.clientDelay = delayValue(sbClientDelay);
        cfg.clientLoss  = sbClientLoss.getProgress();

        cfg.afterTimerMode        = afterTimerMode;
        // Гарантируем ограничение 0–500 при сохранении
        cfg.afterTimerDelayMs     = Math.max(0, Math.min(delayValue(sbAfterDelay), MAX_AFTER_DELAY));
        cfg.afterTimerDurationSec = sbAfterDuration.getProgress();

        // Фильтр по размеру пакета
        cfg.clientSizeFilterMode = clientSizeFilterMode;
        cfg.serverSizeFilterMode = serverSizeFilterMode;
        if (sbClientSzMin != null) {
            cfg.clientSizeMin = sbClientSzMin.getProgress();
            cfg.clientSizeMax = sbClientSzMax.getProgress();
        }
        if (sbServerSzMin != null) {
            cfg.serverSizeMin = sbServerSzMin.getProgress();
            cfg.serverSizeMax = sbServerSzMax.getProgress();
        }

        // duration хранится в миллисекундах (поддержка формата "1.700")
        String ds = etDuration.getText().toString().trim();
        cfg.duration = parseDurationMs(ds);

        // ── Если конфиг активен — применяем в реальном времени ─────
        if (cfg.installed) {
            // Обновляем статические поля MainActivity
            MainActivity.curServerDelay           = cfg.serverDelay;
            MainActivity.curServerLoss            = cfg.serverLoss;
            MainActivity.curClientDelay           = cfg.clientDelay;
            MainActivity.curClientLoss            = cfg.clientLoss;
            MainActivity.curDuration              = cfg.duration;
            MainActivity.curAfterTimerMode        = cfg.afterTimerMode;
            MainActivity.curAfterTimerDelayMs     = cfg.afterTimerDelayMs;
            MainActivity.curAfterTimerDurationSec = cfg.afterTimerDurationSec;

            // Отправляем Intent в MyVpnService для немедленного применения
            try {
                Intent vpnIntent = new Intent(this, MyVpnService.class);
                vpnIntent.setAction(MyVpnService.ACTION_UPDATE_SETTINGS);
                vpnIntent.putExtra(MyVpnService.EXTRA_SERVER_DELAY,         cfg.serverDelay);
                vpnIntent.putExtra(MyVpnService.EXTRA_SERVER_LOSS,          cfg.serverLoss);
                vpnIntent.putExtra(MyVpnService.EXTRA_CLIENT_DELAY,         cfg.clientDelay);
                vpnIntent.putExtra(MyVpnService.EXTRA_CLIENT_LOSS,          cfg.clientLoss);
                vpnIntent.putExtra(MyVpnService.EXTRA_AFTER_TIMER_MODE,     cfg.afterTimerMode);
                vpnIntent.putExtra(MyVpnService.EXTRA_AFTER_TIMER_DELAY,    cfg.afterTimerDelayMs);
                vpnIntent.putExtra(MyVpnService.EXTRA_AFTER_TIMER_DURATION, cfg.afterTimerDurationSec);
                vpnIntent.putExtra(MyVpnService.EXTRA_CLIENT_SZ_MODE, cfg.clientSizeFilterMode);
                vpnIntent.putExtra(MyVpnService.EXTRA_CLIENT_SZ_MIN,  cfg.clientSizeMin);
                vpnIntent.putExtra(MyVpnService.EXTRA_CLIENT_SZ_MAX,  cfg.clientSizeMax);
                vpnIntent.putExtra(MyVpnService.EXTRA_SERVER_SZ_MODE, cfg.serverSizeFilterMode);
                vpnIntent.putExtra(MyVpnService.EXTRA_SERVER_SZ_MIN,  cfg.serverSizeMin);
                vpnIntent.putExtra(MyVpnService.EXTRA_SERVER_SZ_MAX,  cfg.serverSizeMax);
                startService(vpnIntent);
            } catch (Exception ignored) {}

            // Отправляем Intent во FloatService для немедленного применения
            try {
                Intent floatIntent = new Intent(this, FloatService.class);
                floatIntent.setAction(FloatService.ACTION_UPDATE_SETTINGS);
                floatIntent.putExtra(FloatService.EXTRA_SECONDS,          cfg.duration);
                floatIntent.putExtra(FloatService.EXTRA_AFTER_TIMER_MODE, cfg.afterTimerMode);
                floatIntent.putExtra(FloatService.EXTRA_AFTER_TIMER_DELAY,cfg.afterTimerDelayMs);
                startService(floatIntent);
            } catch (Exception ignored) {}
        }

        // ── Персистентное сохранение ─────────────────────────────────
        saveConfigsToPrefs();

        Toast.makeText(this, "Конфиг сохранён", Toast.LENGTH_SHORT).show();
        finish();
    }

    // ── helpers ───────────────────────────────────────────────────────────
    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    /**
     * Создаёт плавный SeekBar с шагом 1 (нет keyProgressIncrement — Android по умолчанию 1).
     * Для большей плавности устанавливаем keyProgressIncrement = 1.
     */
    // Шаги ползунков задержки: 100 визуальных шагов (как у ползунков потерь).
    // Это даёт одинаковую физическую чувствительность для всех ползунков.
    // SeekBar.max = 100 (100 шагов), реальное значение = progress * STEP_*
    // SeekBar задержки использует прямой диапазон 0..MAX_*,
    // поэтому отдельные шаговые константы больше не нужны.

    /**
     * Ползунок потерь: 100 внутренних шагов (0–100%), без масштабирования.
     */
    private SeekBar neonSeekBar(int max) {
        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(0);
        sb.setKeyProgressIncrement(1);
        sb.setProgressDrawable(getResources().getDrawable(R.drawable.seekbar_progress));
        sb.setThumb(getResources().getDrawable(R.drawable.seekbar_thumb));
        sb.setSplitTrack(false);
        sb.setPadding(dp(16), 0, dp(16), 0);
        return sb;
    }

    /**
     * Ползунок задержки — прямой ввод мс без округлений.
     * sb.getProgress() == реальное значение в мс (шаг 1 мс).
     * Тег не используется; stepMs игнорируется (оставлен для совместимости сигнатуры).
     */
    private SeekBar neonSeekBarDelay(int maxMs, int stepMs) {
        SeekBar sb = new SeekBar(this);
        sb.setMax(maxMs);  // прямое значение в мс — точный ввод без шагов
        sb.setProgress(0);
        sb.setKeyProgressIncrement(1);
        sb.setProgressDrawable(getResources().getDrawable(R.drawable.seekbar_progress));
        sb.setThumb(getResources().getDrawable(R.drawable.seekbar_thumb));
        sb.setSplitTrack(false);
        sb.setPadding(dp(16), dp(4), dp(16), dp(4));
        return sb;
    }

    /** Возвращает реальное значение задержки — progress == мс напрямую */
    private int delayValue(SeekBar sb) {
        return sb.getProgress();
    }

    /** Устанавливает значение задержки — progress == мс напрямую */
    private void setDelayValue(SeekBar sb, int ms) {
        sb.setProgress(ms);
    }

    /**
     * Парсит строку таймера в миллисекунды.
     * Форматы: "5" → 5000 мс, "1.700" → 1700 мс, "10.200" → 10200 мс
     */
    private int parseDurationMs(String s) {
        if (s == null || s.isEmpty()) return 0;
        try {
            if (s.contains(".")) {
                String[] parts = s.split("\\.", 2);
                int sec = parts[0].isEmpty() ? 0 : Integer.parseInt(parts[0]);
                String msStr = parts[1];
                // Дополняем до 3 цифр справа нулями (или обрезаем)
                while (msStr.length() < 3) msStr += "0";
                if (msStr.length() > 3) msStr = msStr.substring(0, 3);
                int ms = Integer.parseInt(msStr);
                return sec * 1000 + ms;
            } else {
                return Integer.parseInt(s) * 1000;
            }
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private TextView neonValueLabel(String text, int color) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(15);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(color);
        tv.setShadowLayer(8, 0, 0, color);
        return tv;
    }

    private View spacer(int dpVal) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(dpVal)));
        return v;
    }

    // ─── Фильтр по размеру пакета ─────────────────────────────────────────────

    private View buildPacketSizeFilterCard() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundResource(R.drawable.bg_card);
        outer.setPadding(dp(18), dp(16), dp(18), dp(16));
        outer.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        // Заголовок
        TextView title = new TextView(this);
        title.setText("ФИЛЬТР ПО РАЗМЕРУ ПАКЕТА");
        title.setTextSize(11);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setLetterSpacing(0.18f);
        title.setTextColor(0xFFB8C4D0);
        title.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        outer.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Задержка/дроп только для пакетов выбранного размера");
        subtitle.setTextSize(11);
        subtitle.setTextColor(0xFF4A5A6A);
        LinearLayout.LayoutParams sublp = new LinearLayout.LayoutParams(MATCH, WRAP);
        sublp.topMargin = dp(4);
        sublp.bottomMargin = dp(14);
        subtitle.setLayoutParams(sublp);
        outer.addView(subtitle);

        // Клиент
        outer.addView(buildSizeFilterRow("Клиент:", true));
        clientSzSliders = buildSizeSliders(true);
        clientSzSliders.setVisibility(clientSizeFilterMode == 0 ? View.GONE : View.VISIBLE);
        outer.addView(clientSzSliders);

        outer.addView(spacer(12));

        // Сервер
        outer.addView(buildSizeFilterRow("Сервер:", false));
        serverSzSliders = buildSizeSliders(false);
        serverSzSliders.setVisibility(serverSizeFilterMode == 0 ? View.GONE : View.VISIBLE);
        outer.addView(serverSzSliders);

        return outer;
    }

    private LinearLayout buildSizeFilterRow(String label, final boolean isClient) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, dp(44));
        row.setLayoutParams(rlp);

        android.graphics.drawable.GradientDrawable rowBg = new android.graphics.drawable.GradientDrawable();
        rowBg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        rowBg.setCornerRadius(dp(10));
        rowBg.setColor(0xFF0D1520);
        row.setBackground(rowBg);
        row.setPadding(dp(12), 0, dp(8), 0);

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextSize(14);
        lbl.setTypeface(null, android.graphics.Typeface.BOLD);
        lbl.setTextColor(0xFFFFFFFF);
        lbl.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(lbl);

        // Кнопки режима
        String[] labels = {"Все", "В диап.", "Вне диап."};
        Button[] btns = new Button[3];
        for (int i = 0; i < 3; i++) {
            Button b = makeToggleBtn(labels[i]);
            final int mode = i;
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (isClient) {
                        clientSizeFilterMode = mode;
                        updateSzBtnStates(true);
                        clientSzSliders.setVisibility(mode == 0 ? View.GONE : View.VISIBLE);
                    } else {
                        serverSizeFilterMode = mode;
                        updateSzBtnStates(false);
                        serverSzSliders.setVisibility(mode == 0 ? View.GONE : View.VISIBLE);
                    }
                }
            });
            btns[i] = b;
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(WRAP, dp(32));
            blp.leftMargin = dp(4);
            b.setLayoutParams(blp);
            row.addView(b);
        }

        if (isClient) {
            btnClientSzAll = btns[0]; btnClientSzIn = btns[1]; btnClientSzOut = btns[2];
        } else {
            btnServerSzAll = btns[0]; btnServerSzIn = btns[1]; btnServerSzOut = btns[2];
        }
        return row;
    }

    private LinearLayout buildSizeSliders(final boolean isClient) {
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(10);
        ll.setLayoutParams(lp);

        // Min slider row
        ll.addView(buildSzSliderRow("Мин:", isClient, true));
        // Max slider row
        ll.addView(buildSzSliderRow("Макс:", isClient, false));

        return ll;
    }

    private LinearLayout buildSzSliderRow(final String labelStr, final boolean isClient, final boolean isMin) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.bottomMargin = dp(6);
        row.setLayoutParams(rlp);

        TextView lbl = new TextView(this);
        lbl.setText(labelStr);
        lbl.setTextSize(12);
        lbl.setTextColor(0xFF6C7885);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(dp(40), WRAP);
        lbl.setLayoutParams(llp);
        row.addView(lbl);

        SeekBar sb = new SeekBar(this);
        sb.setMax(1500);
        sb.setKeyProgressIncrement(1);
        sb.setProgressDrawable(getResources().getDrawable(R.drawable.seekbar_progress));
        sb.setThumb(getResources().getDrawable(R.drawable.seekbar_thumb));
        sb.setSplitTrack(false);
        sb.setPadding(dp(8), 0, dp(8), 0);
        sb.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));

        final TextView valView = new TextView(this);
        valView.setTextSize(12);
        valView.setTypeface(null, android.graphics.Typeface.BOLD);
        valView.setTextColor(0xFF00FF9D);
        valView.setGravity(android.view.Gravity.END | android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(dp(44), WRAP);
        valView.setLayoutParams(vlp);

        if (isClient && isMin)  { sbClientSzMin = sb; tvClientSzMin = valView; }
        if (isClient && !isMin) { sbClientSzMax = sb; tvClientSzMax = valView; }
        if (!isClient && isMin) { sbServerSzMin = sb; tvServerSzMin = valView; }
        if (!isClient && !isMin){ sbServerSzMax = sb; tvServerSzMax = valView; }

        // Default values
        int defVal = isMin ? 0 : 1500;
        sb.setProgress(defVal);
        valView.setText(String.valueOf(defVal));

        sb.setOnSeekBarChangeListener(new SBL() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                valView.setText(String.valueOf(v));
            }
        });

        row.addView(sb);
        row.addView(valView);
        return row;
    }

    private void updateSzBtnStates(boolean isClient) {
        int mode = isClient ? clientSizeFilterMode : serverSizeFilterMode;
        Button all = isClient ? btnClientSzAll : btnServerSzAll;
        Button in  = isClient ? btnClientSzIn  : btnServerSzIn;
        Button out = isClient ? btnClientSzOut : btnServerSzOut;
        if (all == null || in == null || out == null) return;
        setSzBtnActive(all, mode == 0);
        setSzBtnActive(in,  mode == 1);
        setSzBtnActive(out, mode == 2);
    }

    private void setSzBtnActive(Button b, boolean active) {
        if (active) {
            b.setTextColor(0xFFFFFFFF);
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(8));
            bg.setColor(0xFF2979FF);
            b.setBackground(bg);
        } else {
            b.setTextColor(0xFF6C7885);
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
            bg.setCornerRadius(dp(8));
            bg.setColor(0xFF1A2430);
            b.setBackground(bg);
        }
    }


    /** Сохраняет все конфиги в SharedPreferences */
    private void saveConfigsToPrefs() {
        java.util.ArrayList<ConfigsActivity.Config> list = ConfigsActivity.configs;
        android.content.SharedPreferences.Editor ed =
            getSharedPreferences("cvpn_configs", MODE_PRIVATE).edit();
        ed.putInt("count", list.size());
        for (int i = 0; i < list.size(); i++) {
            ConfigsActivity.Config c = list.get(i);
            String p = "cfg_" + i + "_";
            ed.putString (p + "name",      c.name);
            ed.putString (p + "desc",      c.description);
            ed.putInt    (p + "sDelay",    c.serverDelay);
            ed.putInt    (p + "sLoss",     c.serverLoss);
            ed.putInt    (p + "cDelay",    c.clientDelay);
            ed.putInt    (p + "cLoss",     c.clientLoss);
            ed.putInt    (p + "duration",  c.duration);
            ed.putInt    (p + "atMode",    c.afterTimerMode);
            ed.putInt    (p + "atDelayMs", c.afterTimerDelayMs);
            ed.putInt    (p + "atDurSec",  c.afterTimerDurationSec);
            ed.putBoolean(p + "installed", c.installed);
            ed.putString (p + "vpn",       c.vpn == null ? "" : c.vpn);
            ed.putBoolean(p + "sendEncrypted",     c.sendEncrypted);
            ed.putBoolean(p + "importedEncrypted", c.importedEncrypted);
            ed.putInt    (p + "cSzMode",  c.clientSizeFilterMode);
            ed.putInt    (p + "cSzMin",   c.clientSizeMin);
            ed.putInt    (p + "cSzMax",   c.clientSizeMax);
            ed.putInt    (p + "sSzMode",  c.serverSizeFilterMode);
            ed.putInt    (p + "sSzMin",   c.serverSizeMin);
            ed.putInt    (p + "sSzMax",   c.serverSizeMax);
        }
        ed.apply();
    }

    private int safeInt(String s, int max) {
        if (s == null || s.isEmpty()) return 0;
        try {
            int v = Integer.parseInt(s);
            return Math.min(v, max);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    abstract static class SBL implements SeekBar.OnSeekBarChangeListener {
        public void onStartTrackingTouch(SeekBar s) {}
        public void onStopTrackingTouch(SeekBar s)  {}
    }

}
