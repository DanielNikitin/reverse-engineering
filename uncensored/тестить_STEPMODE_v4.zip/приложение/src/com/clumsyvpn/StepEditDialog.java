package com.clumsyvpn;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * StepEditDialog — окно настройки одного шага «Пошагового режима» (не на весь экран).
 *
 * Порядок настроек, как в ТЗ:
 *   Клиентские пакеты: задержка, дроп, буфер (Обычный/Слив/Сброс/Удалить)
 *   Серверные пакеты:  задержка, дроп, буфер (Обычный/Слив/Сброс/Удалить)
 *   Фильтр по размерам: Все / В диапазоне / Вне диапазона (мин/макс для каждого)
 *   Время до следующего шага
 *   Кнопки: Отмена / Сохранить
 */
public class StepEditDialog {

    public interface OnSaveListener {
        void onSave();
    }

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final int MAX_DELAY = 5000;   // ms
    private static final int MAX_LOSS  = 100;    // %
    private static final String[] BUFFER_LABELS = {"Обычный", "Слив", "Сброс", "Удалить"};

    private final Context context;
    private final ConfigsActivity.Step step;
    private final OnSaveListener listener;

    private Dialog dlg;

    // Клиент
    private SeekBar sbClientDelay; private TextView tvClientDelay;
    private SeekBar sbClientLoss;  private TextView tvClientLoss;
    private int clientBufferMode;
    private Button[] clientBufferBtns;

    // Сервер
    private SeekBar sbServerDelay; private TextView tvServerDelay;
    private SeekBar sbServerLoss;  private TextView tvServerLoss;
    private int serverBufferMode;
    private Button[] serverBufferBtns;

    // Фильтр по размеру
    private int clientSizeMode;
    private int serverSizeMode;
    private Button btnClientSzAll, btnClientSzIn, btnClientSzOut;
    private Button btnServerSzAll, btnServerSzIn, btnServerSzOut;
    private LinearLayout clientSzSliders, serverSzSliders;
    private SeekBar sbClientSzMin, sbClientSzMax; private TextView tvClientSzMin, tvClientSzMax;
    private SeekBar sbServerSzMin, sbServerSzMax; private TextView tvServerSzMin, tvServerSzMax;

    // Время до следующего шага
    private EditText etDuration;

    public StepEditDialog(Context context, ConfigsActivity.Step step, OnSaveListener listener) {
        this.context = context;
        this.step = step;
        this.listener = listener;
    }

    public void show() {
        dlg = new Dialog(context);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout outer = new LinearLayout(context);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundResource(R.drawable.bg_dialog_neon);
        outer.setPadding(dp(20), dp(20), dp(20), dp(16));

        TextView title = new TextView(context);
        title.setText("НАСТРОЙКА ШАГА");
        title.setTextSize(16);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.22f);
        title.setShadowLayer(12, 0, 0, 0xFF00CFFF);
        outer.addView(title);
        outer.addView(spacer(14));

        ScrollView sv = new ScrollView(context);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout.LayoutParams svLp = new LinearLayout.LayoutParams(MATCH, dp(420));
        sv.setLayoutParams(svLp);

        LinearLayout form = new LinearLayout(context);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        form.addView(sectionLabel("КЛИЕНТСКИЕ ПАКЕТЫ", 0xFF00FF9D));
        form.addView(spacer(10));

        sbClientDelay = neonSeekBarDelay(MAX_DELAY);
        sbClientDelay.setProgress(Math.max(0, Math.min(step.clientDelay, MAX_DELAY)));
        tvClientDelay = neonValueLabel(step.clientDelay + " ms", 0xFF00FF9D);
        form.addView(sliderCard("Задержка клиентских пакетов", 0xFF00FF9D, tvClientDelay, sbClientDelay, "ms", MAX_DELAY));
        form.addView(spacer(12));

        sbClientLoss = neonSeekBar(MAX_LOSS);
        sbClientLoss.setProgress(Math.max(0, Math.min(step.clientLoss, MAX_LOSS)));
        tvClientLoss = neonValueLabel(step.clientLoss + "%", 0xFFFF1E4E);
        form.addView(sliderCard("Дроп клиентских пакетов", 0xFFFF1E4E, tvClientLoss, sbClientLoss, "%", MAX_LOSS));
        form.addView(spacer(12));

        clientBufferMode = step.clientBufferMode;
        form.addView(bufferRow("Буфер:", true));
        form.addView(spacer(18));

        form.addView(sectionLabel("СЕРВЕРНЫЕ ПАКЕТЫ", 0xFF00CFFF));
        form.addView(spacer(10));

        sbServerDelay = neonSeekBarDelay(MAX_DELAY);
        sbServerDelay.setProgress(Math.max(0, Math.min(step.serverDelay, MAX_DELAY)));
        tvServerDelay = neonValueLabel(step.serverDelay + " ms", 0xFF00CFFF);
        form.addView(sliderCard("Задержка серверных пакетов", 0xFF00CFFF, tvServerDelay, sbServerDelay, "ms", MAX_DELAY));
        form.addView(spacer(12));

        sbServerLoss = neonSeekBar(MAX_LOSS);
        sbServerLoss.setProgress(Math.max(0, Math.min(step.serverLoss, MAX_LOSS)));
        tvServerLoss = neonValueLabel(step.serverLoss + "%", 0xFFFF1E4E);
        form.addView(sliderCard("Дроп серверных пакетов", 0xFFFF1E4E, tvServerLoss, sbServerLoss, "%", MAX_LOSS));
        form.addView(spacer(12));

        serverBufferMode = step.serverBufferMode;
        form.addView(bufferRow("Буфер:", false));
        form.addView(spacer(18));

        form.addView(sectionLabel("ФИЛЬТР ПО РАЗМЕРАМ", 0xFFB8C4D0));
        form.addView(spacer(10));

        clientSizeMode = step.clientSizeFilterMode;
        serverSizeMode = step.serverSizeFilterMode;

        form.addView(sizeFilterRow("Клиент:", true));
        clientSzSliders = sizeSliders(true);
        clientSzSliders.setVisibility(clientSizeMode == 0 ? View.GONE : View.VISIBLE);
        form.addView(clientSzSliders);
        form.addView(spacer(12));

        form.addView(sizeFilterRow("Сервер:", false));
        serverSzSliders = sizeSliders(false);
        serverSzSliders.setVisibility(serverSizeMode == 0 ? View.GONE : View.VISIBLE);
        form.addView(serverSzSliders);
        form.addView(spacer(18));

        form.addView(sectionLabel("ВРЕМЯ ДО СЛЕДУЮЩЕГО ШАГА", 0xFF00FF9D));
        form.addView(spacer(10));
        form.addView(buildDurationField());

        attachLiveLabelListeners();

        sv.addView(form);
        outer.addView(sv);
        outer.addView(spacer(16));
        outer.addView(buildButtonsRow());

        dlg.setContentView(outer);

        Window w = dlg.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xCC000000));
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.width  = (int) (context.getResources().getDisplayMetrics().widthPixels * 0.92f);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            w.setAttributes(lp);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }

        updateSzBtnStates(true);
        updateSzBtnStates(false);
        updateBufferBtnStates(true);
        updateBufferBtnStates(false);

        dlg.show();
    }

    // ════════════════════════════════════════════════════════════════════
    //  Секции / строки
    // ════════════════════════════════════════════════════════════════════

    private View sectionLabel(String text, int accent) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        View bar = new View(context);
        bar.setBackgroundColor(accent);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(3), dp(14));
        blp.rightMargin = dp(8);
        bar.setLayoutParams(blp);

        TextView lbl = new TextView(context);
        lbl.setText(text);
        lbl.setTextSize(12);
        lbl.setTypeface(null, Typeface.BOLD);
        lbl.setLetterSpacing(0.16f);
        lbl.setTextColor(0xFFB8C4D0);

        row.addView(bar);
        row.addView(lbl);
        return row;
    }

    private View bufferRow(String label, final boolean isClient) {
        LinearLayout wrap = new LinearLayout(context);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackgroundResource(R.drawable.bg_card);
        wrap.setPadding(dp(16), dp(14), dp(16), dp(14));
        wrap.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView lbl = new TextView(context);
        lbl.setText(label);
        lbl.setTextSize(12);
        lbl.setTypeface(null, Typeface.BOLD);
        lbl.setTextColor(0xFF6C7885);
        LinearLayout.LayoutParams lblLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lblLp.bottomMargin = dp(10);
        lbl.setLayoutParams(lblLp);
        wrap.addView(lbl);

        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        Button[] btns = new Button[BUFFER_LABELS.length];
        for (int i = 0; i < BUFFER_LABELS.length; i++) {
            final int mode = i;
            Button b = makeToggleBtn(BUFFER_LABELS[i]);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            if (i < BUFFER_LABELS.length - 1) blp.rightMargin = dp(6);
            b.setLayoutParams(blp);
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (isClient) clientBufferMode = mode; else serverBufferMode = mode;
                    updateBufferBtnStates(isClient);
                }
            });
            btns[i] = b;
            row.addView(b);
        }
        if (isClient) clientBufferBtns = btns; else serverBufferBtns = btns;

        wrap.addView(row);
        return wrap;
    }

    private void updateBufferBtnStates(boolean isClient) {
        Button[] btns = isClient ? clientBufferBtns : serverBufferBtns;
        int mode = isClient ? clientBufferMode : serverBufferMode;
        if (btns == null) return;
        for (int i = 0; i < btns.length; i++) {
            setToggleActive(btns[i], i == mode, 0xFF1A6FE0);
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  Ползунки (стиль ConfigSettingsActivity)
    // ════════════════════════════════════════════════════════════════════

    private View sliderCard(String labelText, int accent, final TextView valView,
                             final SeekBar sb, final String unit, final int maxVal) {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(16), dp(14), dp(16), dp(12));
        card.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        RelativeLayout topRow = new RelativeLayout(context);
        topRow.setLayoutParams(new RelativeLayout.LayoutParams(MATCH, WRAP));

        LinearLayout left = new LinearLayout(context);
        left.setOrientation(LinearLayout.HORIZONTAL);
        left.setGravity(Gravity.CENTER_VERTICAL);
        RelativeLayout.LayoutParams llp = new RelativeLayout.LayoutParams(WRAP, WRAP);
        llp.addRule(RelativeLayout.CENTER_VERTICAL);
        left.setLayoutParams(llp);

        View bar = new View(context);
        bar.setBackgroundColor(accent);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(3), dp(13));
        blp.rightMargin = dp(8);
        bar.setLayoutParams(blp);

        TextView lbl = new TextView(context);
        lbl.setText(labelText);
        lbl.setTextSize(11);
        lbl.setTypeface(null, Typeface.BOLD);
        lbl.setLetterSpacing(0.1f);
        lbl.setTextColor(0xFFB8C4D0);

        left.addView(bar);
        left.addView(lbl);

        RelativeLayout.LayoutParams vrp = new RelativeLayout.LayoutParams(WRAP, WRAP);
        vrp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        vrp.addRule(RelativeLayout.CENTER_VERTICAL);
        valView.setLayoutParams(vrp);
        valView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showInputDialog(sb, valView, unit, maxVal); }
        });

        topRow.addView(left);
        topRow.addView(valView);
        card.addView(topRow);
        card.addView(spacer(10));

        LinearLayout.LayoutParams sblp = new LinearLayout.LayoutParams(MATCH, dp(38));
        sb.setLayoutParams(sblp);
        card.addView(sb);

        return card;
    }

    private void attachLiveLabelListeners() {
        sbClientDelay.setOnSeekBarChangeListener(new SBL() {
            public void onProgressChanged(SeekBar s, int v, boolean u) { tvClientDelay.setText(v + " ms"); }
        });
        sbClientLoss.setOnSeekBarChangeListener(new SBL() {
            public void onProgressChanged(SeekBar s, int v, boolean u) { tvClientLoss.setText(v + "%"); }
        });
        sbServerDelay.setOnSeekBarChangeListener(new SBL() {
            public void onProgressChanged(SeekBar s, int v, boolean u) { tvServerDelay.setText(v + " ms"); }
        });
        sbServerLoss.setOnSeekBarChangeListener(new SBL() {
            public void onProgressChanged(SeekBar s, int v, boolean u) { tvServerLoss.setText(v + "%"); }
        });
    }

    private void showInputDialog(final SeekBar sb, final TextView valView,
                                  final String unit, final int maxVal) {
        final Dialog d = new Dialog(context);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCanceledOnTouchOutside(true);
        d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        d.getWindow().setLayout(
            (int) (context.getResources().getDisplayMetrics().widthPixels * 0.86f),
            WindowManager.LayoutParams.WRAP_CONTENT);

        LinearLayout root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundResource(R.drawable.bg_dialog_neon);
        root.setPadding(dp(22), dp(24), dp(22), dp(20));
        d.setContentView(root);

        TextView title = new TextView(context);
        title.setText("Значение (0–" + maxVal + ")");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(16);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        root.addView(spacer(12));

        final EditText et = new EditText(context);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setTextColor(0xFF00FF9D);
        et.setHintTextColor(0xFF3A4654);
        et.setTextSize(19);
        et.setTypeface(null, Typeface.BOLD);
        et.setBackgroundResource(R.drawable.bg_input);
        et.setPadding(dp(14), dp(10), dp(14), dp(10));
        et.setText(String.valueOf(sb.getProgress()));
        et.selectAll();
        et.setGravity(Gravity.CENTER);
        et.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(et);
        root.addView(spacer(18));

        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        Button btnCancel = new Button(context);
        btnCancel.setText("Отмена");
        btnCancel.setTextColor(0xFFB8C4D0);
        btnCancel.setTextSize(13);
        btnCancel.setTypeface(null, Typeface.BOLD);
        btnCancel.setAllCaps(false);
        btnCancel.setBackgroundResource(R.drawable.btn_neon_outline);
        LinearLayout.LayoutParams c1 = new LinearLayout.LayoutParams(0, dp(42), 1f);
        c1.rightMargin = dp(10);
        btnCancel.setLayoutParams(c1);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { d.dismiss(); }
        });

        Button btnApply = new Button(context);
        btnApply.setText("Изменить");
        btnApply.setTextColor(0xFF000000);
        btnApply.setTextSize(13);
        btnApply.setTypeface(null, Typeface.BOLD);
        btnApply.setAllCaps(false);
        btnApply.setBackgroundResource(R.drawable.btn_neon_green);
        btnApply.setLayoutParams(new LinearLayout.LayoutParams(0, dp(42), 1f));
        btnApply.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int val = 0;
                try { val = Integer.parseInt(et.getText().toString().trim()); } catch (NumberFormatException ignored) {}
                val = Math.max(0, Math.min(val, maxVal));
                sb.setProgress(val);
                valView.setText(val + (unit.equals("%") ? "%" : " " + unit));
                d.dismiss();
            }
        });

        row.addView(btnCancel);
        row.addView(btnApply);
        root.addView(row);

        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
    }

    // ════════════════════════════════════════════════════════════════════
    //  Фильтр по размеру
    // ════════════════════════════════════════════════════════════════════

    private LinearLayout sizeFilterRow(String label, final boolean isClient) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(R.drawable.bg_card);
        row.setPadding(dp(14), dp(10), dp(10), dp(10));
        row.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView lbl = new TextView(context);
        lbl.setText(label);
        lbl.setTextSize(13);
        lbl.setTypeface(null, Typeface.BOLD);
        lbl.setTextColor(0xFFFFFFFF);
        lbl.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(lbl);

        String[] labels = {"Все", "В диап.", "Вне диап."};
        Button[] btns = new Button[3];
        for (int i = 0; i < 3; i++) {
            final int mode = i;
            Button b = makeToggleBtn(labels[i]);
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (isClient) {
                        clientSizeMode = mode;
                        updateSzBtnStates(true);
                        clientSzSliders.setVisibility(mode == 0 ? View.GONE : View.VISIBLE);
                    } else {
                        serverSizeMode = mode;
                        updateSzBtnStates(false);
                        serverSzSliders.setVisibility(mode == 0 ? View.GONE : View.VISIBLE);
                    }
                }
            });
            btns[i] = b;
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(WRAP, dp(32));
            blp.leftMargin = dp(4);
            b.setLayoutParams(blp);
            row.addView(b);
        }
        if (isClient) { btnClientSzAll = btns[0]; btnClientSzIn = btns[1]; btnClientSzOut = btns[2]; }
        else           { btnServerSzAll = btns[0]; btnServerSzIn = btns[1]; btnServerSzOut = btns[2]; }
        return row;
    }

    private LinearLayout sizeSliders(final boolean isClient) {
        LinearLayout ll = new LinearLayout(context);
        ll.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(8);
        ll.setLayoutParams(lp);
        ll.addView(szSliderRow("Мин:", isClient, true));
        ll.addView(szSliderRow("Макс:", isClient, false));
        return ll;
    }

    private LinearLayout szSliderRow(String labelStr, final boolean isClient, final boolean isMin) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        rlp.bottomMargin = dp(6);
        row.setLayoutParams(rlp);

        TextView lbl = new TextView(context);
        lbl.setText(labelStr);
        lbl.setTextSize(12);
        lbl.setTextColor(0xFF6C7885);
        lbl.setLayoutParams(new LinearLayout.LayoutParams(dp(40), WRAP));
        row.addView(lbl);

        SeekBar sb = new SeekBar(context);
        sb.setMax(1500);
        sb.setKeyProgressIncrement(1);
        sb.setProgressDrawable(context.getResources().getDrawable(R.drawable.seekbar_progress));
        sb.setThumb(context.getResources().getDrawable(R.drawable.seekbar_thumb));
        sb.setSplitTrack(false);
        sb.setPadding(dp(8), 0, dp(8), 0);
        sb.setLayoutParams(new LinearLayout.LayoutParams(0, WRAP, 1f));

        final TextView valView = new TextView(context);
        valView.setTextSize(12);
        valView.setTypeface(null, Typeface.BOLD);
        valView.setTextColor(0xFF00FF9D);
        valView.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        valView.setLayoutParams(new LinearLayout.LayoutParams(dp(44), WRAP));

        int defVal = isMin
            ? (isClient ? step.clientSizeMin : step.serverSizeMin)
            : (isClient ? step.clientSizeMax : step.serverSizeMax);
        sb.setProgress(defVal);
        valView.setText(String.valueOf(defVal));

        if (isClient && isMin)   { sbClientSzMin = sb; tvClientSzMin = valView; }
        if (isClient && !isMin)  { sbClientSzMax = sb; tvClientSzMax = valView; }
        if (!isClient && isMin)  { sbServerSzMin = sb; tvServerSzMin = valView; }
        if (!isClient && !isMin) { sbServerSzMax = sb; tvServerSzMax = valView; }

        sb.setOnSeekBarChangeListener(new SBL() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                valView.setText(String.valueOf(v));
            }
        });

        row.addView(sb);
        row.addView(valView);
        return row;
    }

    private void updateSzBtnStates(boolean isClient) {
        int mode = isClient ? clientSizeMode : serverSizeMode;
        Button all = isClient ? btnClientSzAll : btnServerSzAll;
        Button in  = isClient ? btnClientSzIn  : btnServerSzIn;
        Button out = isClient ? btnClientSzOut : btnServerSzOut;
        if (all == null || in == null || out == null) return;
        setToggleActive(all, mode == 0, 0xFF2979FF);
        setToggleActive(in,  mode == 1, 0xFF2979FF);
        setToggleActive(out, mode == 2, 0xFF2979FF);
    }

    private void setToggleActive(Button b, boolean active, int activeColor) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(8));
        if (active) {
            b.setTextColor(0xFFFFFFFF);
            bg.setColor(activeColor);
        } else {
            b.setTextColor(0xFF6C7885);
            bg.setColor(0xFF1A2430);
        }
        b.setBackground(bg);
    }

    // ════════════════════════════════════════════════════════════════════
    //  Время до следующего шага
    // ════════════════════════════════════════════════════════════════════

    private View buildDurationField() {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(16), dp(14), dp(16), dp(16));
        card.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView hint = new TextView(context);
        hint.setText("Секунд до автоматического перехода к следующему шагу");
        hint.setTextSize(11);
        hint.setTextColor(0xFF7A8899);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(MATCH, WRAP);
        hlp.bottomMargin = dp(10);
        hint.setLayoutParams(hlp);
        card.addView(hint);

        etDuration = new EditText(context);
        etDuration.setHint("0 или 1.700");
        etDuration.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etDuration.setTextColor(0xFF00FF9D);
        etDuration.setHintTextColor(0xFF3A4654);
        etDuration.setTextSize(20);
        etDuration.setTypeface(null, Typeface.BOLD);
        etDuration.setShadowLayer(8, 0, 0, 0xFF00FF9D);
        etDuration.setBackgroundResource(R.drawable.bg_input);
        etDuration.setPadding(dp(16), dp(12), dp(16), dp(12));
        etDuration.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(52)));

        int sec = step.duration / 1000;
        int ms  = step.duration % 1000;
        if (step.duration > 0) {
            etDuration.setText(ms == 0 ? String.valueOf(sec) : sec + "." + String.format("%03d", ms));
        }

        card.addView(etDuration);
        return card;
    }

    private int parseDurationMs(String s) {
        if (s == null || s.isEmpty()) return 0;
        try {
            if (s.contains(".")) {
                String[] parts = s.split("\\.", 2);
                int sec = parts[0].isEmpty() ? 0 : Integer.parseInt(parts[0]);
                String msStr = parts[1];
                while (msStr.length() < 3) msStr += "0";
                if (msStr.length() > 3) msStr = msStr.substring(0, 3);
                return sec * 1000 + Integer.parseInt(msStr);
            }
            return Integer.parseInt(s) * 1000;
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  Кнопки Отмена / Сохранить
    // ════════════════════════════════════════════════════════════════════

    private View buildButtonsRow() {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));

        Button btnCancel = new Button(context);
        btnCancel.setText("ОТМЕНА");
        btnCancel.setTextSize(13);
        btnCancel.setLetterSpacing(0.2f);
        btnCancel.setTypeface(null, Typeface.BOLD);
        btnCancel.setTextColor(0xFFB8C4D0);
        btnCancel.setBackgroundResource(R.drawable.btn_neon_outline);
        btnCancel.setStateListAnimator(null);
        LinearLayout.LayoutParams c1 = new LinearLayout.LayoutParams(0, dp(50), 1f);
        c1.rightMargin = dp(10);
        btnCancel.setLayoutParams(c1);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { dlg.dismiss(); }
        });

        Button btnSave = new Button(context);
        btnSave.setText("СОХРАНИТЬ");
        btnSave.setTextSize(13);
        btnSave.setLetterSpacing(0.22f);
        btnSave.setTypeface(null, Typeface.BOLD);
        btnSave.setTextColor(0xFF001A0E);
        btnSave.setBackgroundResource(R.drawable.btn_neon_green);
        btnSave.setStateListAnimator(null);
        btnSave.setLayoutParams(new LinearLayout.LayoutParams(0, dp(50), 1.2f));
        btnSave.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { saveAndClose(); }
        });

        row.addView(btnCancel);
        row.addView(btnSave);
        return row;
    }

    private void saveAndClose() {
        step.clientDelay = sbClientDelay.getProgress();
        step.clientLoss  = sbClientLoss.getProgress();
        step.clientBufferMode = clientBufferMode;

        step.serverDelay = sbServerDelay.getProgress();
        step.serverLoss  = sbServerLoss.getProgress();
        step.serverBufferMode = serverBufferMode;

        step.clientSizeFilterMode = clientSizeMode;
        step.serverSizeFilterMode = serverSizeMode;
        if (sbClientSzMin != null) {
            step.clientSizeMin = sbClientSzMin.getProgress();
            step.clientSizeMax = sbClientSzMax.getProgress();
        }
        if (sbServerSzMin != null) {
            step.serverSizeMin = sbServerSzMin.getProgress();
            step.serverSizeMax = sbServerSzMax.getProgress();
        }

        step.duration = parseDurationMs(etDuration.getText().toString().trim());

        dlg.dismiss();
        if (listener != null) listener.onSave();
    }

    // ════════════════════════════════════════════════════════════════════
    //  helpers
    // ════════════════════════════════════════════════════════════════════

    private Button makeToggleBtn(String text) {
        Button b = new Button(context);
        b.setText(text);
        b.setTextSize(11);
        b.setTypeface(null, Typeface.BOLD);
        b.setTextColor(0xFFB8C4D0);
        b.setBackgroundResource(R.drawable.bg_secondary_btn);
        b.setStateListAnimator(null);
        b.setAllCaps(false);
        b.setPadding(dp(6), 0, dp(6), 0);
        return b;
    }

    private SeekBar neonSeekBar(int max) {
        SeekBar sb = new SeekBar(context);
        sb.setMax(max);
        sb.setProgress(0);
        sb.setKeyProgressIncrement(1);
        sb.setProgressDrawable(context.getResources().getDrawable(R.drawable.seekbar_progress));
        sb.setThumb(context.getResources().getDrawable(R.drawable.seekbar_thumb));
        sb.setSplitTrack(false);
        sb.setPadding(dp(14), 0, dp(14), 0);
        return sb;
    }

    private SeekBar neonSeekBarDelay(int maxMs) {
        SeekBar sb = new SeekBar(context);
        sb.setMax(maxMs);
        sb.setProgress(0);
        sb.setKeyProgressIncrement(1);
        sb.setProgressDrawable(context.getResources().getDrawable(R.drawable.seekbar_progress));
        sb.setThumb(context.getResources().getDrawable(R.drawable.seekbar_thumb));
        sb.setSplitTrack(false);
        sb.setPadding(dp(14), dp(4), dp(14), dp(4));
        return sb;
    }

    private TextView neonValueLabel(String text, int color) {
        TextView tv = new TextView(context);
        tv.setText(text);
        tv.setTextSize(14);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(color);
        tv.setShadowLayer(7, 0, 0, color);
        return tv;
    }

    private View spacer(int dpVal) {
        View v = new View(context);
        v.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(dpVal)));
        return v;
    }

    private int dp(int v) {
        return Math.round(v * context.getResources().getDisplayMetrics().density);
    }

    private abstract static class SBL implements SeekBar.OnSeekBarChangeListener {
        public void onStartTrackingTouch(SeekBar s) {}
        public void onStopTrackingTouch(SeekBar s)  {}
    }
}
